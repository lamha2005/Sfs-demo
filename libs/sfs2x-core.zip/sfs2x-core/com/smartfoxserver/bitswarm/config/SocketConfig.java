// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.config;

import com.smartfoxserver.bitswarm.data.TransportType;

public class SocketConfig
{
    protected String address;
    protected int port;
    protected TransportType type;
    
    public SocketConfig(final String address, final int port, final TransportType type) {
        this.address = address;
        this.port = port;
        this.type = type;
    }
    
    public String getAddress() {
        return this.address;
    }
    
    public int getPort() {
        return this.port;
    }
    
    public TransportType getType() {
        return this.type;
    }
    
    @Override
    public String toString() {
        return "{ " + this.address + ":" + this.port + ", " + this.type.toString() + " }";
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.config;

import java.util.ArrayList;
import com.smartfoxserver.bitswarm.io.IPacketFinalizer;
import com.smartfoxserver.bitswarm.websocket.WebSocketConfig;
import java.util.List;
import com.smartfoxserver.bitswarm.data.BufferType;

public final class EngineConfiguration
{
    private String localNodeName;
    private int defaultMaxSessionIdleTime;
    private int defaultMaxLoggedInSessionIdleTime;
    private int connectionCleanerInterval;
    private int acceptorThreadPoolSize;
    private int readerThreadPoolSize;
    private int writerThreadPoolSize;
    private int sessionPacketQueueMaxSize;
    private boolean clustered;
    private boolean nagleAlgorithm;
    private String sessionManagerClass;
    private String ioHandlerClass;
    private String packetQueuePolicyClass;
    private BufferType readBufferType;
    private BufferType writeBufferType;
    private int readMaxBufferSize;
    private int writeMaxBufferSize;
    private int maxIncomingRequestSize;
    private List<SocketConfig> bindableAddresses;
    private List<ControllerConfig> controllerConfigs;
    private String clusterUniqueIdGeneratorClass;
    private boolean flashCrossdomainPolicyEnabled;
    private String flashCrossdomainPolicyXml;
    private int globalReconnectionSeconds;
    private int maxConnectionsFromSameIp;
    private boolean packetDebug;
    private boolean lagDebug;
    private WebSocketConfig webSocketEngineConfig;
    private IPacketFinalizer packetFinalizerImpl;
    
    public EngineConfiguration() {
        this.localNodeName = "local";
        this.defaultMaxSessionIdleTime = 60;
        this.defaultMaxLoggedInSessionIdleTime = 120;
        this.connectionCleanerInterval = 60;
        this.acceptorThreadPoolSize = 1;
        this.readerThreadPoolSize = 1;
        this.writerThreadPoolSize = 1;
        this.sessionPacketQueueMaxSize = 200;
        this.clustered = false;
        this.nagleAlgorithm = true;
        this.sessionManagerClass = "com.smartfoxserver.bitswarm.sessions.DefaultSessionManager";
        this.ioHandlerClass = "com.smartfoxserver.bitswarm.io.protocols.text.TextIOHandler";
        this.packetQueuePolicyClass = "com.smartfoxserver.bitswarm.sessions.DefaultPacketQueuePolicy";
        this.readBufferType = EngineConstants.DEFAULT_READ_BUFFER_TYPE;
        this.writeBufferType = EngineConstants.DEFAULT_WRITE_BUFFER_TYPE;
        this.readMaxBufferSize = 8192;
        this.writeMaxBufferSize = 32768;
        this.maxIncomingRequestSize = 4096;
        this.globalReconnectionSeconds = 0;
        this.maxConnectionsFromSameIp = 3;
        this.packetDebug = false;
        this.lagDebug = false;
        this.webSocketEngineConfig = new WebSocketConfig();
        this.bindableAddresses = new ArrayList<SocketConfig>();
        this.controllerConfigs = new ArrayList<ControllerConfig>();
    }
    
    public void addController(final ControllerConfig cfg) {
        this.controllerConfigs.add(cfg);
    }
    
    public List<ControllerConfig> getControllerConfigs() {
        return this.controllerConfigs;
    }
    
    public void addBindableAddress(final SocketConfig socket) {
        this.bindableAddresses.add(socket);
    }
    
    public List<SocketConfig> getBindableSockets() {
        return this.bindableAddresses;
    }
    
    public String getSessionManagerClass() {
        return this.sessionManagerClass;
    }
    
    public void setSessionManagerClass(final String sessionManagerClass) {
        this.sessionManagerClass = sessionManagerClass;
    }
    
    public boolean isNagleAlgorithm() {
        return this.nagleAlgorithm;
    }
    
    public void setNagleAlgorithm(final boolean nagleAlgorithm) {
        this.nagleAlgorithm = nagleAlgorithm;
    }
    
    public String getLocalNodeName() {
        return this.localNodeName;
    }
    
    public void setLocalNodeName(final String localNodeName) {
        this.localNodeName = localNodeName;
    }
    
    public boolean isClustered() {
        return this.clustered;
    }
    
    public int getDefaultMaxSessionIdleTime() {
        return this.defaultMaxSessionIdleTime;
    }
    
    public void setDefaultMaxSessionIdleTime(final int defaultMaxSessionIdleTime) {
        this.defaultMaxSessionIdleTime = defaultMaxSessionIdleTime;
    }
    
    public int getDefaultMaxLoggedInSessionIdleTime() {
        return this.defaultMaxLoggedInSessionIdleTime;
    }
    
    public void setDefaultMaxLoggedInSessionIdleTime(final int defaultMaxLoggedInSessionIdleTime) throws IllegalArgumentException {
        if (defaultMaxLoggedInSessionIdleTime < this.defaultMaxSessionIdleTime) {
            final String errorMsg = String.format("userMaxIdleTime (%s) cannot be smaller than sessionMaxIdleTime (%s)", defaultMaxLoggedInSessionIdleTime, this.defaultMaxSessionIdleTime);
            throw new IllegalArgumentException(errorMsg);
        }
        this.defaultMaxLoggedInSessionIdleTime = defaultMaxLoggedInSessionIdleTime;
    }
    
    public int getConnectionCleanerInterval() {
        return this.connectionCleanerInterval;
    }
    
    public void setConnectionCleanerInterval(final int connectionCleanerInterval) {
        this.connectionCleanerInterval = connectionCleanerInterval;
    }
    
    public int getAcceptorThreadPoolSize() {
        return this.acceptorThreadPoolSize;
    }
    
    public void setAcceptorThreadPoolSize(final int acceptorThreadPoolSize) {
        this.acceptorThreadPoolSize = acceptorThreadPoolSize;
    }
    
    public int getReaderThreadPoolSize() {
        return this.readerThreadPoolSize;
    }
    
    public void setReaderThreadPoolSize(final int readerThreadPoolSize) {
        this.readerThreadPoolSize = readerThreadPoolSize;
    }
    
    public int getWriterThreadPoolSize() {
        return this.writerThreadPoolSize;
    }
    
    public void setWriterThreadPoolSize(final int writerThreadPoolSize) {
        this.writerThreadPoolSize = writerThreadPoolSize;
    }
    
    public String getIoHandlerClass() {
        return this.ioHandlerClass;
    }
    
    public void setIoHandlerClass(final String ioHandlerClass) {
        this.ioHandlerClass = ioHandlerClass;
    }
    
    public BufferType getReadBufferType() {
        return this.readBufferType;
    }
    
    public void setReadBufferType(final BufferType readBufferType) {
        this.readBufferType = readBufferType;
    }
    
    public BufferType getWriteBufferType() {
        return this.writeBufferType;
    }
    
    public void setWriteBufferType(final BufferType writeBufferType) {
        this.writeBufferType = writeBufferType;
    }
    
    public int getReadMaxBufferSize() {
        return this.readMaxBufferSize;
    }
    
    public void setReadMaxBufferSize(final int readMaxBufferSize) {
        this.readMaxBufferSize = readMaxBufferSize;
    }
    
    public void setClustered(final boolean clustered) {
        this.clustered = clustered;
    }
    
    public List<SocketConfig> getBindableAddresses() {
        return this.bindableAddresses;
    }
    
    public void setBindableAddresses(final List<SocketConfig> bindableAddresses) {
        this.bindableAddresses = bindableAddresses;
    }
    
    public int getSessionPacketQueueMaxSize() {
        return this.sessionPacketQueueMaxSize;
    }
    
    public void setSessionPacketQueueMaxSize(final int sessionPacketQueueMaxSize) {
        this.sessionPacketQueueMaxSize = sessionPacketQueueMaxSize;
    }
    
    public String getPacketQueuePolicyClass() {
        return this.packetQueuePolicyClass;
    }
    
    public void setPacketQueuePolicyClass(final String packetQueuePolicyClass) {
        this.packetQueuePolicyClass = packetQueuePolicyClass;
    }
    
    public int getWriteMaxBufferSize() {
        return this.writeMaxBufferSize;
    }
    
    public void setWriteMaxBufferSize(final int writeMaxBufferSize) {
        this.writeMaxBufferSize = writeMaxBufferSize;
    }
    
    public String getClusterUniqueIdGeneratorClass() {
        return this.clusterUniqueIdGeneratorClass;
    }
    
    public void setClusterUniqueIdGeneratorClass(final String clusterUniqueIdGeneratorClass) {
        this.clusterUniqueIdGeneratorClass = clusterUniqueIdGeneratorClass;
    }
    
    public int getMaxIncomingRequestSize() {
        return this.maxIncomingRequestSize;
    }
    
    public void setMaxIncomingRequestSize(final int maxIncomingRequestSize) {
        this.maxIncomingRequestSize = maxIncomingRequestSize;
    }
    
    public boolean isFlashCrossdomainPolicyEnabled() {
        return this.flashCrossdomainPolicyEnabled;
    }
    
    public void setFlashCrossdomainPolicyEnabled(final boolean flashCrossdomainPolicyEnabled) {
        this.flashCrossdomainPolicyEnabled = flashCrossdomainPolicyEnabled;
    }
    
    public String getFlashCrossdomainPolicyXml() {
        return this.flashCrossdomainPolicyXml;
    }
    
    public void setFlashCrossdomainPolicyXml(final String flashCrossdomainPolicyXml) {
        this.flashCrossdomainPolicyXml = flashCrossdomainPolicyXml;
    }
    
    public int getGlobalReconnectionSeconds() {
        return this.globalReconnectionSeconds;
    }
    
    public void setGlobalReconnectionSeconds(final int globalReconnectionSeconds) {
        this.globalReconnectionSeconds = globalReconnectionSeconds;
    }
    
    public int getMaxConnectionsFromSameIp() {
        return this.maxConnectionsFromSameIp;
    }
    
    public void setMaxConnectionsFromSameIp(final int maxConnectionsFromSameIp) {
        this.maxConnectionsFromSameIp = maxConnectionsFromSameIp;
    }
    
    public void setPacketDebug(final boolean packetDebug) {
        this.packetDebug = packetDebug;
    }
    
    public boolean isPacketDebug() {
        return this.packetDebug;
    }
    
    public void setLagDebug(final boolean lagDebug) {
        this.lagDebug = lagDebug;
    }
    
    public boolean isLagDebug() {
        return this.lagDebug;
    }
    
    public WebSocketConfig getWebSocketEngineConfig() {
        return this.webSocketEngineConfig;
    }
    
    public void setWebSocketEngineConfig(final WebSocketConfig webSocketEngineConfig) {
        this.webSocketEngineConfig = webSocketEngineConfig;
    }
    
    public IPacketFinalizer getPacketFinalizerImpl() {
        return this.packetFinalizerImpl;
    }
    
    public void setPacketFinalizerImpl(final IPacketFinalizer packetFinalizerImpl) {
        this.packetFinalizerImpl = packetFinalizerImpl;
    }
}

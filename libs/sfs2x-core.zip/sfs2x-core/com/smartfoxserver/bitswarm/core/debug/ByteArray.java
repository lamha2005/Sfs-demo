// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.debug;

public class ByteArray
{
    private byte[] rawData;
    private final int expectedLen;
    private int fragments;
    
    public ByteArray(final byte[] startData) {
        this(startData, -1);
    }
    
    public ByteArray(final byte[] startData, final int expectedLen) {
        this.expectedLen = expectedLen;
        this.rawData = startData;
        this.fragments = 1;
    }
    
    public byte[] getRawData() {
        return this.rawData;
    }
    
    public void addBytes(final byte[] data) {
        if (data.length > 0) {
            final int newSize = this.rawData.length + data.length;
            ++this.fragments;
            if (this.expectedLen > 0 && newSize > this.expectedLen) {
                throw new IllegalStateException(String.format("ByteArray exceeds expected size. Fragments: %s, Expected: %s, Current: %s, With last addition: %s", this.fragments, this.expectedLen, this.rawData.length, newSize));
            }
            final byte[] buffer = new byte[newSize];
            System.arraycopy(this.rawData, 0, buffer, 0, this.rawData.length);
            System.arraycopy(data, 0, buffer, this.rawData.length, data.length);
        }
    }
    
    public int size() {
        return this.rawData.length;
    }
    
    public boolean isComplete() {
        return this.rawData.length == this.expectedLen;
    }
    
    public int getFragments() {
        return this.fragments;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.debug;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.BlockingQueue;
import com.smartfoxserver.v2.entities.data.SFSObject;
import java.util.Arrays;
import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.exceptions.PacketException;
import com.smartfoxserver.bitswarm.events.Event;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.events.IEventListener;
import org.slf4j.Logger;
import com.smartfoxserver.v2.protocol.binary.DefaultPacketCompressor;
import com.smartfoxserver.bitswarm.data.IPacket;
import java.util.concurrent.ConcurrentMap;

public class DefaultPacketDebugger implements IPacketDebugger
{
    private final ConcurrentMap<IPacket, ByteArray> pendingPackets;
    private final ConcurrentMap<IPacket, byte[]> originalPackets;
    private final Dispatcher dispatcher;
    private final DefaultPacketCompressor packetCompressor;
    private final Logger log;
    
    public DefaultPacketDebugger(final IEventListener callbackHandler) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.pendingPackets = new ConcurrentHashMap<IPacket, ByteArray>();
        this.originalPackets = new ConcurrentHashMap<IPacket, byte[]>();
        this.dispatcher = new Dispatcher(callbackHandler);
        this.packetCompressor = new DefaultPacketCompressor();
    }
    
    @Override
    public void handleWrittenBytes(final IPacket id, final byte[] data) {
        ByteArray buf = this.pendingPackets.get(id);
        final byte[] originalBuf = this.originalPackets.get(id);
        if (buf == null) {
            final byte[] startData = new byte[data.length];
            System.arraycopy(data, 0, startData, 0, startData.length);
            buf = new ByteArray(startData, originalBuf.length);
            this.pendingPackets.put(id, buf);
        }
        else {
            buf.addBytes(data);
        }
        if (buf.isComplete()) {
            this.pendingPackets.remove(id);
            try {
                this.performPacketVerification(id, buf);
                if (this.log.isDebugEnabled()) {
                    this.log.debug("Packet Verification Ok: " + id);
                }
            }
            catch (PacketException e) {
                final IEvent evt = new Event("debugPacketWriteFail");
                evt.setParameter("debugMessage", e.getMessage());
                evt.setParameter("debugOriginalPacket", (e.getOriginalPacket() != null) ? e.getOriginalPacket() : new byte[0]);
                evt.setParameter("debugWrittenPacket", e.getWrittenPacket());
                this.dispatcher.fireEvent(evt);
            }
        }
    }
    
    @Override
    public void setNextExpectedPacket(final IPacket id, final byte[] expectedPacket) {
        this.originalPackets.putIfAbsent(id, expectedPacket);
    }
    
    private void performPacketVerification(final IPacket id, final ByteArray ba) throws PacketException {
        final byte[] writtenData = ba.getRawData();
        final ByteBuffer buf = ByteBuffer.wrap(writtenData);
        final byte[] expectedBytes = this.originalPackets.remove(id);
        if (expectedBytes != null && !Arrays.equals(writtenData, expectedBytes)) {
            throw new PacketException("Expected data doesn't match written data", expectedBytes, writtenData);
        }
        final byte headerByte = buf.get();
        final PacketHeader header = PacketHeader.fromHeaderByte(headerByte);
        if (!header.isBinary()) {
            throw new PacketException("Expected Binary Packet: " + header);
        }
        int size = -1;
        byte[] chunk;
        if (header.isBigSized()) {
            chunk = new byte[4];
        }
        else {
            chunk = new byte[2];
        }
        buf.get(chunk);
        size = this.getDataSize(chunk);
        if (size == -1) {
            throw new PacketException("Unexpected error decoding packet data size: " + header);
        }
        if (buf.remaining() != size) {
            throw new PacketException("Packet size doesn't match remaining bytes. Packet says: " + size + "bytes, buffer has: " + buf.remaining() + "bytes");
        }
        byte[] packetData = new byte[size];
        buf.get(packetData, 0, size);
        if (header.isCompressed()) {
            try {
                packetData = this.packetCompressor.uncompress(packetData);
            }
            catch (Exception e) {
                throw new PacketException("Packet decompress problem: " + e);
            }
        }
        try {
            SFSObject.newFromBinaryData(packetData);
        }
        catch (Exception e) {
            throw new PacketException("SFS Decoding error: " + e);
        }
    }
    
    private int getDataSize(final byte[] data) {
        int dataSize = -1;
        if (data.length == 4) {
            dataSize = 0;
            for (int i = 0; i < 4; ++i) {
                final int pow256 = (int)Math.pow(256.0, 3 - i);
                final int intByte = data[i] & 0xFF;
                dataSize += pow256 * intByte;
            }
        }
        else if (data.length >= 2) {
            final int msb = data[0] & 0xFF;
            final int lsb = data[1] & 0xFF;
            dataSize = msb * 256 + lsb;
        }
        return dataSize;
    }
    
    private static class Dispatcher implements Runnable
    {
        final Thread eventDispatcher;
        final BlockingQueue<IEvent> eventQueue;
        final IEventListener callbackHandler;
        
        public Dispatcher(final IEventListener callbackHandler) {
            this.eventDispatcher = new Thread(this, "PacketDebuggerDisptacher");
            this.eventQueue = new LinkedBlockingQueue<IEvent>();
            this.callbackHandler = callbackHandler;
            this.eventDispatcher.start();
        }
        
        @Override
        public void run() {
            try {
                while (true) {
                    final IEvent evt = this.eventQueue.take();
                    this.callbackHandler.handleEvent(evt);
                }
            }
            catch (InterruptedException ex) {}
        }
        
        public void fireEvent(final IEvent evt) {
            this.eventQueue.offer(evt);
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.debug;

import com.smartfoxserver.bitswarm.data.IPacket;

public interface IPacketDebugger
{
    void handleWrittenBytes(final IPacket p0, final byte[] p1);
    
    void setNextExpectedPacket(final IPacket p0, final byte[] p1);
}

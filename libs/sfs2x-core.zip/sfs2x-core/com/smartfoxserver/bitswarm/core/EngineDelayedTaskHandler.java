// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.bitswarm.util.scheduling.Task;
import com.smartfoxserver.bitswarm.util.scheduling.ITaskHandler;

public final class EngineDelayedTaskHandler extends AbstractMethodDispatcher implements ITaskHandler
{
    public EngineDelayedTaskHandler() {
        this.registerTasks();
    }
    
    private void registerTasks() {
        this.registerMethod("delayedSocketWrite", "onDelayedSocketWrite");
        this.registerMethod("RESTART", "onRestart");
    }
    
    @Override
    public void doTask(final Task task) throws Exception {
        try {
            this.callMethod((String)task.getId(), new Object[] { task });
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void onRestart(final Object o) {
        BitSwarmEngine.getInstance().restart();
    }
    
    public void onDelayedSocketWrite(final Object o) {
        final Task task = (Task)o;
        final IResponse response = task.getParameters().get("response");
        if (response != null) {
            response.write();
        }
    }
}

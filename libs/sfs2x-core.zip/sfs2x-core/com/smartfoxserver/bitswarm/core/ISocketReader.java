// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.io.IOHandler;
import java.nio.channels.Selector;

public interface ISocketReader
{
    Selector getSelector();
    
    IOHandler getIOHandler();
    
    void setIoHandler(final IOHandler p0);
    
    long getReadBytes();
    
    long getReadPackets();
}

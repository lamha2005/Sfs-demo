// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.events.Event;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.events.IEventListener;

public class EngineEventHandler extends AbstractMethodDispatcher implements IEventListener
{
    BitSwarmEngine engine;
    
    public EngineEventHandler() {
        this.engine = BitSwarmEngine.getInstance();
        this.registerMethods();
    }
    
    private void registerMethods() {
        this.registerMethod("sessionAdded", "onSessionAdded");
        this.registerMethod("sessionLost", "onSessionLost");
        this.registerMethod("packetDropped", "onPacketDropped");
    }
    
    @Override
    public void handleEvent(final IEvent event) {
        try {
            this.callMethod(event.getName(), new Object[] { event });
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void onSessionLost(final Object o) {
        this.engine.dispatchEvent((IEvent)o);
    }
    
    public void onSessionAdded(final Object o) {
        this.engine.dispatchEvent((IEvent)o);
    }
    
    public void onPacketDropped(final Object o) {
        this.engine.dispatchEvent((IEvent)o);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.util.ByteUtils;
import com.smartfoxserver.bitswarm.events.IEventListener;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.events.Event;
import com.smartfoxserver.bitswarm.exceptions.MessageQueueFullException;
import com.smartfoxserver.bitswarm.exceptions.PacketQueueWarning;
import java.util.Iterator;
import java.util.Collection;
import java.nio.channels.DatagramChannel;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.nio.channels.SocketChannel;
import java.nio.channels.SelectionKey;
import java.io.IOException;
import java.nio.channels.ClosedChannelException;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.sessions.IPacketQueue;
import com.smartfoxserver.bitswarm.sessions.bluebox.IBBClient;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.util.Logging;
import com.smartfoxserver.bitswarm.util.NetworkServices;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.LoggerFactory;
import java.util.concurrent.Executors;
import com.smartfoxserver.bitswarm.io.IPacketFinalizer;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.io.IOHandler;
import com.smartfoxserver.bitswarm.service.BaseCoreService;

public final class SocketWriter extends BaseCoreService implements ISocketWriter, Runnable
{
    private BitSwarmEngine engine;
    private IOHandler ioHandler;
    private final Logger logger;
    private final Logger bootLogger;
    private final ExecutorService threadPool;
    private final BlockingQueue<ISession> sessionTicketsQueue;
    private volatile int threadId;
    private volatile boolean isActive;
    private volatile long droppedPacketsCount;
    private volatile long writtenBytes;
    private volatile long writtenPackets;
    private volatile long droppedUdpPacketsCount;
    private ISessionManager sessionManager;
    private int threadPoolSize;
    private IPacketFinalizer packetFinalizer;
    
    public SocketWriter(final int threadPoolSize) {
        this.threadId = 1;
        this.isActive = false;
        this.droppedPacketsCount = 0L;
        this.writtenBytes = 0L;
        this.writtenPackets = 0L;
        this.droppedUdpPacketsCount = 0L;
        this.threadPoolSize = threadPoolSize;
        this.threadPool = Executors.newFixedThreadPool(threadPoolSize);
        this.logger = LoggerFactory.getLogger((Class)SocketWriter.class);
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        this.sessionTicketsQueue = new LinkedBlockingQueue<ISession>();
    }
    
    @Override
    public void init(final Object o) {
        super.init(o);
        if (this.isActive) {
            throw new IllegalArgumentException("Object is already initialized. Destroy it first!");
        }
        if (this.threadPoolSize < 1) {
            throw new IllegalArgumentException("Illegal value for a thread pool size: " + this.threadPoolSize);
        }
        this.engine = BitSwarmEngine.getInstance();
        this.sessionManager = this.engine.getSessionManager();
        this.isActive = true;
        this.initThreadPool();
        this.bootLogger.info("Socket Writer started (pool size:" + this.threadPoolSize + ")");
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        this.isActive = false;
        final List<Runnable> leftOvers = this.threadPool.shutdownNow();
        this.bootLogger.info("SocketWriter stopped. Unprocessed tasks: " + leftOvers.size());
    }
    
    @Override
    public int getQueueSize() {
        return this.sessionTicketsQueue.size();
    }
    
    @Override
    public int getThreadPoolSize() {
        return this.threadPoolSize;
    }
    
    @Override
    public IOHandler getIOHandler() {
        return this.ioHandler;
    }
    
    @Override
    public void setIOHandler(final IOHandler ioHandler) {
        if (this.ioHandler != null) {
            throw new IllegalStateException("You cannot reassign the IOHandler class!");
        }
        this.ioHandler = ioHandler;
    }
    
    @Override
    public IPacketFinalizer getPacketFinalizer() {
        return this.packetFinalizer;
    }
    
    @Override
    public void setPacketFinalizer(final IPacketFinalizer value) {
        if (this.packetFinalizer != null) {
            throw new IllegalStateException("PacketFinalizer already set!");
        }
        this.packetFinalizer = value;
    }
    
    @Override
    public void continueWriteOp(final ISession session) {
        if (session != null) {
            this.sessionTicketsQueue.add(session);
        }
    }
    
    private void initThreadPool() {
        for (int j = 0; j < this.threadPoolSize; ++j) {
            this.threadPool.execute(this);
        }
    }
    
    @Override
    public void run() {
        Thread.currentThread().setName("SocketWriter-" + this.threadId++);
        final ByteBuffer writeBuffer = NetworkServices.allocateBuffer(32768, this.engine.getConfiguration().getWriteBufferType());
        while (this.isActive) {
            try {
                final ISession session = this.sessionTicketsQueue.take();
                this.processSessionQueue(writeBuffer, session);
            }
            catch (InterruptedException e) {
                this.logger.warn("SocketWriter thread interrupted: " + Thread.currentThread());
                this.isActive = false;
            }
            catch (Throwable t) {
                this.logger.warn("Problems in SocketWriter main loop, Thread: " + Thread.currentThread());
                Logging.logStackTrace(this.logger, t);
            }
        }
        this.bootLogger.info("SocketWriter threadpool shutting down.");
    }
    
    private void processSessionQueue(final ByteBuffer writeBuffer, final ISession session) {
        if (session != null) {
            final SessionType type = session.getType();
            if (type == SessionType.DEFAULT) {
                this.processRegularSession(writeBuffer, session);
            }
            else if (type == SessionType.BLUEBOX) {
                this.processBlueBoxSession(session);
            }
            else if (type == SessionType.VOID) {
                return;
            }
        }
    }
    
    private void processBlueBoxSession(final ISession session) {
        final IPacketQueue sessionQ = session.getPacketQueue();
        IPacket packet = null;
        synchronized (sessionQ) {
            if (!sessionQ.isEmpty()) {
                packet = sessionQ.take();
            }
        }
        // monitorexit(sessionQ)
        if (packet != null) {
            final IBBClient bbClient = (IBBClient)session.getSystemProperty("bbClient");
            bbClient.enqueueMessage((byte[])packet.getData());
        }
    }
    
    private void processRegularSession(final ByteBuffer writeBuffer, final ISession session) {
        if (session.isFrozen()) {
            return;
        }
        IPacket packet = null;
        try {
            final IPacketQueue sessionQ = session.getPacketQueue();
            synchronized (sessionQ) {
                if (!sessionQ.isEmpty()) {
                    packet = sessionQ.peek();
                    if (packet == null) {
                        // monitorexit(sessionQ)
                        return;
                    }
                    if (packet.isTcp()) {
                        this.tcpSend(writeBuffer, sessionQ, session, packet);
                    }
                    else if (packet.isUdp()) {
                        this.udpSend(writeBuffer, sessionQ, session, packet);
                    }
                    else {
                        this.logger.warn("Unknow packet type: " + packet);
                    }
                }
            }
            // monitorexit(sessionQ)
        }
        catch (ClosedChannelException cce) {
            this.logger.debug("Socket closed during write operation for session: " + session);
        }
        catch (IOException ex) {}
        catch (Exception e) {
            this.logger.warn("Error during write. Session: " + session);
            Logging.logStackTrace(this.logger, e);
        }
    }
    
    private void tcpSend(ByteBuffer writeBuffer, final IPacketQueue sessionQ, final ISession session, final IPacket packet) throws Exception {
        final SocketChannel channel = session.getConnection();
        if (channel == null) {
            this.logger.debug("Skipping packet, found null socket for Session: " + session);
            return;
        }
        writeBuffer.clear();
        final byte[] buffer = (byte[])(packet.isFragmented() ? packet.getFragmentBuffer() : packet.getData());
        if (writeBuffer.capacity() < buffer.length) {
            if (this.logger.isTraceEnabled()) {
                this.logger.trace("Allocating new buffer. Curr. capacity: " + writeBuffer.capacity() + ", Need: " + buffer.length);
            }
            writeBuffer = NetworkServices.allocateBuffer(buffer.length, this.engine.getConfiguration().getWriteBufferType());
        }
        writeBuffer.put(buffer);
        writeBuffer.flip();
        final long toWrite = writeBuffer.remaining();
        final long bytesWritten = channel.write(writeBuffer);
        this.writtenBytes += bytesWritten;
        session.addWrittenBytes(bytesWritten);
        if (bytesWritten < toWrite) {
            final byte[] bb = new byte[writeBuffer.remaining()];
            writeBuffer.get(bb);
            if (this.logger.isTraceEnabled()) {
                this.logger.trace("<<< Partial Socket Write >>>");
                this.logger.trace("Remaining: " + bb.length);
            }
            packet.setFragmentBuffer(bb);
            final SelectionKey sk = (SelectionKey)session.getSystemProperty("SessionSelectionKey");
            if (sk != null && sk.isValid()) {
                sk.interestOps(5);
            }
            else {
                this.logger.warn("Could not OP_WRITE for Session: " + session + ", written bytes: " + bytesWritten);
                System.out.println("SK: " + sk + ", Valid:" + sk.isValid());
            }
        }
        else {
            ++this.writtenPackets;
            sessionQ.take();
            if (!sessionQ.isEmpty()) {
                this.sessionTicketsQueue.add(session);
            }
        }
    }
    
    private void udpSend(ByteBuffer writeBuffer, final IPacketQueue sessionQ, final ISession session, final IPacket packet) throws Exception {
        sessionQ.take();
        if (!sessionQ.isEmpty()) {
            this.sessionTicketsQueue.add(session);
        }
        writeBuffer.clear();
        final byte[] buffer = (byte[])packet.getData();
        if (writeBuffer.capacity() < buffer.length) {
            this.logger.trace("Allocating new buffer. Curr. capacity: " + writeBuffer.capacity() + ", Need: " + buffer.length);
            writeBuffer = NetworkServices.allocateBuffer(buffer.length, this.engine.getConfiguration().getWriteBufferType());
        }
        writeBuffer.put(buffer);
        writeBuffer.flip();
        final DatagramChannel datagramChannel = session.getDatagramChannel();
        final Integer sessionUdpPort = (Integer)session.getSystemProperty("UDPPort");
        if (datagramChannel == null) {
            throw new IllegalStateException("UDP Packet cannot be sent to: " + session + ", no DatagramChannel was ever set!");
        }
        if (sessionUdpPort == null) {
            throw new IllegalStateException("UDP Packet cannot be sent to: " + session + ", no UDP port set.");
        }
        final int written = datagramChannel.send(writeBuffer, new InetSocketAddress(session.getAddress(), sessionUdpPort));
        if (written != 0) {
            this.writtenBytes += written;
            session.addWrittenBytes(written);
        }
        else {
            ++this.droppedUdpPacketsCount;
        }
    }
    
    @Override
    public void enqueuePacket(final IPacket packet) {
        final Collection<ISession> recipients = packet.getRecipients();
        final int size = recipients.size();
        if (recipients != null && size > 0) {
            if (packet.getSender() != null) {
                packet.getSender().setLastWriteTime(System.currentTimeMillis());
            }
            if (size == 1) {
                this.enqueueLocalPacket(packet.getRecipients().iterator().next(), packet);
            }
            else {
                for (final ISession session : recipients) {
                    this.enqueueLocalPacket(session, packet.clone());
                }
            }
        }
    }
    
    private void enqueueLocalPacket(final ISession session, final IPacket packet) {
        final IPacketQueue sessionQ = session.getPacketQueue();
        final boolean isBlueBoxed = session.getType() == SessionType.BLUEBOX;
        try {
            packet.setData(this.packetFinalizer.process(session, packet));
        }
        catch (Exception e) {
            this.logger.error("Problem during packet finalization: " + e.getMessage());
            e.printStackTrace();
            this.dropOneMessage(session);
            return;
        }
        if (sessionQ != null) {
            synchronized (sessionQ) {
                try {
                    final boolean wasEmpty = sessionQ.isEmpty();
                    sessionQ.put(packet);
                    if (wasEmpty || isBlueBoxed) {
                        this.sessionTicketsQueue.add(session);
                    }
                    packet.setRecipients(null);
                }
                catch (PacketQueueWarning err) {
                    this.dropOneMessage(session);
                    if (this.logger.isDebugEnabled()) {
                        this.logger.debug(String.valueOf(err.getMessage()) + ": " + session);
                    }
                }
                catch (MessageQueueFullException error) {
                    this.dropOneMessage(session);
                }
            }
            // monitorexit(sessionQ)
        }
    }
    
    private void dropOneMessage(final ISession session) {
        session.addDroppedMessages(1);
        ++this.droppedPacketsCount;
        final IEvent event = new Event("packetDropped");
        event.setParameter("session", session);
        this.dispatchEvent(event);
    }
    
    @Override
    public long getDroppedPacketsCount() {
        return this.droppedPacketsCount;
    }
    
    public long getDroppedUdpPacketCount() {
        return this.droppedUdpPacketsCount;
    }
    
    @Override
    public long getWrittenBytes() {
        return this.writtenBytes;
    }
    
    @Override
    public long getWrittenPackets() {
        return this.writtenPackets;
    }
    
    private class PacketDebugListener implements IEventListener
    {
        @Override
        public void handleEvent(final IEvent event) {
            SocketWriter.this.logger.warn(String.format("PacketError: %s \n ORIGINAL: %s\nWRITTEN:%s", event.getParameter("debugMessage"), ByteUtils.fullHexDump((byte[])event.getParameter("debugOriginalPacket")), ByteUtils.fullHexDump((byte[])event.getParameter("debugWrittenPacket"))));
        }
    }
}

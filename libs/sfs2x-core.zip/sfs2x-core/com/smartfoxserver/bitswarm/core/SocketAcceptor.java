// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectableChannel;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.util.Collection;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.config.SocketConfig;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.net.InetAddress;
import com.smartfoxserver.bitswarm.exceptions.RefusedAddressException;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.events.Event;
import java.util.Iterator;
import java.util.Set;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SelectionKey;
import java.io.IOException;
import com.smartfoxserver.bitswarm.util.Logging;
import com.smartfoxserver.bitswarm.core.security.AdvancedConnectionFilter;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import org.slf4j.LoggerFactory;
import java.nio.channels.Selector;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import com.smartfoxserver.bitswarm.core.security.IConnectionFilter;
import com.smartfoxserver.bitswarm.data.BindableSocket;
import java.nio.channels.SocketChannel;
import java.util.List;
import java.util.concurrent.ExecutorService;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.service.BaseCoreService;

public class SocketAcceptor extends BaseCoreService implements ISocketAcceptor, Runnable
{
    private final BitSwarmEngine engine;
    private final Logger logger;
    private final Logger bootLogger;
    private volatile int threadId;
    private int threadPoolSize;
    private final ExecutorService threadPool;
    private List<SocketChannel> acceptableConnections;
    private List<BindableSocket> boundSockets;
    private IConnectionFilter connectionFilter;
    private ISessionManager sessionManager;
    private ISocketReader socketReader;
    private IDatagramReader datagramReader;
    private Selector acceptSelector;
    private volatile boolean isActive;
    
    public SocketAcceptor() {
        this(1);
    }
    
    public SocketAcceptor(final int threadPoolSize) {
        this.threadId = 1;
        this.threadPoolSize = 1;
        this.isActive = false;
        this.threadPoolSize = threadPoolSize;
        this.engine = BitSwarmEngine.getInstance();
        this.logger = LoggerFactory.getLogger((Class)SocketAcceptor.class);
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        this.threadPool = Executors.newFixedThreadPool(threadPoolSize);
        this.acceptableConnections = new ArrayList<SocketChannel>();
        this.boundSockets = new ArrayList<BindableSocket>();
        this.socketReader = this.engine.getSocketReader();
        this.datagramReader = this.engine.getDatagramReader();
        this.connectionFilter = new AdvancedConnectionFilter();
        try {
            this.acceptSelector = Selector.open();
            this.bootLogger.info("AcceptSelector opened");
        }
        catch (IOException e) {
            this.bootLogger.warn("Problems during SocketAcceptor init: " + e);
            Logging.logStackTrace(this.bootLogger, e);
        }
    }
    
    @Override
    public void init(final Object o) {
        super.init(o);
        if (this.isActive) {
            throw new IllegalArgumentException("Object is already initialized. Destroy it first!");
        }
        if (this.threadPoolSize < 1) {
            throw new IllegalArgumentException("Illegal value for a thread pool size: " + this.threadPoolSize);
        }
        this.sessionManager = this.engine.getSessionManager();
        this.isActive = true;
        this.initThreadPool();
        this.bootLogger.info("SocketAcceptor initialized");
        this.checkBoundSockets();
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        this.isActive = false;
        this.shutDownBoundSockets();
        final List<Runnable> leftOvers = this.threadPool.shutdownNow();
        try {
            Thread.sleep(500L);
            this.acceptSelector.close();
        }
        catch (Exception e) {
            this.bootLogger.warn("Error when shutting down Accept selector: " + e.getMessage());
        }
        this.bootLogger.info("SocketAcceptor stopped. Unprocessed tasks: " + leftOvers.size());
    }
    
    private void initThreadPool() {
        for (int j = 0; j < this.threadPoolSize; ++j) {
            this.threadPool.execute(this);
        }
    }
    
    @Override
    public void run() {
        Thread.currentThread().setName("SocketAcceptor-" + this.threadId++);
        while (this.isActive) {
            try {
                this.acceptLoop();
            }
            catch (IOException e) {
                this.logger.info("I/O Error with Accept Selector: " + e.getMessage());
                Logging.logStackTrace(this.logger, e);
            }
        }
        this.bootLogger.info("SocketAcceptor threadpool shutting down.");
    }
    
    private void acceptLoop() throws IOException {
        this.acceptSelector.select();
        final Set<SelectionKey> readyKeys = this.acceptSelector.selectedKeys();
        SelectionKey key = null;
        final Iterator<SelectionKey> it = readyKeys.iterator();
        while (it.hasNext()) {
            try {
                key = it.next();
                it.remove();
                final ServerSocketChannel ssChannel = (ServerSocketChannel)key.channel();
                final SocketChannel clientChannel = ssChannel.accept();
                this.logger.trace("Accepted client connection on: " + ssChannel.socket().getInetAddress().getHostAddress() + ":" + ssChannel.socket().getLocalPort());
                synchronized (this.acceptableConnections) {
                    this.acceptableConnections.add(clientChannel);
                }
                // monitorexit(this.acceptableConnections)
            }
            catch (IOException error) {
                this.logger.info("I/O Error during accept loop: " + error.getMessage());
            }
        }
        if (this.isActive) {
            this.socketReader.getSelector().wakeup();
        }
    }
    
    @Override
    public void handleAcceptableConnections() {
        if (this.acceptableConnections.size() == 0) {
            return;
        }
        synchronized (this.acceptableConnections) {
            final Iterator<SocketChannel> it = this.acceptableConnections.iterator();
            while (it.hasNext()) {
                final SocketChannel connection = it.next();
                it.remove();
                try {
                    final InetAddress iAddr = connection.socket().getInetAddress();
                    if (iAddr == null) {
                        continue;
                    }
                    this.connectionFilter.validateAndAddAddress(iAddr.getHostAddress());
                    connection.configureBlocking(false);
                    connection.socket().setTcpNoDelay(!this.engine.getConfiguration().isNagleAlgorithm());
                    final SelectionKey selectionKey = connection.register(this.socketReader.getSelector(), 1);
                    final ISession session = this.sessionManager.createSession(connection);
                    session.setSystemProperty("SessionSelectionKey", selectionKey);
                    this.sessionManager.addSession(session);
                    final Event sessionAddedEvent = new Event("sessionAdded");
                    sessionAddedEvent.setParameter("session", session);
                    this.dispatchEvent(sessionAddedEvent);
                }
                catch (RefusedAddressException e) {
                    this.logger.info("Refused connection. " + e.getMessage());
                    try {
                        connection.socket().shutdownInput();
                        connection.socket().shutdownOutput();
                        connection.close();
                    }
                    catch (IOException e2) {
                        this.logger.warn("Additional problem with refused connection. Was not able to shut down the channel: " + e2.getMessage());
                    }
                }
                catch (IOException e3) {
                    final StringBuilder sb = new StringBuilder("Failed accepting connection: ");
                    if (connection != null && connection.socket() != null) {
                        sb.append(connection.socket().getInetAddress().getHostAddress());
                    }
                    this.logger.info(sb.toString());
                }
            }
        }
        // monitorexit(this.acceptableConnections)
    }
    
    @Override
    public void bindSocket(final SocketConfig socketConfig) throws IOException {
        if (socketConfig.getType() == TransportType.TCP) {
            this.bindTcpSocket(socketConfig.getAddress(), socketConfig.getPort());
        }
        else {
            if (socketConfig.getType() != TransportType.UDP) {
                throw new UnsupportedOperationException("Invalid transport type!");
            }
            this.bindUdpSocket(socketConfig.getAddress(), socketConfig.getPort());
        }
    }
    
    @Override
    public List<BindableSocket> getBoundSockets() {
        ArrayList<BindableSocket> list = null;
        synchronized (this.boundSockets) {
            list = new ArrayList<BindableSocket>(this.boundSockets);
        }
        // monitorexit(this.boundSockets)
        return list;
    }
    
    @Override
    public IConnectionFilter getConnectionFilter() {
        return this.connectionFilter;
    }
    
    @Override
    public void setConnectionFilter(final IConnectionFilter filter) {
        if (this.connectionFilter != null) {
            throw new IllegalStateException("A connection filter already exists!");
        }
        this.connectionFilter = filter;
    }
    
    private void bindTcpSocket(final String address, final int port) throws IOException {
        final ServerSocketChannel socketChannel = ServerSocketChannel.open();
        socketChannel.configureBlocking(false);
        socketChannel.socket().bind(new InetSocketAddress(address, port));
        socketChannel.socket().setReuseAddress(true);
        socketChannel.register(this.acceptSelector, 16);
        synchronized (this.boundSockets) {
            this.boundSockets.add(new BindableSocket(socketChannel, address, port, TransportType.TCP));
        }
        // monitorexit(this.boundSockets)
        this.bootLogger.info("Added bound tcp socket --> " + address + ":" + port);
    }
    
    private void bindUdpSocket(final String address, final int port) throws IOException {
        final DatagramChannel datagramChannel = DatagramChannel.open();
        datagramChannel.configureBlocking(false);
        datagramChannel.socket().bind(new InetSocketAddress(address, port));
        datagramChannel.socket().setReuseAddress(true);
        datagramChannel.register(this.datagramReader.getSelector(), 1);
        synchronized (this.boundSockets) {
            this.boundSockets.add(new BindableSocket(datagramChannel, address, port, TransportType.UDP));
        }
        // monitorexit(this.boundSockets)
        this.bootLogger.info("Added bound udp socket --> " + address + ":" + port);
    }
    
    private void bindBlueBox() throws IOException {
        throw new UnsupportedOperationException("Not supported yet!");
    }
    
    private void checkBoundSockets() {
        if (this.boundSockets.size() < 1) {
            this.bootLogger.error("No bound sockets! Check the boot logs for possible problems!");
        }
    }
    
    private void shutDownBoundSockets() {
        List<BindableSocket> problematicSockets = null;
        for (final BindableSocket bindableSocket : this.boundSockets) {
            try {
                bindableSocket.getChannel().close();
            }
            catch (IOException e) {
                if (problematicSockets == null) {
                    problematicSockets = new ArrayList<BindableSocket>();
                }
                problematicSockets.add(bindableSocket);
            }
        }
        if (problematicSockets != null) {
            final StringBuilder sb = new StringBuilder("Problems closing bound socket(s). The following socket(s) raised exceptions: ");
            for (final BindableSocket socket : problematicSockets) {
                sb.append(socket.toString()).append(" ");
            }
            throw new RuntimeException(sb.toString());
        }
    }
}

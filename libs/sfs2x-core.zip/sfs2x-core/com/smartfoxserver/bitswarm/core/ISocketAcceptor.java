// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.core.security.IConnectionFilter;
import com.smartfoxserver.bitswarm.data.BindableSocket;
import java.util.List;
import java.io.IOException;
import com.smartfoxserver.bitswarm.config.SocketConfig;

public interface ISocketAcceptor
{
    void bindSocket(final SocketConfig p0) throws IOException;
    
    List<BindableSocket> getBoundSockets();
    
    void handleAcceptableConnections();
    
    IConnectionFilter getConnectionFilter();
    
    void setConnectionFilter(final IConnectionFilter p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.Iterator;
import java.util.Set;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedSelectorException;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.SelectionKey;
import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.util.NetworkServices;
import java.util.List;
import com.smartfoxserver.bitswarm.util.Logging;
import java.io.IOException;
import org.slf4j.LoggerFactory;
import java.util.concurrent.Executors;
import com.smartfoxserver.bitswarm.io.IOHandler;
import java.nio.channels.Selector;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import java.util.concurrent.ExecutorService;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.service.BaseCoreService;

public class SocketReader extends BaseCoreService implements ISocketReader, Runnable
{
    private final BitSwarmEngine engine;
    private final Logger logger;
    private final Logger bootLogger;
    private int threadPoolSize;
    private final ExecutorService threadPool;
    private ISessionManager sessionManager;
    private ISocketAcceptor socketAcceptor;
    private ISocketWriter socketWriter;
    private Selector readSelector;
    private IOHandler ioHandler;
    private volatile boolean isActive;
    private volatile long readBytes;
    private volatile int threadId;
    
    public SocketReader() {
        this(1);
    }
    
    public SocketReader(final int nThreads) {
        this.threadPoolSize = 1;
        this.isActive = false;
        this.readBytes = 0L;
        this.threadId = 1;
        this.threadPoolSize = nThreads;
        this.threadPool = Executors.newSingleThreadExecutor();
        this.engine = BitSwarmEngine.getInstance();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        try {
            this.readSelector = Selector.open();
            this.bootLogger.info("TCP Selector opened");
        }
        catch (IOException e) {
            this.bootLogger.error("Failed opening UDP Selector: " + e.toString());
            e.printStackTrace();
        }
    }
    
    @Override
    public void init(final Object o) {
        super.init(o);
        if (this.isActive) {
            throw new IllegalArgumentException("Object is already initialized. Destroy it first!");
        }
        this.sessionManager = this.engine.getSessionManager();
        this.socketAcceptor = this.engine.getSocketAcceptor();
        this.socketWriter = this.engine.getSocketWriter();
        this.isActive = true;
        this.initThreadPool();
        this.bootLogger.info("IOHandler: " + this.ioHandler);
        this.bootLogger.info("SocketReader started");
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        this.isActive = false;
        final List<Runnable> leftOvers = this.threadPool.shutdownNow();
        try {
            Thread.sleep(500L);
            this.readSelector.close();
        }
        catch (Exception e) {
            this.bootLogger.warn("Error when shutting down TCP Selector: " + e.getMessage());
            Logging.logStackTrace(this.bootLogger, e);
        }
        this.bootLogger.info("SocketReader stopped. Unprocessed tasks: " + leftOvers.size());
    }
    
    public void initThreadPool() {
        for (int j = 0; j < this.threadPoolSize; ++j) {
            this.threadPool.execute(this);
        }
    }
    
    @Override
    public void run() {
        final ByteBuffer readBuffer = NetworkServices.allocateBuffer(this.engine.getConfiguration().getReadMaxBufferSize(), this.engine.getConfiguration().getReadBufferType());
        Thread.currentThread().setName("SocketReader");
        while (this.isActive) {
            try {
                this.socketAcceptor.handleAcceptableConnections();
                this.readIncomingSocketData(readBuffer);
                Thread.sleep(5L);
            }
            catch (Throwable t) {
                this.logger.warn("Problems in SocketReader main loop: " + t + ", Thread: " + Thread.currentThread());
                Logging.logStackTrace(this.logger, t);
            }
        }
        this.bootLogger.info("SocketReader threadpool shutting down.");
    }
    
    private void readIncomingSocketData(final ByteBuffer readBuffer) {
        SocketChannel channel = null;
        SelectionKey key = null;
        try {
            final int readyKeyCount = this.readSelector.selectNow();
            if (readyKeyCount > 0) {
                final Set<SelectionKey> readyKeys = this.readSelector.selectedKeys();
                final Iterator<SelectionKey> it = readyKeys.iterator();
                while (it.hasNext()) {
                    key = it.next();
                    it.remove();
                    if (!key.isValid()) {
                        continue;
                    }
                    channel = (SocketChannel)key.channel();
                    readBuffer.clear();
                    try {
                        this.readTcpData(channel, key, readBuffer);
                    }
                    catch (IOException e) {
                        this.closeConnection(channel);
                        this.logger.info("Socket closed: " + channel);
                    }
                }
            }
        }
        catch (ClosedSelectorException e2) {
            this.logger.debug("Selector is closed!");
        }
        catch (CancelledKeyException ex) {}
        catch (IOException ioe) {
            this.logger.warn("I/O reading/selection error: " + ioe);
            Logging.logStackTrace(this.logger, ioe);
        }
        catch (Exception err) {
            this.logger.warn("Generic reading/selection error: " + err);
            Logging.logStackTrace(this.logger, err);
        }
    }
    
    private void readTcpData(final SocketChannel channel, final SelectionKey key, final ByteBuffer readBuffer) throws IOException {
        final ISession session = this.sessionManager.getLocalSessionByConnection(channel);
        if (key.isWritable()) {
            key.interestOps(1);
            this.socketWriter.continueWriteOp(session);
        }
        if (!key.isReadable()) {
            return;
        }
        readBuffer.clear();
        long byteCount = 0L;
        byteCount = channel.read(readBuffer);
        if (byteCount == -1L) {
            this.closeConnection(channel);
        }
        else if (byteCount > 0L) {
            session.setLastReadTime(System.currentTimeMillis());
            this.readBytes += byteCount;
            session.addReadBytes(byteCount);
            readBuffer.flip();
            final byte[] binaryData = new byte[readBuffer.limit()];
            readBuffer.get(binaryData);
            this.ioHandler.onDataRead(session, binaryData);
        }
    }
    
    private void closeConnection(final SelectableChannel channel) throws IOException {
        channel.close();
        if (channel instanceof SocketChannel) {
            this.sessionManager.onSocketDisconnected((SocketChannel)channel);
        }
    }
    
    @Override
    public IOHandler getIOHandler() {
        return this.ioHandler;
    }
    
    @Override
    public Selector getSelector() {
        return this.readSelector;
    }
    
    @Override
    public void setIoHandler(final IOHandler handler) {
        if (handler == null) {
            throw new IllegalStateException("IOHandler si already set!");
        }
        this.ioHandler = handler;
    }
    
    @Override
    public long getReadBytes() {
        return this.readBytes;
    }
    
    @Override
    public long getReadPackets() {
        return this.ioHandler.getReadPackets();
    }
}

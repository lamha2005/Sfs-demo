// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public abstract class AbstractMethodDispatcher implements IMethodDispatcher
{
    protected Map<String, String> methodDictionary;
    
    public AbstractMethodDispatcher() {
        this.methodDictionary = new ConcurrentHashMap<String, String>();
    }
    
    @Override
    public void callMethod(final String key, final Object[] params) throws Exception {
        final String methodName = this.methodDictionary.get(key);
        if (methodName == null) {
            throw new IllegalArgumentException("No method was found for key: " + key);
        }
        final Class[] arguments = new Class[params.length];
        final Class<?> clazz = this.getClass();
        for (int j = 0; j < params.length; ++j) {
            arguments[j] = params[j].getClass();
        }
        final Method method = clazz.getMethod(methodName, (Class<?>[])arguments);
        method.invoke(this, params);
    }
    
    @Override
    public void registerMethod(final String key, final String methodName) {
        this.methodDictionary.put(key, methodName);
    }
    
    @Override
    public void unregisterKey(final String key) {
        this.methodDictionary.remove(key);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import java.util.Iterator;
import java.util.Collection;
import com.smartfoxserver.bitswarm.exceptions.MessageQueueFullException;
import com.smartfoxserver.bitswarm.exceptions.PacketQueueWarning;
import java.net.SocketAddress;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import com.smartfoxserver.bitswarm.data.MultiSegmentPacketBuffer;
import com.smartfoxserver.bitswarm.data.IPacketBuffer;
import com.smartfoxserver.bitswarm.sessions.IPacketQueue;
import com.smartfoxserver.bitswarm.data.IPacket;
import java.io.IOException;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.util.Logging;
import com.smartfoxserver.bitswarm.util.NetworkServices;
import com.smartfoxserver.bitswarm.config.EngineConstants;
import com.smartfoxserver.bitswarm.io.IPacketFinalizer;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.LoggerFactory;
import java.util.concurrent.Executors;
import java.util.List;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.io.IOHandler;
import com.smartfoxserver.bitswarm.service.BaseCoreService;

public class AdvancedSocketWriter extends BaseCoreService implements ISocketWriter, Runnable
{
    private BitSwarmEngine engine;
    private IOHandler ioHandler;
    private final Logger logger;
    private final Logger bootLogger;
    private final ExecutorService threadPool;
    private final BlockingQueue<ISession> sessionTicketsQueue;
    private final List<ISession> failedSessions;
    private volatile int threadId;
    private volatile boolean isActive;
    private volatile long droppedPacketsCount;
    private volatile long writtenBytes;
    private volatile long writtenPackets;
    private int threadPoolSize;
    
    public AdvancedSocketWriter(final int threadPoolSize) {
        this.threadId = 1;
        this.isActive = false;
        this.droppedPacketsCount = 0L;
        this.writtenBytes = 0L;
        this.writtenPackets = 0L;
        this.threadPoolSize = threadPoolSize;
        this.threadPool = Executors.newFixedThreadPool(threadPoolSize);
        this.logger = LoggerFactory.getLogger((Class)AdvancedSocketWriter.class);
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        this.sessionTicketsQueue = new LinkedBlockingQueue<ISession>();
        this.failedSessions = new ArrayList<ISession>();
    }
    
    @Override
    public int getQueueSize() {
        return this.sessionTicketsQueue.size();
    }
    
    @Override
    public int getThreadPoolSize() {
        return this.threadPoolSize;
    }
    
    @Override
    public void init(final Object o) {
        if (this.isActive) {
            throw new IllegalArgumentException("Object is already initialized. Destroy it first!");
        }
        if (this.threadPoolSize < 1) {
            throw new IllegalArgumentException("Illegal value for a thread pool size: " + this.threadPoolSize);
        }
        this.engine = BitSwarmEngine.getInstance();
        this.isActive = true;
        this.initThreadPool();
        this.bootLogger.info("Socket Writer started (pool size:" + this.threadPoolSize + ")");
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        this.isActive = false;
        final List<Runnable> leftOvers = this.threadPool.shutdownNow();
        this.bootLogger.info("SocketWriter stopped. Unprocessed tasks: " + leftOvers.size());
    }
    
    @Override
    public IOHandler getIOHandler() {
        return this.ioHandler;
    }
    
    @Override
    public void setIOHandler(final IOHandler ioHandler) {
        if (this.ioHandler != null) {
            throw new IllegalStateException("You cannot reassign the IOHandler class!");
        }
        this.ioHandler = ioHandler;
    }
    
    @Override
    public IPacketFinalizer getPacketFinalizer() {
        return null;
    }
    
    @Override
    public void setPacketFinalizer(final IPacketFinalizer value) {
    }
    
    @Override
    public void continueWriteOp(final ISession session) {
        if (session != null) {
            this.sessionTicketsQueue.add(session);
        }
    }
    
    private void initThreadPool() {
        for (int j = 0; j < this.threadPoolSize; ++j) {
            this.threadPool.execute(this);
        }
    }
    
    @Override
    public void run() {
        Thread.currentThread().setName("SocketWriter-" + this.threadId++);
        final ByteBuffer writeBuffer = NetworkServices.allocateBuffer(32768, EngineConstants.DEFAULT_WRITE_BUFFER_TYPE);
        while (this.isActive) {
            try {
                final ISession session = this.sessionTicketsQueue.take();
                this.processSessionQueue(writeBuffer, session);
            }
            catch (InterruptedException e) {
                this.isActive = false;
                this.logger.warn("SocketWriter thread interruped: " + Thread.currentThread());
            }
            catch (Throwable t) {
                this.logger.warn("Problems in SocketWriter main loop: " + t.getMessage() + ", Thread: " + Thread.currentThread());
                Logging.logStackTrace(this.logger, t);
            }
        }
        this.bootLogger.info("SocketWriter threadpool shutting down.");
    }
    
    private void processSessionQueue(final ByteBuffer writeBuffer, final ISession session) throws Exception {
        if (session != null) {
            final SessionType type = session.getType();
            if (type == SessionType.DEFAULT) {
                this.processRegularSession(writeBuffer, session);
            }
            else {
                if (type == SessionType.BLUEBOX) {
                    throw new UnsupportedOperationException("Not implemented yet");
                }
                if (type == SessionType.VOID) {
                    return;
                }
            }
        }
    }
    
    private void processRegularSession(final ByteBuffer writeBuffer, final ISession session) throws Exception {
        IPacket packet = null;
        try {
            final IPacketQueue sessionQ = session.getPacketQueue();
            if (!sessionQ.isEmpty()) {
                synchronized (sessionQ) {
                    packet = sessionQ.peek();
                    if (packet == null) {
                        // monitorexit(sessionQ)
                        return;
                    }
                    if (packet.getTransportType() == TransportType.TCP) {
                        this.tcpSend(writeBuffer, sessionQ, session, packet);
                    }
                    else {
                        this.udpSend(writeBuffer, sessionQ, session, packet);
                    }
                }
                // monitorexit(sessionQ)
            }
        }
        catch (IOException ioe) {
            this.logger.warn("Failed writing to Session: " + session);
            Logging.logStackTrace(this.logger, ioe);
        }
    }
    
    private void tcpSend(final ByteBuffer writeBuffer, final IPacketQueue sessionQ, final ISession session, final IPacket packet) throws Exception {
        final SocketChannel channel = null;
        writeBuffer.clear();
        final Object packetData = packet.getData();
        if (packetData == null) {
            return;
        }
        if (packetData instanceof IPacketBuffer) {
            final IPacketBuffer packetBuffer = (IPacketBuffer)packetData;
            if (packetBuffer.getSegment() == null) {
                packetBuffer.setSegment(packetBuffer.nextSegment());
                System.out.println("Get next segment!");
            }
            this.writePendingSegment(writeBuffer, packet, session);
        }
        else {
            if (!(packetData instanceof byte[])) {
                throw new UnsupportedOperationException("Unexpected packet data type: " + packetData.getClass().getName());
            }
            final byte[] message = (byte[])packet.getData();
            if (message.length > writeBuffer.capacity()) {
                final IPacketBuffer buffer = new MultiSegmentPacketBuffer(writeBuffer.capacity());
                buffer.setData(message, writeBuffer.capacity());
                buffer.setSegment(buffer.nextSegment());
                packet.setData(buffer);
                this.writePendingSegment(writeBuffer, packet, session);
            }
            else {
                this.writeNewSegment(writeBuffer, packet, session, message);
            }
        }
    }
    
    private void writePendingSegment(final ByteBuffer writeBuffer, final IPacket packet, final ISession session) throws IOException {
        final IPacketBuffer buffer = (IPacketBuffer)packet.getData();
        final int size = buffer.getSize() - buffer.getPosition();
        writeBuffer.put(buffer.getSegment(), buffer.getPosition(), size);
        writeBuffer.flip();
        final SocketChannel channel = session.getConnection();
        final int bytesWritten = channel.write(writeBuffer);
        final int remaining = size - bytesWritten;
        if (remaining == 0) {
            if (buffer.isMultiSegment() && buffer.hasMoreSegments()) {
                buffer.setSegment(null);
                this.setOpWrite(session);
            }
            else {
                this.onPacketComplete(session);
            }
        }
        else {
            if (remaining <= 0) {
                throw new IllegalStateException("Negative remaining bytes: " + remaining);
            }
            buffer.forward(bytesWritten);
            this.setOpWrite(session);
        }
    }
    
    private void writeNewSegment(final ByteBuffer writeBuffer, final IPacket packet, final ISession session, final byte[] message) throws IOException {
        writeBuffer.put(message);
        writeBuffer.flip();
        final SocketChannel channel = session.getConnection();
        final int bytesWritten = channel.write(writeBuffer);
        final int remaining = message.length - bytesWritten;
        if (remaining > 0) {
            final IPacketBuffer buffer = new MultiSegmentPacketBuffer(writeBuffer.capacity());
            buffer.setSegment(message);
            buffer.forward(bytesWritten);
            packet.setData(buffer);
            this.setOpWrite(session);
        }
        else {
            if (remaining != 0) {
                throw new IllegalStateException("Negative remaining bytes: " + remaining);
            }
            this.onPacketComplete(session);
        }
    }
    
    private void onPacketComplete(final ISession session) {
        session.getPacketQueue().take();
        ++this.writtenPackets;
        if (!session.getPacketQueue().isEmpty()) {
            this.sessionTicketsQueue.add(session);
        }
    }
    
    private void setOpWrite(final ISession session) {
        final SelectionKey sk = (SelectionKey)session.getSystemProperty("SessionSelectionKey");
        if (sk != null && sk.isValid()) {
            sk.interestOps(5);
        }
    }
    
    private void udpSend(ByteBuffer writeBuffer, final IPacketQueue sessionQ, final ISession session, final IPacket packet) throws Exception {
        writeBuffer.clear();
        final byte[] buffer = (byte[])packet.getData();
        if (writeBuffer.capacity() < buffer.length) {
            this.logger.info("Allocating new buffer. Curr. capacity: " + writeBuffer.capacity() + ", Need: " + buffer.length);
            writeBuffer = NetworkServices.allocateBuffer(buffer.length, EngineConstants.DEFAULT_WRITE_BUFFER_TYPE);
        }
        writeBuffer.put(buffer);
        writeBuffer.flip();
        final DatagramChannel channel = DatagramChannel.open();
        final int written = channel.send(writeBuffer, (SocketAddress)session.getSystemProperty("sender"));
        if (written != 0) {
            this.writtenBytes += written;
        }
        this.logger.info("Written UDP: " + new String(buffer) + " // " + written);
    }
    
    @Override
    public void enqueuePacket(final IPacket packet) {
        final Collection<ISession> recipients = packet.getRecipients();
        if (recipients != null && recipients.size() > 0) {
            for (final ISession session : recipients) {
                final IPacketQueue sessionQ = session.getPacketQueue();
                if (sessionQ != null) {
                    try {
                        final boolean wasEmpty = sessionQ.isEmpty();
                        sessionQ.put(packet);
                        if (!wasEmpty) {
                            continue;
                        }
                        this.sessionTicketsQueue.add(session);
                    }
                    catch (PacketQueueWarning err) {
                        this.dropOneMessage(session);
                    }
                    catch (MessageQueueFullException error) {
                        this.dropOneMessage(session);
                    }
                }
            }
        }
    }
    
    private void dropOneMessage(final ISession session) {
        session.addDroppedMessages(1);
        ++this.droppedPacketsCount;
    }
    
    @Override
    public long getDroppedPacketsCount() {
        return this.droppedPacketsCount;
    }
    
    @Override
    public long getWrittenBytes() {
        return this.writtenBytes;
    }
    
    @Override
    public long getWrittenPackets() {
        return this.writtenPackets;
    }
}

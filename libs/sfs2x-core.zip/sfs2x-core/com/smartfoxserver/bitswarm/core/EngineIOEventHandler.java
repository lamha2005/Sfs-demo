// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.events.IEventListener;

public class EngineIOEventHandler implements IEventListener
{
    private final BitSwarmEngine engine;
    
    public EngineIOEventHandler() {
        this.engine = BitSwarmEngine.getInstance();
    }
    
    @Override
    public void handleEvent(final IEvent event) {
        this.engine.dispatchEvent(event);
    }
}

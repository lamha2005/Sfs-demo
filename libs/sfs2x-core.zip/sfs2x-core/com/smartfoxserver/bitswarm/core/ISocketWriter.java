// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.io.IPacketFinalizer;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.io.IOHandler;

public interface ISocketWriter
{
    IOHandler getIOHandler();
    
    void setIOHandler(final IOHandler p0);
    
    void continueWriteOp(final ISession p0);
    
    void enqueuePacket(final IPacket p0);
    
    long getDroppedPacketsCount();
    
    long getWrittenBytes();
    
    long getWrittenPackets();
    
    int getQueueSize();
    
    int getThreadPoolSize();
    
    IPacketFinalizer getPacketFinalizer();
    
    void setPacketFinalizer(final IPacketFinalizer p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import com.smartfoxserver.bitswarm.util.scheduling.ITaskHandler;
import java.io.IOException;
import com.smartfoxserver.bitswarm.config.SocketConfig;
import com.smartfoxserver.bitswarm.controllers.IController;
import com.smartfoxserver.bitswarm.config.ControllerConfig;
import com.smartfoxserver.bitswarm.clustering.DefaultClusterManager;
import java.lang.reflect.Method;
import com.smartfoxserver.bitswarm.core.debug.LaggySocketWriter;
import com.smartfoxserver.bitswarm.core.debug.DebugSocketWriter;
import com.smartfoxserver.bitswarm.io.IOHandler;
import com.smartfoxserver.bitswarm.controllers.DefaultControllerManager;
import com.smartfoxserver.bitswarm.core.security.DefaultSecurityManager;
import java.util.List;
import com.smartfoxserver.bitswarm.io.Response;
import java.util.Collection;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.ArrayList;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.bitswarm.exceptions.BootSequenceException;
import java.util.Iterator;
import com.smartfoxserver.bitswarm.boot.SystemPropertiesEnumerator;
import com.smartfoxserver.bitswarm.util.Logging;
import com.smartfoxserver.bitswarm.events.Event;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import com.smartfoxserver.bitswarm.events.IEvent;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.events.IEventListener;
import com.smartfoxserver.bitswarm.service.IService;
import java.util.Map;
import com.smartfoxserver.bitswarm.clustering.IClusterManager;
import com.smartfoxserver.bitswarm.core.security.ISecurityManager;
import com.smartfoxserver.bitswarm.controllers.IControllerManager;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import com.smartfoxserver.bitswarm.config.EngineConfiguration;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.util.scheduling.Scheduler;
import com.smartfoxserver.bitswarm.sessions.bluebox.BlueBoxService;
import com.smartfoxserver.bitswarm.websocket.WebSocketService;
import com.smartfoxserver.bitswarm.service.BaseCoreService;

public final class BitSwarmEngine extends BaseCoreService
{
    public static final String version = "3.40.3";
    private static BitSwarmEngine __engine__;
    private ISocketAcceptor socketAcceptor;
    private ISocketReader socketReader;
    private IDatagramReader datagramReader;
    private ISocketWriter socketWriter;
    private WebSocketService webSocketService;
    private BlueBoxService blueBoxService;
    private Scheduler scheduler;
    private Logger logger;
    private Logger bootLogger;
    private EngineConfiguration configuration;
    private ISessionManager sessionManager;
    private IControllerManager controllerManager;
    private ISecurityManager securityManager;
    private IClusterManager clusterManager;
    private volatile boolean running;
    private volatile boolean restarting;
    private volatile boolean inited;
    private Map<String, IService> coreServicesByName;
    private Map<IService, Object> configByService;
    private IEventListener eventHandler;
    private EngineDelayedTaskHandler engineDelayedTaskHandler;
    private volatile int restartCount;
    
    public static BitSwarmEngine getInstance() {
        if (BitSwarmEngine.__engine__ == null) {
            BitSwarmEngine.__engine__ = new BitSwarmEngine();
        }
        return BitSwarmEngine.__engine__;
    }
    
    private BitSwarmEngine() {
        this.running = false;
        this.restarting = false;
        this.inited = false;
        this.restartCount = 0;
        this.setName("BitSwarmEngine 3.40.3");
    }
    
    private void initializeServerEngine() {
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        this.logger = LoggerFactory.getLogger((Class)BitSwarmEngine.class);
        this.inited = true;
    }
    
    public void start() throws Exception {
        this.start(null);
    }
    
    public void start(final String extraLogMessage) throws Exception {
        if (!this.inited) {
            this.initializeServerEngine();
        }
        if (extraLogMessage != null) {
            this.bootLogger.info(extraLogMessage);
        }
        this.eventHandler = new IEventListener() {
            @Override
            public void handleEvent(final IEvent event) {
                BitSwarmEngine.this.dispatchEvent(event);
            }
        };
        this.engineDelayedTaskHandler = new EngineDelayedTaskHandler();
        this.coreServicesByName = new ConcurrentHashMap<String, IService>();
        this.configByService = new HashMap<IService, Object>();
        this.bootSequence();
        ((BaseCoreService)this.socketAcceptor).addEventListener("sessionAdded", this.eventHandler);
        ((BaseCoreService)this.socketReader).addEventListener("sessionLost", this.eventHandler);
        ((BaseCoreService)this.socketWriter).addEventListener("packetDropped", this.eventHandler);
        final Event engineStartedEvent = new Event("serverStarted");
        this.dispatchEvent(engineStartedEvent);
        this.running = true;
        if (this.configuration.isClustered()) {
            this.bootLogger.info("Cluster Node Id: " + this.clusterManager.getLocalNodeName());
        }
    }
    
    public void restart() {
        final Thread runningThread = Thread.currentThread();
        if (!this.securityManager.isEngineThread(runningThread)) {
            this.logger.error(String.format("This thread is not allowed to perform a restart: %s (%s) ", runningThread.getName(), runningThread.getThreadGroup().getName()));
            Logging.logStackTrace(this.logger, runningThread.getStackTrace());
            return;
        }
        ++this.restartCount;
        if (this.restarting || !this.running) {
            return;
        }
        this.bootLogger.info("Restart Sequence inited...");
        this.restarting = true;
        this.running = false;
        final Thread restarter = new Thread(new Runnable() {
            @Override
            public void run() {
                BitSwarmEngine.this.halt();
                BitSwarmEngine.this.bootLogger.info("Restart Sequence complete!");
            }
        }, "--== Restarter ==--");
        restarter.start();
    }
    
    public void halt() {
        try {
            final boolean needRestart = this.restarting;
            this.bootLogger.info("Halting Server Engine...");
            ((BaseCoreService)this.socketAcceptor).removeEventListener("sessionAdded", this.eventHandler);
            ((BaseCoreService)this.socketReader).removeEventListener("sessionLost", this.eventHandler);
            this.shutDownSequence();
            this.socketAcceptor = null;
            this.socketReader = null;
            this.socketWriter = null;
            this.eventHandler = null;
            this.engineDelayedTaskHandler = null;
            this.coreServicesByName = null;
            this.restarting = false;
            this.running = false;
            this.bootLogger.info("ShutDown Sequence Complete... ");
            if (needRestart) {
                System.gc();
                Thread.sleep(4000L);
                this.start("Restarting Server Engine...");
            }
        }
        catch (Throwable problem) {
            this.bootLogger.warn("Error while shutting down the server: " + problem.getMessage());
            Logging.logStackTrace(this.bootLogger, problem);
        }
    }
    
    public int getRestartCount() {
        return this.restartCount;
    }
    
    public void bootSequence() throws BootSequenceException, Exception {
        this.bootLogger.info("BitSwarmEngine version: 3.40.3 { " + Thread.currentThread().getName() + " }");
        new SystemPropertiesEnumerator().logProperties(this.bootLogger);
        this.startCoreServices();
        this.bindSockets(this.configuration.getBindableSockets());
        this.configByService.put(this.webSocketService, this.getConfiguration().getWebSocketEngineConfig());
        for (final IService service : this.coreServicesByName.values()) {
            if (service != null) {
                service.init(this.configByService.get(service));
            }
        }
        this.startClusteringServices();
        this.bootLogger.info("[[[ ===--- Boot sequence complete ---=== ]]]");
    }
    
    public void shutDownSequence() throws Exception {
        this.stopClusteringServices();
        this.stopCoreServices();
    }
    
    public void write(final IResponse response) {
        try {
            if (this.configuration.getWebSocketEngineConfig().isActive()) {
                final List<ISession> webSocketRecipients = new ArrayList<ISession>();
                final List<ISession> socketRecipients = new ArrayList<ISession>();
                for (final ISession session : response.getRecipients()) {
                    if (session.getType() == SessionType.WEBSOCKET) {
                        webSocketRecipients.add(session);
                    }
                    else {
                        socketRecipients.add(session);
                    }
                }
                if (webSocketRecipients.size() > 0) {
                    response.setRecipients(socketRecipients);
                    final IResponse webSocketResponse = Response.clone(response);
                    webSocketResponse.setRecipients(webSocketRecipients);
                    this.writeToWebSocket(webSocketResponse);
                }
            }
        }
        finally {
            this.writeToSocket(response);
        }
        this.writeToSocket(response);
    }
    
    private void writeToSocket(final IResponse res) {
        this.socketWriter.getIOHandler().getCodec().onPacketWrite(res);
    }
    
    private void writeToWebSocket(final IResponse res) {
        this.webSocketService.getProtocolCodec().onPacketWrite(res);
    }
    
    private void startCoreServices() throws Exception {
        this.securityManager = new DefaultSecurityManager();
        this.scheduler = new Scheduler(this.bootLogger);
        final Class<?> sessionManagerClass = Class.forName(this.configuration.getSessionManagerClass());
        final Method getInstanceMethod = sessionManagerClass.getDeclaredMethod("getInstance", (Class<?>[])new Class[0]);
        if (getInstanceMethod != null) {
            this.sessionManager = (ISessionManager)getInstanceMethod.invoke(sessionManagerClass, new Object[0]);
        }
        else {
            this.sessionManager = (ISessionManager)sessionManagerClass.newInstance();
        }
        this.bootLogger.info("Session manager ready: " + this.sessionManager);
        this.controllerManager = new DefaultControllerManager();
        this.configureControllers();
        this.socketReader = new SocketReader(this.configuration.getReaderThreadPoolSize());
        final Class<?> ioHandlerClass = Class.forName(this.configuration.getIoHandlerClass());
        final IOHandler ioHandler = (IOHandler)ioHandlerClass.newInstance();
        this.socketReader.setIoHandler(ioHandler);
        (this.datagramReader = new DatagramReader()).setIoHandler(ioHandler);
        this.socketAcceptor = new SocketAcceptor(this.configuration.getAcceptorThreadPoolSize());
        this.socketAcceptor.getConnectionFilter().setMaxConnectionsPerIp(this.configuration.getMaxConnectionsFromSameIp());
        if (this.configuration.isPacketDebug()) {
            this.socketWriter = new DebugSocketWriter(this.configuration.getWriterThreadPoolSize());
        }
        else if (this.configuration.isLagDebug()) {
            this.socketWriter = new LaggySocketWriter(this.configuration.getWriterThreadPoolSize());
        }
        else {
            this.socketWriter = new SocketWriter(this.configuration.getWriterThreadPoolSize());
        }
        this.socketWriter.setIOHandler(ioHandler);
        this.socketWriter.setPacketFinalizer(this.configuration.getPacketFinalizerImpl());
        this.webSocketService = new WebSocketService();
        this.coreServicesByName.put("webSocketEngine", this.webSocketService);
        this.blueBoxService = new BlueBoxService();
        this.coreServicesByName.put("blueBoxEngine", this.blueBoxService);
        this.securityManager.setName("securityManager");
        this.scheduler.setName("scheduler");
        this.sessionManager.setName("sessionManager");
        this.controllerManager.setName("controllerManager");
        ((BaseCoreService)this.socketAcceptor).setName("socketAcceptor");
        ((BaseCoreService)this.socketReader).setName("socketReader");
        ((BaseCoreService)this.socketWriter).setName("socketWriter");
        this.coreServicesByName.put("scheduler", this.scheduler);
        this.coreServicesByName.put("sessionManager", this.sessionManager);
        this.coreServicesByName.put("controllerManager", this.controllerManager);
        this.coreServicesByName.put("socketAcceptor", (IService)this.socketAcceptor);
        this.coreServicesByName.put("socketReader", (IService)this.socketReader);
        this.coreServicesByName.put("socketWriter", (IService)this.socketWriter);
        this.coreServicesByName.put("securityManager", this.securityManager);
        this.coreServicesByName.put("datagramReader", (IService)this.datagramReader);
    }
    
    private void stopCoreServices() throws Exception {
        this.scheduler.destroy(null);
        ((IService)this.socketWriter).destroy(null);
        ((IService)this.socketReader).destroy(null);
        ((IService)this.datagramReader).destroy(null);
        Thread.sleep(2000L);
        this.controllerManager.destroy(null);
        this.sessionManager.destroy(null);
        this.securityManager.destroy(null);
        ((IService)this.socketAcceptor).destroy(null);
    }
    
    private void startClusteringServices() throws Exception {
        if (this.configuration.isClustered()) {
            (this.clusterManager = new DefaultClusterManager()).setName("clusterManager");
            this.clusterManager.init(null);
        }
    }
    
    private void stopClusteringServices() {
        if (this.configuration.isClustered()) {
            this.clusterManager.destroy(null);
        }
    }
    
    private void configureControllers() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        final List<ControllerConfig> cfgs = this.configuration.getControllerConfigs();
        for (final ControllerConfig controllerConfig : cfgs) {
            final Class<?> controllerClass = Class.forName(controllerConfig.getClassName());
            final IController controller = (IController)controllerClass.newInstance();
            controller.setId(controllerConfig.getId());
            controller.setThreadPoolSize(controllerConfig.getThreadPoolSize());
            controller.setMaxQueueSize(controllerConfig.getMaxRequestQueueSize());
            this.controllerManager.addController(controller.getId(), controller);
        }
    }
    
    private void bindSockets(final List<SocketConfig> bindableSockets) {
        for (final SocketConfig socketCfg : bindableSockets) {
            try {
                this.socketAcceptor.bindSocket(socketCfg);
            }
            catch (IOException e) {
                this.bootLogger.warn("Was not able to bind socket: " + socketCfg);
            }
        }
    }
    
    public IService getServiceByName(final String serviceName) {
        return this.coreServicesByName.get(serviceName);
    }
    
    public ISocketAcceptor getSocketAcceptor() {
        return this.socketAcceptor;
    }
    
    public ISocketReader getSocketReader() {
        return this.socketReader;
    }
    
    public IDatagramReader getDatagramReader() {
        return this.datagramReader;
    }
    
    public ISocketWriter getSocketWriter() {
        return this.socketWriter;
    }
    
    public Logger getLogger() {
        return this.logger;
    }
    
    public void setLogger(final Logger logger) {
        this.logger = logger;
    }
    
    public EngineConfiguration getConfiguration() {
        return this.configuration;
    }
    
    public void setConfiguration(final EngineConfiguration configuration) {
        this.configuration = configuration;
    }
    
    public ITaskHandler getEngineDelayedTaskHandler() {
        return this.engineDelayedTaskHandler;
    }
    
    public IControllerManager getControllerManager() {
        return this.controllerManager;
    }
    
    public ISessionManager getSessionManager() {
        return this.sessionManager;
    }
    
    public IClusterManager getClusterManager() {
        return this.clusterManager;
    }
    
    @Override
    public void init(final Object o) {
        throw new UnsupportedOperationException("This call is not supported in this class!");
    }
    
    @Override
    public void destroy(final Object o) {
        throw new UnsupportedOperationException("This call is not supported in this class!");
    }
    
    private String threadDump() {
        String dump = "{{{ Thread Dump }}}\n";
        final Thread[] threads = new Thread[Thread.activeCount()];
        Thread.enumerate(threads);
        Thread[] array;
        for (int length = (array = threads).length, i = 0; i < length; ++i) {
            final Thread t = array[i];
            dump = String.valueOf(dump) + "\t" + t.getName() + ", " + t.getPriority() + ", " + t.getState() + ", daemon: " + t.isDaemon() + "\n";
        }
        return dump;
    }
}

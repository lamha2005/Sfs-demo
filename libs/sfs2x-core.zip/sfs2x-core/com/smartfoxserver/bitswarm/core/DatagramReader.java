// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

import java.net.SocketAddress;
import java.util.Iterator;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedSelectorException;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.util.NetworkServices;
import com.smartfoxserver.bitswarm.util.Logging;
import java.io.IOException;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.io.IOHandler;
import java.nio.channels.Selector;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.service.IService;

public class DatagramReader implements IDatagramReader, Runnable, IService
{
    private final BitSwarmEngine engine;
    private final Logger logger;
    private final Logger bootLogger;
    private final Thread readerThread;
    private Selector udpSelector;
    private IOHandler ioHandler;
    private volatile boolean isActive;
    private volatile long readBytes;
    
    public DatagramReader() {
        this.isActive = false;
        this.readBytes = 0L;
        this.engine = BitSwarmEngine.getInstance();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        try {
            this.udpSelector = Selector.open();
            this.bootLogger.info("UDP Selector opened");
        }
        catch (IOException e) {
            this.bootLogger.error("Failed opening TCP Selector: " + e.toString());
            e.printStackTrace();
        }
        this.readerThread = new Thread(this, "DatagramReader");
    }
    
    @Override
    public void init(final Object o) {
        if (this.isActive) {
            throw new IllegalArgumentException("Object is already initialized. Destroy it first!");
        }
        this.isActive = true;
        this.readerThread.start();
        this.bootLogger.info("DatagramReader started");
    }
    
    @Override
    public void destroy(final Object o) {
        this.isActive = false;
        try {
            Thread.sleep(500L);
            this.udpSelector.close();
        }
        catch (Exception e) {
            this.bootLogger.warn("Error when shutting down UDP Selector: " + e.getMessage());
            Logging.logStackTrace(this.bootLogger, e);
        }
    }
    
    @Override
    public void run() {
        final ByteBuffer readBuffer = NetworkServices.allocateBuffer(this.engine.getConfiguration().getReadMaxBufferSize(), this.engine.getConfiguration().getReadBufferType());
        while (this.isActive) {
            try {
                this.readIncomingDatagrams(readBuffer);
            }
            catch (Throwable t) {
                this.logger.warn("Problems in DatagramReader main loop: " + t);
                Logging.logStackTrace(this.logger, t);
            }
        }
        this.bootLogger.info("SocketReader threadpool shutting down.");
    }
    
    private void readIncomingDatagrams(final ByteBuffer readBuffer) {
        DatagramChannel chan = null;
        SelectionKey key = null;
        try {
            this.udpSelector.select();
            final Iterator<SelectionKey> selectedKeys = this.udpSelector.selectedKeys().iterator();
            while (selectedKeys.hasNext()) {
                try {
                    key = selectedKeys.next();
                    selectedKeys.remove();
                    if (!key.isValid()) {
                        continue;
                    }
                    if (!key.isReadable()) {
                        continue;
                    }
                    readBuffer.clear();
                    chan = (DatagramChannel)key.channel();
                    this.readPacket(chan, readBuffer);
                }
                catch (IOException e) {
                    this.logger.warn(String.format("Problem reading UDP Packet, from: %s, Error: %s", chan.toString(), e.toString()));
                }
            }
        }
        catch (ClosedSelectorException e2) {
            this.logger.debug("Selector is closed!");
        }
        catch (CancelledKeyException ex) {}
        catch (IOException ioe) {
            this.logger.warn("Datagram selection IOError: " + ioe);
            Logging.logStackTrace(this.logger, ioe);
        }
        catch (Exception err) {
            this.logger.warn("Generic reading/selection error: " + err);
            Logging.logStackTrace(this.logger, err);
        }
    }
    
    private void readPacket(final DatagramChannel chan, final ByteBuffer readBuffer) throws IOException {
        long byteCount = 0L;
        final SocketAddress address = chan.receive(readBuffer);
        if (address != null) {
            byteCount = readBuffer.position();
            if (byteCount > 0L) {
                this.readBytes += byteCount;
                readBuffer.flip();
                final byte[] binaryData = new byte[readBuffer.limit()];
                readBuffer.get(binaryData);
                this.ioHandler.onDataRead(chan, address, binaryData);
            }
        }
        else {
            this.logger.info("Could not read any data from DatagramChannel: " + chan);
        }
    }
    
    @Override
    public IOHandler getIOHandler() {
        return this.ioHandler;
    }
    
    @Override
    public long getReadBytes() {
        return this.readBytes;
    }
    
    @Override
    public long getReadPackets() {
        return this.ioHandler.getReadPackets();
    }
    
    @Override
    public void setIoHandler(final IOHandler handler) {
        if (handler == null) {
            throw new IllegalStateException("IOHandler is already set!");
        }
        this.ioHandler = handler;
    }
    
    @Override
    public String getName() {
        return "DatagramReader";
    }
    
    @Override
    public Selector getSelector() {
        return this.udpSelector;
    }
    
    @Override
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void setName(final String name) {
        throw new UnsupportedOperationException();
    }
}

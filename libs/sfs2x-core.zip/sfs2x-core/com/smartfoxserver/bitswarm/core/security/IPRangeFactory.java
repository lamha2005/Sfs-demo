// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

public class IPRangeFactory
{
    public static IPRange parse(final String ipRangeStr) {
        return new IPV4Range(ipRangeStr);
    }
}

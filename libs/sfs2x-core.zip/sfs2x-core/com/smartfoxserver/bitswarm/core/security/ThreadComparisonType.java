// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

public enum ThreadComparisonType
{
    EXACT("EXACT", 0), 
    STARTSWITH("STARTSWITH", 1), 
    ENDSWITH("ENDSWITH", 2);
    
    private ThreadComparisonType(final String s, final int n) {
    }
}

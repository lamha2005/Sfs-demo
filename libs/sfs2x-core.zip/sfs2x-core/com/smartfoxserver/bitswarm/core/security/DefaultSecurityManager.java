// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

import java.util.Iterator;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import org.slf4j.Logger;
import java.util.List;

public class DefaultSecurityManager implements ISecurityManager
{
    private final List<IAllowedThread> secureThreads;
    private String name;
    private final Logger bootLogger;
    
    public DefaultSecurityManager() {
        this.secureThreads = new ArrayList<IAllowedThread>();
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
    }
    
    @Override
    public void init(final Object o) {
        this.secureThreads.add(new EngineThread("com.smartfoxserver.bitswarm.controllers", ThreadComparisonType.STARTSWITH));
        this.bootLogger.info("Security Manager started");
    }
    
    @Override
    public void destroy(final Object o) {
        this.bootLogger.info("Security Manager stopped");
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public void handleMessage(final Object message) {
    }
    
    @Override
    public boolean isEngineThread(final Thread thread) {
        boolean okay = false;
        final String currThreadName = thread.getName();
        for (final IAllowedThread allowedThread : this.secureThreads) {
            if (allowedThread.getComparisonType() == ThreadComparisonType.STARTSWITH) {
                if (currThreadName.startsWith(allowedThread.getName())) {
                    okay = true;
                    break;
                }
                continue;
            }
            else if (allowedThread.getComparisonType() == ThreadComparisonType.EXACT) {
                if (currThreadName.equals(currThreadName)) {
                    okay = true;
                    break;
                }
                continue;
            }
            else {
                if (allowedThread.getComparisonType() == ThreadComparisonType.ENDSWITH && currThreadName.endsWith(allowedThread.getName())) {
                    okay = true;
                    break;
                }
                continue;
            }
        }
        return okay;
    }
}

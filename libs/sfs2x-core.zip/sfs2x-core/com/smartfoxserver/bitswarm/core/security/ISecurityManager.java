// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

import com.smartfoxserver.bitswarm.service.IService;

public interface ISecurityManager extends IService
{
    boolean isEngineThread(final Thread p0);
}

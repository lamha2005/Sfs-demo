// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

public interface IPRange
{
    String getAddress();
    
    int getBitMask();
    
    boolean isRange();
}

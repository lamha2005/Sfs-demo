// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

import com.smartfoxserver.bitswarm.exceptions.RefusedAddressException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ConcurrentMap;
import java.util.Set;

public class DefaultConnectionFilter implements IConnectionFilter
{
    private final Set<String> addressWhiteList;
    private final Set<String> bannedAddresses;
    private final ConcurrentMap<String, AtomicInteger> addressMap;
    private int maxConnectionsPerIp;
    
    public DefaultConnectionFilter() {
        this.addressWhiteList = new HashSet<String>();
        this.bannedAddresses = new HashSet<String>();
        this.addressMap = new ConcurrentHashMap<String, AtomicInteger>();
        this.maxConnectionsPerIp = 10;
    }
    
    @Override
    public void addBannedAddress(final String ipAddress) {
        synchronized (this.bannedAddresses) {
            this.bannedAddresses.add(ipAddress);
        }
        // monitorexit(this.bannedAddresses)
    }
    
    @Override
    public void addWhiteListAddress(final String ipAddress) {
        synchronized (this.addressWhiteList) {
            this.addressWhiteList.add(ipAddress);
        }
        // monitorexit(this.addressWhiteList)
    }
    
    @Override
    public String[] getBannedAddresses() {
        String[] set = null;
        synchronized (this.bannedAddresses) {
            set = new String[this.bannedAddresses.size()];
            set = this.bannedAddresses.toArray(set);
        }
        // monitorexit(this.bannedAddresses)
        return set;
    }
    
    @Override
    public int getMaxConnectionsPerIp() {
        return this.maxConnectionsPerIp;
    }
    
    @Override
    public String[] getWhiteListAddresses() {
        String[] set = null;
        synchronized (this.addressWhiteList) {
            set = new String[this.addressWhiteList.size()];
            set = this.addressWhiteList.toArray(set);
        }
        // monitorexit(this.addressWhiteList)
        return set;
    }
    
    @Override
    public void removeAddress(final String ipAddress) {
        synchronized (this.addressMap) {
            final AtomicInteger count = this.addressMap.get(ipAddress);
            if (count != null) {
                final int value = count.decrementAndGet();
                if (value == 0) {
                    this.addressMap.remove(ipAddress);
                }
            }
        }
        // monitorexit(this.addressMap)
    }
    
    @Override
    public void removeBannedAddress(final String ipAddress) {
        synchronized (this.bannedAddresses) {
            this.bannedAddresses.remove(ipAddress);
        }
        // monitorexit(this.bannedAddresses)
    }
    
    @Override
    public void removeWhiteListAddress(final String ipAddress) {
        synchronized (this.addressWhiteList) {
            this.addressWhiteList.remove(ipAddress);
        }
        // monitorexit(this.addressWhiteList)
    }
    
    @Override
    public void setMaxConnectionsPerIp(final int max) {
        this.maxConnectionsPerIp = max;
    }
    
    @Override
    public void validateAndAddAddress(final String ipAddress) throws RefusedAddressException {
        synchronized (this.addressWhiteList) {
            if (this.addressWhiteList.contains(ipAddress)) {
                // monitorexit(this.addressWhiteList)
                return;
            }
        }
        // monitorexit(this.addressWhiteList)
        if (this.isAddressBanned(ipAddress)) {
            throw new RefusedAddressException("Ip Address: " + ipAddress + " is banned!");
        }
        synchronized (this.addressMap) {
            AtomicInteger count = this.addressMap.get(ipAddress);
            if (count != null && count.intValue() >= this.maxConnectionsPerIp) {
                throw new RefusedAddressException("Ip Address: " + ipAddress + " has reached maximum allowed connections.");
            }
            if (count == null) {
                count = new AtomicInteger(1);
                this.addressMap.put(ipAddress, count);
            }
            else {
                count.incrementAndGet();
            }
        }
        // monitorexit(this.addressMap)
    }
    
    private boolean isAddressBanned(final String ip) {
        boolean isBanned = false;
        synchronized (this.bannedAddresses) {
            isBanned = this.bannedAddresses.contains(ip);
        }
        // monitorexit(this.bannedAddresses)
        return isBanned;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

public final class EngineThread implements IAllowedThread
{
    private String name;
    private ThreadComparisonType comparisonType;
    
    public EngineThread(final String name, final ThreadComparisonType comparisonType) {
        this.name = name;
        this.comparisonType = comparisonType;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public ThreadComparisonType getComparisonType() {
        return this.comparisonType;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

import com.google.common.net.InetAddresses;
import com.smartfoxserver.bitswarm.util.IPUtil;
import com.smartfoxserver.bitswarm.exceptions.RefusedAddressException;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashSet;
import org.slf4j.LoggerFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ConcurrentMap;
import java.util.Set;
import org.slf4j.Logger;

public class AdvancedConnectionFilter implements IConnectionFilter
{
    private final Logger log;
    private final Set<IPRange> addressWhiteList;
    private final Set<IPRange> addressBlackList;
    private final ConcurrentMap<String, AtomicInteger> addressCountMap;
    private int maxConnectionsPerIp;
    
    public AdvancedConnectionFilter() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.addressWhiteList = new HashSet<IPRange>();
        this.addressBlackList = new HashSet<IPRange>();
        this.addressCountMap = new ConcurrentHashMap<String, AtomicInteger>();
        this.maxConnectionsPerIp = 10;
    }
    
    @Override
    public void addBannedAddress(final String ipString) {
        final IPRange range = IPRangeFactory.parse(ipString);
        if (!this.isValidAddress(range.getAddress())) {
            return;
        }
        synchronized (this.addressBlackList) {
            this.addressBlackList.add(range);
        }
        // monitorexit(this.addressBlackList)
    }
    
    @Override
    public void addWhiteListAddress(final String ipString) {
        final IPRange range = IPRangeFactory.parse(ipString);
        if (!this.isValidAddress(range.getAddress())) {
            return;
        }
        synchronized (this.addressWhiteList) {
            this.addressWhiteList.add(range);
        }
        // monitorexit(this.addressWhiteList)
    }
    
    @Override
    public void removeBannedAddress(final String ipString) {
        synchronized (this.addressBlackList) {
            this.addressBlackList.remove(IPRangeFactory.parse(ipString));
        }
        // monitorexit(this.addressBlackList)
    }
    
    @Override
    public void removeWhiteListAddress(final String ipString) {
        synchronized (this.addressWhiteList) {
            this.addressWhiteList.remove(IPRangeFactory.parse(ipString));
        }
        // monitorexit(this.addressWhiteList)
    }
    
    @Override
    public String[] getBannedAddresses() {
        String[] data = null;
        synchronized (this.addressBlackList) {
            data = new String[this.addressBlackList.size()];
            int count = 0;
            for (final IPRange item : this.addressBlackList) {
                data[count++] = item.toString();
            }
        }
        // monitorexit(this.addressBlackList)
        return data;
    }
    
    @Override
    public String[] getWhiteListAddresses() {
        String[] data = null;
        synchronized (this.addressWhiteList) {
            data = new String[this.addressWhiteList.size()];
            int count = 0;
            for (final IPRange item : this.addressWhiteList) {
                data[count++] = item.toString();
            }
        }
        // monitorexit(this.addressWhiteList)
        return data;
    }
    
    @Override
    public void removeAddress(final String ipAddress) {
        synchronized (this.addressCountMap) {
            final AtomicInteger count = this.addressCountMap.get(ipAddress);
            if (count != null) {
                final int value = count.decrementAndGet();
                if (value == 0) {
                    this.addressCountMap.remove(ipAddress);
                }
            }
        }
        // monitorexit(this.addressCountMap)
    }
    
    @Override
    public int getMaxConnectionsPerIp() {
        return this.maxConnectionsPerIp;
    }
    
    @Override
    public void setMaxConnectionsPerIp(final int max) {
        this.maxConnectionsPerIp = max;
    }
    
    @Override
    public void validateAndAddAddress(final String ipAddress) throws RefusedAddressException {
        if (this.isWhiteListed(ipAddress)) {
            return;
        }
        if (this.isBlackListed(ipAddress)) {
            throw new RefusedAddressException("Ip Address: " + ipAddress + " is black listed!");
        }
        this.validateConnectionCount(ipAddress);
    }
    
    private boolean isWhiteListed(final String ipAddress) {
        synchronized (this.addressWhiteList) {
            for (final IPRange range : this.addressWhiteList) {
                if (IPUtil.isInRange(ipAddress, range)) {
                    // monitorexit(this.addressWhiteList)
                    return true;
                }
            }
        }
        // monitorexit(this.addressWhiteList)
        return false;
    }
    
    private boolean isBlackListed(final String ipAddress) {
        synchronized (this.addressBlackList) {
            for (final IPRange range : this.addressBlackList) {
                if (IPUtil.isInRange(ipAddress, range)) {
                    // monitorexit(this.addressBlackList)
                    return true;
                }
            }
        }
        // monitorexit(this.addressBlackList)
        return false;
    }
    
    private void validateConnectionCount(final String ipAddress) throws RefusedAddressException {
        synchronized (this.addressCountMap) {
            AtomicInteger count = this.addressCountMap.get(ipAddress);
            if (count != null && count.intValue() >= this.maxConnectionsPerIp) {
                throw new RefusedAddressException("Ip Address: " + ipAddress + " has reached maximum allowed connections.");
            }
            if (count == null) {
                count = new AtomicInteger(1);
                this.addressCountMap.put(ipAddress, count);
            }
            else {
                count.incrementAndGet();
            }
        }
        // monitorexit(this.addressCountMap)
    }
    
    private boolean isValidAddress(final String ipAddress) {
        boolean res = true;
        try {
            InetAddresses.forString(ipAddress);
        }
        catch (IllegalArgumentException ex) {
            res = false;
            this.log.warn("Address not added to IP Filter: " + ipAddress + ", Reason: " + ex.getMessage());
        }
        return res;
    }
}

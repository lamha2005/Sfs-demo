// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

public interface IAllowedThread
{
    String getName();
    
    ThreadComparisonType getComparisonType();
}

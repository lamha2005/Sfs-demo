// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

public class IPV4Range implements IPRange
{
    private static final char MASK_TOKEN = '/';
    protected String address;
    protected int bitMask;
    
    public IPV4Range(final String ipRangeStr) {
        final String[] parts = ipRangeStr.split("/");
        this.address = parts[0];
        this.bitMask = 0;
        if (parts.length > 1) {
            try {
                this.bitMask = Integer.valueOf(parts[1]);
            }
            catch (NumberFormatException ex) {}
        }
    }
    
    public IPV4Range(final String address, final int bitMask) {
        this.address = address;
        this.bitMask = bitMask;
    }
    
    @Override
    public String getAddress() {
        return this.address;
    }
    
    @Override
    public int getBitMask() {
        return this.bitMask;
    }
    
    @Override
    public boolean isRange() {
        return this.bitMask > 0;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(this.address);
        if (this.bitMask > 0) {
            sb.append('/').append(this.bitMask);
        }
        return sb.toString();
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = 31 * result + ((this.address == null) ? 0 : this.address.hashCode());
        result = 31 * result + this.bitMask;
        return result;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        final IPV4Range other = (IPV4Range)obj;
        if (this.address == null) {
            if (other.address != null) {
                return false;
            }
        }
        else if (!this.address.equals(other.address)) {
            return false;
        }
        return this.bitMask == other.bitMask;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core.security;

import com.smartfoxserver.bitswarm.exceptions.RefusedAddressException;

public interface IConnectionFilter
{
    void addBannedAddress(final String p0);
    
    void removeBannedAddress(final String p0);
    
    String[] getBannedAddresses();
    
    void validateAndAddAddress(final String p0) throws RefusedAddressException;
    
    void removeAddress(final String p0);
    
    void addWhiteListAddress(final String p0);
    
    void removeWhiteListAddress(final String p0);
    
    String[] getWhiteListAddresses();
    
    int getMaxConnectionsPerIp();
    
    void setMaxConnectionsPerIp(final int p0);
}

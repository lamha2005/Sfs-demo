// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.core;

public interface IMethodDispatcher
{
    void registerMethod(final String p0, final String p1);
    
    void unregisterKey(final String p0);
    
    void callMethod(final String p0, final Object[] p1) throws Exception;
}

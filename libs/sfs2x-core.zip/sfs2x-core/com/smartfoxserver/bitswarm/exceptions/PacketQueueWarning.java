// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class PacketQueueWarning extends RuntimeException
{
    public PacketQueueWarning() {
    }
    
    public PacketQueueWarning(final String message) {
        super(message);
    }
}

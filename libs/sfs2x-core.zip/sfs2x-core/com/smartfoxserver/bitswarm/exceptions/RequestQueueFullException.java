// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class RequestQueueFullException extends Exception
{
    public RequestQueueFullException() {
    }
    
    public RequestQueueFullException(final String message) {
        super(message);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class MessageQueueFullException extends Exception
{
    public MessageQueueFullException() {
    }
    
    public MessageQueueFullException(final String message) {
        super(message);
    }
}

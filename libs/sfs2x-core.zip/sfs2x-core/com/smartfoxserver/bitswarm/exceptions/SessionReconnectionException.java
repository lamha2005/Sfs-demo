// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class SessionReconnectionException extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public SessionReconnectionException(final String message) {
        super(message);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class BootSequenceException extends BitSwarmEngineException
{
    public BootSequenceException(final String message) {
        super(message);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class PacketException extends Exception
{
    private final byte[] originalPacket;
    private final byte[] writtenPacket;
    
    public PacketException() {
        this.originalPacket = null;
        this.writtenPacket = null;
    }
    
    public PacketException(final String message) {
        this(message, null, null);
    }
    
    public PacketException(final String message, final byte[] original, final byte[] written) {
        super(message);
        this.originalPacket = original;
        this.writtenPacket = written;
    }
    
    public byte[] getOriginalPacket() {
        return this.originalPacket;
    }
    
    public byte[] getWrittenPacket() {
        return this.writtenPacket;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class RefusedAddressException extends Exception
{
    public RefusedAddressException() {
    }
    
    public RefusedAddressException(final String message) {
        super(message);
    }
}

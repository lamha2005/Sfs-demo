// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.exceptions;

public class BitSwarmEngineRuntimeException extends RuntimeException
{
    public BitSwarmEngineRuntimeException() {
    }
    
    public BitSwarmEngineRuntimeException(final String msg) {
        super(msg);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util.scheduling;

import java.util.HashMap;
import java.util.Map;

public class Task
{
    private Object id;
    private Map<Object, Object> parameters;
    private volatile boolean active;
    
    public Task() {
        this.active = true;
        this.parameters = new HashMap<Object, Object>();
    }
    
    public Task(final Object id) {
        this();
        this.id = id;
    }
    
    public Task(final Object id, final Map<Object, Object> mapObj) {
        this.active = true;
        this.id = id;
        this.parameters = mapObj;
    }
    
    public Object getId() {
        return this.id;
    }
    
    public Map<Object, Object> getParameters() {
        return this.parameters;
    }
    
    public boolean isActive() {
        return this.active;
    }
    
    public void setActive(final boolean active) {
        this.active = active;
    }
}

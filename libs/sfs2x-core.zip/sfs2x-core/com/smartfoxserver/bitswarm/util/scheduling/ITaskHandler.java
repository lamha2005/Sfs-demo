// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util.scheduling;

public interface ITaskHandler
{
    void doTask(final Task p0) throws Exception;
}

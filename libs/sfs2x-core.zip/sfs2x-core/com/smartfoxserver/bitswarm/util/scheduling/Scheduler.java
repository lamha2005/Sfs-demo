// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util.scheduling;

import java.util.Iterator;
import java.util.Collection;
import com.smartfoxserver.bitswarm.util.Logging;
import java.util.List;
import java.util.concurrent.Executors;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.bitswarm.service.IService;

public class Scheduler implements IService, Runnable
{
    private static AtomicInteger schedulerId;
    private volatile int threadId;
    private long SLEEP_TIME;
    private ExecutorService taskExecutor;
    private LinkedList<ScheduledTask> taskList;
    private LinkedList<ScheduledTask> addList;
    private String serviceName;
    private Logger logger;
    private volatile boolean running;
    
    static {
        Scheduler.schedulerId = new AtomicInteger(0);
    }
    
    public Scheduler() {
        this(null);
    }
    
    public Scheduler(final Logger customLogger) {
        this.threadId = 1;
        this.SLEEP_TIME = 250L;
        this.running = false;
        Scheduler.schedulerId.incrementAndGet();
        this.taskList = new LinkedList<ScheduledTask>();
        this.addList = new LinkedList<ScheduledTask>();
        if (this.logger == null) {
            this.logger = LoggerFactory.getLogger("bootLogger");
        }
        else {
            this.logger = customLogger;
        }
    }
    
    public Scheduler(final long interval) {
        this();
        this.SLEEP_TIME = interval;
    }
    
    @Override
    public void init(final Object o) {
        this.startService();
    }
    
    @Override
    public void destroy(final Object o) {
        this.stopService();
    }
    
    @Override
    public String getName() {
        return this.serviceName;
    }
    
    @Override
    public void setName(final String name) {
        this.serviceName = name;
    }
    
    @Override
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException("not supported in this class version");
    }
    
    public void startService() {
        this.running = true;
        (this.taskExecutor = Executors.newSingleThreadExecutor()).execute(this);
    }
    
    public void stopService() {
        this.running = false;
        final List<Runnable> leftOvers = this.taskExecutor.shutdownNow();
        this.taskExecutor = null;
        this.logger.info("Scheduler stopped. Unprocessed tasks: " + leftOvers.size());
    }
    
    @Override
    public void run() {
        Thread.currentThread().setName("Scheduler" + Scheduler.schedulerId.get() + "-thread-" + this.threadId++);
        this.logger.info("Scheduler started: " + this.serviceName);
        while (this.running) {
            try {
                this.executeTasks();
                Thread.sleep(this.SLEEP_TIME);
            }
            catch (InterruptedException ie) {
                this.logger.warn("Scheduler: " + this.serviceName + " interrupted.");
            }
            catch (Exception e) {
                Logging.logStackTrace(this.logger, "Scheduler: " + this.serviceName + " caught a generic exception: " + e, e.getStackTrace());
            }
        }
    }
    
    public void addScheduledTask(final Task task, final int interval, final boolean loop, final ITaskHandler callback) {
        synchronized (this.addList) {
            this.addList.add(new ScheduledTask(task, interval, loop, callback));
        }
        // monitorexit(this.addList)
    }
    
    private void executeTasks() {
        final long now = System.currentTimeMillis();
        if (this.taskList.size() > 0) {
            synchronized (this.taskList) {
                final Iterator<ScheduledTask> it = this.taskList.iterator();
                while (it.hasNext()) {
                    final ScheduledTask t = it.next();
                    if (!t.task.isActive()) {
                        it.remove();
                    }
                    else {
                        if (now < t.expiry) {
                            continue;
                        }
                        try {
                            t.callback.doTask(t.task);
                        }
                        catch (Exception e) {
                            Logging.logStackTrace(this.logger, "Scheduler callback exception. Callback: " + t.callback + ", Exception: " + e, e.getStackTrace());
                        }
                        if (t.loop) {
                            final ScheduledTask scheduledTask = t;
                            scheduledTask.expiry += t.interval * 1000;
                        }
                        else {
                            it.remove();
                        }
                    }
                }
            }
            // monitorexit(this.taskList)
        }
        if (this.addList.size() > 0) {
            synchronized (this.taskList) {
                this.taskList.addAll(this.addList);
                this.addList.clear();
            }
            // monitorexit(this.taskList)
        }
    }
    
    private final class ScheduledTask
    {
        long expiry;
        int interval;
        boolean loop;
        ITaskHandler callback;
        Task task;
        
        public ScheduledTask(final Task t, final int interval, final boolean loop, final ITaskHandler callback) {
            this.task = t;
            this.interval = interval;
            this.expiry = System.currentTimeMillis() + interval * 1000;
            this.callback = callback;
            this.loop = loop;
        }
        
        public int getInterval() {
            return this.interval;
        }
        
        public Task getTask() {
            return this.task;
        }
        
        public ITaskHandler getCallback() {
            return this.callback;
        }
        
        public long getExpiry() {
            return this.expiry;
        }
        
        public boolean isLooping() {
            return this.loop;
        }
    }
}

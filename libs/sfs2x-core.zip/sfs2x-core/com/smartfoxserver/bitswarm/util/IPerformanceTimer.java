// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util;

public interface IPerformanceTimer
{
    void startSampling();
    
    void stopSampling();
    
    double getAverageMillis();
    
    int getMaxSamples();
}

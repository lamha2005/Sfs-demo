// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util;

public class LagSimulator
{
    static void lagMe(final int milliseconds) throws InterruptedException {
        Thread.sleep(milliseconds);
    }
}

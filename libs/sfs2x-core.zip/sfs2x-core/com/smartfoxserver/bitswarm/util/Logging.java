// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util;

import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.ConsoleHandler;
import java.util.logging.Logger;
import java.util.logging.Level;

public class Logging
{
    private static final String NEW_LINE;
    private static final String TAB = "\t";
    
    static {
        NEW_LINE = System.getProperty("line.separator");
    }
    
    public static void changeConsoleHandlerLevel(final Level newLevel) {
        final Logger rootLogger = Logger.getLogger("");
        final Handler[] handlers = rootLogger.getHandlers();
        if (handlers.length > 0) {
            final Handler firstHandler = handlers[0];
            if (firstHandler != null && firstHandler instanceof ConsoleHandler) {
                firstHandler.setLevel(newLevel);
            }
        }
    }
    
    public static Level getConsoleHandlerLevel() {
        Level level = null;
        final Logger rootLogger = Logger.getLogger("");
        final Handler[] handlers = rootLogger.getHandlers();
        if (handlers.length > 0) {
            final Handler firstHandler = handlers[0];
            if (firstHandler != null && firstHandler instanceof ConsoleHandler) {
                level = firstHandler.getLevel();
            }
        }
        return level;
    }
    
    public static void changeConsoleHandlerFormatter(final Formatter formatter) {
        final Logger rootLogger = Logger.getLogger("");
        final Handler[] handlers = rootLogger.getHandlers();
        if (handlers.length > 0) {
            final Handler firstHandler = handlers[0];
            if (firstHandler == null || !(firstHandler instanceof ConsoleHandler)) {
                throw new RuntimeException("Could not change the ConsoleHandler's formatter!");
            }
            firstHandler.setFormatter(formatter);
        }
    }
    
    public static void logStackTrace(final org.slf4j.Logger logger, final Throwable throwable) {
        logStackTrace(logger, throwable.toString(), throwable.getStackTrace());
    }
    
    public static void logStackTrace(final org.slf4j.Logger logger, final StackTraceElement[] stackTrace) {
        logStackTrace(logger, null, stackTrace);
    }
    
    public static void logStackTrace(final org.slf4j.Logger logger, final String cause, final StackTraceElement[] stackTrace) {
        final StringBuilder sb = new StringBuilder();
        if (cause != null) {
            sb.append(cause).append(Logging.NEW_LINE);
        }
        for (final StackTraceElement element : stackTrace) {
            sb.append("\t").append(element).append(Logging.NEW_LINE);
        }
        logger.warn(sb.toString());
    }
    
    public static String formatStackTrace(final StackTraceElement[] elements) {
        final StringBuilder sb = new StringBuilder();
        for (final StackTraceElement element : elements) {
            sb.append(element).append(Logging.NEW_LINE);
        }
        return sb.toString();
    }
}

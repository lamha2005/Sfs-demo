// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util.scheduling2;

import java.util.List;
import org.slf4j.LoggerFactory;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import org.slf4j.Logger;
import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.bitswarm.service.IService;

public class Scheduler implements IService
{
    private static AtomicInteger schedulerId;
    private String serviceName;
    private Logger logger;
    private final ScheduledThreadPoolExecutor executor;
    
    static {
        Scheduler.schedulerId = new AtomicInteger(0);
    }
    
    public Scheduler(final int poolSize) {
        this(poolSize, null);
    }
    
    public Scheduler(final int poolSize, final Logger customLogger) {
        if (poolSize < 1) {
            throw new IllegalArgumentException("Cannot create a thread pool of size: " + poolSize);
        }
        this.serviceName = "Scheduler-" + Scheduler.schedulerId.getAndIncrement();
        this.executor = new ScheduledThreadPoolExecutor(poolSize);
        if (this.logger == null) {
            this.logger = LoggerFactory.getLogger("bootLogger");
        }
        else {
            this.logger = customLogger;
        }
    }
    
    @Override
    public void init(final Object o) {
        this.logger.info(String.valueOf(this.serviceName) + " started.");
    }
    
    @Override
    public void destroy(final Object o) {
        final List<Runnable> awaitingExecution = this.executor.shutdownNow();
        this.logger.info(String.valueOf(this.serviceName) + " stopping. Tasks awaiting execution: " + awaitingExecution.size());
    }
    
    @Override
    public String getName() {
        return this.serviceName;
    }
    
    @Override
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException(String.valueOf(this.serviceName) + ": operation not supported.");
    }
    
    @Override
    public void setName(final String name) {
        this.serviceName = name;
    }
    
    public void resizeThreadPool(final int poolSize) {
        this.executor.setCorePoolSize(poolSize);
    }
    
    public int getThreadPoolSize() {
        return this.executor.getCorePoolSize();
    }
    
    public int getActiveThreadCount() {
        return this.executor.getActiveCount();
    }
}

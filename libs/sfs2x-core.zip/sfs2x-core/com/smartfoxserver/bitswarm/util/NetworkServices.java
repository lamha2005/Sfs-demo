// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util;

import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.data.BufferType;

public class NetworkServices
{
    public static ByteBuffer allocateBuffer(final int size, final BufferType type) {
        ByteBuffer bb = null;
        if (type == BufferType.DIRECT) {
            bb = ByteBuffer.allocateDirect(size);
        }
        else if (type == BufferType.HEAP) {
            bb = ByteBuffer.allocate(size);
        }
        return bb;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util;

import java.net.InetAddress;
import com.google.common.net.InetAddresses;
import com.smartfoxserver.bitswarm.core.security.IPRange;
import java.net.SocketAddress;

public final class IPUtil
{
    public static String[] getIpPortTuple(final SocketAddress address) {
        return getIpPortTuple(address.toString());
    }
    
    private static String[] getIpPortTuple(final String address) {
        final String[] tuple = { getIP(address), String.valueOf(getPort(address)) };
        return tuple;
    }
    
    public static String getIP(final SocketAddress address) {
        return getIP(address.toString());
    }
    
    private static String getIP(final String str) {
        final int colonSep = str.lastIndexOf(58);
        return str.substring(1, colonSep);
    }
    
    public static int getPort(final SocketAddress address) {
        return getPort(address.toString());
    }
    
    private static int getPort(final String str) {
        int res = 0;
        final int sep = str.lastIndexOf(58);
        if (sep > 0) {
            try {
                res = Integer.parseInt(str.substring(sep + 1));
            }
            catch (NumberFormatException ex) {}
        }
        return res;
    }
    
    public static boolean isInRange(final String sourceIp, final IPRange ipRange) {
        final int address = getIntAddress(sourceIp);
        final int subnet = getIntAddress(ipRange.getAddress());
        final int mask = -1 << 32 - ipRange.getBitMask();
        return (subnet & mask) == (address & mask);
    }
    
    private static int getIntAddress(final String addrStr) {
        final InetAddress addr = InetAddresses.forString(addrStr);
        final byte[] b = addr.getAddress();
        final int ii = (b[0] & 0xFF) << 24 | (b[1] & 0xFF) << 16 | (b[2] & 0xFF) << 8 | (b[3] & 0xFF) << 0;
        return ii;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util;

import com.smartfoxserver.bitswarm.exceptions.BitSwarmEngineException;
import java.io.File;

public class FileServices
{
    private static final String WINDOWS_SEPARATOR = "\\";
    private static final String UNIX_SEPARATOR = "/";
    
    public static void recursiveMakeDir(final String basePath, final String dirStructure) throws BitSwarmEngineException {
        dirStructure.replace("\\", "/");
        final String finalPath = String.valueOf(basePath) + (basePath.endsWith("/") ? "" : "/") + dirStructure;
        final File folder = new File(finalPath);
        System.out.println("Creating: " + finalPath);
        if (folder.exists()) {
            return;
        }
        final boolean ok = folder.mkdirs();
        if (!ok) {
            throw new BitSwarmEngineException("Was not able to create the following folder(s): " + dirStructure);
        }
    }
}

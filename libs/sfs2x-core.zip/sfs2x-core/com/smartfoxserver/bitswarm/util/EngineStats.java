// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.util;

import com.smartfoxserver.bitswarm.core.BitSwarmEngine;

public class EngineStats
{
    public static long getIncomingBytes() {
        return BitSwarmEngine.getInstance().getSocketReader().getReadBytes() + BitSwarmEngine.getInstance().getDatagramReader().getReadBytes();
    }
    
    public static long getIncomingPackets() {
        return BitSwarmEngine.getInstance().getSocketReader().getReadPackets();
    }
    
    public static long getOutgoingBytes() {
        return BitSwarmEngine.getInstance().getSocketWriter().getWrittenBytes();
    }
    
    public static long getOutgoingPackets() {
        return BitSwarmEngine.getInstance().getSocketWriter().getWrittenPackets();
    }
    
    public static long getOutgoingDroppedPackets() {
        return BitSwarmEngine.getInstance().getSocketWriter().getDroppedPacketsCount();
    }
    
    public static int getRestartCount() {
        return BitSwarmEngine.getInstance().getRestartCount();
    }
}

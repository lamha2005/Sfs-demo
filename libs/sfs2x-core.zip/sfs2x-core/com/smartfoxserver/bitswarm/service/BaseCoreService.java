// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.service;

import java.util.Iterator;
import com.smartfoxserver.bitswarm.events.IEvent;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ConcurrentHashMap;
import com.smartfoxserver.bitswarm.events.IEventListener;
import java.util.Set;
import java.util.Map;
import com.smartfoxserver.bitswarm.events.IEventDispatcher;

public abstract class BaseCoreService implements IService, IEventDispatcher
{
    private String serviceName;
    private Map<String, Set<IEventListener>> listenersByEvent;
    
    public BaseCoreService() {
        this.listenersByEvent = new ConcurrentHashMap<String, Set<IEventListener>>();
    }
    
    @Override
    public void init(final Object o) {
    }
    
    @Override
    public void destroy(final Object o) {
        this.listenersByEvent.clear();
    }
    
    @Override
    public String getName() {
        return this.serviceName;
    }
    
    @Override
    public void setName(final String name) {
        this.serviceName = name;
    }
    
    @Override
    public void handleMessage(final Object message) {
    }
    
    @Override
    public synchronized void addEventListener(final String eventType, final IEventListener listener) {
        Set<IEventListener> listeners = this.listenersByEvent.get(eventType);
        if (listeners == null) {
            listeners = new CopyOnWriteArraySet<IEventListener>();
            this.listenersByEvent.put(eventType, listeners);
        }
        listeners.add(listener);
    }
    
    @Override
    public boolean hasEventListener(final String eventType) {
        boolean found = false;
        final Set<IEventListener> listeners = this.listenersByEvent.get(eventType);
        if (listeners != null && listeners.size() > 0) {
            found = true;
        }
        return found;
    }
    
    @Override
    public void removeEventListener(final String eventType, final IEventListener listener) {
        final Set<IEventListener> listeners = this.listenersByEvent.get(eventType);
        if (listeners != null) {
            listeners.remove(listener);
        }
    }
    
    @Override
    public void dispatchEvent(final IEvent event) {
        final Set<IEventListener> listeners = this.listenersByEvent.get(event.getName());
        if (listeners != null && listeners.size() > 0) {
            for (final IEventListener listenerObj : listeners) {
                listenerObj.handleEvent(event);
            }
        }
    }
}

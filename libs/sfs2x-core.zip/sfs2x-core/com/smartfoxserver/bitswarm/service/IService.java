// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.service;

public interface IService
{
    void init(final Object p0);
    
    void destroy(final Object p0);
    
    void handleMessage(final Object p0) throws Exception;
    
    String getName();
    
    void setName(final String p0);
}

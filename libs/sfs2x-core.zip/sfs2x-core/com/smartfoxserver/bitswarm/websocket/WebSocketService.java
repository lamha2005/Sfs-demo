// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket;

import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import com.smartfoxserver.bitswarm.websocket.netty.WebSocketBoot;
import com.smartfoxserver.bitswarm.service.BaseCoreService;

public class WebSocketService extends BaseCoreService
{
    private volatile boolean inited;
    private final WebSocketStats webSocketStats;
    private final WebSocketProtocolCodec protocolCodec;
    private final boolean isActive;
    
    public WebSocketService() {
        this.inited = false;
        this.isActive = true;
        this.webSocketStats = new WebSocketStats();
        this.protocolCodec = new WebSocketProtocolCodec(this.webSocketStats);
    }
    
    @Override
    public void init(final Object o) {
        if (this.inited) {
            throw new IllegalArgumentException("Service is already initialized. Destroy it first!");
        }
        this.inited = true;
        new WebSocketBoot((WebSocketConfig)o, this.protocolCodec);
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
    }
    
    public boolean isActive() {
        return this.isActive;
    }
    
    public WebSocketStats getWebSocketStats() {
        return this.webSocketStats;
    }
    
    public WebSocketProtocolCodec getProtocolCodec() {
        return this.protocolCodec;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket;

public class WebSocketStats
{
    private volatile long readBytes;
    private volatile long readPackets;
    private volatile long writtenBytes;
    private volatile long writtenPackets;
    private volatile long droppedInPackets;
    
    public WebSocketStats() {
        this.readBytes = 0L;
        this.readPackets = 0L;
        this.writtenBytes = 0L;
        this.writtenPackets = 0L;
        this.droppedInPackets = 0L;
    }
    
    public void addDroppedInPacket() {
        ++this.droppedInPackets;
    }
    
    public long getDroppedInPackets() {
        return this.droppedInPackets;
    }
    
    public void addReadBytes(final int value) {
        this.readBytes += value;
    }
    
    public void addReadPackets(final int value) {
        this.readPackets += value;
    }
    
    public void addWrittenBytes(final int value) {
        this.writtenBytes += value;
    }
    
    public void addWrittenPackets(final int value) {
        this.writtenPackets += value;
    }
    
    public long getReadBytes() {
        return this.readBytes;
    }
    
    public long getReadPackets() {
        return this.readPackets;
    }
    
    public long getWrittenBytes() {
        return this.writtenBytes;
    }
    
    public long getWrittenPackets() {
        return this.writtenPackets;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket;

import java.net.SocketAddress;

public interface IWebSocketChannel
{
    void write(final String p0);
    
    SocketAddress getRemoteAddress();
    
    SocketAddress getLocalAddress();
    
    void close();
}

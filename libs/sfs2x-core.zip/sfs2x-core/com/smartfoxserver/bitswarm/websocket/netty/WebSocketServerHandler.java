// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket.netty;

import java.net.SocketAddress;
import java.nio.channels.ClosedChannelException;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.ChannelFutureListener;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.bitswarm.io.protocols.ProtocolType;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.data.Packet;
import org.jboss.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import org.jboss.netty.handler.codec.http.websocketx.PongWebSocketFrame;
import org.jboss.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import org.jboss.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
import org.jboss.netty.handler.codec.http.HttpResponse;
import org.jboss.netty.handler.codec.http.websocketx.WebSocketServerHandshakerFactory;
import org.jboss.netty.handler.codec.http.HttpMessage;
import org.jboss.netty.handler.codec.http.HttpHeaders;
import org.jboss.netty.handler.codec.http.DefaultHttpResponse;
import org.jboss.netty.handler.codec.http.HttpResponseStatus;
import org.jboss.netty.handler.codec.http.HttpVersion;
import org.jboss.netty.handler.codec.http.websocketx.WebSocketFrame;
import org.jboss.netty.handler.codec.http.HttpRequest;
import org.jboss.netty.channel.MessageEvent;
import com.smartfoxserver.bitswarm.exceptions.RefusedAddressException;
import com.smartfoxserver.bitswarm.util.IPUtil;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.slf4j.LoggerFactory;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.util.CharsetUtil;
import org.jboss.netty.channel.Channel;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.concurrent.Executor;
import com.smartfoxserver.bitswarm.core.security.IConnectionFilter;
import com.smartfoxserver.bitswarm.websocket.WebSocketStats;
import org.jboss.netty.handler.codec.http.websocketx.WebSocketServerHandshaker;
import com.smartfoxserver.bitswarm.websocket.WebSocketService;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import org.jboss.netty.buffer.ChannelBuffer;
import com.smartfoxserver.bitswarm.websocket.IWebSocketChannel;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;

public class WebSocketServerHandler extends SimpleChannelUpstreamHandler implements IWebSocketChannel
{
    private static final ChannelBuffer HTTP_INDEX_BUFFER;
    public static final String WEBSOCKET_PATH = "/websocket";
    private final BitSwarmEngine engine;
    private final SmartFoxServer sfs;
    private final ISessionManager sessionManager;
    private final IProtocolCodec codec;
    private final Logger logger;
    private final WebSocketService webSocketService;
    private WebSocketServerHandshaker handshaker;
    private final WebSocketStats webSocketStats;
    private final int MAX_REQ_SIZE;
    private final IConnectionFilter connFilter;
    private final boolean isSSL;
    private final Executor systemThreadPool;
    private ISession sfsSession;
    private Channel wsChannel;
    
    static {
        HTTP_INDEX_BUFFER = ChannelBuffers.copiedBuffer((CharSequence)"<html><header><title>SFS2X Websocket</title></header><body><h3>{ SFS2X Websocket Index Page�}</h3></body></html>", CharsetUtil.UTF_8);
    }
    
    public WebSocketServerHandler(final IProtocolCodec codec, final boolean isSSL) {
        this.codec = codec;
        this.isSSL = isSSL;
        this.engine = BitSwarmEngine.getInstance();
        this.sfs = SmartFoxServer.getInstance();
        this.connFilter = this.engine.getSocketAcceptor().getConnectionFilter();
        this.systemThreadPool = this.sfs.getSystemThreadPool();
        this.sessionManager = this.engine.getSessionManager();
        this.MAX_REQ_SIZE = this.engine.getConfiguration().getMaxIncomingRequestSize();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.webSocketService = (WebSocketService)this.engine.getServiceByName("webSocketEngine");
        this.webSocketStats = this.webSocketService.getWebSocketStats();
    }
    
    public void channelConnected(final ChannelHandlerContext ctx, final ChannelStateEvent e) throws Exception {
        try {
            this.wsChannel = ctx.getChannel();
            this.connFilter.validateAndAddAddress(IPUtil.getIP(this.wsChannel.getRemoteAddress()));
            this.sfsSession = this.sessionManager.createWebSocketSession(this);
            this.sessionManager.addSession(this.sfsSession);
        }
        catch (RefusedAddressException error) {
            this.logger.warn("Refused connection. " + error.getMessage());
            ctx.getChannel().close();
        }
    }
    
    public void channelDisconnected(final ChannelHandlerContext ctx, final ChannelStateEvent e) throws Exception {
        if (this.sfsSession == null) {
            return;
        }
        this.sfsSession.setConnected(false);
        this.sfs.getSessionManager().onSocketDisconnected(this.sfsSession);
    }
    
    public void messageReceived(final ChannelHandlerContext ctx, final MessageEvent e) throws Exception {
        final Object msg = e.getMessage();
        if (msg instanceof HttpRequest) {
            this.handleHttpRequest(ctx, (HttpRequest)msg);
        }
        else if (msg instanceof WebSocketFrame) {
            this.handleWebSocketFrame(ctx, (WebSocketFrame)msg);
        }
    }
    
    private void handleHttpRequest(final ChannelHandlerContext ctx, final HttpRequest req) throws Exception {
        if ("/".equals(req.getUri())) {
            final HttpResponse res = (HttpResponse)new DefaultHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
            res.headers().set("Content-Type", (Object)"text/html; charset=UTF-8");
            HttpHeaders.setContentLength((HttpMessage)res, (long)WebSocketServerHandler.HTTP_INDEX_BUFFER.readableBytes());
            res.setContent(WebSocketServerHandler.HTTP_INDEX_BUFFER);
            this.sendHttpResponse(ctx, req, res);
            return;
        }
        final WebSocketServerHandshakerFactory wsFactory = new WebSocketServerHandshakerFactory(this.getWebSocketLocation(req), "*", false);
        this.handshaker = wsFactory.newHandshaker(req);
        if (this.handshaker == null) {
            wsFactory.sendUnsupportedWebSocketVersionResponse(ctx.getChannel());
        }
        else {
            this.handshaker.handshake(ctx.getChannel(), req).addListener(WebSocketServerHandshaker.HANDSHAKE_LISTENER);
        }
    }
    
    private void handleWebSocketFrame(final ChannelHandlerContext ctx, final WebSocketFrame frame) {
        if (frame instanceof CloseWebSocketFrame) {
            this.handshaker.close(ctx.getChannel(), (CloseWebSocketFrame)frame);
            return;
        }
        if (frame instanceof PingWebSocketFrame) {
            ctx.getChannel().write((Object)new PongWebSocketFrame(frame.getBinaryData()));
            return;
        }
        if (!(frame instanceof TextWebSocketFrame)) {
            return;
        }
        final String rawRequest = ((TextWebSocketFrame)frame).getText();
        final int reqLen = rawRequest.length();
        if (reqLen > this.MAX_REQ_SIZE) {
            final User uu = this.sfs.getUserManager().getUserBySession(this.sfsSession);
            this.logger.warn(String.format("Refused WebSocket request. Too large: %s, From: %s ", (reqLen > 10240) ? (String.valueOf(reqLen / 1024) + "KB") : reqLen, (uu != null) ? uu : this.sfsSession));
            return;
        }
        this.webSocketStats.addReadBytes(reqLen);
        this.webSocketStats.addReadBytes(reqLen);
        this.webSocketStats.addReadPackets(1);
        final IPacket packet = new Packet();
        packet.setData(rawRequest);
        packet.setSender(this.sfsSession);
        packet.setOriginalSize(rawRequest.length());
        packet.setTransportType(TransportType.TCP);
        packet.setAttribute("type", ProtocolType.TEXT);
        this.systemThreadPool.execute(new WSIOExecutor(packet));
    }
    
    private void sendHttpResponse(final ChannelHandlerContext ctx, final HttpRequest req, final HttpResponse res) {
        if (res.getStatus().getCode() != 200) {
            res.setContent(ChannelBuffers.copiedBuffer((CharSequence)res.getStatus().toString(), CharsetUtil.UTF_8));
            HttpHeaders.setContentLength((HttpMessage)res, (long)res.getContent().readableBytes());
        }
        final ChannelFuture f = ctx.getChannel().write((Object)res);
        if (!HttpHeaders.isKeepAlive((HttpMessage)req) || res.getStatus().getCode() != 200) {
            f.addListener(ChannelFutureListener.CLOSE);
        }
    }
    
    public void exceptionCaught(final ChannelHandlerContext ctx, final ExceptionEvent e) throws Exception {
        if (e.getCause() instanceof ClosedChannelException) {
            return;
        }
        this.logger.warn(e.getCause().toString());
        if (this.wsChannel.isOpen()) {
            this.wsChannel.close();
        }
    }
    
    private String getWebSocketLocation(final HttpRequest req) {
        return String.valueOf(this.isSSL ? "wss://" : "ws://") + req.headers().get("Host") + "/websocket";
    }
    
    public void close() {
        this.wsChannel.close();
    }
    
    public void write(final String message) {
        this.wsChannel.write((Object)new TextWebSocketFrame(message));
    }
    
    public void write(final byte[] message) {
    }
    
    public ISession getSFSSession() {
        return null;
    }
    
    public Object getWSSession() {
        return null;
    }
    
    public SocketAddress getLocalAddress() {
        return this.wsChannel.getLocalAddress();
    }
    
    public SocketAddress getRemoteAddress() {
        return this.wsChannel.getRemoteAddress();
    }
    
    private final class WSIOExecutor implements Runnable
    {
        private final IPacket packet;
        
        public WSIOExecutor(final IPacket packet) {
            this.packet = packet;
        }
        
        @Override
        public void run() {
            WebSocketServerHandler.this.codec.onPacketRead(this.packet);
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket.netty;

import java.security.SecureRandom;
import javax.net.ssl.TrustManager;
import javax.net.ssl.KeyManagerFactory;
import java.io.InputStream;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.Security;
import org.slf4j.LoggerFactory;
import javax.net.ssl.SSLContext;
import org.slf4j.Logger;

public final class WebSocketSslServerSslContext
{
    private static final Logger logger;
    private static final String PROTOCOL = "TLS";
    private final SSLContext _serverContext;
    
    static {
        logger = LoggerFactory.getLogger((Class)WebSocketSslServerSslContext.class);
    }
    
    public static WebSocketSslServerSslContext getInstance() {
        return SingletonHolder.INSTANCE;
    }
    
    private WebSocketSslServerSslContext() {
        SSLContext serverContext = null;
        try {
            String algorithm = Security.getProperty("ssl.KeyManagerFactory.algorithm");
            if (algorithm == null) {
                algorithm = "SunX509";
            }
            try {
                final String keyStoreFilePath = System.getProperty("keystore.file.path");
                final String keyStoreFilePassword = System.getProperty("keystore.file.password");
                final KeyStore ks = KeyStore.getInstance("JKS");
                final FileInputStream fin = new FileInputStream(keyStoreFilePath);
                ks.load(fin, keyStoreFilePassword.toCharArray());
                final KeyManagerFactory kmf = KeyManagerFactory.getInstance(algorithm);
                kmf.init(ks, keyStoreFilePassword.toCharArray());
                serverContext = SSLContext.getInstance("TLS");
                serverContext.init(kmf.getKeyManagers(), null, null);
            }
            catch (Exception e) {
                throw new Error("Failed to initialize the server-side SSLContext", e);
            }
        }
        catch (Exception ex) {
            if (WebSocketSslServerSslContext.logger.isErrorEnabled()) {
                WebSocketSslServerSslContext.logger.error("Error initializing SslContextManager. " + ex.getMessage(), (Throwable)ex);
            }
            return;
        }
        finally {
            this._serverContext = serverContext;
        }
        this._serverContext = serverContext;
    }
    
    public SSLContext getServerContext() {
        return this._serverContext;
    }
    
    private interface SingletonHolder
    {
        public static final WebSocketSslServerSslContext INSTANCE = new WebSocketSslServerSslContext(null);
    }
}

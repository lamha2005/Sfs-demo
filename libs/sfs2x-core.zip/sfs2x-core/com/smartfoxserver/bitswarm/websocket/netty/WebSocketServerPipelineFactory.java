// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket.netty;

import javax.net.ssl.SSLEngine;
import org.jboss.netty.handler.codec.http.HttpResponseEncoder;
import org.jboss.netty.handler.codec.http.HttpChunkAggregator;
import org.jboss.netty.handler.codec.http.HttpRequestDecoder;
import org.jboss.netty.channel.ChannelHandler;
import org.jboss.netty.handler.ssl.SslHandler;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ChannelPipeline;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import org.jboss.netty.channel.ChannelPipelineFactory;

public class WebSocketServerPipelineFactory implements ChannelPipelineFactory
{
    private final IProtocolCodec codec;
    private boolean isSSL;
    
    public WebSocketServerPipelineFactory(final IProtocolCodec codec, final boolean isSSL) {
        this.isSSL = false;
        this.isSSL = isSSL;
        this.codec = codec;
    }
    
    public ChannelPipeline getPipeline() throws Exception {
        final ChannelPipeline pipeline = Channels.pipeline();
        if (this.isSSL) {
            final SSLEngine engine = WebSocketSslServerSslContext.getInstance().getServerContext().createSSLEngine();
            engine.setUseClientMode(false);
            pipeline.addLast("ssl", (ChannelHandler)new SslHandler(engine));
        }
        pipeline.addLast("decoder", (ChannelHandler)new HttpRequestDecoder());
        pipeline.addLast("aggregator", (ChannelHandler)new HttpChunkAggregator(65536));
        pipeline.addLast("encoder", (ChannelHandler)new HttpResponseEncoder());
        pipeline.addLast("handler", (ChannelHandler)new WebSocketServerHandler(this.codec, this.isSSL));
        return pipeline;
    }
}

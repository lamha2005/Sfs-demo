// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket.netty;

import java.net.SocketAddress;
import java.net.InetSocketAddress;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.ChannelFactory;
import org.jboss.netty.bootstrap.ServerBootstrap;
import java.util.concurrent.Executor;
import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;
import java.util.concurrent.Executors;
import com.smartfoxserver.bitswarm.util.Logging;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import com.smartfoxserver.bitswarm.websocket.WebSocketConfig;

public class WebSocketBoot
{
    private final WebSocketConfig config;
    private final IProtocolCodec protocolCodec;
    private final Logger bootLogger;
    
    public WebSocketBoot(final WebSocketConfig cfg, final IProtocolCodec codec) {
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        this.config = cfg;
        this.protocolCodec = codec;
        if (!cfg.isActive()) {
            return;
        }
        try {
            this.boot();
            this.bootLogger.info("WebSocketService started: " + this.config.getHost() + ":" + this.config.getPort());
        }
        catch (Exception problem) {
            this.bootLogger.error("Failed starting up websocket engine: " + problem.getMessage());
            Logging.logStackTrace(this.bootLogger, problem);
        }
    }
    
    private void boot() throws Exception {
        final ServerBootstrap boot = new ServerBootstrap((ChannelFactory)new NioServerSocketChannelFactory((Executor)Executors.newCachedThreadPool(), (Executor)Executors.newCachedThreadPool()));
        int webSocketPort = this.config.getPort();
        if (this.config.isSSL()) {
            webSocketPort = this.config.getSslPort();
            System.setProperty("keystore.file.path", this.config.getKeyStoreFile());
            System.setProperty("keystore.file.password", this.config.getKeyStorePassword());
        }
        boot.setPipelineFactory((ChannelPipelineFactory)new WebSocketServerPipelineFactory(this.protocolCodec, this.config.isSSL()));
        boot.bind((SocketAddress)new InetSocketAddress(this.config.getHost(), webSocketPort));
    }
}

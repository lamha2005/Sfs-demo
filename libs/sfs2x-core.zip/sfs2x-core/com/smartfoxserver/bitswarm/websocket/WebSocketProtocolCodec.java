// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket;

import com.smartfoxserver.bitswarm.io.IOHandler;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.bitswarm.io.Request;
import java.util.Iterator;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.io.protocols.AbstractProtocolCodec;

public class WebSocketProtocolCodec extends AbstractProtocolCodec
{
    private static final String CONTROLLER_ID = "c";
    private static final String ACTION_ID = "a";
    private static final String PARAM_ID = "p";
    private final WebSocketStats webSocketStats;
    
    public WebSocketProtocolCodec(final WebSocketStats wss) {
        this.webSocketStats = wss;
    }
    
    @Override
    public void onPacketRead(final IPacket packet) {
        if (packet == null) {
            throw new IllegalStateException("WebSocket null packet!");
        }
        ISFSObject requestObject = null;
        if (packet.isTcp()) {
            final String buff = (String)packet.getData();
            try {
                requestObject = SFSObject.newFromJsonData(buff);
            }
            catch (Exception e) {
                this.logger.warn("Error deserializing request: " + e);
            }
        }
        if (requestObject != null) {
            if (this.logger.isDebugEnabled()) {
                this.logger.debug(requestObject.getDump());
            }
            this.dispatchRequest(requestObject, packet);
        }
    }
    
    @Override
    public void onPacketWrite(final IResponse response) {
        final ISFSObject packet = (ISFSObject)SFSObject.newInstance();
        packet.putByte("c", (byte)response.getTargetController());
        packet.putShort("a", (short)response.getId());
        packet.putSFSObject("p", (ISFSObject)response.getContent());
        if (response.getRecipients().size() > 0 && this.logger.isDebugEnabled()) {
            this.logger.debug("{OUT}: " + SystemRequest.fromId(response.getId()));
        }
        final String rawPacket = packet.toJson();
        for (final ISession session : response.getRecipients()) {
            final int bytesLen = rawPacket.length();
            final IWebSocketChannel channel = (IWebSocketChannel)session.getSystemProperty("wsChannel");
            channel.write(rawPacket);
            session.addWrittenBytes(rawPacket.length());
            this.webSocketStats.addWrittenPackets(1);
            this.webSocketStats.addWrittenBytes(bytesLen);
        }
    }
    
    private void dispatchRequest(final ISFSObject requestObject, final IPacket packet) {
        if (requestObject.isNull("c")) {
            throw new IllegalStateException("Request rejected: No Controller ID in request!");
        }
        if (requestObject.isNull("a")) {
            throw new IllegalStateException("Request rejected: No Action ID in request!");
        }
        if (requestObject.isNull("p")) {
            throw new IllegalStateException("Request rejected: Missing parameters field!");
        }
        final IRequest request = new Request();
        Object controllerKey = null;
        request.setId(Short.parseShort(requestObject.getInt("a").toString()));
        controllerKey = Byte.parseByte(requestObject.getInt("c").toString());
        request.setContent(requestObject.getSFSObject("p"));
        request.setSender(packet.getSender());
        request.setTransportType(packet.getTransportType());
        if (packet.isUdp()) {
            request.setAttribute("$FS_REQUEST_UDP_TIMESTAMP", requestObject.getLong("i"));
        }
        this.dispatchRequestToController(request, controllerKey);
    }
    
    @Override
    public IOHandler getIOHandler() {
        throw new UnsupportedOperationException("Now Allowed!");
    }
    
    @Override
    public void setIOHandler(final IOHandler handler) {
        throw new UnsupportedOperationException("Now Allowed!");
    }
}

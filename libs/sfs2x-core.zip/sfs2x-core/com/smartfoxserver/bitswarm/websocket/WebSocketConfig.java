// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.websocket;

import java.util.List;

public class WebSocketConfig
{
    public static final String LOCALHOST = "127.0.0.1";
    private int port;
    private int sslPort;
    private String host;
    private List<String> validDomains;
    private boolean isActive;
    private boolean isSSL;
    private String keyStoreFile;
    private String keyStorePassword;
    
    public WebSocketConfig() {
        this.port = 8888;
        this.sslPort = 8889;
        this.host = "127.0.0.1";
        this.isActive = false;
        this.isSSL = true;
        this.keyStoreFile = "config/keystore.jks";
        this.keyStorePassword = "password";
    }
    
    public int getPort() {
        return this.port;
    }
    
    public void setPort(final int port) {
        this.port = port;
    }
    
    public int getSslPort() {
        return this.sslPort;
    }
    
    public void setSslPort(final int sslPort) {
        this.sslPort = sslPort;
    }
    
    public String getHost() {
        return this.host;
    }
    
    public void setHost(final String host) {
        this.host = host;
    }
    
    public List<String> getValidDomains() {
        return this.validDomains;
    }
    
    public void setValidDomains(final List<String> validDomains) {
        this.validDomains = validDomains;
    }
    
    public boolean isActive() {
        return this.isActive;
    }
    
    public void setActive(final boolean isActive) {
        this.isActive = isActive;
    }
    
    public String getKeyStoreFile() {
        return this.keyStoreFile;
    }
    
    public void setKeyStoreFile(final String keyStorePath) {
        this.keyStoreFile = keyStorePath;
    }
    
    public String getKeyStorePassword() {
        return this.keyStorePassword;
    }
    
    public void setKeyStorePassword(final String keyStorePassword) {
        this.keyStorePassword = keyStorePassword;
    }
    
    public boolean isSSL() {
        return this.isSSL;
    }
    
    public void setSSL(final boolean isSSL) {
        this.isSSL = isSSL;
    }
}

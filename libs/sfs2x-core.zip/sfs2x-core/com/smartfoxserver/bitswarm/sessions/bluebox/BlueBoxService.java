// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions.bluebox;

import com.smartfoxserver.bitswarm.service.IService;

public class BlueBoxService implements IService
{
    private BlueBoxStats bbStats;
    
    public BlueBoxService() {
        this.bbStats = new BlueBoxStats();
    }
    
    @Override
    public void init(final Object o) {
    }
    
    @Override
    public void destroy(final Object o) {
    }
    
    public BlueBoxStats getBbStats() {
        return this.bbStats;
    }
    
    @Override
    public void handleMessage(final Object message) {
    }
    
    @Override
    public String getName() {
        return "BlueBox Service";
    }
    
    @Override
    public void setName(final String name) {
    }
}

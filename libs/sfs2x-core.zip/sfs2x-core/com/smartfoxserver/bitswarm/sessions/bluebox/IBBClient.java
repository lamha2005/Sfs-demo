// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions.bluebox;

import com.smartfoxserver.bitswarm.sessions.IPacketQueue;
import java.util.List;
import org.eclipse.jetty.continuation.Continuation;
import com.smartfoxserver.bitswarm.sessions.ISession;

public interface IBBClient
{
    ISession getSession();
    
    String getSessionId();
    
    long getCreationTime();
    
    long getLastActivityTime();
    
    long getLastRequestTime();
    
    String getIpAddress();
    
    void setLastRequestTime(final long p0);
    
    void setLastActivityTime(final long p0);
    
    Continuation getSuspendedRequest();
    
    void setSuspendedRequest(final Continuation p0);
    
    void enqueueMessage(final byte[] p0);
    
    int getMessageQueueSize();
    
    void clearMessageQueue();
    
    List<byte[]> getMessagesInQueue();
    
    List<byte[]> getMessagesInQueue(final boolean p0);
    
    long getReadBytes();
    
    long getWrittenBytes();
    
    IPacketQueue getPacketQueue();
    
    void setSession(final ISession p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions.bluebox;

import java.util.List;

public interface IBBConnectionManager
{
    void addClient(final String p0, final IBBClient p1);
    
    IBBClient getClient(final String p0);
    
    void removeClient(final String p0);
    
    void removeClients(final List<String> p0);
    
    void init();
    
    void handleClientDisconnection(final IBBClient p0);
    
    int getClientCount();
    
    List<IBBClient> getAllClients();
    
    BlueBoxStats getBBStats();
}

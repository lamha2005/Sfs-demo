// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions.bluebox;

public class BlueBoxStats
{
    private volatile long readBytes;
    private volatile long writtenBytes;
    private volatile long readPackets;
    private volatile long writtenPackets;
    
    public BlueBoxStats() {
        this.readBytes = 0L;
        this.writtenBytes = 0L;
        this.readPackets = 0L;
        this.writtenPackets = 0L;
    }
    
    public long getReadBytes() {
        return this.readBytes;
    }
    
    public long getWrittenBytes() {
        return this.writtenBytes;
    }
    
    public long getReadPackets() {
        return this.readPackets;
    }
    
    public long getWrittenPackets() {
        return this.writtenPackets;
    }
    
    public void addReadPacket(final int packetSize) {
        this.readBytes += packetSize;
        ++this.readPackets;
    }
    
    public void addWrittenPacket(final int packetSize) {
        this.writtenBytes += packetSize;
        ++this.writtenPackets;
    }
}

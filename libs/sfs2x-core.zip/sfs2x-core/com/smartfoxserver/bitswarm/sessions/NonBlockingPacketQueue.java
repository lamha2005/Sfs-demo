// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import com.smartfoxserver.bitswarm.exceptions.MessageQueueFullException;
import com.smartfoxserver.bitswarm.data.IPacket;
import java.util.LinkedList;

public final class NonBlockingPacketQueue implements IPacketQueue
{
    private final LinkedList<IPacket> queue;
    private int maxSize;
    private IPacketQueuePolicy packetQueuePolicy;
    
    public NonBlockingPacketQueue(final int maxSize) {
        this.queue = new LinkedList<IPacket>();
        this.maxSize = maxSize;
    }
    
    @Override
    public void clear() {
        synchronized (this.queue) {
            this.queue.clear();
        }
        // monitorexit(this.queue)
    }
    
    @Override
    public int getSize() {
        return this.queue.size();
    }
    
    @Override
    public int getMaxSize() {
        return this.maxSize;
    }
    
    @Override
    public boolean isEmpty() {
        return this.queue.size() == 0;
    }
    
    @Override
    public boolean isFull() {
        return this.queue.size() >= this.maxSize;
    }
    
    @Override
    public float getPercentageUsed() {
        if (this.maxSize == 0) {
            return 0.0f;
        }
        return this.queue.size() * 100 / this.maxSize;
    }
    
    @Override
    public IPacket peek() {
        IPacket packet = null;
        synchronized (this.queue) {
            if (!this.isEmpty()) {
                packet = this.queue.get(0);
            }
        }
        // monitorexit(this.queue)
        return packet;
    }
    
    @Override
    public void put(final IPacket packet) throws MessageQueueFullException {
        if (this.isFull()) {
            throw new MessageQueueFullException();
        }
        this.packetQueuePolicy.applyPolicy(this, packet);
        synchronized (this.queue) {
            this.queue.addLast(packet);
        }
        // monitorexit(this.queue)
    }
    
    @Override
    public void setMaxSize(final int size) {
        this.maxSize = size;
    }
    
    @Override
    public IPacket take() {
        IPacket packet = null;
        synchronized (this.queue) {
            packet = this.queue.removeFirst();
        }
        // monitorexit(this.queue)
        return packet;
    }
    
    @Override
    public IPacketQueuePolicy getPacketQueuePolicy() {
        return this.packetQueuePolicy;
    }
    
    @Override
    public void setPacketQueuePolicy(final IPacketQueuePolicy packetQueuePolicy) {
        this.packetQueuePolicy = packetQueuePolicy;
    }
}

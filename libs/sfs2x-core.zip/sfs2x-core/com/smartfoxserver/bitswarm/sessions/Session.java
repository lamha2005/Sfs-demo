// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import java.io.IOException;
import java.net.Socket;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.bitswarm.util.IPUtil;
import com.smartfoxserver.bitswarm.websocket.IWebSocketChannel;
import com.smartfoxserver.bitswarm.sessions.bluebox.IBBClient;
import java.net.SocketAddress;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SocketChannel;
import java.util.concurrent.atomic.AtomicInteger;

public final class Session implements ISession
{
    public static final String ENCRYPTION_ENABLED = "session_encryption_enabled";
    public static final String DATA_BUFFER = "session_data_buffer";
    public static final String PROTOCOL = "session_protocol";
    public static final String NO_IP = "NO_IP";
    public static final String BBCLIENT = "bbClient";
    public static final String WS_CHANNEL = "wsChannel";
    public static final String PACKET_READ_STATE = "read_state";
    private static AtomicInteger idCounter;
    private volatile long readBytes;
    private volatile long writtenBytes;
    private volatile int droppedMessages;
    private SocketChannel connection;
    private DatagramChannel datagramChannel;
    private volatile long creationTime;
    private volatile long lastReadTime;
    private volatile long lastWriteTime;
    private volatile long lastActivityTime;
    private volatile long lastLoggedInActivityTime;
    private int id;
    private String hashId;
    private String nodeId;
    private SessionType type;
    private volatile String clientIpAddress;
    private volatile int clientPort;
    private int serverPort;
    private String serverAddress;
    private int maxIdleTime;
    private int maxLoggedInIdleTime;
    private volatile int reconnectionSeconds;
    private volatile long freezeTime;
    private volatile boolean frozen;
    private boolean markedForEviction;
    private volatile boolean connected;
    private volatile boolean loggedIn;
    private IPacketQueue packetQueue;
    private ISessionManager sessionManager;
    private Map<String, Object> systemProperties;
    private Map<String, Object> properties;
    private Object cryptoKey;
    
    static {
        Session.idCounter = new AtomicInteger(0);
    }
    
    public Session() {
        this.readBytes = 0L;
        this.writtenBytes = 0L;
        this.droppedMessages = 0;
        this.freezeTime = 0L;
        this.frozen = false;
        this.markedForEviction = false;
        this.connected = false;
        this.loggedIn = false;
        final long currentTimeMillis = System.currentTimeMillis();
        this.lastActivityTime = currentTimeMillis;
        this.lastWriteTime = currentTimeMillis;
        this.lastReadTime = currentTimeMillis;
        this.creationTime = currentTimeMillis;
        this.setId(getUniqueId());
        this.setHashId("---");
        this.properties = new ConcurrentHashMap<String, Object>();
        this.systemProperties = new ConcurrentHashMap<String, Object>();
    }
    
    public Session(final SocketAddress address) {
        this.readBytes = 0L;
        this.writtenBytes = 0L;
        this.droppedMessages = 0;
        this.freezeTime = 0L;
        this.frozen = false;
        this.markedForEviction = false;
        this.connected = false;
        this.loggedIn = false;
        final long currentTimeMillis = System.currentTimeMillis();
        this.lastWriteTime = currentTimeMillis;
        this.lastReadTime = currentTimeMillis;
        this.creationTime = currentTimeMillis;
        this.setId(-1);
        this.properties = new ConcurrentHashMap<String, Object>();
        (this.systemProperties = new ConcurrentHashMap<String, Object>()).put("sender", address);
    }
    
    private static int getUniqueId() {
        return Session.idCounter.incrementAndGet();
    }
    
    @Override
    public void addReadBytes(final long amount) {
        this.readBytes += amount;
    }
    
    @Override
    public void addWrittenBytes(final long amount) {
        this.writtenBytes += amount;
    }
    
    @Override
    public SocketChannel getConnection() {
        return this.connection;
    }
    
    @Override
    public DatagramChannel getDatagramChannel() {
        return this.datagramChannel;
    }
    
    @Override
    public void setDatagramChannel(final DatagramChannel channel) {
        this.datagramChannel = channel;
    }
    
    @Override
    public long getCreationTime() {
        return this.creationTime;
    }
    
    @Override
    public String getHashId() {
        return this.hashId;
    }
    
    @Override
    public int getId() {
        return this.id;
    }
    
    @Override
    public String getFullIpAddress() {
        return (this.clientPort > 0) ? (String.valueOf(this.getAddress()) + ":" + this.clientPort) : this.getAddress();
    }
    
    @Override
    public String getAddress() {
        if (this.type == SessionType.BLUEBOX) {
            final IBBClient client = (IBBClient)this.getSystemProperty("bbClient");
            if (client != null) {
                return client.getIpAddress();
            }
        }
        else if (this.type == SessionType.WEBSOCKET) {
            final IWebSocketChannel channel = (IWebSocketChannel)this.getSystemProperty("wsChannel");
            return IPUtil.getIP(channel.getRemoteAddress());
        }
        return this.clientIpAddress;
    }
    
    @Override
    public int getClientPort() {
        if (this.type == SessionType.WEBSOCKET && this.clientPort == 0) {
            final IWebSocketChannel channel = (IWebSocketChannel)this.getSystemProperty("wsChannel");
            this.clientPort = IPUtil.getPort(channel.getRemoteAddress());
        }
        return this.clientPort;
    }
    
    @Override
    public int getServerPort() {
        if (this.type == SessionType.WEBSOCKET && this.serverPort == 0) {
            final IWebSocketChannel channel = (IWebSocketChannel)this.getSystemProperty("wsChannel");
            this.serverPort = IPUtil.getPort(channel.getLocalAddress());
        }
        return this.serverPort;
    }
    
    @Override
    public String getFullServerIpAddress() {
        return String.valueOf(this.serverAddress) + ":" + this.serverPort;
    }
    
    @Override
    public String getServerAddress() {
        return this.serverAddress;
    }
    
    @Override
    public long getLastActivityTime() {
        return this.lastActivityTime;
    }
    
    @Override
    public long getLastReadTime() {
        return this.lastReadTime;
    }
    
    @Override
    public long getLastWriteTime() {
        return this.lastWriteTime;
    }
    
    @Override
    public int getMaxIdleTime() {
        return this.maxIdleTime;
    }
    
    @Override
    public IPacketQueue getPacketQueue() {
        return this.packetQueue;
    }
    
    @Override
    public String getNodeId() {
        return this.nodeId;
    }
    
    @Override
    public Object getProperty(final String key) {
        return this.properties.get(key);
    }
    
    @Override
    public void removeProperty(final String key) {
        this.properties.remove(key);
    }
    
    @Override
    public long getReadBytes() {
        if (this.type != SessionType.BLUEBOX) {
            return this.readBytes;
        }
        final IBBClient bbClient = (IBBClient)this.getSystemProperty("bbClient");
        if (bbClient != null) {
            return bbClient.getReadBytes();
        }
        return -1L;
    }
    
    @Override
    public Object getSystemProperty(final String key) {
        return this.systemProperties.get(key);
    }
    
    @Override
    public void removeSystemProperty(final String key) {
        this.systemProperties.remove(key);
    }
    
    @Override
    public SessionType getType() {
        return this.type;
    }
    
    @Override
    public long getWrittenBytes() {
        if (this.type != SessionType.BLUEBOX) {
            return this.writtenBytes;
        }
        final IBBClient bbClient = (IBBClient)this.getSystemProperty("bbClient");
        if (bbClient != null) {
            return bbClient.getWrittenBytes();
        }
        return -1L;
    }
    
    @Override
    public boolean isConnected() {
        return this.connected;
    }
    
    @Override
    public void setConnected(final boolean value) {
        this.connected = value;
    }
    
    @Override
    public boolean isLoggedIn() {
        return this.loggedIn;
    }
    
    @Override
    public void setLoggedIn(final boolean value) {
        this.loggedIn = value;
    }
    
    @Override
    public int getMaxLoggedInIdleTime() {
        return this.maxLoggedInIdleTime;
    }
    
    @Override
    public void setMaxLoggedInIdleTime(int idleTime) {
        if (idleTime < this.maxIdleTime) {
            idleTime = this.maxIdleTime + 60;
        }
        this.maxLoggedInIdleTime = idleTime;
    }
    
    @Override
    public long getLastLoggedInActivityTime() {
        return this.lastLoggedInActivityTime;
    }
    
    @Override
    public void setLastLoggedInActivityTime(final long timestamp) {
        this.lastLoggedInActivityTime = timestamp;
    }
    
    @Override
    public boolean isLocal() {
        boolean isLocal = true;
        if (BitSwarmEngine.getInstance().getConfiguration().isClustered()) {
            isLocal = BitSwarmEngine.getInstance().getClusterManager().getLocalNodeName().equals(this.nodeId);
        }
        return isLocal;
    }
    
    @Override
    public boolean isIdle() {
        if (this.loggedIn) {
            return this.isLoggedInIdle();
        }
        return this.isSocketIdle();
    }
    
    private boolean isSocketIdle() {
        boolean isIdle = false;
        if (this.maxIdleTime > 0) {
            final long elapsedSinceLastActivity = System.currentTimeMillis() - this.lastActivityTime;
            isIdle = (elapsedSinceLastActivity / 1000L > this.maxIdleTime);
        }
        return isIdle;
    }
    
    private boolean isLoggedInIdle() {
        boolean isIdle = false;
        if (this.maxLoggedInIdleTime > 0) {
            final long elapsedSinceLastActivity = System.currentTimeMillis() - this.lastLoggedInActivityTime;
            isIdle = (elapsedSinceLastActivity / 1000L > this.maxLoggedInIdleTime);
        }
        return isIdle;
    }
    
    @Override
    public boolean isMarkedForEviction() {
        return this.markedForEviction;
    }
    
    @Override
    public void setConnection(final SocketChannel connection) {
        if (connection == null) {
            this.reconnectionDestroy();
            return;
        }
        if (this.reconnectionSeconds > 0) {
            this.setSocketConnection(connection);
        }
        else {
            if (this.connection != null) {
                throw new IllegalArgumentException("You cannot overwrite the connection linked to a Session!");
            }
            this.setSocketConnection(connection);
        }
    }
    
    private void setSocketConnection(final SocketChannel connection) {
        this.connection = connection;
        this.serverPort = connection.socket().getLocalPort();
        this.serverAddress = connection.socket().getLocalAddress().toString().substring(1);
        if (connection != null && connection.socket() != null && !connection.socket().isClosed()) {
            this.clientIpAddress = IPUtil.getIP(connection.socket().getRemoteSocketAddress());
            this.clientPort = IPUtil.getPort(connection.socket().getRemoteSocketAddress());
            this.connected = true;
        }
        else {
            this.clientIpAddress = "[unknown]";
        }
    }
    
    private void reconnectionDestroy() {
        this.packetQueue = null;
        this.connection = null;
        this.sessionManager.removeSession(this);
    }
    
    @Override
    public void setPacketQueue(final IPacketQueue queue) {
        if (this.packetQueue != null) {
            throw new IllegalStateException("Cannot reassing the packet queue. Queue already exists!");
        }
        this.packetQueue = queue;
    }
    
    @Override
    public void setCreationTime(final long timestamp) {
        this.creationTime = timestamp;
    }
    
    @Override
    public void setHashId(final String hash) {
        this.hashId = hash;
    }
    
    @Override
    public void setId(final int id) {
        this.id = id;
    }
    
    @Override
    public void setLastActivityTime(final long timestamp) {
        this.lastActivityTime = timestamp;
    }
    
    @Override
    public void setLastReadTime(final long timestamp) {
        this.lastActivityTime = timestamp;
        this.lastReadTime = timestamp;
    }
    
    @Override
    public void setLastWriteTime(final long timestamp) {
        this.lastActivityTime = timestamp;
        this.lastWriteTime = timestamp;
    }
    
    @Override
    public void setMarkedForEviction() {
        this.markedForEviction = true;
        this.reconnectionSeconds = 0;
    }
    
    @Override
    public void setMaxIdleTime(final int idleTime) {
        this.maxIdleTime = idleTime;
    }
    
    @Override
    public void setNodeId(final String nodeId) {
        this.nodeId = nodeId;
    }
    
    @Override
    public void setProperty(final String key, final Object property) {
        this.properties.put(key, property);
    }
    
    @Override
    public void setSystemProperty(final String key, final Object property) {
        this.systemProperties.put(key, property);
    }
    
    @Override
    public void setType(final SessionType type) {
        this.type = type;
        if (type == SessionType.VOID) {
            this.clientIpAddress = "NO_IP";
            this.clientPort = 0;
        }
    }
    
    @Override
    public int getDroppedMessages() {
        return this.droppedMessages;
    }
    
    @Override
    public void addDroppedMessages(final int amount) {
        this.droppedMessages += amount;
    }
    
    @Override
    public ISessionManager getSessionManager() {
        return this.sessionManager;
    }
    
    @Override
    public void setSessionManager(final ISessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }
    
    @Override
    public boolean isFrozen() {
        return this.frozen;
    }
    
    @Override
    public synchronized void freeze() {
        this.frozen = true;
        this.freezeTime = System.currentTimeMillis();
    }
    
    @Override
    public synchronized void unfreeze() {
        this.frozen = false;
        this.freezeTime = 0L;
    }
    
    @Override
    public long getFreezeTime() {
        return this.freezeTime;
    }
    
    @Override
    public boolean isReconnectionTimeExpired() {
        final long expiry = this.freezeTime + 1000 * this.reconnectionSeconds;
        return System.currentTimeMillis() > expiry;
    }
    
    @Override
    public void close() throws IOException {
        this.packetQueue = null;
        try {
            if (this.type == SessionType.DEFAULT && this.connection != null) {
                final Socket socket = this.connection.socket();
                if (socket != null && !socket.isClosed()) {
                    socket.shutdownInput();
                    socket.shutdownOutput();
                    socket.close();
                    this.connection.close();
                }
                this.datagramChannel = null;
            }
            else if (this.type == SessionType.WEBSOCKET) {
                final IWebSocketChannel channel = (IWebSocketChannel)this.getSystemProperty("wsChannel");
                if (channel != null) {
                    channel.close();
                }
            }
        }
        finally {
            this.connected = false;
            this.sessionManager.removeSession(this);
        }
        this.connected = false;
        this.sessionManager.removeSession(this);
    }
    
    @Override
    public int getReconnectionSeconds() {
        return this.reconnectionSeconds;
    }
    
    @Override
    public void setReconnectionSeconds(final int value) {
        if (this.type == SessionType.DEFAULT) {
            if (value < 0) {
                this.reconnectionSeconds = 0;
            }
            else {
                this.reconnectionSeconds = value;
            }
        }
    }
    
    @Override
    public boolean isEncrypted() {
        return this.cryptoKey != null;
    }
    
    @Override
    public Object getCryptoKey() {
        return this.cryptoKey;
    }
    
    @Override
    public void setCryptoKey(final Object key) {
        if (this.cryptoKey != null) {
            throw new IllegalStateException("CryptoKey already set for: " + this.toString());
        }
        this.cryptoKey = key;
    }
    
    @Override
    public String toString() {
        return String.format("{ Id: %s, Type: %s, Logged: %s, IP: %s }", this.id, this.type, this.loggedIn ? "Yes" : "No", this.getFullIpAddress());
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (!(obj instanceof ISession)) {
            return false;
        }
        boolean isEqual = false;
        final ISession session = (ISession)obj;
        if (session.getId() == this.id) {
            isEqual = true;
        }
        return isEqual;
    }
}

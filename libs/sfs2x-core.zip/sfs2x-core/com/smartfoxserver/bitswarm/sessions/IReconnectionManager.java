// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import com.smartfoxserver.bitswarm.exceptions.SessionReconnectionException;

public interface IReconnectionManager
{
    ISession getReconnectableSession(final String p0);
    
    ISession reconnectSession(final ISession p0, final String p1) throws SessionReconnectionException;
    
    void onSessionLost(final ISession p0);
    
    ISessionManager getSessionManager();
}

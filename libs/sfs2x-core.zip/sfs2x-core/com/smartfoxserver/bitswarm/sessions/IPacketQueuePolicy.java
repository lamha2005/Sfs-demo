// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import com.smartfoxserver.bitswarm.exceptions.PacketQueueWarning;
import com.smartfoxserver.bitswarm.data.IPacket;

public interface IPacketQueuePolicy
{
    void applyPolicy(final IPacketQueue p0, final IPacket p1) throws PacketQueueWarning;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import com.smartfoxserver.bitswarm.exceptions.SessionReconnectionException;
import java.io.IOException;
import java.util.List;
import java.nio.channels.SocketChannel;
import com.smartfoxserver.bitswarm.service.IService;

public interface ISessionManager extends IService
{
    void addSession(final ISession p0);
    
    void removeSession(final ISession p0);
    
    ISession removeSession(final int p0);
    
    ISession removeSession(final String p0);
    
    ISession removeSession(final SocketChannel p0);
    
    boolean containsSession(final ISession p0);
    
    void shutDownLocalSessions();
    
    List<ISession> getAllSessions();
    
    ISession getSessionById(final int p0);
    
    ISession getSessionByHash(final String p0);
    
    int getNodeSessionCount(final String p0);
    
    int getHighestCCS();
    
    List<ISession> getAllSessionsAtNode(final String p0);
    
    List<ISession> getAllLocalSessions();
    
    ISession getLocalSessionById(final int p0);
    
    ISession getLocalSessionByHash(final String p0);
    
    ISession getLocalSessionByConnection(final SocketChannel p0);
    
    int getLocalSessionCount();
    
    ISession createSession(final SocketChannel p0);
    
    ISession createConnectionlessSession();
    
    ISession createBlueBoxSession();
    
    ISession createWebSocketSession(final Object p0);
    
    void publishLocalNode(final String p0);
    
    void clearClusterData();
    
    void onNodeLost(final String p0);
    
    void onSocketDisconnected(final SocketChannel p0) throws IOException;
    
    void onSocketDisconnected(final ISession p0) throws IOException;
    
    ISession reconnectSession(final ISession p0, final String p1) throws SessionReconnectionException, IOException;
}

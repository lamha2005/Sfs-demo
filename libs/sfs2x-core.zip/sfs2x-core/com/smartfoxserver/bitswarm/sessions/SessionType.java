// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

public enum SessionType
{
    DEFAULT("DEFAULT", 0), 
    BLUEBOX("BLUEBOX", 1), 
    VOID("VOID", 2), 
    WEBSOCKET("WEBSOCKET", 3);
    
    private SessionType(final String s, final int n) {
    }
}

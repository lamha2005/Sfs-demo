// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import java.io.IOException;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SocketChannel;

public interface ISession
{
    int getId();
    
    void setId(final int p0);
    
    String getHashId();
    
    void setHashId(final String p0);
    
    SessionType getType();
    
    void setType(final SessionType p0);
    
    String getNodeId();
    
    void setNodeId(final String p0);
    
    boolean isLocal();
    
    boolean isLoggedIn();
    
    void setLoggedIn(final boolean p0);
    
    IPacketQueue getPacketQueue();
    
    void setPacketQueue(final IPacketQueue p0);
    
    SocketChannel getConnection();
    
    void setConnection(final SocketChannel p0);
    
    DatagramChannel getDatagramChannel();
    
    void setDatagramChannel(final DatagramChannel p0);
    
    long getCreationTime();
    
    void setCreationTime(final long p0);
    
    boolean isConnected();
    
    void setConnected(final boolean p0);
    
    long getLastActivityTime();
    
    void setLastActivityTime(final long p0);
    
    long getLastLoggedInActivityTime();
    
    void setLastLoggedInActivityTime(final long p0);
    
    long getLastReadTime();
    
    void setLastReadTime(final long p0);
    
    long getLastWriteTime();
    
    void setLastWriteTime(final long p0);
    
    long getReadBytes();
    
    void addReadBytes(final long p0);
    
    long getWrittenBytes();
    
    void addWrittenBytes(final long p0);
    
    int getDroppedMessages();
    
    void addDroppedMessages(final int p0);
    
    int getMaxIdleTime();
    
    void setMaxIdleTime(final int p0);
    
    int getMaxLoggedInIdleTime();
    
    void setMaxLoggedInIdleTime(final int p0);
    
    boolean isMarkedForEviction();
    
    void setMarkedForEviction();
    
    boolean isIdle();
    
    boolean isFrozen();
    
    void freeze();
    
    void unfreeze();
    
    long getFreezeTime();
    
    boolean isReconnectionTimeExpired();
    
    Object getSystemProperty(final String p0);
    
    void setSystemProperty(final String p0, final Object p1);
    
    void removeSystemProperty(final String p0);
    
    Object getProperty(final String p0);
    
    void setProperty(final String p0, final Object p1);
    
    void removeProperty(final String p0);
    
    String getFullIpAddress();
    
    String getAddress();
    
    int getClientPort();
    
    String getServerAddress();
    
    int getServerPort();
    
    String getFullServerIpAddress();
    
    ISessionManager getSessionManager();
    
    void setSessionManager(final ISessionManager p0);
    
    void close() throws IOException;
    
    int getReconnectionSeconds();
    
    void setReconnectionSeconds(final int p0);
    
    boolean isEncrypted();
    
    Object getCryptoKey();
    
    void setCryptoKey(final Object p0);
}

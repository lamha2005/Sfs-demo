// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import java.util.Iterator;
import java.io.IOException;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.events.Event;
import java.nio.channels.SocketChannel;
import com.smartfoxserver.bitswarm.exceptions.SessionReconnectionException;
import com.smartfoxserver.bitswarm.util.scheduling.ITaskHandler;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.bitswarm.util.scheduling.Scheduler;
import com.smartfoxserver.bitswarm.util.scheduling.Task;
import org.slf4j.Logger;
import java.util.Map;
import com.smartfoxserver.bitswarm.service.IService;

public final class DefaultReconnectionManager implements IService, IReconnectionManager
{
    private static final String SERVICE_NAME = "DefaultReconnectionManager";
    private static final String RECONNETION_CLEANING_TASK_ID = "SessionReconnectionCleanerTask";
    private final ISessionManager sessionManager;
    private final Map<String, ISession> frozenSessionsByHash;
    private final Logger logger;
    private Task sessionReconnectionCleanTask;
    private Scheduler systemScheduler;
    private BitSwarmEngine engine;
    private boolean allowUnfrozenReconnection;
    
    public DefaultReconnectionManager(final ISessionManager sessionManager) {
        this.allowUnfrozenReconnection = true;
        this.sessionManager = sessionManager;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.frozenSessionsByHash = new ConcurrentHashMap<String, ISession>();
    }
    
    @Override
    public void init(final Object o) {
        this.engine = BitSwarmEngine.getInstance();
        this.systemScheduler = (Scheduler)o;
        this.sessionReconnectionCleanTask = new Task("SessionReconnectionCleanerTask");
        this.systemScheduler.addScheduledTask(this.sessionReconnectionCleanTask, 3, true, new ReconnectionSessionCleaner((ReconnectionSessionCleaner)null));
    }
    
    @Override
    public void destroy(final Object o) {
        this.sessionReconnectionCleanTask.setActive(false);
        this.frozenSessionsByHash.clear();
    }
    
    @Override
    public String getName() {
        return "DefaultReconnectionManager";
    }
    
    @Override
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException("Not supported in this class");
    }
    
    @Override
    public void setName(final String name) {
        throw new UnsupportedOperationException("Not supported in this class");
    }
    
    @Override
    public ISessionManager getSessionManager() {
        return this.sessionManager;
    }
    
    @Override
    public void onSessionLost(final ISession session) {
        this.addSession(session);
        session.freeze();
    }
    
    @Override
    public ISession getReconnectableSession(final String token) {
        return this.frozenSessionsByHash.get(token);
    }
    
    @Override
    public ISession reconnectSession(final ISession tempSession, final String prevSessionToken) throws SessionReconnectionException {
        final SocketChannel connection = tempSession.getConnection();
        ISession session = this.getReconnectableSession(prevSessionToken);
        if (session == null && this.allowUnfrozenReconnection) {
            session = this.engine.getSessionManager().getLocalSessionByHash(prevSessionToken);
        }
        if (session == null) {
            this.dispatchSessionReconnectionFailureEvent(tempSession);
            throw new SessionReconnectionException("Session Reconnection failure. The passed Session is not managed by the ReconnectionManager: " + connection);
        }
        if (!connection.isConnected()) {
            throw new SessionReconnectionException("Session Reconnection failure. The new socket is not connected: " + session.toString());
        }
        if (session.isReconnectionTimeExpired()) {
            throw new SessionReconnectionException("Session Reconnection failure. Time expired for Session: " + session.toString());
        }
        session.setConnection(connection);
        session.setSystemProperty("SessionSelectionKey", tempSession.getSystemProperty("SessionSelectionKey"));
        this.removeSession(session);
        session.unfreeze();
        if (!session.getPacketQueue().isEmpty()) {
            this.engine.getSocketWriter().continueWriteOp(session);
        }
        this.dispatchSessionReconnectionSuccessEvent(session);
        this.logger.debug("Reconnection done. Sessions remaining: " + this.frozenSessionsByHash);
        return session;
    }
    
    private void addSession(final ISession session) {
        if (this.frozenSessionsByHash.containsKey(session.getHashId())) {
            throw new IllegalStateException("Unexpected: Session is already managed by ReconnectionManager. " + session.toString());
        }
        if (session.getReconnectionSeconds() <= 0) {
            throw new IllegalStateException("Unexpected: Session cannot be frozen. " + session.toString());
        }
        this.frozenSessionsByHash.put(session.getHashId(), session);
        this.logger.debug("Session added in ReconnectionManager: " + session + ", ReconnTime: " + session.getReconnectionSeconds() + "s");
    }
    
    private void removeSession(final ISession session) {
        this.frozenSessionsByHash.remove(session.getHashId());
        this.logger.debug("Session removed from ReconnectionManager: " + session);
    }
    
    private void dispatchSessionReconnectionSuccessEvent(final ISession session) {
        final Event event = new Event("sessionReconnectionSuccess");
        event.setParameter("session", session);
        this.engine.dispatchEvent(event);
    }
    
    private void dispatchSessionReconnectionFailureEvent(final ISession incomingSession) {
        final Event event = new Event("sessionReconnectionFailure");
        event.setParameter("session", incomingSession);
        this.engine.dispatchEvent(event);
    }
    
    private void applySessionCleaning() {
        if (this.frozenSessionsByHash.size() > 0) {
            final Iterator<ISession> iter = this.frozenSessionsByHash.values().iterator();
            while (iter.hasNext()) {
                final ISession session = iter.next();
                if (session.isReconnectionTimeExpired()) {
                    iter.remove();
                    this.logger.debug("Removing expired reconnectable Session: " + session);
                    session.setReconnectionSeconds(0);
                    try {
                        this.sessionManager.onSocketDisconnected(session);
                    }
                    catch (IOException e) {
                        this.logger.warn("I/O Error while closing session: " + session);
                    }
                }
            }
        }
    }
    
    private final class ReconnectionSessionCleaner implements ITaskHandler
    {
        @Override
        public void doTask(final Task task) throws Exception {
            DefaultReconnectionManager.this.applySessionCleaning();
        }
    }
}

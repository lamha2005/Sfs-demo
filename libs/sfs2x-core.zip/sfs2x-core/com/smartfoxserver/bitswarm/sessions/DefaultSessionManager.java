// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import com.smartfoxserver.bitswarm.websocket.IWebSocketChannel;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.events.Event;
import com.smartfoxserver.bitswarm.exceptions.BitSwarmEngineRuntimeException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Collection;
import com.smartfoxserver.bitswarm.exceptions.SessionReconnectionException;
import java.io.IOException;
import com.smartfoxserver.bitswarm.util.Logging;
import com.smartfoxserver.bitswarm.service.IService;
import com.smartfoxserver.bitswarm.util.scheduling.ITaskHandler;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.util.scheduling.Scheduler;
import com.smartfoxserver.bitswarm.util.scheduling.Task;
import java.nio.channels.SocketChannel;
import com.smartfoxserver.bitswarm.config.EngineConfiguration;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import org.slf4j.Logger;

public final class DefaultSessionManager implements ISessionManager
{
    private static final String SESSION_CLEANING_TASK_ID = "SessionCleanerTask";
    public static final int SESSION_CLEANING_INTERVAL_SECONDS = 10;
    private static ISessionManager __instance__;
    private final Logger bootLogger;
    private Logger logger;
    private ConcurrentMap<String, List<ISession>> sessionsByNode;
    private ConcurrentMap<Integer, ISession> sessionsById;
    private BitSwarmEngine engine;
    private EngineConfiguration config;
    private final List<ISession> localSessions;
    private final ConcurrentMap<Integer, ISession> localSessionsById;
    private final ConcurrentMap<SocketChannel, ISession> localSessionsByConnection;
    private String serviceName;
    private Task sessionCleanTask;
    private Scheduler systemScheduler;
    IReconnectionManager reconnectionManager;
    private int highestCCS;
    private IPacketQueuePolicy packetQueuePolicy;
    
    public static ISessionManager getInstance() {
        if (DefaultSessionManager.__instance__ == null) {
            DefaultSessionManager.__instance__ = new DefaultSessionManager();
        }
        return DefaultSessionManager.__instance__;
    }
    
    private DefaultSessionManager() {
        this.engine = null;
        this.config = null;
        this.serviceName = "DefaultSessionManager";
        this.highestCCS = 0;
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        if (this.sessionsByNode == null) {
            this.sessionsByNode = new ConcurrentHashMap<String, List<ISession>>();
        }
        if (this.sessionsById == null) {
            this.sessionsById = new ConcurrentHashMap<Integer, ISession>();
        }
        this.localSessions = new ArrayList<ISession>();
        this.localSessionsById = new ConcurrentHashMap<Integer, ISession>();
        this.localSessionsByConnection = new ConcurrentHashMap<SocketChannel, ISession>();
        this.reconnectionManager = new DefaultReconnectionManager(this);
    }
    
    @Override
    public void init(final Object o) {
        this.engine = BitSwarmEngine.getInstance();
        this.config = this.engine.getConfiguration();
        this.logger = LoggerFactory.getLogger((Class)DefaultSessionManager.class);
        this.systemScheduler = (Scheduler)this.engine.getServiceByName("scheduler");
        this.sessionCleanTask = new Task("SessionCleanerTask");
        this.systemScheduler.addScheduledTask(this.sessionCleanTask, 10, true, new SessionCleaner((SessionCleaner)null));
        ((IService)this.reconnectionManager).init(this.systemScheduler);
        try {
            final Class<?> packetPolicyClass = Class.forName(this.config.getPacketQueuePolicyClass());
            this.packetQueuePolicy = (IPacketQueuePolicy)packetPolicyClass.newInstance();
        }
        catch (Exception e) {
            this.bootLogger.warn("SessionManager could not load a valid PacketQueuePolicy. Reason: " + e);
            Logging.logStackTrace(this.bootLogger, e);
        }
    }
    
    @Override
    public void destroy(final Object o) {
        this.sessionCleanTask.setActive(false);
        ((IService)this.reconnectionManager).destroy(null);
        this.shutDownLocalSessions();
        this.localSessionsById.clear();
        this.localSessionsByConnection.clear();
    }
    
    @Override
    public void publishLocalNode(final String nodeId) {
        if (this.sessionsByNode.get(nodeId) != null) {
            throw new IllegalStateException("NodeID already exists in the cluster: " + nodeId);
        }
        this.sessionsByNode.put(nodeId, this.localSessions);
    }
    
    @Override
    public void addSession(final ISession session) {
        synchronized (this.localSessions) {
            this.localSessions.add(session);
        }
        // monitorexit(this.localSessions)
        this.localSessionsById.put(session.getId(), session);
        if (session.getType() == SessionType.DEFAULT) {
            this.localSessionsByConnection.put(session.getConnection(), session);
        }
        if (this.config.isClustered()) {
            this.sessionsById.put(session.getId(), session);
        }
        if (this.localSessions.size() > this.highestCCS) {
            this.highestCCS = this.localSessions.size();
        }
        this.logger.info("Session created: " + session + " on Server port: " + session.getServerPort() + " <---> " + session.getClientPort());
    }
    
    @Override
    public boolean containsSession(final ISession session) {
        return this.localSessionsById.containsValue(session);
    }
    
    @Override
    public void removeSession(final ISession session) {
        if (session == null) {
            return;
        }
        synchronized (this.localSessions) {
            this.localSessions.remove(session);
        }
        // monitorexit(this.localSessions)
        final SocketChannel connection = session.getConnection();
        final int id = session.getId();
        this.localSessionsById.remove(id);
        if (connection != null) {
            this.localSessionsByConnection.remove(connection);
        }
        if (session.getType() != SessionType.VOID) {
            this.engine.getSocketAcceptor().getConnectionFilter().removeAddress(session.getAddress());
        }
        if (this.config.isClustered()) {
            this.sessionsById.remove(id);
        }
        this.logger.info("Session removed: " + session);
    }
    
    @Override
    public ISession removeSession(final int id) {
        final ISession session = this.localSessionsById.get(id);
        if (session != null) {
            this.removeSession(session);
        }
        return session;
    }
    
    @Override
    public ISession removeSession(final String hash) {
        throw new UnsupportedOperationException("Not implemented yet!");
    }
    
    @Override
    public ISession removeSession(final SocketChannel connection) {
        final ISession session = this.getLocalSessionByConnection(connection);
        if (session != null) {
            this.removeSession(session);
        }
        return session;
    }
    
    @Override
    public void onSocketDisconnected(final SocketChannel connection) throws IOException {
        final ISession session = this.localSessionsByConnection.get(connection);
        if (session == null) {
            return;
        }
        this.localSessionsByConnection.remove(connection);
        session.setConnected(false);
        this.onSocketDisconnected(session);
    }
    
    @Override
    public void onSocketDisconnected(final ISession session) throws IOException {
        if (session.getReconnectionSeconds() > 0) {
            this.reconnectionManager.onSessionLost(session);
            this.dispatchSessionReconnectionTryEvent(session);
        }
        else {
            this.removeSession(session);
            this.dispatchLostSessionEvent(session);
        }
    }
    
    @Override
    public ISession reconnectSession(final ISession tempSession, final String sessionToken) throws SessionReconnectionException, IOException {
        ISession resumedSession = null;
        try {
            resumedSession = this.reconnectionManager.reconnectSession(tempSession, sessionToken);
        }
        catch (SessionReconnectionException sre) {
            throw sre;
        }
        this.localSessionsByConnection.put(tempSession.getConnection(), resumedSession);
        tempSession.setConnection(null);
        this.logger.info("Session was resurrected: " + resumedSession + ", using temp Session: " + tempSession + ", " + resumedSession.getReconnectionSeconds());
        return resumedSession;
    }
    
    @Override
    public List<ISession> getAllLocalSessions() {
        List<ISession> allSessions = null;
        synchronized (this.localSessions) {
            allSessions = new ArrayList<ISession>(this.localSessions);
        }
        // monitorexit(this.localSessions)
        return allSessions;
    }
    
    @Override
    public List<ISession> getAllSessions() {
        List<ISession> sessions = null;
        sessions = (this.config.isClustered() ? new LinkedList<ISession>(this.sessionsById.values()) : this.getAllLocalSessions());
        return sessions;
    }
    
    @Override
    public List<ISession> getAllSessionsAtNode(final String nodeName) {
        List<ISession> allSessions = null;
        final List<ISession> theSessions = this.sessionsByNode.get(nodeName);
        if (theSessions != null) {
            allSessions = new ArrayList<ISession>(theSessions);
        }
        return allSessions;
    }
    
    @Override
    public ISession getLocalSessionByHash(final String hash) {
        for (final ISession session : this.localSessionsById.values()) {
            if (session.getHashId().equals(hash)) {
                return session;
            }
        }
        return null;
    }
    
    @Override
    public ISession getLocalSessionById(final int id) {
        return this.localSessionsById.get(id);
    }
    
    @Override
    public ISession getSessionByHash(final String hash) {
        throw new UnsupportedOperationException("Not implemented yet!");
    }
    
    @Override
    public ISession getLocalSessionByConnection(final SocketChannel connection) {
        return this.localSessionsByConnection.get(connection);
    }
    
    @Override
    public ISession getSessionById(final int id) {
        return this.sessionsById.get(id);
    }
    
    @Override
    public int getHighestCCS() {
        return this.highestCCS;
    }
    
    @Override
    public void shutDownLocalSessions() {
        synchronized (this.localSessions) {
            final Iterator<ISession> it = this.localSessions.iterator();
            while (it.hasNext()) {
                final ISession session = it.next();
                it.remove();
                try {
                    session.close();
                }
                catch (IOException e) {
                    this.bootLogger.warn("I/O Error while closing session: " + session);
                }
            }
        }
        // monitorexit(this.localSessions)
    }
    
    @Override
    public void onNodeLost(final String nodeId) {
        final List<ISession> nodeSessions = this.sessionsByNode.remove(nodeId);
        if (nodeSessions == null) {
            throw new IllegalStateException("Unable to remove node sessions from cluster. Lost Node ID: " + nodeId);
        }
        synchronized (this.sessionsById) {
            for (final ISession session : nodeSessions) {
                this.sessionsById.remove(session.getId());
            }
        }
        // monitorexit(this.sessionsById)
    }
    
    @Override
    public void clearClusterData() {
        this.sessionsById.clear();
        this.sessionsByNode.clear();
    }
    
    @Override
    public String getName() {
        return this.serviceName;
    }
    
    @Override
    public void setName(final String name) {
        this.serviceName = name;
    }
    
    @Override
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException("Not implemented in this class!");
    }
    
    @Override
    public ISession createSession(final SocketChannel connection) {
        final ISession session = new Session();
        session.setSessionManager(this);
        session.setConnection(connection);
        session.setMaxIdleTime(this.engine.getConfiguration().getDefaultMaxSessionIdleTime());
        session.setNodeId(this.config.isClustered() ? this.engine.getClusterManager().getLocalNodeName() : "");
        session.setType(SessionType.DEFAULT);
        session.setReconnectionSeconds(this.engine.getConfiguration().getGlobalReconnectionSeconds());
        final IPacketQueue packetQueue = new NonBlockingPacketQueue(this.engine.getConfiguration().getSessionPacketQueueMaxSize());
        packetQueue.setPacketQueuePolicy(this.packetQueuePolicy);
        session.setPacketQueue(packetQueue);
        return session;
    }
    
    @Override
    public ISession createConnectionlessSession() {
        final ISession session = new Session();
        session.setSessionManager(this);
        session.setNodeId(this.config.isClustered() ? this.engine.getClusterManager().getLocalNodeName() : "");
        session.setType(SessionType.VOID);
        session.setConnected(true);
        return session;
    }
    
    @Override
    public ISession createBlueBoxSession() {
        final ISession session = new Session();
        session.setSessionManager(this);
        session.setMaxIdleTime(this.engine.getConfiguration().getDefaultMaxSessionIdleTime());
        session.setNodeId(this.config.isClustered() ? this.engine.getClusterManager().getLocalNodeName() : "");
        session.setType(SessionType.BLUEBOX);
        final IPacketQueue packetQueue = new NonBlockingPacketQueue(this.engine.getConfiguration().getSessionPacketQueueMaxSize());
        packetQueue.setPacketQueuePolicy(this.packetQueuePolicy);
        session.setPacketQueue(packetQueue);
        return session;
    }
    
    @Override
    public ISession createWebSocketSession(final Object channel) {
        final Session session = new Session();
        session.setSessionManager(this);
        session.setMaxIdleTime(this.engine.getConfiguration().getDefaultMaxSessionIdleTime());
        session.setNodeId(this.config.isClustered() ? this.engine.getClusterManager().getLocalNodeName() : "");
        session.setType(SessionType.WEBSOCKET);
        session.setConnected(true);
        final IPacketQueue packetQueue = new NonBlockingPacketQueue(this.engine.getConfiguration().getSessionPacketQueueMaxSize());
        packetQueue.setPacketQueuePolicy(this.packetQueuePolicy);
        session.setPacketQueue(packetQueue);
        session.setSystemProperty("wsChannel", channel);
        return session;
    }
    
    @Override
    public int getLocalSessionCount() {
        return this.localSessions.size();
    }
    
    @Override
    public int getNodeSessionCount(final String nodeId) {
        final List<ISession> nodeSessionList = this.sessionsByNode.get(nodeId);
        if (nodeSessionList == null) {
            throw new BitSwarmEngineRuntimeException("Can't find session count for requested node in the cluster. Node not found: " + nodeId);
        }
        return nodeSessionList.size();
    }
    
    private void applySessionCleaning() {
        if (this.getLocalSessionCount() > 0) {
            for (final ISession session : this.getAllLocalSessions()) {
                if (session != null && !session.isFrozen()) {
                    if (session.isMarkedForEviction()) {
                        this.terminateSession(session);
                        this.logger.info("Terminated idle logged-in session: " + session);
                    }
                    else {
                        if (!session.isIdle()) {
                            continue;
                        }
                        if (session.isLoggedIn()) {
                            session.setMarkedForEviction();
                            this.dispatchSessionIdleEvent(session);
                        }
                        else {
                            this.terminateSession(session);
                            if (!this.logger.isDebugEnabled()) {
                                continue;
                            }
                            this.logger.debug("Removed idle session: " + session);
                        }
                    }
                }
            }
        }
        final Event event = new Event("sessionIdleCheckComplete");
        this.engine.dispatchEvent(event);
    }
    
    public void terminateSession(final ISession session) {
        if (session.getType() == SessionType.DEFAULT) {
            final SocketChannel connection = session.getConnection();
            session.setReconnectionSeconds(0);
            try {
                if (connection.socket() != null) {
                    connection.socket().shutdownInput();
                    connection.socket().shutdownOutput();
                    connection.close();
                }
                session.setConnected(false);
            }
            catch (IOException err) {
                this.logger.warn("Failed closing connection while removing idle Session: " + session);
            }
        }
        else if (session.getType() == SessionType.WEBSOCKET) {
            final IWebSocketChannel channel = (IWebSocketChannel)session.getSystemProperty("wsChannel");
            channel.close();
            return;
        }
        this.removeSession(session);
        this.dispatchLostSessionEvent(session);
    }
    
    private void dispatchLostSessionEvent(final ISession closedSession) {
        final Event event = new Event("sessionLost");
        event.setParameter("session", closedSession);
        this.engine.dispatchEvent(event);
    }
    
    private void dispatchSessionIdleEvent(final ISession idleSession) {
        final Event event = new Event("sessionIdle");
        event.setParameter("session", idleSession);
        this.engine.dispatchEvent(event);
    }
    
    private void dispatchSessionReconnectionTryEvent(final ISession session) {
        final Event event = new Event("sessionReconnectionTry");
        event.setParameter("session", session);
        this.engine.dispatchEvent(event);
    }
    
    private final class SessionCleaner implements ITaskHandler
    {
        @Override
        public void doTask(final Task task) throws Exception {
            DefaultSessionManager.this.applySessionCleaning();
        }
    }
}

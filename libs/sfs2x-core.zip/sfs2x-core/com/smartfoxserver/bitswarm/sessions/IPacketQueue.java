// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import com.smartfoxserver.bitswarm.exceptions.MessageQueueFullException;
import com.smartfoxserver.bitswarm.data.IPacket;

public interface IPacketQueue
{
    IPacket peek();
    
    IPacket take();
    
    boolean isEmpty();
    
    boolean isFull();
    
    int getSize();
    
    int getMaxSize();
    
    void setMaxSize(final int p0);
    
    float getPercentageUsed();
    
    void clear();
    
    void put(final IPacket p0) throws MessageQueueFullException;
    
    IPacketQueuePolicy getPacketQueuePolicy();
    
    void setPacketQueuePolicy(final IPacketQueuePolicy p0);
}

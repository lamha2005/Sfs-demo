// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.sessions;

import com.smartfoxserver.bitswarm.exceptions.PacketQueueWarning;
import com.smartfoxserver.bitswarm.data.MessagePriority;
import com.smartfoxserver.bitswarm.data.IPacket;

public class DefaultPacketQueuePolicy implements IPacketQueuePolicy
{
    private static final int THREE_QUARTERS_FULL = 75;
    private static final int NINETY_PERCENT_FULL = 90;
    
    @Override
    public void applyPolicy(final IPacketQueue packetQueue, final IPacket packet) throws PacketQueueWarning {
        final int percentageFree = packetQueue.getSize() * 100 / packetQueue.getMaxSize();
        if (percentageFree >= 75 && percentageFree < 90) {
            if (packet.getPriority().getValue() < MessagePriority.NORMAL.getValue()) {
                this.fireDropMessageError(packet, percentageFree);
            }
        }
        else if (percentageFree >= 90 && packet.getPriority().getValue() < MessagePriority.HIGH.getValue()) {
            this.fireDropMessageError(packet, percentageFree);
        }
    }
    
    private void fireDropMessageError(final IPacket packet, final int percentageFree) {
        throw new PacketQueueWarning("Dropping packet: " + packet + ", Free queue: " + percentageFree + "%");
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.boot;

import java.io.IOException;
import com.smartfoxserver.bitswarm.exceptions.BitSwarmEngineException;
import java.util.logging.Handler;
import java.util.logging.Logger;
import java.util.logging.Formatter;
import java.util.logging.FileHandler;
import java.util.Date;
import java.text.SimpleDateFormat;
import com.smartfoxserver.bitswarm.util.FileServices;

public final class BootLoggerConfigurator
{
    private static final String BASE_FOLDER = "./";
    private static final String PROP_FOLDER = "logFolder";
    private static final String PROP_FILENAME = "baseFileName";
    private static final String PROP_MAX_DAYS = "keepLogForDays";
    private static final String PROP_LEVEL = "logLevel";
    private BootLoggerConfig bootLoggerCfg;
    
    public BootLoggerConfigurator(final BootLoggerConfig bootLoggerCfg) {
        this.bootLoggerCfg = bootLoggerCfg;
    }
    
    public void configure() throws BitSwarmEngineException, IOException {
        new BootLogFilesCleaner().cleanFiles(this.bootLoggerCfg.getLogFolder(), this.bootLoggerCfg.getLogFileExtension(), this.bootLoggerCfg.getKeepLogForDays());
        FileServices.recursiveMakeDir("./", this.bootLoggerCfg.getLogFolder());
        final SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd__HH.mm.ss");
        String logFilePostfix = dateFormatter.format(new Date());
        logFilePostfix = String.valueOf(logFilePostfix) + this.bootLoggerCfg.getLogFileExtension();
        final FileHandler logFileHandler = new FileHandler("./" + this.bootLoggerCfg.getLogFolder() + this.bootLoggerCfg.getLogFileBaseName() + logFilePostfix);
        logFileHandler.setFormatter(new BootLogFormatter());
        final Logger jdkLogger = Logger.getLogger("bootLogger");
        jdkLogger.addHandler(logFileHandler);
    }
}

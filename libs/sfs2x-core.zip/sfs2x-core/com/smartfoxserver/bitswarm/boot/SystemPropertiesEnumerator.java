// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.boot;

import java.util.Enumeration;
import java.net.SocketException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.charset.Charset;
import org.slf4j.Logger;

public class SystemPropertiesEnumerator
{
    private static final String NEW_LINE;
    private static final String TAB = "\t";
    private static final String[] props;
    
    static {
        NEW_LINE = System.getProperty("line.separator");
        props = new String[] { "os.name", "os.arch", "os.version", "java.version", "java.vendor", "java.vendor.url", "java.vm.specification.version", "java.vm.version", "java.vm.vendor", "java.vm.name", "java.io.tmpdir" };
    }
    
    public void logProperties(final Logger logger) {
        this.logSystemInfo(logger);
        this.logNetCardsInfo(logger);
    }
    
    private void logSystemInfo(final Logger logger) {
        final StringBuilder sb = new StringBuilder("System Info:").append(SystemPropertiesEnumerator.NEW_LINE);
        final Runtime rt = Runtime.getRuntime();
        sb.append("\t").append("Processor(s): ").append(rt.availableProcessors()).append(SystemPropertiesEnumerator.NEW_LINE);
        sb.append("\t").append("VM Max. memory: ").append(rt.maxMemory() / 1000000L).append("MB").append(SystemPropertiesEnumerator.NEW_LINE);
        String[] props;
        for (int length = (props = SystemPropertiesEnumerator.props).length, i = 0; i < length; ++i) {
            final String prop = props[i];
            sb.append("\t").append(prop).append(": ").append(System.getProperty(prop)).append(SystemPropertiesEnumerator.NEW_LINE);
        }
        sb.append("\t").append("Default charset: " + Charset.defaultCharset()).append(SystemPropertiesEnumerator.NEW_LINE);
        logger.info(sb.toString());
    }
    
    private void logNetCardsInfo(final Logger logger) {
        final StringBuilder sb = new StringBuilder("Network Info:").append(SystemPropertiesEnumerator.NEW_LINE);
        try {
            final Enumeration<NetworkInterface> list = NetworkInterface.getNetworkInterfaces();
            while (list.hasMoreElements()) {
                final NetworkInterface iFace = list.nextElement();
                sb.append("\t").append("Card: ").append(iFace.getDisplayName()).append(SystemPropertiesEnumerator.NEW_LINE);
                final Enumeration<InetAddress> addresses = iFace.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    final InetAddress adr = addresses.nextElement();
                    sb.append("\t").append("\t").append(" ->").append(adr.getHostAddress()).append(SystemPropertiesEnumerator.NEW_LINE);
                }
            }
            logger.info(sb.toString());
        }
        catch (SocketException se) {
            logger.warn("Exception while discovering network cards: " + se.getMessage());
        }
    }
}

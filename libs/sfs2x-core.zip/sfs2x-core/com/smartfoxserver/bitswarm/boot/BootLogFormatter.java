// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.boot;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.logging.LogRecord;
import java.util.logging.Formatter;

public class BootLogFormatter extends Formatter
{
    private static String NEW_LINE;
    
    static {
        BootLogFormatter.NEW_LINE = System.getProperty("line.separator");
    }
    
    @Override
    public String format(final LogRecord record) {
        final String s = String.valueOf(this.formatTime(record)) + " - [ " + record.getLevel() + " ]: " + record.getMessage() + BootLogFormatter.NEW_LINE;
        final Throwable t = record.getThrown();
        if (t == null) {
            return s;
        }
        final StackTraceElement[] elements = t.getStackTrace();
        final StringBuffer sb = new StringBuffer(s);
        sb.append(" ").append(t.toString()).append(BootLogFormatter.NEW_LINE);
        for (int i = 0; i < elements.length; ++i) {
            final StackTraceElement element = elements[i];
            sb.append("\t").append(element.toString()).append(BootLogFormatter.NEW_LINE);
        }
        return sb.toString();
    }
    
    private String formatTime(final LogRecord record) {
        final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss.SSS");
        return fmt.format(new Date(record.getMillis()));
    }
}

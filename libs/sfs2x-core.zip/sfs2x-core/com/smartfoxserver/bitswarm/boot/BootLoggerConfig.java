// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.boot;

import java.util.logging.Level;

public class BootLoggerConfig
{
    public static final String DEFAULT_LOG_FOLDER = "logs/boot/";
    public static final String DEFAULT_BASE_FILE_NAME = "boot_";
    public static final int DEFAULT_LOG_MAX_SIZE = 100000000;
    public static final int DEFAULT_LOG_MAX_DAYS = 5;
    public static final Level DEFAULT_LOGGING_LEVEL;
    private String logFolder;
    private String logFileBaseName;
    private String logFileExtension;
    private int keepLogForDays;
    private long logMaxFileSize;
    private Level loggingLevel;
    public static final String DEFAULT_FILE_EXT = ".log";
    
    static {
        DEFAULT_LOGGING_LEVEL = Level.INFO;
    }
    
    public BootLoggerConfig() {
        this.logFolder = "logs/boot/";
        this.logFileBaseName = "boot_";
        this.logFileExtension = ".log";
        this.keepLogForDays = 5;
        this.logMaxFileSize = 100000000L;
        this.loggingLevel = BootLoggerConfig.DEFAULT_LOGGING_LEVEL;
    }
    
    public String getLogFolder() {
        return this.logFolder;
    }
    
    public void setLogFolder(final String logFolder) {
        this.logFolder = logFolder;
    }
    
    public String getLogFileBaseName() {
        return this.logFileBaseName;
    }
    
    public void setLogFileBaseName(final String logFileBaseName) {
        this.logFileBaseName = logFileBaseName;
    }
    
    public int getKeepLogForDays() {
        return this.keepLogForDays;
    }
    
    public void setKeepLogForDays(final int keepLogForDays) {
        this.keepLogForDays = keepLogForDays;
    }
    
    public Level getLoggingLevel() {
        return this.loggingLevel;
    }
    
    public void setLoggingLevel(final Level loggingLevel) {
        this.loggingLevel = loggingLevel;
    }
    
    public void setLogFileExtension(final String logFileExtension) {
        this.logFileExtension = logFileExtension;
    }
    
    public String getLogFileExtension() {
        return this.logFileExtension;
    }
    
    public void setLogMaxFileSize(final long logMaxFileSize) {
        this.logMaxFileSize = logMaxFileSize;
    }
    
    public long getLogMaxFileSize() {
        return this.logMaxFileSize;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.boot;

import java.io.FilenameFilter;
import java.io.File;

public class BootLogFilesCleaner
{
    private static final int DAYS = 86400000;
    
    public void cleanFiles(final String folder, final String fileExt, final int days) {
        final File folderLocation = new File(folder);
        final File[] entries = folderLocation.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(final File dir, final String name) {
                boolean ok = false;
                if (name.endsWith(".log")) {
                    ok = true;
                }
                return ok;
            }
        });
        if (entries == null) {
            return;
        }
        final long now = System.currentTimeMillis();
        File[] array;
        for (int length = (array = entries).length, i = 0; i < length; ++i) {
            final File entry = array[i];
            final long elapsed = now - entry.lastModified();
            final long elapsedDays = elapsed / 86400000L;
            if (elapsedDays > days) {
                entry.delete();
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.data;

public enum BufferType
{
    HEAP("HEAP", 0), 
    DIRECT("DIRECT", 1);
    
    private BufferType(final String s, final int n) {
    }
}

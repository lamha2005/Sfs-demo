// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.data;

import java.nio.channels.SelectableChannel;
import com.smartfoxserver.bitswarm.config.SocketConfig;

public class BindableSocket extends SocketConfig
{
    protected SelectableChannel channel;
    
    public BindableSocket(final SelectableChannel channel, final String address, final int port, final TransportType type) {
        super(address, port, type);
        this.channel = channel;
    }
    
    public SelectableChannel getChannel() {
        return this.channel;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.data;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Collection;
import java.util.concurrent.ConcurrentMap;
import com.smartfoxserver.bitswarm.sessions.ISession;

public class Packet implements IPacket
{
    protected long creationTime;
    protected Object data;
    protected String ownerNode;
    protected MessagePriority priority;
    protected ISession sender;
    protected TransportType transportType;
    protected int originalSize;
    protected ConcurrentMap<String, Object> attributes;
    protected Collection<ISession> recipients;
    protected byte[] fragmentBuffer;
    
    public Packet() {
        this.originalSize = -1;
        this.creationTime = System.nanoTime();
        this.priority = MessagePriority.NORMAL;
        this.transportType = TransportType.TCP;
    }
    
    @Override
    public Object getAttribute(final String key) {
        if (this.attributes == null) {
            return null;
        }
        return this.attributes.get(key);
    }
    
    @Override
    public void setAttribute(final String key, final Object attr) {
        if (this.attributes == null) {
            this.attributes = new ConcurrentHashMap<String, Object>();
        }
        this.attributes.put(key, attr);
    }
    
    @Override
    public boolean hasAttribute(final String key) {
        return this.attributes != null && this.attributes.containsKey(key);
    }
    
    @Override
    public long getCreationTime() {
        return this.creationTime;
    }
    
    @Override
    public void setCreationTime(final long creationTime) {
        this.creationTime = creationTime;
    }
    
    @Override
    public Object getData() {
        return this.data;
    }
    
    @Override
    public void setData(final Object data) {
        this.data = data;
    }
    
    @Override
    public String getOwnerNode() {
        return this.ownerNode;
    }
    
    @Override
    public void setOwnerNode(final String ownerNode) {
        this.ownerNode = ownerNode;
    }
    
    @Override
    public MessagePriority getPriority() {
        return this.priority;
    }
    
    @Override
    public void setPriority(final MessagePriority priority) {
        this.priority = priority;
    }
    
    @Override
    public ISession getSender() {
        return this.sender;
    }
    
    @Override
    public void setSender(final ISession sender) {
        this.sender = sender;
    }
    
    @Override
    public TransportType getTransportType() {
        return this.transportType;
    }
    
    @Override
    public void setTransportType(final TransportType transportType) {
        this.transportType = transportType;
    }
    
    @Override
    public Collection<ISession> getRecipients() {
        return this.recipients;
    }
    
    @Override
    public void setRecipients(final Collection<ISession> recipients) {
        this.recipients = recipients;
    }
    
    @Override
    public boolean isTcp() {
        return this.transportType == TransportType.TCP;
    }
    
    @Override
    public boolean isUdp() {
        return this.transportType == TransportType.UDP;
    }
    
    @Override
    public boolean isFragmented() {
        return this.fragmentBuffer != null;
    }
    
    @Override
    public int getOriginalSize() {
        return this.originalSize;
    }
    
    @Override
    public void setOriginalSize(final int originalSize) {
        if (this.originalSize == -1) {
            this.originalSize = originalSize;
        }
    }
    
    @Override
    public byte[] getFragmentBuffer() {
        return this.fragmentBuffer;
    }
    
    @Override
    public void setFragmentBuffer(final byte[] bb) {
        this.fragmentBuffer = bb;
    }
    
    @Override
    public String toString() {
        return String.format("{ Packet: %s, data: %s, Pri: %s }", this.transportType, this.data.getClass().getName(), this.priority);
    }
    
    @Override
    public IPacket clone() {
        final IPacket newPacket = new Packet();
        newPacket.setCreationTime(this.getCreationTime());
        newPacket.setData(this.getData());
        newPacket.setOriginalSize(this.getOriginalSize());
        newPacket.setOwnerNode(this.getOwnerNode());
        newPacket.setPriority(this.getPriority());
        newPacket.setRecipients(null);
        newPacket.setSender(this.getSender());
        newPacket.setTransportType(this.getTransportType());
        return newPacket;
    }
}

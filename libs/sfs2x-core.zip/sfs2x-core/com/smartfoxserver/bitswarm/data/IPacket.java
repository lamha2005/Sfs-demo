// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.data;

import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.Collection;

public interface IPacket
{
    Object getData();
    
    void setData(final Object p0);
    
    TransportType getTransportType();
    
    void setTransportType(final TransportType p0);
    
    MessagePriority getPriority();
    
    void setPriority(final MessagePriority p0);
    
    Collection<ISession> getRecipients();
    
    void setRecipients(final Collection<ISession> p0);
    
    byte[] getFragmentBuffer();
    
    void setFragmentBuffer(final byte[] p0);
    
    ISession getSender();
    
    void setSender(final ISession p0);
    
    Object getAttribute(final String p0);
    
    void setAttribute(final String p0, final Object p1);
    
    boolean hasAttribute(final String p0);
    
    String getOwnerNode();
    
    void setOwnerNode(final String p0);
    
    long getCreationTime();
    
    void setCreationTime(final long p0);
    
    int getOriginalSize();
    
    void setOriginalSize(final int p0);
    
    boolean isTcp();
    
    boolean isUdp();
    
    boolean isFragmented();
    
    IPacket clone();
}

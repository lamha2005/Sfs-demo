// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.data;

public interface IPacketBuffer
{
    boolean isMultiSegment();
    
    boolean hasMoreSegments();
    
    int getRemaining();
    
    int getPosition();
    
    int getSize();
    
    byte[] getSegment();
    
    void setSegment(final byte[] p0);
    
    void setData(final byte[] p0, final int p1);
    
    byte[] nextSegment();
    
    void backward(final int p0);
    
    void forward(final int p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.data;

public enum MessagePriority
{
    VERY_LOW("VERY_LOW", 0, 1, "Very LOW"), 
    LOW("LOW", 1, 2, "LOW"), 
    NORMAL("NORMAL", 2, 3, "NORMAL"), 
    HIGH("HIGH", 3, 4, "HIGH"), 
    VERY_HIGH("VERY_HIGH", 4, 5, "Very HIGH");
    
    private int level;
    private String repr;
    
    private MessagePriority(final String s, final int n, final int lev, final String repr) {
        this.level = lev;
        this.repr = repr;
    }
    
    public int getValue() {
        return this.level;
    }
    
    @Override
    public String toString() {
        return "{ " + this.repr + " }";
    }
}

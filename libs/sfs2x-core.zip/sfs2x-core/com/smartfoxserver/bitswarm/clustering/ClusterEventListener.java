// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import com.smartfoxserver.bitswarm.clustering.handlers.NodeShutDownHandler;
import com.smartfoxserver.bitswarm.clustering.handlers.SendMessageHandler;
import com.smartfoxserver.bitswarm.clustering.handlers.HelloHandler;
import com.smartfoxserver.bitswarm.util.Logging;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.events.IEvent;
import java.util.concurrent.BlockingQueue;
import org.slf4j.Logger;
import java.util.concurrent.ConcurrentMap;

public class ClusterEventListener implements IClusterEventListener, Runnable
{
    private final ConcurrentMap<String, IClusterEventHandler> handlers;
    private final Logger logger;
    private final Thread queueWorker;
    private BlockingQueue<IEvent> mailBox;
    private IClusterManager clusterManager;
    private volatile boolean isActive;
    
    public ClusterEventListener() {
        this.isActive = false;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.handlers = new ConcurrentHashMap<String, IClusterEventHandler>();
        this.queueWorker = new Thread(this, "ClusterEventListener");
        this.logger.info("ClusterEventListener CREATED");
    }
    
    @Override
    public void init(final Object o) {
        this.clusterManager = (IClusterManager)o;
        this.mailBox = DataStore.instance().postOffice.get(this.clusterManager.getLocalNodeName());
        this.registerHandlers();
        this.queueWorker.start();
        this.logger.info("ClusterEventListener INITED");
    }
    
    @Override
    public void destroy(final Object o) {
        this.isActive = false;
        this.queueWorker.interrupt();
    }
    
    @Override
    public void run() {
        this.isActive = true;
        while (this.isActive) {
            try {
                final IEvent event = this.mailBox.take();
                if (this.clusterManager.isReadyForEvents()) {
                    this.handleClusterEvent(event);
                }
                else {
                    this.logger.info("Cluster manager not ready for events. Event discarded: " + event);
                }
            }
            catch (InterruptedException e) {
                this.logger.warn("ClusterEventListener interrupted, shutting down.");
                Logging.logStackTrace(this.logger, e);
                this.isActive = false;
            }
            catch (Throwable t) {
                this.logger.warn("Error handling cluster event: " + t.getMessage());
                Logging.logStackTrace(this.logger, t);
            }
        }
    }
    
    @Override
    public void addEventHandler(final String eventName, final IClusterEventHandler clusterEventHandler) {
        this.handlers.putIfAbsent(eventName, clusterEventHandler);
    }
    
    private void handleClusterEvent(final IEvent event) throws Exception {
        final IClusterEventHandler handler = this.handlers.get(event.getName());
        if (handler != null) {
            handler.handleClusterEvent(event);
        }
        else {
            this.logger.info("No handlers for cluster event called: " + event.getName());
        }
    }
    
    private void registerHandlers() {
        this.handlers.put("cluster_hello", new HelloHandler());
        this.handlers.put("cluster_sendMessage", new SendMessageHandler());
        this.handlers.put("cluster_nodeShutDown", new NodeShutDownHandler());
    }
}

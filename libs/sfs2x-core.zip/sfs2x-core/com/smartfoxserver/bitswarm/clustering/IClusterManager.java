// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import java.util.List;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.service.IService;

public interface IClusterManager extends IService
{
    String getLocalNodeName();
    
    void registerLocalNode();
    
    void removeNode(final String p0);
    
    void clearDataStore();
    
    boolean isReadyForEvents();
    
    void dispatchClusterEvent(final IEvent p0, final String p1);
    
    void broadcastClusterEvent(final IEvent p0, final List<String> p1);
    
    void broadcastClusterEvent(final IEvent p0);
}

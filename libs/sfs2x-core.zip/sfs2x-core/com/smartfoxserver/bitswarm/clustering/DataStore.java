// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.events.IEvent;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentMap;

public class DataStore
{
    private static DataStore _instance;
    public ConcurrentMap<String, BlockingQueue<IEvent>> postOffice;
    public String lastNodeRemoved;
    private Logger logger;
    
    private DataStore() {
        this.logger = LoggerFactory.getLogger((Class)DataStore.class);
        if (this.postOffice == null) {
            this.postOffice = new ConcurrentHashMap<String, BlockingQueue<IEvent>>();
        }
        if (this.lastNodeRemoved == null) {
            this.lastNodeRemoved = "---";
        }
    }
    
    public static DataStore instance() {
        if (DataStore._instance == null) {
            DataStore._instance = new DataStore();
        }
        return DataStore._instance;
    }
}

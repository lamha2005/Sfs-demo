// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

public class ClusterEvents
{
    public static final String SEND_MESSAGE = "cluster_sendMessage";
    public static final String HELLO = "cluster_hello";
    public static final String NODE_SHUT_DOWN = "cluster_nodeShutDown";
}

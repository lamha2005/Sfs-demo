// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import com.smartfoxserver.bitswarm.events.IEvent;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import org.slf4j.Logger;

public abstract class AbstractClusterEventHandler implements IClusterEventHandler
{
    protected final Logger logger;
    protected final BitSwarmEngine engine;
    protected final IClusterManager clusterManager;
    
    public AbstractClusterEventHandler() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.engine = BitSwarmEngine.getInstance();
        this.clusterManager = this.engine.getClusterManager();
    }
    
    @Override
    public abstract void handleClusterEvent(final IEvent p0) throws Exception;
}

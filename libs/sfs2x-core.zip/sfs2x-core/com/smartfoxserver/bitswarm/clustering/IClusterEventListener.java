// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import com.smartfoxserver.bitswarm.service.ISimpleService;

public interface IClusterEventListener extends ISimpleService
{
    void addEventHandler(final String p0, final IClusterEventHandler p1);
}

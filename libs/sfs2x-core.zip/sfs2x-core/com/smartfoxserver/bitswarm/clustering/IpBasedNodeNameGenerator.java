// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import java.util.Iterator;
import com.smartfoxserver.bitswarm.config.SocketConfig;
import java.util.ArrayList;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import java.util.List;

public class IpBasedNodeNameGenerator implements IUniqueNodeNameGenerator
{
    private final List<String> localIPv4Addresses;
    private final BitSwarmEngine engine;
    
    public IpBasedNodeNameGenerator() {
        this.localIPv4Addresses = new ArrayList<String>();
        this.engine = BitSwarmEngine.getInstance();
        this.populateLocalAddresses();
    }
    
    @Override
    public String getUniqueNodeName() {
        final StringBuilder uniqueNodeName = new StringBuilder();
        final List<SocketConfig> bindableAddresses = this.engine.getConfiguration().getBindableAddresses();
        for (final SocketConfig config : bindableAddresses) {
            final String addr = config.getAddress();
            if (this.matches(addr)) {
                uniqueNodeName.append(addr).append(":").append(config.getPort());
            }
        }
        return uniqueNodeName.toString();
    }
    
    private boolean matches(final String matchable) {
        boolean ok = false;
        for (final String s : this.localIPv4Addresses) {
            if (matchable.startsWith(s)) {
                ok = true;
                break;
            }
        }
        return ok;
    }
    
    private void populateLocalAddresses() {
        this.localIPv4Addresses.add("10.");
        for (int id = 16; id <= 31; ++id) {
            this.localIPv4Addresses.add("176." + id + ".");
        }
        this.localIPv4Addresses.add("192.168.");
    }
}

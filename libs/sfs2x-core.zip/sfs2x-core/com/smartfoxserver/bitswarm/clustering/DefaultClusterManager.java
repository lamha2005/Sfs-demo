// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import java.util.List;
import java.util.Iterator;
import com.smartfoxserver.bitswarm.events.IEvent;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.BlockingQueue;
import com.smartfoxserver.bitswarm.util.EngineStats;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;

public final class DefaultClusterManager extends AbstractClusterManager
{
    private final ISessionManager sessionManager;
    private final DataStore dataStore;
    
    public DefaultClusterManager() {
        this.sessionManager = this.engine.getSessionManager();
        this.dataStore = DataStore.instance();
        this.terracottaServerEventListener.init(this);
    }
    
    @Override
    public void init(final Object o) {
        super.init(o);
        if (EngineStats.getRestartCount() > 0) {
            this.dataStore.postOffice.get(this.getLocalNodeName()).clear();
            this.eventListener.init(this);
        }
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
    }
    
    @Override
    public void registerLocalNode() {
        if (this.dataStore.postOffice.get(this.getLocalNodeName()) != null) {
            throw new IllegalStateException("Cannot register local node with cluster! Node already exists: " + this.getLocalNodeName() + ", Node names collision???");
        }
        this.dataStore.postOffice.put(this.getLocalNodeName(), new LinkedBlockingQueue<IEvent>());
        this.eventListener.init(this);
        this.sessionManager.publishLocalNode(this.getLocalNodeName());
    }
    
    @Override
    public void removeNode(final String nodeName) {
        synchronized (this.dataStore) {
            if (!this.dataStore.lastNodeRemoved.equals(nodeName)) {
                this.dataStore.postOffice.remove(nodeName);
                this.sessionManager.onNodeLost(nodeName);
                this.dataStore.lastNodeRemoved = nodeName;
                this.logger.info(String.format("Removed cluster node: %s. By: %s, Thread: %s", nodeName, this.getLocalNodeName(), Thread.currentThread().getName()));
            }
        }
        // monitorexit(this.dataStore)
    }
    
    @Override
    public void clearDataStore() {
        this.logger.info("Data store cleared. " + this.dataStore.postOffice + ", " + this.sessionManager);
        this.dataStore.postOffice.clear();
        this.sessionManager.clearClusterData();
    }
    
    @Override
    public void dispatchClusterEvent(final IEvent event, final String recipientNode) {
        final BlockingQueue<IEvent> mailBox = this.dataStore.postOffice.get(recipientNode);
        if (mailBox != null && event != null) {
            mailBox.offer(event);
        }
        else {
            this.logger.info("Could not disptach cluster event. Node: " + recipientNode + ", Event: " + event);
        }
    }
    
    @Override
    public void broadcastClusterEvent(final IEvent event) {
        for (final String node : this.dataStore.postOffice.keySet()) {
            if (!node.equals(this.getLocalNodeName())) {
                this.dispatchClusterEvent(event, node);
            }
        }
    }
    
    @Override
    public void broadcastClusterEvent(final IEvent event, final List<String> nodeList) {
        for (final String node : nodeList) {
            this.dispatchClusterEvent(event, node);
        }
    }
}

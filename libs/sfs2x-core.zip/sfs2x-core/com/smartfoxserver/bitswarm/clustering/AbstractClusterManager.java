// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import java.util.List;
import com.smartfoxserver.bitswarm.events.IEvent;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.bitswarm.service.BaseCoreService;

public abstract class AbstractClusterManager extends BaseCoreService implements IClusterManager
{
    protected final BitSwarmEngine engine;
    protected final DataStore dataStore;
    protected final Logger logger;
    protected final Logger bootLogger;
    protected final IClusterEventListener eventListener;
    protected final TCEventListener terracottaServerEventListener;
    protected volatile boolean _readyForEvents;
    
    public AbstractClusterManager() {
        this._readyForEvents = false;
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.dataStore = DataStore.instance();
        this.eventListener = new ClusterEventListener();
        this.engine = BitSwarmEngine.getInstance();
        this.terracottaServerEventListener = TCEventListener.getInstance();
    }
    
    @Override
    public void init(final Object o) {
        super.init(o);
        this._readyForEvents = true;
        this.bootLogger.info("Clustering services started: " + this._readyForEvents);
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        this._readyForEvents = false;
        this.eventListener.destroy(null);
        this.bootLogger.info("Clustering services stopped.");
    }
    
    @Override
    public boolean isReadyForEvents() {
        return this._readyForEvents;
    }
    
    @Override
    public void registerLocalNode() {
    }
    
    @Override
    public void removeNode(final String nodeName) {
    }
    
    @Override
    public void clearDataStore() {
    }
    
    @Override
    public abstract void dispatchClusterEvent(final IEvent p0, final String p1);
    
    @Override
    public abstract void broadcastClusterEvent(final IEvent p0, final List<String> p1);
    
    @Override
    public abstract void broadcastClusterEvent(final IEvent p0);
    
    @Override
    public String getLocalNodeName() {
        return TCEventListener.getInstance().getNoideId();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering.handlers;

import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.clustering.AbstractClusterEventHandler;

public class HelloHandler extends AbstractClusterEventHandler
{
    @Override
    public void handleClusterEvent(final IEvent event) throws Exception {
        this.logger.info("Hello Message acknowledged. Sender: " + event.getParameter("sender"));
    }
}

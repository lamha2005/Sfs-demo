// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering.handlers;

import java.util.Iterator;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.events.IEvent;
import com.smartfoxserver.bitswarm.clustering.AbstractClusterEventHandler;

public class SendMessageHandler extends AbstractClusterEventHandler
{
    @Override
    public void handleClusterEvent(final IEvent event) throws Exception {
        final IPacket packet = (IPacket)event.getParameter("packet");
        for (final ISession session : packet.getRecipients()) {
            this.logger.info("Session: " + session.getId() + ", " + session.getNodeId() + ", conn: " + session.getConnection());
        }
        this.engine.getSocketWriter().enqueuePacket(packet);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import com.smartfoxserver.bitswarm.core.BitSwarmEngine;

public class ConfigBasedNodeNameGenerator implements IUniqueNodeNameGenerator
{
    @Override
    public String getUniqueNodeName() {
        return BitSwarmEngine.getInstance().getConfiguration().getLocalNodeName();
    }
}

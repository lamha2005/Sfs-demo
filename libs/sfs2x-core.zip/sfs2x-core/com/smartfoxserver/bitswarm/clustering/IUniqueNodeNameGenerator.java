// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

public interface IUniqueNodeNameGenerator
{
    String getUniqueNodeName();
}

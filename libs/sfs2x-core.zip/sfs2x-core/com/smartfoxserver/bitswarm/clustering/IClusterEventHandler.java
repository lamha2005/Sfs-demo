// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import com.smartfoxserver.bitswarm.events.IEvent;

public interface IClusterEventHandler
{
    void handleClusterEvent(final IEvent p0) throws Exception;
}

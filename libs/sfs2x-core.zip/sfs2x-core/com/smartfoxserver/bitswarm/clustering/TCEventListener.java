// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.clustering;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class TCEventListener
{
    private static TCEventListener _instance;
    protected volatile IClusterManager manager;
    protected final Logger logger;
    private String nodeId;
    
    static {
        TCEventListener._instance = new TCEventListener();
    }
    
    private TCEventListener() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    public void init(final IClusterManager manager) {
        if (this.manager != null) {
            throw new IllegalStateException("TCEventListener is already initialized.");
        }
        this.manager = manager;
    }
    
    public static TCEventListener getInstance() {
        return TCEventListener._instance;
    }
    
    public String getNoideId() {
        return this.nodeId;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.sessions.ISession;

public interface IPacketFinalizer
{
    byte[] process(final ISession p0, final IPacket p1) throws Exception;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.data.IPacket;

public interface IProtocolCodec
{
    void onPacketRead(final IPacket p0);
    
    void onPacketWrite(final IResponse p0);
    
    IOHandler getIOHandler();
    
    void setIOHandler(final IOHandler p0);
}

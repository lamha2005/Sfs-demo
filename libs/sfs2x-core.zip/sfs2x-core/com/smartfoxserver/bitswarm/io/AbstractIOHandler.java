// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.io.filter.IFilterChain;

public abstract class AbstractIOHandler implements IOHandler
{
    protected IProtocolCodec codec;
    protected volatile long readPackets;
    protected IFilterChain preFilterChain;
    protected IFilterChain postFilterChain;
    
    @Override
    public IProtocolCodec getCodec() {
        return this.codec;
    }
    
    @Override
    public void setCodec(final IProtocolCodec codec) {
        this.codec = codec;
    }
    
    @Override
    public long getReadPackets() {
        return this.readPackets;
    }
    
    @Override
    public IFilterChain getPreFilterChain() {
        return this.preFilterChain;
    }
    
    public void setPreFilterChain(final IFilterChain preFilterChain) {
        this.preFilterChain = preFilterChain;
    }
    
    @Override
    public IFilterChain getPostFilterChain() {
        return this.postFilterChain;
    }
    
    public void setPostFilterChain(final IFilterChain postFilterChain) {
        this.postFilterChain = postFilterChain;
    }
}

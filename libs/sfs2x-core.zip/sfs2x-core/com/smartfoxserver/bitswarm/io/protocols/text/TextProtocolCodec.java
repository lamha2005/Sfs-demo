// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io.protocols.text;

import com.smartfoxserver.bitswarm.io.Request;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.bitswarm.data.Packet;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.io.protocols.AbstractProtocolCodec;

public class TextProtocolCodec extends AbstractProtocolCodec
{
    private String defaultControllerId;
    
    public TextProtocolCodec() {
        this.defaultControllerId = "text";
    }
    
    public String getDefaultControllerId() {
        return this.defaultControllerId;
    }
    
    public void setDefaultControllerId(final String defaultControllerId) {
        this.defaultControllerId = defaultControllerId;
    }
    
    @Override
    public void onPacketRead(final IPacket packet) {
        this.dispatchRequestToController(this.packet2Request(packet), this.defaultControllerId);
    }
    
    @Override
    public void onPacketWrite(final IResponse response) {
        final IPacket packet = new Packet();
        packet.setRecipients(response.getRecipients());
        packet.setData(response.getContent());
        this.ioHandler.onDataWrite(packet);
    }
    
    private IRequest packet2Request(final IPacket packet) {
        final IRequest request = new Request();
        final String message = (String)packet.getData();
        final String[] slices = message.split("\\:");
        if (slices.length == 2) {
            request.setId(slices[0]);
            request.setContent(slices[1]);
        }
        else {
            request.setId("generic");
            request.setContent(message);
        }
        request.setSender(packet.getSender());
        return request;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io.protocols;

public enum ProtocolType
{
    BINARY("BINARY", 0, "Binary"), 
    TEXT("TEXT", 1, "Text"), 
    FLASH_CROSSDOMAIN_POLICY("FLASH_CROSSDOMAIN_POLICY", 2, "Flash CrossDomain Policy");
    
    private String description;
    
    private ProtocolType(final String s, final int n, final String description) {
        this.description = description;
    }
    
    @Override
    public String toString() {
        return this.description;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io.protocols;

import com.smartfoxserver.bitswarm.controllers.IController;
import com.smartfoxserver.bitswarm.util.Logging;
import com.smartfoxserver.bitswarm.exceptions.RequestQueueFullException;
import com.smartfoxserver.bitswarm.io.IRequest;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.io.IOHandler;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.bitswarm.controllers.IControllerManager;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;

public abstract class AbstractProtocolCodec implements IProtocolCodec
{
    protected final IControllerManager controllerManager;
    protected final BitSwarmEngine engine;
    protected final Logger logger;
    protected IOHandler ioHandler;
    
    public AbstractProtocolCodec() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.engine = BitSwarmEngine.getInstance();
        this.controllerManager = this.engine.getControllerManager();
    }
    
    protected void dispatchRequestToController(final IRequest request, final Object controllerId) {
        if (controllerId == null) {
            throw new IllegalStateException("Invalid Request: missing controllerId -> " + request);
        }
        final IController controller = this.controllerManager.getControllerById(controllerId);
        try {
            controller.enqueueRequest(request);
        }
        catch (RequestQueueFullException err2) {
            this.logger.error(String.format("RequestQueue is full (%s/%s). Controller ID: %s, Dropping incoming request: ", controller.getQueueSize(), controller.getMaxQueueSize(), controllerId.toString(), request.toString()));
        }
        catch (NullPointerException err) {
            this.logger.warn("Can't handle this request! The related controller is not found: " + controllerId + ", Request: " + request);
            Logging.logStackTrace(this.logger, err);
        }
    }
    
    @Override
    public IOHandler getIOHandler() {
        return this.ioHandler;
    }
    
    @Override
    public void setIOHandler(final IOHandler handler) {
        this.ioHandler = handler;
    }
}

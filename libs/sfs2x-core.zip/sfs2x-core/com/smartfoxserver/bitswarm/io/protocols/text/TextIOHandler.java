// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io.protocols.text;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.data.Packet;
import java.net.SocketAddress;
import java.nio.channels.DatagramChannel;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.bitswarm.io.IOHandler;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.bitswarm.io.AbstractIOHandler;

public class TextIOHandler extends AbstractIOHandler
{
    private static final String PROP_BUFFER = "buffer";
    private static final char[] END_OF_MESSAGE;
    private static final String EOM;
    private final BitSwarmEngine engine;
    private final Logger logger;
    
    static {
        END_OF_MESSAGE = new char[1];
        EOM = new String(TextIOHandler.END_OF_MESSAGE);
    }
    
    public TextIOHandler() {
        this.engine = BitSwarmEngine.getInstance();
        (this.codec = new TextProtocolCodec()).setIOHandler(this);
        this.logger = LoggerFactory.getLogger((Class)TextIOHandler.class);
    }
    
    @Override
    public long getIncomingDroppedPackets() {
        return 0L;
    }
    
    @Override
    public void onDataRead(final DatagramChannel channel, final SocketAddress address, final byte[] data) {
        if (data == null) {
            throw new IllegalArgumentException("Did not expect null byte array!");
        }
        final String fullMsg = new String(data);
        final IPacket packet = new Packet();
        packet.setTransportType(TransportType.UDP);
        packet.setData(fullMsg);
        packet.setOriginalSize(fullMsg.length());
        this.codec.onPacketRead(packet);
    }
    
    @Override
    public void onDataRead(final ISession session, final byte[] data) {
        if (data == null) {
            throw new IllegalArgumentException("Did not expect null byte array!");
        }
        final String rawStr = new String(data);
        StringBuilder buffer = (StringBuilder)session.getSystemProperty("buffer");
        if (buffer == null) {
            buffer = new StringBuilder();
            session.setSystemProperty("buffer", buffer);
        }
        buffer.append(rawStr);
        int msgCount = 0;
        for (int posEOM = buffer.indexOf(TextIOHandler.EOM); posEOM != -1; posEOM = buffer.indexOf(TextIOHandler.EOM)) {
            ++msgCount;
            final String fullMsg = buffer.substring(0, posEOM).trim();
            final int msgSize = fullMsg.length();
            final IPacket packet = new Packet();
            packet.setData(fullMsg);
            packet.setSender(session);
            packet.setOriginalSize(fullMsg.length());
            this.codec.onPacketRead(packet);
            buffer.delete(0, posEOM + 1);
        }
    }
    
    @Override
    public void onDataWrite(final IPacket packet) {
        String message = (String)packet.getData();
        message = String.valueOf(message) + TextIOHandler.EOM;
        packet.setData(message.getBytes());
        this.engine.getSocketWriter().enqueuePacket(packet);
    }
    
    private String getHexDump(final byte[] byteData) {
        String dump = "";
        for (int j = 0; j < byteData.length; ++j) {
            String hexByte = Integer.toHexString(byteData[j]).toUpperCase();
            if (hexByte.length() == 1) {
                hexByte = "0" + hexByte;
            }
            dump = String.valueOf(dump) + hexByte + " ";
        }
        return dump;
    }
}

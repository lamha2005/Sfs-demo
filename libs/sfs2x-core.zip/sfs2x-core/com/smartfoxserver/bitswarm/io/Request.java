// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.data.MessagePriority;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.sessions.ISession;

public final class Request extends AbstractEngineMessage implements IRequest
{
    private ISession sender;
    private TransportType type;
    private MessagePriority priority;
    private long timeStamp;
    
    public Request() {
        this.type = TransportType.TCP;
        this.priority = MessagePriority.NORMAL;
        this.timeStamp = System.nanoTime();
    }
    
    @Override
    public ISession getSender() {
        return this.sender;
    }
    
    @Override
    public TransportType getTransportType() {
        return this.type;
    }
    
    @Override
    public void setSender(final ISession session) {
        this.sender = session;
    }
    
    @Override
    public void setTransportType(final TransportType type) {
        this.type = type;
    }
    
    @Override
    public MessagePriority getPriority() {
        return this.priority;
    }
    
    @Override
    public void setPriority(final MessagePriority priority) {
        this.priority = priority;
    }
    
    @Override
    public long getTimeStamp() {
        return this.timeStamp;
    }
    
    @Override
    public void setTimeStamp(final long timeStamp) {
        this.timeStamp = timeStamp;
    }
    
    @Override
    public boolean isTcp() {
        return this.type == TransportType.TCP;
    }
    
    @Override
    public boolean isUdp() {
        return this.type == TransportType.UDP;
    }
    
    @Override
    public String toString() {
        return String.format("[Req Type: %s, Sender: %s]", this.type, this.sender);
    }
}

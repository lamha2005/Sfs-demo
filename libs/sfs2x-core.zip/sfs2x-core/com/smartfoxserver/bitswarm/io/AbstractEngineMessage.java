// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public abstract class AbstractEngineMessage implements IEngineMessage
{
    protected Object id;
    protected Object content;
    protected Map<String, Object> attributes;
    
    @Override
    public Object getId() {
        return this.id;
    }
    
    @Override
    public void setId(final Object id) {
        this.id = id;
    }
    
    @Override
    public Object getContent() {
        return this.content;
    }
    
    @Override
    public void setContent(final Object content) {
        this.content = content;
    }
    
    @Override
    public Object getAttribute(final String key) {
        Object attr = null;
        if (this.attributes != null) {
            attr = this.attributes.get(key);
        }
        return attr;
    }
    
    @Override
    public void setAttribute(final String key, final Object attribute) {
        if (this.attributes == null) {
            this.attributes = new ConcurrentHashMap<String, Object>();
        }
        this.attributes.put(key, attribute);
    }
    
    @Override
    public boolean hasAttribute(final String key) {
        return this.attributes != null && this.attributes.containsKey(key);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

public interface IEngineMessage
{
    Object getId();
    
    void setId(final Object p0);
    
    Object getContent();
    
    void setContent(final Object p0);
    
    Object getAttribute(final String p0);
    
    void setAttribute(final String p0, final Object p1);
    
    boolean hasAttribute(final String p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.data.IPacket;
import java.net.SocketAddress;
import java.nio.channels.DatagramChannel;
import com.smartfoxserver.bitswarm.sessions.ISession;

public interface IOHandler extends IFilterSupport
{
    void onDataRead(final ISession p0, final byte[] p1);
    
    void onDataRead(final DatagramChannel p0, final SocketAddress p1, final byte[] p2);
    
    void onDataWrite(final IPacket p0);
    
    IProtocolCodec getCodec();
    
    void setCodec(final IProtocolCodec p0);
    
    long getReadPackets();
    
    long getIncomingDroppedPackets();
}

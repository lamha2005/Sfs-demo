// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io.filter;

public interface IFilter
{
}

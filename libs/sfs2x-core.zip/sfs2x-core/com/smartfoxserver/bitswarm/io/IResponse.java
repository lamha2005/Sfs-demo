// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.Collection;
import com.smartfoxserver.bitswarm.data.TransportType;

public interface IResponse extends IEngineMessage
{
    TransportType getTransportType();
    
    void setTransportType(final TransportType p0);
    
    Object getTargetController();
    
    void setTargetController(final Object p0);
    
    Collection<ISession> getRecipients();
    
    void setRecipients(final Collection<ISession> p0);
    
    void setRecipients(final ISession p0);
    
    boolean isTCP();
    
    boolean isUDP();
    
    void write();
    
    void write(final int p0);
}

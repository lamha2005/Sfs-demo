// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.sessions.ISession;

public interface IPacketEncrypter
{
    byte[] encrypt(final ISession p0, final byte[] p1) throws Exception;
    
    byte[] decrypt(final ISession p0, final byte[] p1) throws Exception;
}

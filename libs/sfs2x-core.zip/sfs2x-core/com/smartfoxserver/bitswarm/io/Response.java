// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.util.scheduling.Task;
import com.smartfoxserver.bitswarm.util.scheduling.Scheduler;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import java.util.List;
import java.util.ArrayList;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.Collection;

public class Response extends AbstractEngineMessage implements IResponse
{
    private Collection<ISession> recipients;
    private TransportType type;
    private Object targetController;
    
    public Response() {
        this.type = TransportType.TCP;
    }
    
    @Override
    public Collection<ISession> getRecipients() {
        return this.recipients;
    }
    
    @Override
    public TransportType getTransportType() {
        return this.type;
    }
    
    @Override
    public boolean isTCP() {
        return this.type == TransportType.TCP;
    }
    
    @Override
    public boolean isUDP() {
        return this.type == TransportType.UDP;
    }
    
    @Override
    public void setRecipients(final Collection<ISession> recipents) {
        this.recipients = recipents;
    }
    
    @Override
    public void setRecipients(final ISession session) {
        final List<ISession> recipients = new ArrayList<ISession>();
        recipients.add(session);
        this.setRecipients(recipients);
    }
    
    @Override
    public void setTransportType(final TransportType type) {
        this.type = type;
    }
    
    @Override
    public void write() {
        BitSwarmEngine.getInstance().write(this);
    }
    
    @Override
    public void write(final int delay) {
        final Scheduler scheduler = (Scheduler)BitSwarmEngine.getInstance().getServiceByName("scheduler");
        final Task delayedSocketWriteTask = new Task("delayedSocketWrite");
        delayedSocketWriteTask.getParameters().put("response", this);
        scheduler.addScheduledTask(delayedSocketWriteTask, delay, false, BitSwarmEngine.getInstance().getEngineDelayedTaskHandler());
    }
    
    @Override
    public Object getTargetController() {
        return this.targetController;
    }
    
    @Override
    public void setTargetController(final Object o) {
        this.targetController = o;
    }
    
    public static IResponse clone(final IResponse original) {
        final IResponse newResponse = new Response();
        newResponse.setContent(original.getContent());
        newResponse.setTargetController(original.getTargetController());
        newResponse.setId(original.getId());
        newResponse.setTransportType(original.getTransportType());
        return newResponse;
    }
}

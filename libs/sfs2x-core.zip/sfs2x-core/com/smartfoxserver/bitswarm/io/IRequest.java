// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.data.MessagePriority;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.data.TransportType;

public interface IRequest extends IEngineMessage
{
    TransportType getTransportType();
    
    void setTransportType(final TransportType p0);
    
    ISession getSender();
    
    void setSender(final ISession p0);
    
    MessagePriority getPriority();
    
    void setPriority(final MessagePriority p0);
    
    long getTimeStamp();
    
    void setTimeStamp(final long p0);
    
    boolean isTcp();
    
    boolean isUdp();
}

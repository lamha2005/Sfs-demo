// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.io;

import com.smartfoxserver.bitswarm.io.filter.IFilterChain;

public interface IFilterSupport
{
    IFilterChain getPreFilterChain();
    
    IFilterChain getPostFilterChain();
}

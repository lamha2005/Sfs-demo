// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.controllers;

import com.smartfoxserver.bitswarm.service.IService;

public interface IControllerManager extends IService
{
    IController getControllerById(final Object p0);
    
    void addController(final Object p0, final IController p1);
    
    void removeController(final Object p0);
}

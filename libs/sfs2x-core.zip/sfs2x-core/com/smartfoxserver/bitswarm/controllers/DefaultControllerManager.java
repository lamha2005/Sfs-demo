// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.controllers;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class DefaultControllerManager implements IControllerManager
{
    protected String name;
    protected ConcurrentMap<Object, IController> controllers;
    
    public DefaultControllerManager() {
        this.controllers = new ConcurrentHashMap<Object, IController>();
    }
    
    @Override
    public void init(final Object o) {
        this.startAllControllers();
    }
    
    @Override
    public void destroy(final Object o) {
        this.shutDownAllControllers();
        this.controllers = null;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public void handleMessage(final Object message) {
    }
    
    @Override
    public void addController(final Object id, final IController controller) {
        this.controllers.putIfAbsent(id, controller);
    }
    
    @Override
    public IController getControllerById(final Object id) {
        return this.controllers.get(id);
    }
    
    @Override
    public void removeController(final Object id) {
        this.controllers.remove(id);
    }
    
    private synchronized void shutDownAllControllers() {
        for (final IController controller : this.controllers.values()) {
            controller.destroy(null);
        }
    }
    
    private synchronized void startAllControllers() {
        for (final IController controller : this.controllers.values()) {
            controller.init(null);
        }
    }
}

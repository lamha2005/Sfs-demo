// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.controllers;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public abstract class SimpleController implements IController
{
    protected Object id;
    protected String name;
    protected volatile boolean isActive;
    protected final Logger bootLogger;
    protected final Logger logger;
    
    public SimpleController() {
        this.isActive = false;
        this.bootLogger = LoggerFactory.getLogger("bootLogger");
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void init(final Object o) {
        if (this.isActive) {
            throw new IllegalArgumentException("Object is already initialized. Destroy it first!");
        }
        this.isActive = true;
        this.bootLogger.info(String.format("Controller started: %s ", this.getClass().getName()));
    }
    
    @Override
    public void destroy(final Object o) {
        this.isActive = false;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setName(final String name) {
        if (this.name != null) {
            throw new IllegalStateException("Controller already has a name: " + this.name);
        }
        this.name = name;
    }
    
    @Override
    public Object getId() {
        return this.id;
    }
    
    @Override
    public void setId(final Object id) {
        if (this.id != null) {
            throw new IllegalStateException("Controller already has an id: " + this.id);
        }
        this.id = id;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.controllers;

import com.smartfoxserver.bitswarm.exceptions.RequestQueueFullException;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.bitswarm.service.IService;

public interface IController extends IService
{
    Object getId();
    
    void setId(final Object p0);
    
    void enqueueRequest(final IRequest p0) throws RequestQueueFullException;
    
    int getQueueSize();
    
    int getMaxQueueSize();
    
    void setMaxQueueSize(final int p0);
    
    int getThreadPoolSize();
    
    void setThreadPoolSize(final int p0);
}

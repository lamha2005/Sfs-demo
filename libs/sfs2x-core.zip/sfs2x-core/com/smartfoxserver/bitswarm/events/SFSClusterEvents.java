// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.events;

public class SFSClusterEvents
{
    public static final String LOCAL_NODE_JOIN = "localNodeJoin";
    public static final String LOCAL_NODE_ACTIVE = "localNodeActive";
    public static final String LOCAL_NODE_DISACTIVE = "localNodeDisactive";
    public static final String NODE_JOIN = "nodeJoin";
    public static final String NODE_LEFT = "nodeLeft";
    public static final String PARAM_IS_FIRST_NODE = "isFirstNode";
    public static final String PARAM_NODE_NAME = "nodeName";
}

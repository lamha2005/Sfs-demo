// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.events;

public interface IEventListener
{
    void handleEvent(final IEvent p0);
}

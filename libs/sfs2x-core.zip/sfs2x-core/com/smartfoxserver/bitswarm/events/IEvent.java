// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.events;

public interface IEvent
{
    Object getTarget();
    
    void setTarget(final Object p0);
    
    String getName();
    
    void setName(final String p0);
    
    Object getParameter(final String p0);
    
    void setParameter(final String p0, final Object p1);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.events;

public final class BitSwarmEventParam
{
    public static final String SESSION = "session";
    public static final String DEBUG_ORIGINAL_PACKET = "debugOriginalPacket";
    public static final String DEBUG_WRITTENL_PACKET = "debugWrittenPacket";
    public static final String DEBUG_MESSAGE = "debugMessage";
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.events;

public interface IEventDispatcher
{
    void addEventListener(final String p0, final IEventListener p1);
    
    boolean hasEventListener(final String p0);
    
    void removeEventListener(final String p0, final IEventListener p1);
    
    void dispatchEvent(final IEvent p0);
}

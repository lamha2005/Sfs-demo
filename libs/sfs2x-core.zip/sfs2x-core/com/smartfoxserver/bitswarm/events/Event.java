// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.bitswarm.events;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class Event implements IEvent
{
    protected Object target;
    protected String name;
    protected Map<String, Object> params;
    
    public Event(final String name) {
        this.name = name;
    }
    
    public Event(final String name, final Object source) {
        this.target = source;
        this.name = name;
    }
    
    @Override
    public Object getTarget() {
        return this.target;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setTarget(final Object target) {
        this.target = target;
    }
    
    @Override
    public void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public Object getParameter(final String key) {
        Object param = null;
        if (this.params != null) {
            param = this.params.get(key);
        }
        return param;
    }
    
    @Override
    public void setParameter(final String key, final Object value) {
        if (this.params == null) {
            this.params = new ConcurrentHashMap<String, Object>();
        }
        this.params.put(key, value);
    }
    
    @Override
    public String toString() {
        return "Event { Name:" + this.name + ", Source: " + this.target + ", Params: " + this.params + " }";
    }
}

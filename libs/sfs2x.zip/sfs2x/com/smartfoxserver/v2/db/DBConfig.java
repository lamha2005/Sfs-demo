// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.db;

import java.io.Serializable;

public class DBConfig implements Serializable
{
    private static final long serialVersionUID = -4805085372962209222L;
    public static final String POOL_ACTION_FAIL = "FAIL";
    public static final String POOL_ACTION_BLOCK = "BLOCK";
    public static final String POOL_ACTION_GROW = "GROW";
    public boolean active;
    public String driverName;
    public String connectionString;
    public String userName;
    public String password;
    public String testSql;
    public int maxActiveConnections;
    public int maxIdleConnections;
    public String exhaustedPoolAction;
    public int blockTime;
    
    public DBConfig() {
        this.active = false;
        this.maxActiveConnections = 10;
        this.maxIdleConnections = 10;
        this.exhaustedPoolAction = "FAIL";
        this.blockTime = 3000;
        this.driverName = "";
        this.connectionString = "";
        this.userName = "";
        this.password = "";
        this.testSql = "";
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.db;

import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.pool.KeyedObjectPoolFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.commons.pool.ObjectPool;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import org.apache.commons.dbcp.PoolingDriver;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;

public class SFSDBManager extends BaseDBManager
{
    private static final String JDBC_APACHE_COMMONS_DBCP = "jdbc:apache:commons:dbcp:";
    
    public SFSDBManager(final DBConfig config) {
        super(config);
    }
    
    @Override
    public void init(final Object o) {
        super.init(o);
        if (!this.config.active) {
            return;
        }
        try {
            this.setupDriver();
            this.active = true;
            if (this.config.testSql != null && this.config.testSql.length() > 0) {
                this.testSQLStatement();
            }
        }
        catch (Exception e) {
            final ExceptionMessageComposer message = new ExceptionMessageComposer(e);
            message.setDescription("The initialization of the DBManager has failed.");
            message.setPossibleCauses("if the database driver is not 'seen' int the server classpath the setup fails.");
            message.addInfo("Make sure to deploy the driver .jar file in the extensions/__lib__/ folder and restart the Server.");
            this.log.error(message.toString());
        }
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        try {
            final PoolingDriver driver = (PoolingDriver)DriverManager.getDriver("jdbc:apache:commons:dbcp:");
            driver.closePool(this.name);
        }
        catch (SQLException sqle) {
            this.log.warn(String.format("Failed shutting down DBManager: %s, Reason: %s", this.name, sqle.toString()));
        }
    }
    
    @Override
    public Connection getConnection() throws SQLException {
        this.checkState();
        return DriverManager.getConnection("jdbc:apache:commons:dbcp:" + this.name);
    }
    
    @Override
    public ISFSArray executeQuery(final String sql) throws SQLException {
        return this.executeQuery(sql, null);
    }
    
    @Override
    public ISFSArray executeQuery(final String sql, final Object[] params) throws SQLException {
        this.checkState();
        ISFSArray sfsa = null;
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = this.getConnection();
            stmt = conn.prepareStatement(sql);
            if (params != null) {
                int index = 1;
                for (final Object o : params) {
                    stmt.setObject(index++, o);
                }
            }
            if (this.log.isDebugEnabled()) {
                this.log.debug("Execute Query SQL: " + stmt.toString());
            }
            final ResultSet resultSet = stmt.executeQuery();
            if (resultSet != null) {
                sfsa = SFSArray.newFromResultSet(resultSet);
            }
        }
        finally {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
        return sfsa;
    }
    
    @Override
    public void executeUpdate(final String sql) throws SQLException {
        this.executeUpdate(sql, null);
    }
    
    @Override
    public void executeUpdate(final String sql, final Object[] params) throws SQLException {
        this.checkState();
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = this.getConnection();
            stmt = conn.prepareStatement(sql);
            if (params != null) {
                int index = 1;
                for (final Object o : params) {
                    stmt.setObject(index++, o);
                }
            }
            if (this.log.isDebugEnabled()) {
                this.log.debug("Execute Update SQL: " + stmt.toString());
            }
            stmt.executeUpdate();
        }
        finally {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
    }
    
    @Override
    public Object executeInsert(final String sql, final Object[] params) throws SQLException {
        this.checkState();
        Connection conn = null;
        PreparedStatement stmt = null;
        Object id = null;
        try {
            conn = this.getConnection();
            stmt = conn.prepareStatement(sql, 1);
            if (params != null) {
                int index = 1;
                for (final Object o : params) {
                    stmt.setObject(index++, o);
                }
            }
            if (this.log.isDebugEnabled()) {
                this.log.debug("Execute Insert SQL: " + stmt.toString());
            }
            stmt.executeUpdate();
            final ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (!generatedKeys.next()) {
                return null;
            }
            id = generatedKeys.getObject(1);
        }
        finally {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
        return id;
    }
    
    public int getActiveConnections() {
        if (!this.isActive()) {
            return 0;
        }
        int value = -1;
        try {
            final PoolingDriver driver = (PoolingDriver)DriverManager.getDriver("jdbc:apache:commons:dbcp:");
            final ObjectPool connectionPool = driver.getConnectionPool(this.name);
            value = connectionPool.getNumActive();
        }
        catch (SQLException e) {
            this.log.info(e.toString());
        }
        return value;
    }
    
    public int getIdleConnections() {
        if (!this.isActive()) {
            return 0;
        }
        int value = -1;
        try {
            final PoolingDriver driver = (PoolingDriver)DriverManager.getDriver("jdbc:apache:commons:dbcp:");
            final ObjectPool connectionPool = driver.getConnectionPool(this.name);
            value = connectionPool.getNumIdle();
        }
        catch (SQLException e) {
            this.log.info(e.toString());
        }
        return value;
    }
    
    private void checkState() throws SQLException {
        if (!this.active) {
            throw new SQLException("The DBManager is NOT active in this Zone. SQL Query failed. Please activate it the DBManager from the AdminTool");
        }
    }
    
    private void setupDriver() throws Exception {
        Class.forName(this.config.driverName);
        final GenericObjectPool.Config cfg = new GenericObjectPool.Config();
        cfg.maxActive = this.config.maxActiveConnections;
        cfg.maxIdle = this.config.maxIdleConnections;
        cfg.testOnBorrow = true;
        if (this.config.exhaustedPoolAction.equalsIgnoreCase("GROW")) {
            cfg.whenExhaustedAction = 2;
        }
        else if (this.config.exhaustedPoolAction.equalsIgnoreCase("FAIL")) {
            cfg.whenExhaustedAction = 0;
        }
        else if (this.config.exhaustedPoolAction.equalsIgnoreCase("BLOCK")) {
            cfg.whenExhaustedAction = 1;
            cfg.maxWait = this.config.blockTime;
        }
        final ObjectPool connectionPool = (ObjectPool)new GenericObjectPool((PoolableObjectFactory)null, cfg);
        final ConnectionFactory connectionFactory = (ConnectionFactory)new DriverManagerConnectionFactory(this.config.connectionString, this.config.userName, this.config.password);
        new PoolableConnectionFactory(connectionFactory, connectionPool, (KeyedObjectPoolFactory)null, this.config.testSql, false, true);
        final PoolingDriver driver = new PoolingDriver();
        driver.registerPool(this.name, connectionPool);
    }
    
    private void testSQLStatement() {
        try {
            this.executeQuery(this.config.testSql);
        }
        catch (SQLException sqle) {
            final ExceptionMessageComposer message = new ExceptionMessageComposer(sqle, false);
            message.setDescription("The DBManager Test SQL failed: " + this.config.testSql);
            message.addInfo("Please double check your SQL code and make sure that Database server is running.");
            this.log.error(message.toString());
        }
    }
}

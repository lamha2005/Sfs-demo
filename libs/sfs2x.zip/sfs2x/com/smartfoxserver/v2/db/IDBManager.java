// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.db;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.sql.SQLException;
import java.sql.Connection;
import com.smartfoxserver.bitswarm.service.IService;

public interface IDBManager extends IService
{
    boolean isActive();
    
    DBConfig getConfig();
    
    Connection getConnection() throws SQLException;
    
    ISFSArray executeQuery(final String p0, final Object[] p1) throws SQLException;
    
    @Deprecated
    ISFSArray executeQuery(final String p0) throws SQLException;
    
    void executeUpdate(final String p0, final Object[] p1) throws SQLException;
    
    Object executeInsert(final String p0, final Object[] p1) throws SQLException;
    
    @Deprecated
    void executeUpdate(final String p0) throws SQLException;
}

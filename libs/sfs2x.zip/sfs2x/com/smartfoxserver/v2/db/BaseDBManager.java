// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.db;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.Zone;
import java.util.concurrent.atomic.AtomicInteger;

abstract class BaseDBManager implements IDBManager
{
    private static final AtomicInteger autoId;
    protected Zone parentZone;
    protected boolean active;
    protected final DBConfig config;
    protected final String name;
    protected final Logger log;
    
    static {
        autoId = new AtomicInteger();
    }
    
    public BaseDBManager(final DBConfig config) {
        this.active = false;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.config = config;
        this.name = "DBManager-" + BaseDBManager.autoId.incrementAndGet();
    }
    
    public void init(final Object o) {
        if (o != null && o instanceof Zone) {
            this.parentZone = (Zone)o;
        }
        if (this.config == null) {
            throw new IllegalStateException("DBManager was not configured! Please make sure to pass a non-null DBConfig to the constructor.");
        }
    }
    
    public void destroy(final Object o) {
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        throw new UnsupportedOperationException("Sorry, operation is not supported in this class. The name is auto-generated.");
    }
    
    public void handleMessage(final Object arg0) {
        throw new UnsupportedOperationException("Sorry, operation is not supported in this class.");
    }
    
    @Override
    public DBConfig getConfig() {
        return this.config;
    }
    
    @Override
    public boolean isActive() {
        return this.active;
    }
}

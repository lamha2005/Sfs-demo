// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.security;

public enum SystemPermission
{
    SuperUser("SuperUser", 0), 
    ExtensionCalls("ExtensionCalls", 1);
    
    private SystemPermission(final String s, final int n) {
    }
}

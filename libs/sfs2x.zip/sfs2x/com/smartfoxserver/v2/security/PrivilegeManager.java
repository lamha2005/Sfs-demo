// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.security;

import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.entities.User;

public interface PrivilegeManager
{
    boolean isActive();
    
    void setActive(final boolean p0);
    
    void setPermissionProfile(final SFSPermissionProfile p0);
    
    void removePermissionProfile(final short p0);
    
    void removePermissionProfile(final String p0);
    
    boolean containsPermissionProfile(final short p0);
    
    boolean containsPermissionProfile(final String p0);
    
    SFSPermissionProfile getPermissionProfile(final short p0);
    
    SFSPermissionProfile getPermissionProfile(final String p0);
    
    boolean isRequestAllowed(final User p0, final SystemRequest p1);
    
    boolean isFlagSet(final User p0, final SystemPermission p1);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.security;

public interface IPermissionProfile
{
    short getId();
}

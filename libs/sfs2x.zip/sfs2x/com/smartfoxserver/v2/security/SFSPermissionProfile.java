// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.security;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import com.smartfoxserver.v2.controllers.SystemRequest;
import java.util.Set;

public class SFSPermissionProfile
{
    private short id;
    private String name;
    private Set<SystemRequest> deniedRequest;
    private Set<SystemPermission> permissionFlags;
    
    public SFSPermissionProfile(final short id, final String name, final List<SystemRequest> deniedRequests) {
        this(id, name, deniedRequests, null);
    }
    
    public SFSPermissionProfile(final short id, final String name, final List<SystemRequest> deniedRequests, final List<SystemPermission> flags) {
        this.id = id;
        this.name = name;
        this.deniedRequest = new HashSet<SystemRequest>();
        this.permissionFlags = new HashSet<SystemPermission>();
        if (deniedRequests != null) {
            this.deniedRequest.addAll(deniedRequests);
        }
        if (flags != null) {
            this.permissionFlags.addAll(flags);
        }
    }
    
    public boolean isRequestAllowed(final SystemRequest request) {
        return !this.deniedRequest.contains(request);
    }
    
    public boolean isFlagSet(final SystemPermission permission) {
        return this.permissionFlags.contains(permission);
    }
    
    public short getId() {
        return this.id;
    }
    
    public String getName() {
        return this.name;
    }
}

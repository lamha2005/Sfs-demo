// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.security;

import java.util.Iterator;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.entities.User;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.util.Map;

public class SFSPrivilegeManager implements PrivilegeManager
{
    private final Map<Short, SFSPermissionProfile> privilegeProfiles;
    private final Logger log;
    private volatile boolean active;
    
    public SFSPrivilegeManager() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.privilegeProfiles = new ConcurrentHashMap<Short, SFSPermissionProfile>();
    }
    
    @Override
    public boolean isActive() {
        return this.active;
    }
    
    @Override
    public void setActive(final boolean active) {
        this.active = active;
    }
    
    @Override
    public boolean containsPermissionProfile(final short profileId) {
        return this.privilegeProfiles.containsKey(profileId);
    }
    
    @Override
    public boolean containsPermissionProfile(final String profileName) {
        boolean found = false;
        final Short id = this.findIdFromName(profileName);
        if (id != null) {
            found = this.containsPermissionProfile(id);
        }
        return found;
    }
    
    @Override
    public SFSPermissionProfile getPermissionProfile(final short profileId) {
        return this.privilegeProfiles.get(profileId);
    }
    
    @Override
    public SFSPermissionProfile getPermissionProfile(final String profileName) {
        final Short id = this.findIdFromName(profileName);
        if (id == null) {
            return null;
        }
        return this.privilegeProfiles.get(id);
    }
    
    @Override
    public void removePermissionProfile(final short permId) {
        this.privilegeProfiles.remove(permId);
    }
    
    @Override
    public void removePermissionProfile(final String profileName) {
        final Short id = this.findIdFromName(profileName);
        if (id != null) {
            this.privilegeProfiles.remove(id);
        }
    }
    
    @Override
    public void setPermissionProfile(final SFSPermissionProfile profile) {
        if (this.privilegeProfiles.containsKey(profile.getId())) {
            this.log.warn("Profile with duplicate ID: " + profile.getId() + ", name: " + profile.getName() + " was not added to the manager");
            return;
        }
        this.privilegeProfiles.put(profile.getId(), profile);
    }
    
    @Override
    public boolean isRequestAllowed(final User user, final SystemRequest request) {
        if (!this.isActive()) {
            return true;
        }
        boolean success = false;
        final SFSPermissionProfile profile = this.privilegeProfiles.get(user.getPrivilegeId());
        if (profile != null) {
            success = profile.isRequestAllowed(request);
        }
        return success;
    }
    
    @Override
    public boolean isFlagSet(final User user, final SystemPermission permission) {
        boolean success = false;
        final SFSPermissionProfile profile = this.privilegeProfiles.get(user.getPrivilegeId());
        if (profile != null) {
            success = profile.isFlagSet(permission);
        }
        return success;
    }
    
    private Short findIdFromName(final String name) {
        Short profileId = null;
        for (final SFSPermissionProfile profile : this.privilegeProfiles.values()) {
            if (profile.getName().equals(name)) {
                profileId = profile.getId();
                break;
            }
        }
        return profileId;
    }
    
    public void dump() {
        for (final Short id : this.privilegeProfiles.keySet()) {
            System.out.println(id + ":");
            final SFSPermissionProfile profile = this.privilegeProfiles.get(id);
            System.out.println("\tAllowed Sys Req:");
            SystemRequest[] values;
            for (int length = (values = SystemRequest.values()).length, i = 0; i < length; ++i) {
                final SystemRequest sysReq = values[i];
                if (profile.isRequestAllowed(sysReq)) {
                    System.out.println("\t\t" + sysReq);
                }
            }
            System.out.println("\tPermission Flags:");
            SystemPermission[] values2;
            for (int length2 = (values2 = SystemPermission.values()).length, j = 0; j < length2; ++j) {
                final SystemPermission perm = values2[j];
                if (profile.isFlagSet(perm)) {
                    System.out.println("\t\t" + perm);
                }
            }
        }
    }
}

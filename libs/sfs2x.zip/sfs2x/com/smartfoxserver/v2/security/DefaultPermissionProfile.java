// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.security;

public enum DefaultPermissionProfile implements IPermissionProfile
{
    GUEST("GUEST", 0, 0), 
    STANDARD("STANDARD", 1, 1), 
    MODERATOR("MODERATOR", 2, 2), 
    ADMINISTRATOR("ADMINISTRATOR", 3, 3);
    
    private short id;
    
    private DefaultPermissionProfile(final String s, final int n, final int id) {
        this.id = (short)id;
    }
    
    @Override
    public short getId() {
        return this.id;
    }
    
    public static DefaultPermissionProfile fromId(final short id) {
        DefaultPermissionProfile[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final DefaultPermissionProfile dpp = values[i];
            if (dpp.id == id) {
                return dpp;
            }
        }
        return null;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

public class ReservedRoomVariables
{
    public static final String RV_GAME_STARTED = "$GS";
}

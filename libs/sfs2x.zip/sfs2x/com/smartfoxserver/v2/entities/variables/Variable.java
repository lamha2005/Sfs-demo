// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public interface Variable extends Cloneable
{
    String getName();
    
    VariableType getType();
    
    Object getValue();
    
    Boolean getBoolValue();
    
    Integer getIntValue();
    
    Double getDoubleValue();
    
    String getStringValue();
    
    ISFSObject getSFSObjectValue();
    
    ISFSArray getSFSArrayValue();
    
    boolean isNull();
    
    ISFSArray toSFSArray();
}

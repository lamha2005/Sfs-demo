// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

public interface UserVariable extends Variable
{
    void setHidden(final boolean p0);
    
    boolean isHidden();
    
    boolean isPrivate();
    
    void setPrivate(final boolean p0);
    
    void setNull();
}

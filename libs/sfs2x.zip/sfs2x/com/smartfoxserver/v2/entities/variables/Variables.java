// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public final class Variables
{
    public static Map<String, ? extends Variable> toVariablesMap(final List<? extends Variable> varList) {
        final Map<String, Variable> varMap = new HashMap<String, Variable>();
        for (final Variable vv : varList) {
            varMap.put(vv.getName(), vv);
        }
        return varMap;
    }
}

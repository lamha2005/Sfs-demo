// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

import com.smartfoxserver.v2.entities.User;

public interface RoomVariable extends UserVariable
{
    boolean isPersistent();
    
    boolean isGlobal();
    
    void setPersistent(final boolean p0);
    
    void setGlobal(final boolean p0);
    
    User getOwner();
    
    void setOwner(final User p0);
}

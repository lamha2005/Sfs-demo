// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class UserVariableChanges
{
    public List<UserVariable> publicVarList;
    public List<UserVariable> privateVarList;
    
    public UserVariableChanges() {
        this.privateVarList = new LinkedList<UserVariable>();
        this.publicVarList = new LinkedList<UserVariable>();
    }
    
    public boolean needsUpdate() {
        return this.publicVarList.size() + this.privateVarList.size() > 0;
    }
    
    public List<UserVariable> getCombined() {
        final List<UserVariable> combined = new LinkedList<UserVariable>(this.publicVarList);
        combined.addAll(this.privateVarList);
        return combined;
    }
}

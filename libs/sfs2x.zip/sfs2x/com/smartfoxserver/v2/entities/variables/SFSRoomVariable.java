// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.User;

public class SFSRoomVariable extends SFSUserVariable implements RoomVariable
{
    private volatile boolean _private;
    private volatile boolean _persistent;
    private volatile boolean _global;
    private User _owner;
    
    private SFSRoomVariable(final String name) {
        super(name);
    }
    
    private SFSRoomVariable(final String name, final String type, final String literal) {
        super(name, VariableType.fromString(type), literal);
    }
    
    public SFSRoomVariable(final String name, final Object value) {
        this(name, value, false, false, false);
    }
    
    public SFSRoomVariable(final String name, final Object value, final boolean isPrivate, final boolean isPersistent, final boolean isGlobal) {
        super(name, value);
        this._private = isPrivate;
        this._persistent = isPersistent;
        this._global = isGlobal;
    }
    
    public static SFSRoomVariable newFromStringLiteral(final String name, final String type, final String literal) {
        return new SFSRoomVariable(name, type, literal);
    }
    
    public static SFSRoomVariable newFromSFSArray(final ISFSArray array) {
        return new SFSRoomVariable(array.getUtfString(0), array.getElementAt(2), array.getBool(3), array.getBool(4), false);
    }
    
    @Override
    public boolean isGlobal() {
        return this._global;
    }
    
    @Override
    public boolean isPersistent() {
        return this._persistent;
    }
    
    @Override
    public boolean isPrivate() {
        return this._private;
    }
    
    @Override
    public void setGlobal(final boolean flag) {
        this._global = flag;
    }
    
    @Override
    public void setPersistent(final boolean flag) {
        this._persistent = flag;
    }
    
    @Override
    public void setPrivate(final boolean flag) {
        this._private = flag;
    }
    
    @Override
    public User getOwner() {
        return this._owner;
    }
    
    @Override
    public void setOwner(final User user) {
        this._owner = user;
    }
    
    @Override
    public ISFSArray toSFSArray() {
        final ISFSArray sfsa = SFSArray.newInstance();
        sfsa.addUtfString(this.name);
        sfsa.addByte((byte)this.type.getId());
        this.populateArrayWithValue(sfsa);
        sfsa.addBool(this.isPrivate());
        sfsa.addBool(this.isPersistent());
        return sfsa;
    }
    
    @Override
    public String toString() {
        return String.format("{ N: %s, T: %s, V: %s, Pr: %s, Ps: %s, G: %s, H: %s, Owner: %s }", this.name, this.type, this.value, this._private, this._persistent, this._global, this.isHidden(), (this._owner == null) ? "<Server>" : this._owner.toString());
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.variables;

public enum VariableType
{
    NULL("NULL", 0, 0), 
    BOOL("BOOL", 1, 1), 
    INT("INT", 2, 2), 
    DOUBLE("DOUBLE", 3, 3), 
    STRING("STRING", 4, 4), 
    OBJECT("OBJECT", 5, 5), 
    ARRAY("ARRAY", 6, 6);
    
    private int id;
    
    private VariableType(final String s, final int n, final int id) {
        this.id = id;
    }
    
    public int getId() {
        return this.id;
    }
    
    public static VariableType fromString(final String id) {
        return valueOf(id.toUpperCase());
    }
    
    public static VariableType fromId(final int id) {
        VariableType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final VariableType type = values[i];
            if (type.id == id) {
                return type;
            }
        }
        return null;
    }
}

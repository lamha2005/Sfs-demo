// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

public interface Email
{
    String getFromAddress();
    
    String getToAddress();
    
    String getSubject();
    
    String getMessage();
    
    int getPriority();
}

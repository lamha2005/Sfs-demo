// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.mmo.CreateMMORoomSettings;
import com.smartfoxserver.v2.game.SFSGame;
import com.smartfoxserver.v2.game.CreateSFSGameSettings;
import com.smartfoxserver.v2.api.CreateRoomSettings;

public class DefaultRoomFactory implements IRoomFactory
{
    @Override
    public Room createNewRoom(final CreateRoomSettings settings) {
        Room newRoom;
        if (settings instanceof CreateSFSGameSettings) {
            newRoom = new SFSGame(settings.getName());
            settings.setGame(true);
        }
        else if (settings instanceof CreateMMORoomSettings) {
            newRoom = new MMORoom(settings.getName(), ((CreateMMORoomSettings)settings).getDefaultAOI(), ((CreateMMORoomSettings)settings).getProximityListUpdateMillis());
        }
        else {
            newRoom = new SFSRoom(settings.getName());
        }
        return newRoom;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Room;
import java.util.List;
import com.smartfoxserver.v2.entities.Zone;

public interface IMatchingEngine
{
    List<Room> findGames(final MatchExpression p0, final Zone p1);
    
    List<Room> findGames(final MatchExpression p0, final Zone p1, final int p2);
    
    List<Room> findGames(final MatchExpression p0, final Zone p1, final String p2);
    
    List<Room> findGames(final MatchExpression p0, final Zone p1, final String p2, final int p3);
    
    List<User> findPlayers(final MatchExpression p0, final Zone p1);
    
    List<User> findPlayers(final MatchExpression p0, final Zone p1, final int p2);
    
    List<User> findPlayers(final MatchExpression p0, final Zone p1, final Room p2);
    
    List<User> findPlayers(final MatchExpression p0, final Zone p1, final Room p2, final int p3);
}

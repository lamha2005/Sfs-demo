// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;

public class MatchExpression
{
    private final String varName;
    private final IMatcher condition;
    private final Object value;
    private LogicOperator logicOp;
    private MatchExpression parent;
    private MatchExpression next;
    
    public MatchExpression(final String varName, final IMatcher condition, final Object value) {
        this.logicOp = null;
        this.parent = null;
        this.next = null;
        this.varName = varName;
        this.condition = condition;
        this.value = value;
    }
    
    private MatchExpression(final String varName, final IMatcher condition, final Object value, final LogicOperator logicOp, final MatchExpression parent) {
        this.logicOp = null;
        this.parent = null;
        this.next = null;
        this.varName = varName;
        this.condition = condition;
        this.value = value;
        this.logicOp = logicOp;
        this.parent = parent;
    }
    
    public MatchExpression and(final String varName, final IMatcher condition, final Object value) {
        return this.next = new MatchExpression(varName, condition, value, LogicOperator.AND, this);
    }
    
    public MatchExpression or(final String varName, final IMatcher condition, final Object value) {
        return this.next = new MatchExpression(varName, condition, value, LogicOperator.OR, this);
    }
    
    String getVarName() {
        return this.varName;
    }
    
    IMatcher getCondition() {
        return this.condition;
    }
    
    Object getValue() {
        return this.value;
    }
    
    LogicOperator getLogicOp() {
        return this.logicOp;
    }
    
    @Override
    public String toString() {
        MatchExpression expr = this.rewind();
        final StringBuilder sb = new StringBuilder(expr.asString());
        while (expr.hasNext()) {
            expr = expr.next();
            sb.append(expr.asString());
        }
        return sb.toString();
    }
    
    private String asString() {
        final StringBuilder sb = new StringBuilder();
        if (this.logicOp != null) {
            sb.append(" ").append(this.logicOp).append(" ");
        }
        sb.append("(");
        sb.append(this.varName).append(" ").append(this.condition.getSymbol()).append(" ").append((Object)((this.value instanceof String) ? ("'" + this.value + "'") : this.value));
        sb.append(")");
        return sb.toString();
    }
    
    public boolean hasNext() {
        return this.next != null;
    }
    
    public MatchExpression next() {
        return this.next;
    }
    
    public MatchExpression rewind() {
        MatchExpression currNode = this;
        for (int c = 0; currNode.parent != null; currNode = currNode.parent, ++c) {}
        return currNode;
    }
    
    public static MatchExpression fromSFSArray(final ISFSArray sfsa) {
        MatchExpression expression = null;
        for (int i = 0; i < sfsa.size(); ++i) {
            final ISFSArray expData = sfsa.getSFSArray(i);
            if (expData.size() != 5) {
                throw new IllegalArgumentException("Malformed expression data: " + sfsa.getDump());
            }
            LogicOperator logicOp = null;
            if (!expData.isNull(0)) {
                logicOp = LogicOperator.valueOf(expData.getUtfString(0));
            }
            final String varName = expData.getUtfString(1);
            final int matcherType = expData.getByte(2);
            IMatcher matcher = null;
            final String matchSymbol = expData.getUtfString(3);
            if (matcherType == 0) {
                matcher = BoolMatch.fromSymbol(matchSymbol);
            }
            else if (matcherType == 1) {
                matcher = NumberMatch.fromSymbol(matchSymbol);
            }
            else {
                matcher = StringMatch.fromSymbol(matchSymbol);
            }
            final Object value = expData.getElementAt(4);
            if (logicOp == null) {
                expression = new MatchExpression(varName, matcher, value);
            }
            else if (logicOp == LogicOperator.AND) {
                expression = expression.and(varName, matcher, value);
            }
            else if (logicOp == LogicOperator.OR) {
                expression = expression.or(varName, matcher, value);
            }
        }
        return expression;
    }
    
    public ISFSArray toSFSArray() {
        MatchExpression expr = this.rewind();
        final ISFSArray sfsa = new SFSArray();
        sfsa.addSFSArray(expr.expressionAsSFSArray());
        while (expr.hasNext()) {
            expr = expr.next();
            sfsa.addSFSArray(expr.expressionAsSFSArray());
        }
        return sfsa;
    }
    
    ISFSArray expressionAsSFSArray() {
        final ISFSArray expr = new SFSArray();
        if (this.logicOp != null) {
            expr.addUtfString(this.logicOp.toString());
        }
        else {
            expr.addNull();
        }
        expr.addUtfString(this.varName);
        expr.addByte((byte)this.condition.getType());
        expr.addUtfString(this.condition.getSymbol());
        if (this.condition.getType() == 0) {
            expr.addBool((boolean)this.value);
        }
        else if (this.condition.getType() == 1) {
            expr.addDouble(((Number)this.value).doubleValue());
        }
        else {
            expr.addUtfString((String)this.value);
        }
        return expr;
    }
}

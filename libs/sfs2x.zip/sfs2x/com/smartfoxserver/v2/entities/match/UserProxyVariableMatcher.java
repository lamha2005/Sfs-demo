// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import com.smartfoxserver.v2.entities.User;

public class UserProxyVariableMatcher implements IProxyVariableResolver
{
    @Override
    public Object getValue(final EntityWithVariables entity, final String variableName) {
        final Object o = entity.getEntity();
        if (!(o instanceof User)) {
            return null;
        }
        final User user = (User)o;
        Object value = null;
        if (variableName.equals("${N}")) {
            value = user.getName();
        }
        else if (variableName.equals("${ISP}")) {
            value = user.isPlayer();
        }
        else if (variableName.equals("${ISS}")) {
            value = user.isSpectator();
        }
        else if (variableName.equals("${ISN}")) {
            value = user.isNpc();
        }
        else if (variableName.equals("${PRID}")) {
            value = user.getPrivilegeId();
        }
        else if (variableName.equals("${IAR}")) {
            value = (user.getJoinedRooms().size() == 0);
        }
        return value;
    }
}

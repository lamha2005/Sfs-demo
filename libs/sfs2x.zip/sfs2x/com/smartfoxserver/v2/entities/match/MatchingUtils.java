// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;

public class MatchingUtils
{
    private static final MatchingUtils _instance;
    private final ExpressionMatcher roomMatcher;
    private final ExpressionMatcher userMatcher;
    
    static {
        _instance = new MatchingUtils();
    }
    
    private MatchingUtils() {
        (this.roomMatcher = new VariablesMatcher()).setProxyVariableResolver(new RoomProxyVariableResolver());
        (this.userMatcher = new VariablesMatcher()).setProxyVariableResolver(new UserProxyVariableMatcher());
    }
    
    public static MatchingUtils getInstance() {
        return MatchingUtils._instance;
    }
    
    public boolean matchUser(final User user, final MatchExpression conditions) {
        return this.userMatcher.match(new EntityWithVariablesWrapper(user), conditions);
    }
    
    public boolean matchRoom(final Room room, final MatchExpression conditions) {
        return this.roomMatcher.match(new EntityWithVariablesWrapper(room), conditions);
    }
    
    public List<User> matchUsers(final Collection<User> userList, final MatchExpression conditions) {
        return this.matchUsers(userList, conditions, Integer.MAX_VALUE);
    }
    
    public List<User> matchUsers(final Collection<User> userList, final MatchExpression conditions, int limit) {
        if (limit <= 0) {
            limit = Integer.MAX_VALUE;
        }
        final List<User> filteredUsers = new ArrayList<User>();
        for (final User user : userList) {
            if (this.matchUser(user, conditions)) {
                if (filteredUsers.size() >= limit) {
                    break;
                }
                filteredUsers.add(user);
            }
        }
        return filteredUsers;
    }
    
    public List<Room> matchRooms(final Collection<Room> roomList, final MatchExpression conditions) {
        return this.matchRooms(roomList, conditions, Integer.MAX_VALUE);
    }
    
    public List<Room> matchRooms(final Collection<Room> roomList, final MatchExpression conditions, int limit) {
        if (limit <= 0) {
            limit = Integer.MAX_VALUE;
        }
        final List<Room> filteredRooms = new ArrayList<Room>();
        for (final Room room : roomList) {
            if (this.matchRoom(room, conditions)) {
                if (filteredRooms.size() >= limit) {
                    break;
                }
                filteredRooms.add(room);
            }
        }
        return filteredRooms;
    }
}

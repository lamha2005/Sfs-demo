// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import java.util.Collection;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Room;

public class EntityWithVariablesWrapper implements EntityWithVariables
{
    private final Object entity;
    
    public EntityWithVariablesWrapper(final Object entity) {
        if (!(entity instanceof Room) && !(entity instanceof User)) {
            throw new IllegalArgumentException("Object not supported. Provided entity is not a Room, nor a User!");
        }
        this.entity = entity;
    }
    
    @Override
    public UserVariable getVariable(final String varName) {
        if (this.entity instanceof Room) {
            return ((Room)this.entity).getVariable(varName);
        }
        return ((User)this.entity).getVariable(varName);
    }
    
    @Override
    public Collection<? extends UserVariable> getVariables() {
        if (this.entity instanceof Room) {
            return ((Room)this.entity).getVariables();
        }
        return ((User)this.entity).getVariables();
    }
    
    @Override
    public Object getEntity() {
        return this.entity;
    }
}

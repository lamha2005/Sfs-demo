// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

interface ExpressionMatcher
{
    boolean match(final EntityWithVariables p0, final MatchExpression p1);
    
    IProxyVariableResolver getProxyVariableResolver();
    
    void setProxyVariableResolver(final IProxyVariableResolver p0);
}

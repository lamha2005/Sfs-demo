// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

enum LogicOperator
{
    AND("AND", 0), 
    OR("OR", 1);
    
    private LogicOperator(final String s, final int n) {
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import com.smartfoxserver.v2.entities.User;
import java.util.Collection;
import com.smartfoxserver.v2.entities.Room;
import java.util.List;
import com.smartfoxserver.v2.entities.Zone;

public class GameMatchingEngine implements IMatchingEngine
{
    private final MatchingUtils matcher;
    
    public GameMatchingEngine() {
        this.matcher = MatchingUtils.getInstance();
    }
    
    @Override
    public List<Room> findGames(final MatchExpression conditions, final Zone zone, final int limit) {
        return this.findGames(conditions, zone, null, limit);
    }
    
    @Override
    public List<Room> findGames(final MatchExpression conditions, final Zone zone, final String groupId, final int limit) {
        if (groupId != null && !zone.containsGroup(groupId)) {
            throw new IllegalArgumentException("Provided group is not available: " + groupId);
        }
        final List<Room> searchableRooms = (groupId == null) ? zone.getRoomList() : zone.getRoomListFromGroup(groupId);
        return this.matcher.matchRooms(searchableRooms, conditions, limit);
    }
    
    @Override
    public List<Room> findGames(final MatchExpression conditions, final Zone zone, final String groupId) {
        return this.findGames(conditions, zone, groupId, Integer.MAX_VALUE);
    }
    
    @Override
    public List<Room> findGames(final MatchExpression conditions, final Zone zone) {
        return this.findGames(conditions, zone, null, Integer.MAX_VALUE);
    }
    
    @Override
    public List<User> findPlayers(final MatchExpression conditions, final Zone zone, final int limit) {
        return this.findPlayers(conditions, zone, null, limit);
    }
    
    @Override
    public List<User> findPlayers(final MatchExpression conditions, final Zone zone, final Room room, final int limit) {
        final Collection<User> searchableUsers = (room == null) ? zone.getUserList() : room.getUserList();
        return this.matcher.matchUsers(searchableUsers, conditions, limit);
    }
    
    @Override
    public List<User> findPlayers(final MatchExpression conditions, final Zone zone, final Room room) {
        return this.findPlayers(conditions, zone, room, Integer.MAX_VALUE);
    }
    
    @Override
    public List<User> findPlayers(final MatchExpression conditions, final Zone zone) {
        return this.findPlayers(conditions, zone, null, Integer.MAX_VALUE);
    }
}

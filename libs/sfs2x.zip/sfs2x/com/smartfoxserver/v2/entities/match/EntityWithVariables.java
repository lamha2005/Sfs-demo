// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import java.util.Collection;
import com.smartfoxserver.v2.entities.variables.UserVariable;

interface EntityWithVariables
{
    UserVariable getVariable(final String p0);
    
    Collection<? extends UserVariable> getVariables();
    
    Object getEntity();
}

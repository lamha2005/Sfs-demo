// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import com.smartfoxserver.v2.game.SFSGame;
import com.smartfoxserver.v2.entities.Room;

public class RoomProxyVariableResolver implements IProxyVariableResolver
{
    @Override
    public Object getValue(final EntityWithVariables entity, final String variableName) {
        final Object o = entity.getEntity();
        if (!(o instanceof Room)) {
            return null;
        }
        final Room room = (Room)o;
        Object value = null;
        if (variableName.equals("${N}")) {
            value = room.getName();
        }
        else if (variableName.equals("${G}")) {
            value = room.getGroupId();
        }
        else if (variableName.equals("${ISG}")) {
            value = room.isGame();
        }
        else if (variableName.equals("${MXU}")) {
            value = room.getMaxUsers();
        }
        else if (variableName.equals("${MXS}")) {
            value = room.getMaxSpectators();
        }
        else if (variableName.equals("${UC}")) {
            value = room.getSize().getUserCount();
        }
        else if (variableName.equals("${SC}")) {
            value = room.getSize().getSpectatorCount();
        }
        else if (variableName.equals("${ISP}")) {
            value = room.isPasswordProtected();
        }
        else if (variableName.equals("${HFP}")) {
            value = !room.isFull();
        }
        else if (variableName.equals("${IST}")) {
            value = (room instanceof SFSGame);
        }
        return value;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

import com.smartfoxserver.v2.entities.variables.Variable;
import com.smartfoxserver.v2.entities.data.SFSDataWrapper;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class VariablesMatcher implements ExpressionMatcher
{
    private static final String DOT_CHAR = ".";
    private final Logger log;
    private IProxyVariableResolver varProxy;
    
    public VariablesMatcher() {
        this.log = LoggerFactory.getLogger((Class)VariablesMatcher.class);
    }
    
    @Override
    public IProxyVariableResolver getProxyVariableResolver() {
        return this.varProxy;
    }
    
    @Override
    public void setProxyVariableResolver(final IProxyVariableResolver resolver) {
        this.varProxy = resolver;
    }
    
    @Override
    public boolean match(final EntityWithVariables entity, MatchExpression expression) {
        if (expression == null) {
            return true;
        }
        boolean result = false;
        expression = expression.rewind();
        result = this.checkCondition(entity, expression);
        while (expression.hasNext()) {
            expression = expression.next();
            if (expression.getLogicOp() == LogicOperator.AND) {
                result = (result && this.checkCondition(entity, expression));
            }
            else {
                result = (result || this.checkCondition(entity, expression));
            }
        }
        return result;
    }
    
    private boolean checkCondition(final EntityWithVariables entity, final MatchExpression expression) {
        boolean result = false;
        final IMatcher condition = expression.getCondition();
        final Object varValue = this.resolveVariable(entity, expression.getVarName());
        if (varValue != null) {
            if (condition instanceof BoolMatch) {
                result = this.matchBoolean((Boolean)varValue, expression);
            }
            else if (condition instanceof NumberMatch) {
                result = this.matchNumber((Number)varValue, expression);
            }
            else if (condition instanceof StringMatch) {
                result = this.matchString((String)varValue, expression);
            }
            else {
                this.log.warn("Unkown match type: " + condition);
            }
        }
        return result;
    }
    
    private boolean matchBoolean(final Boolean boolValue, final MatchExpression expression) {
        boolean result = false;
        final IMatcher condition = expression.getCondition();
        if (condition == BoolMatch.EQUALS) {
            result = boolValue.equals(expression.getValue());
        }
        else if (condition == BoolMatch.NOT_EQUALS) {
            result = !boolValue.equals(expression.getValue());
        }
        return result;
    }
    
    private boolean matchNumber(final Number numValue, final MatchExpression expression) {
        boolean result = false;
        final IMatcher condition = expression.getCondition();
        final double varValue = numValue.doubleValue();
        final double matchValue = ((Number)expression.getValue()).doubleValue();
        if (condition == NumberMatch.EQUALS) {
            result = (varValue == matchValue);
        }
        else if (condition == NumberMatch.NOT_EQUALS) {
            result = (varValue != matchValue);
        }
        else if (condition == NumberMatch.GREATER_THAN) {
            result = (varValue > matchValue);
        }
        else if (condition == NumberMatch.LESS_THAN) {
            result = (varValue < matchValue);
        }
        else if (condition == NumberMatch.GREATER_THAN_OR_EQUAL_TO) {
            result = (varValue >= matchValue);
        }
        else if (condition == NumberMatch.LESS_THAN_OR_EQUAL_TO) {
            result = (varValue <= matchValue);
        }
        return result;
    }
    
    private boolean matchString(final String strValue, final MatchExpression expression) {
        boolean result = false;
        final IMatcher condition = expression.getCondition();
        final String matchValue = (String)expression.getValue();
        if (condition == StringMatch.EQUALS) {
            result = strValue.equals(matchValue);
        }
        else if (condition == StringMatch.NOT_EQUALS) {
            result = !strValue.equals(matchValue);
        }
        else if (condition == StringMatch.CONTAINS) {
            result = (strValue.indexOf(matchValue) > -1);
        }
        else if (condition == StringMatch.STARTS_WITH) {
            result = strValue.startsWith(matchValue);
        }
        else if (condition == StringMatch.ENDS_WITH) {
            result = strValue.endsWith(matchValue);
        }
        return result;
    }
    
    private Object resolveVariable(final EntityWithVariables entity, final String varName) {
        if (varName.startsWith(".")) {
            throw new IllegalArgumentException("Illegal Variable name: " + varName + ", cannot start with a dot.");
        }
        if (varName.endsWith(".")) {
            throw new IllegalArgumentException("Illegal Variable name: " + varName + ", cannot end with a dot.");
        }
        if (varName.indexOf("..") != -1) {
            throw new IllegalArgumentException("Illegal Variable name: " + varName + ", two or more consecutive dots are not allowed.");
        }
        Object subObject = null;
        final int dotPos = varName.indexOf(".");
        if (dotPos == -1) {
            return this.resolveVariableValue(entity, varName);
        }
        final String[] varNameElements = varName.split("\\.");
        final UserVariable var = entity.getVariable(varNameElements[0]);
        if (var == null) {
            return null;
        }
        subObject = var.getValue();
        for (int pos = 1; pos < varNameElements.length; ++pos) {
            if (subObject == null) {
                return null;
            }
            if (subObject instanceof ISFSObject) {
                final SFSDataWrapper wrapper = ((ISFSObject)subObject).get(varNameElements[pos]);
                subObject = ((wrapper != null) ? wrapper.getObject() : null);
            }
            else if (subObject instanceof ISFSArray) {
                subObject = ((ISFSArray)subObject).getElementAt(Integer.parseInt(varNameElements[pos]));
            }
        }
        return subObject;
    }
    
    private Object resolveVariableValue(final EntityWithVariables entity, final String varName) {
        final Variable var = entity.getVariable(varName);
        Object value = null;
        if (var != null) {
            value = var.getValue();
        }
        else if (this.varProxy != null) {
            value = this.varProxy.getValue(entity, varName);
        }
        return value;
    }
}

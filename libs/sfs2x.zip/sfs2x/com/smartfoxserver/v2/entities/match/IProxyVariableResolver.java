// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

public interface IProxyVariableResolver
{
    Object getValue(final EntityWithVariables p0, final String p1);
}

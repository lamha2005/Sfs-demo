// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

interface IMatcher
{
    String getSymbol();
    
    int getType();
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.match;

public class UserProperties
{
    public static final String NAME = "${N}";
    public static final String IS_PLAYER = "${ISP}";
    public static final String IS_SPECTATOR = "${ISS}";
    public static final String IS_NPC = "${ISN}";
    public static final String PRIVILEGE_ID = "${PRID}";
    public static final String IS_IN_ANY_ROOM = "${IAR}";
}

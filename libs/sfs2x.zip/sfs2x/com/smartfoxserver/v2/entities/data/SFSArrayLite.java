// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.data;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

public class SFSArrayLite extends SFSArray
{
    public static SFSArrayLite newInstance() {
        return new SFSArrayLite();
    }
    
    @Override
    public Byte getByte(final int index) {
        final Integer i = super.getInt(index);
        return (i != null) ? ((byte)(Object)i) : null;
    }
    
    @Override
    public Short getShort(final int index) {
        final Integer i = super.getInt(index);
        return (i != null) ? ((short)(Object)i) : null;
    }
    
    @Override
    public Long getLong(final int index) {
        final SFSDataWrapper item = this.get(index);
        if (item == null) {
            return null;
        }
        final Object value = item.getObject();
        if (value instanceof Integer) {
            return (long)value;
        }
        return (Long)value;
    }
    
    @Override
    public Float getFloat(final int index) {
        final Double d = super.getDouble(index);
        return (d != null) ? ((float)(Object)d) : null;
    }
    
    @Override
    public Collection<Boolean> getBoolArray(final int key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Boolean> data = new ArrayList<Boolean>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(arr.getBool(i));
        }
        return data;
    }
    
    @Override
    public Collection<Short> getShortArray(final int key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Short> data = new ArrayList<Short>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add((short)(Object)arr.getInt(i));
        }
        return data;
    }
    
    @Override
    public Collection<Integer> getIntArray(final int key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Integer> data = new ArrayList<Integer>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(arr.getInt(i));
        }
        return data;
    }
    
    @Override
    public Collection<Float> getFloatArray(final int key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Float> data = new ArrayList<Float>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add((float)(Object)arr.getDouble(i));
        }
        return data;
    }
    
    @Override
    public Collection<Double> getDoubleArray(final int key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Double> data = new ArrayList<Double>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(arr.getDouble(i));
        }
        return data;
    }
    
    @Override
    public Collection<String> getUtfStringArray(final int key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<String> data = new ArrayList<String>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(arr.getUtfString(i));
        }
        return data;
    }
}

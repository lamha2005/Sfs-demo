// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.data;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

public final class SFSObjectLite extends SFSObject
{
    public static SFSObject newInstance() {
        return new SFSObjectLite();
    }
    
    @Override
    public Byte getByte(final String key) {
        final Integer i = super.getInt(key);
        return (i != null) ? ((byte)(Object)i) : null;
    }
    
    @Override
    public Short getShort(final String key) {
        final Integer i = super.getInt(key);
        return (i != null) ? ((short)(Object)i) : null;
    }
    
    @Override
    public Long getLong(final String key) {
        final SFSDataWrapper item = this.get(key);
        if (item == null) {
            return null;
        }
        final Object value = item.getObject();
        if (value instanceof Integer) {
            return (long)value;
        }
        return (Long)value;
    }
    
    @Override
    public Float getFloat(final String key) {
        final Double d = super.getDouble(key);
        return (d != null) ? ((float)(Object)d) : null;
    }
    
    @Override
    public Collection<Boolean> getBoolArray(final String key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Boolean> data = new ArrayList<Boolean>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(arr.getBool(i));
        }
        return data;
    }
    
    @Override
    public Collection<Short> getShortArray(final String key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Short> data = new ArrayList<Short>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(((Number)arr.getElementAt(i)).shortValue());
        }
        return data;
    }
    
    @Override
    public Collection<Integer> getIntArray(final String key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Integer> data = new ArrayList<Integer>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(((Number)arr.getElementAt(i)).intValue());
        }
        return data;
    }
    
    @Override
    public Collection<Float> getFloatArray(final String key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Float> data = new ArrayList<Float>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(((Number)arr.getElementAt(i)).floatValue());
        }
        return data;
    }
    
    @Override
    public Collection<Double> getDoubleArray(final String key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<Double> data = new ArrayList<Double>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(((Number)arr.getElementAt(i)).doubleValue());
        }
        return data;
    }
    
    @Override
    public Collection<String> getUtfStringArray(final String key) {
        final ISFSArray arr = this.getSFSArray(key);
        if (arr == null) {
            return null;
        }
        final List<String> data = new ArrayList<String>();
        for (int i = 0; i < arr.size(); ++i) {
            data.add(arr.getUtfString(i));
        }
        return data;
    }
}

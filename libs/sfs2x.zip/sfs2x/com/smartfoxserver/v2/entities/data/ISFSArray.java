// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.data;

import java.util.Collection;
import java.util.Iterator;

public interface ISFSArray
{
    boolean contains(final Object p0);
    
    Iterator<SFSDataWrapper> iterator();
    
    Object getElementAt(final int p0);
    
    SFSDataWrapper get(final int p0);
    
    void removeElementAt(final int p0);
    
    int size();
    
    byte[] toBinary();
    
    String toJson();
    
    String getHexDump();
    
    String getDump();
    
    String getDump(final boolean p0);
    
    void addNull();
    
    void addBool(final boolean p0);
    
    void addByte(final byte p0);
    
    void addShort(final short p0);
    
    void addInt(final int p0);
    
    void addLong(final long p0);
    
    void addFloat(final float p0);
    
    void addDouble(final double p0);
    
    void addUtfString(final String p0);
    
    void addText(final String p0);
    
    void addBoolArray(final Collection<Boolean> p0);
    
    void addByteArray(final byte[] p0);
    
    void addShortArray(final Collection<Short> p0);
    
    void addIntArray(final Collection<Integer> p0);
    
    void addLongArray(final Collection<Long> p0);
    
    void addFloatArray(final Collection<Float> p0);
    
    void addDoubleArray(final Collection<Double> p0);
    
    void addUtfStringArray(final Collection<String> p0);
    
    void addSFSArray(final ISFSArray p0);
    
    void addSFSObject(final ISFSObject p0);
    
    void addClass(final Object p0);
    
    void add(final SFSDataWrapper p0);
    
    boolean isNull(final int p0);
    
    Boolean getBool(final int p0);
    
    Byte getByte(final int p0);
    
    Integer getUnsignedByte(final int p0);
    
    Short getShort(final int p0);
    
    Integer getInt(final int p0);
    
    Long getLong(final int p0);
    
    Float getFloat(final int p0);
    
    Double getDouble(final int p0);
    
    String getUtfString(final int p0);
    
    String getText(final int p0);
    
    Collection<Boolean> getBoolArray(final int p0);
    
    byte[] getByteArray(final int p0);
    
    Collection<Integer> getUnsignedByteArray(final int p0);
    
    Collection<Short> getShortArray(final int p0);
    
    Collection<Integer> getIntArray(final int p0);
    
    Collection<Long> getLongArray(final int p0);
    
    Collection<Float> getFloatArray(final int p0);
    
    Collection<Double> getDoubleArray(final int p0);
    
    Collection<String> getUtfStringArray(final int p0);
    
    Object getClass(final int p0);
    
    ISFSArray getSFSArray(final int p0);
    
    ISFSObject getSFSObject(final int p0);
}

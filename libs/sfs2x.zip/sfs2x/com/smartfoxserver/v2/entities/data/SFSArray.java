// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.data;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collection;
import com.smartfoxserver.bitswarm.util.ByteUtils;
import java.util.Iterator;
import com.smartfoxserver.v2.protocol.serialization.DefaultObjectDumpFormatter;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.smartfoxserver.v2.protocol.serialization.DefaultSFSDataSerializer;
import java.util.ArrayList;
import java.util.List;
import com.smartfoxserver.v2.protocol.serialization.ISFSDataSerializer;

public class SFSArray implements ISFSArray
{
    private ISFSDataSerializer serializer;
    private List<SFSDataWrapper> dataHolder;
    
    public SFSArray() {
        this.dataHolder = new ArrayList<SFSDataWrapper>();
        this.serializer = DefaultSFSDataSerializer.getInstance();
    }
    
    public static SFSArray newFromBinaryData(final byte[] bytes) {
        return (SFSArray)DefaultSFSDataSerializer.getInstance().binary2array(bytes);
    }
    
    public static SFSArray newFromResultSet(final ResultSet rset) throws SQLException {
        return DefaultSFSDataSerializer.getInstance().resultSet2array(rset);
    }
    
    public static SFSArray newFromJsonData(final String jsonStr) {
        return (SFSArray)DefaultSFSDataSerializer.getInstance().json2array(jsonStr);
    }
    
    public static SFSArray newInstance() {
        return new SFSArray();
    }
    
    @Override
    public String getDump() {
        if (this.size() == 0) {
            return "[ Empty SFSArray ]";
        }
        return DefaultObjectDumpFormatter.prettyPrintDump(this.dump());
    }
    
    @Override
    public String getDump(final boolean noFormat) {
        if (!noFormat) {
            return this.dump();
        }
        return this.getDump();
    }
    
    private String dump() {
        final StringBuilder sb = new StringBuilder();
        sb.append('{');
        Object objDump = null;
        for (final SFSDataWrapper wrappedObject : this.dataHolder) {
            if (wrappedObject.getTypeId() == SFSDataType.SFS_OBJECT) {
                objDump = ((ISFSObject)wrappedObject.getObject()).getDump(false);
            }
            else if (wrappedObject.getTypeId() == SFSDataType.SFS_ARRAY) {
                objDump = ((ISFSArray)wrappedObject.getObject()).getDump(false);
            }
            else if (wrappedObject.getTypeId() == SFSDataType.BYTE_ARRAY) {
                objDump = DefaultObjectDumpFormatter.prettyPrintByteArray((byte[])wrappedObject.getObject());
            }
            else if (wrappedObject.getTypeId() == SFSDataType.CLASS) {
                objDump = wrappedObject.getObject().getClass().getName();
            }
            else {
                objDump = wrappedObject.getObject();
            }
            sb.append(" (").append(wrappedObject.getTypeId().name().toLowerCase()).append(") ").append(objDump).append(';');
        }
        if (this.size() > 0) {
            sb.delete(sb.length() - 1, sb.length());
        }
        sb.append('}');
        return sb.toString();
    }
    
    @Override
    public String getHexDump() {
        return ByteUtils.fullHexDump(this.toBinary());
    }
    
    @Override
    public byte[] toBinary() {
        return this.serializer.array2binary(this);
    }
    
    @Override
    public String toJson() {
        return DefaultSFSDataSerializer.getInstance().array2json(this.flatten());
    }
    
    @Override
    public boolean isNull(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return wrapper != null && wrapper.getTypeId() == SFSDataType.NULL;
    }
    
    @Override
    public SFSDataWrapper get(final int index) {
        return this.dataHolder.get(index);
    }
    
    @Override
    public Boolean getBool(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((Boolean)wrapper.getObject()) : null;
    }
    
    @Override
    public Byte getByte(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((Byte)wrapper.getObject()) : null;
    }
    
    @Override
    public Integer getUnsignedByte(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? DefaultSFSDataSerializer.getInstance().getUnsignedByte((byte)wrapper.getObject()) : null;
    }
    
    @Override
    public Short getShort(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((Short)wrapper.getObject()) : null;
    }
    
    @Override
    public Integer getInt(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((Integer)wrapper.getObject()) : null;
    }
    
    @Override
    public Long getLong(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((Long)wrapper.getObject()) : null;
    }
    
    @Override
    public Float getFloat(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((Float)wrapper.getObject()) : null;
    }
    
    @Override
    public Double getDouble(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((Double)wrapper.getObject()) : null;
    }
    
    @Override
    public String getUtfString(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((String)wrapper.getObject()) : null;
    }
    
    @Override
    public String getText(final int index) {
        return this.getUtfString(index);
    }
    
    @Override
    public Collection<Boolean> getBoolArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (Collection<Boolean>)((wrapper != null) ? ((Collection)wrapper.getObject()) : null);
    }
    
    @Override
    public byte[] getByteArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (byte[])((wrapper != null) ? wrapper.getObject() : null);
    }
    
    @Override
    public Collection<Integer> getUnsignedByteArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        if (wrapper == null) {
            return null;
        }
        final DefaultSFSDataSerializer serializer = DefaultSFSDataSerializer.getInstance();
        final Collection<Integer> intCollection = new ArrayList<Integer>();
        byte[] array;
        for (int length = (array = (byte[])wrapper.getObject()).length, i = 0; i < length; ++i) {
            final byte b = array[i];
            intCollection.add(serializer.getUnsignedByte(b));
        }
        return intCollection;
    }
    
    @Override
    public Collection<Short> getShortArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (Collection<Short>)((wrapper != null) ? ((Collection)wrapper.getObject()) : null);
    }
    
    @Override
    public Collection<Integer> getIntArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (Collection<Integer>)((wrapper != null) ? ((Collection)wrapper.getObject()) : null);
    }
    
    @Override
    public Collection<Long> getLongArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (Collection<Long>)((wrapper != null) ? ((Collection)wrapper.getObject()) : null);
    }
    
    @Override
    public Collection<Float> getFloatArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (Collection<Float>)((wrapper != null) ? ((Collection)wrapper.getObject()) : null);
    }
    
    @Override
    public Collection<Double> getDoubleArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (Collection<Double>)((wrapper != null) ? ((Collection)wrapper.getObject()) : null);
    }
    
    @Override
    public Collection<String> getUtfStringArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (Collection<String>)((wrapper != null) ? ((Collection)wrapper.getObject()) : null);
    }
    
    @Override
    public ISFSArray getSFSArray(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((ISFSArray)wrapper.getObject()) : null;
    }
    
    @Override
    public ISFSObject getSFSObject(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? ((ISFSObject)wrapper.getObject()) : null;
    }
    
    @Override
    public Object getClass(final int index) {
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        return (wrapper != null) ? wrapper.getObject() : null;
    }
    
    @Override
    public void addBool(final boolean value) {
        this.addObject(value, SFSDataType.BOOL);
    }
    
    @Override
    public void addBoolArray(final Collection<Boolean> value) {
        this.addObject(value, SFSDataType.BOOL_ARRAY);
    }
    
    @Override
    public void addByte(final byte value) {
        this.addObject(value, SFSDataType.BYTE);
    }
    
    @Override
    public void addByteArray(final byte[] value) {
        this.addObject(value, SFSDataType.BYTE_ARRAY);
    }
    
    @Override
    public void addDouble(final double value) {
        this.addObject(value, SFSDataType.DOUBLE);
    }
    
    @Override
    public void addDoubleArray(final Collection<Double> value) {
        this.addObject(value, SFSDataType.DOUBLE_ARRAY);
    }
    
    @Override
    public void addFloat(final float value) {
        this.addObject(value, SFSDataType.FLOAT);
    }
    
    @Override
    public void addFloatArray(final Collection<Float> value) {
        this.addObject(value, SFSDataType.FLOAT_ARRAY);
    }
    
    @Override
    public void addInt(final int value) {
        this.addObject(value, SFSDataType.INT);
    }
    
    @Override
    public void addIntArray(final Collection<Integer> value) {
        this.addObject(value, SFSDataType.INT_ARRAY);
    }
    
    @Override
    public void addLong(final long value) {
        this.addObject(value, SFSDataType.LONG);
    }
    
    @Override
    public void addLongArray(final Collection<Long> value) {
        this.addObject(value, SFSDataType.LONG_ARRAY);
    }
    
    @Override
    public void addNull() {
        this.addObject(null, SFSDataType.NULL);
    }
    
    @Override
    public void addSFSArray(final ISFSArray value) {
        this.addObject(value, SFSDataType.SFS_ARRAY);
    }
    
    @Override
    public void addSFSObject(final ISFSObject value) {
        this.addObject(value, SFSDataType.SFS_OBJECT);
    }
    
    @Override
    public void addShort(final short value) {
        this.addObject(value, SFSDataType.SHORT);
    }
    
    @Override
    public void addShortArray(final Collection<Short> value) {
        this.addObject(value, SFSDataType.SHORT_ARRAY);
    }
    
    @Override
    public void addUtfString(final String value) {
        this.addObject(value, SFSDataType.UTF_STRING);
    }
    
    @Override
    public void addText(final String value) {
        this.addObject(value, SFSDataType.TEXT);
    }
    
    @Override
    public void addUtfStringArray(final Collection<String> value) {
        this.addObject(value, SFSDataType.UTF_STRING_ARRAY);
    }
    
    @Override
    public void addClass(final Object o) {
        this.addObject(o, SFSDataType.CLASS);
    }
    
    @Override
    public void add(final SFSDataWrapper wrappedObject) {
        this.dataHolder.add(wrappedObject);
    }
    
    @Override
    public boolean contains(final Object obj) {
        if (obj instanceof ISFSArray || obj instanceof ISFSObject) {
            throw new UnsupportedOperationException("ISFSArray and ISFSObject are not supported by this method.");
        }
        boolean found = false;
        final Iterator<SFSDataWrapper> iter = this.dataHolder.iterator();
        while (iter.hasNext()) {
            final Object item = iter.next().getObject();
            if (item.equals(obj)) {
                found = true;
                break;
            }
        }
        return found;
    }
    
    @Override
    public Object getElementAt(final int index) {
        Object item = null;
        final SFSDataWrapper wrapper = this.dataHolder.get(index);
        if (wrapper != null) {}
        item = wrapper.getObject();
        return item;
    }
    
    @Override
    public Iterator<SFSDataWrapper> iterator() {
        return this.dataHolder.iterator();
    }
    
    @Override
    public void removeElementAt(final int index) {
        this.dataHolder.remove(index);
    }
    
    @Override
    public int size() {
        return this.dataHolder.size();
    }
    
    @Override
    public String toString() {
        return "[SFSArray, size: " + this.size() + "]";
    }
    
    private void addObject(final Object value, final SFSDataType typeId) {
        this.dataHolder.add(new SFSDataWrapper(typeId, value));
    }
    
    private List<Object> flatten() {
        final List<Object> list = new ArrayList<Object>();
        DefaultSFSDataSerializer.getInstance().flattenArray(list, this);
        return list;
    }
}

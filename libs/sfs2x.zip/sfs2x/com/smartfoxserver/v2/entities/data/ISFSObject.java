// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.data;

import java.util.Collection;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;

public interface ISFSObject
{
    boolean isNull(final String p0);
    
    boolean containsKey(final String p0);
    
    boolean removeElement(final String p0);
    
    Set<String> getKeys();
    
    int size();
    
    Iterator<Map.Entry<String, SFSDataWrapper>> iterator();
    
    byte[] toBinary();
    
    String toJson();
    
    String getDump();
    
    String getDump(final boolean p0);
    
    String getHexDump();
    
    SFSDataWrapper get(final String p0);
    
    Boolean getBool(final String p0);
    
    Byte getByte(final String p0);
    
    Integer getUnsignedByte(final String p0);
    
    Short getShort(final String p0);
    
    Integer getInt(final String p0);
    
    Long getLong(final String p0);
    
    Float getFloat(final String p0);
    
    Double getDouble(final String p0);
    
    String getUtfString(final String p0);
    
    String getText(final String p0);
    
    Collection<Boolean> getBoolArray(final String p0);
    
    byte[] getByteArray(final String p0);
    
    Collection<Integer> getUnsignedByteArray(final String p0);
    
    Collection<Short> getShortArray(final String p0);
    
    Collection<Integer> getIntArray(final String p0);
    
    Collection<Long> getLongArray(final String p0);
    
    Collection<Float> getFloatArray(final String p0);
    
    Collection<Double> getDoubleArray(final String p0);
    
    Collection<String> getUtfStringArray(final String p0);
    
    ISFSArray getSFSArray(final String p0);
    
    ISFSObject getSFSObject(final String p0);
    
    Object getClass(final String p0);
    
    void putNull(final String p0);
    
    void putBool(final String p0, final boolean p1);
    
    void putByte(final String p0, final byte p1);
    
    void putShort(final String p0, final short p1);
    
    void putInt(final String p0, final int p1);
    
    void putLong(final String p0, final long p1);
    
    void putFloat(final String p0, final float p1);
    
    void putDouble(final String p0, final double p1);
    
    void putUtfString(final String p0, final String p1);
    
    void putText(final String p0, final String p1);
    
    void putBoolArray(final String p0, final Collection<Boolean> p1);
    
    void putByteArray(final String p0, final byte[] p1);
    
    void putShortArray(final String p0, final Collection<Short> p1);
    
    void putIntArray(final String p0, final Collection<Integer> p1);
    
    void putLongArray(final String p0, final Collection<Long> p1);
    
    void putFloatArray(final String p0, final Collection<Float> p1);
    
    void putDoubleArray(final String p0, final Collection<Double> p1);
    
    void putUtfStringArray(final String p0, final Collection<String> p1);
    
    void putSFSArray(final String p0, final ISFSArray p1);
    
    void putSFSObject(final String p0, final ISFSObject p1);
    
    void putClass(final String p0, final Object p1);
    
    void put(final String p0, final SFSDataWrapper p1);
}

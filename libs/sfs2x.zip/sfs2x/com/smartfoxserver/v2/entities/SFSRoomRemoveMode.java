// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

public enum SFSRoomRemoveMode
{
    DEFAULT("DEFAULT", 0), 
    WHEN_EMPTY("WHEN_EMPTY", 1), 
    WHEN_EMPTY_AND_CREATOR_IS_GONE("WHEN_EMPTY_AND_CREATOR_IS_GONE", 2), 
    NEVER_REMOVE("NEVER_REMOVE", 3);
    
    private SFSRoomRemoveMode(final String s, final int n) {
    }
    
    public static SFSRoomRemoveMode fromString(final String id) {
        return valueOf(id.toUpperCase());
    }
}

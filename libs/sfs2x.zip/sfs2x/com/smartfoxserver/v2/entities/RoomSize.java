// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

public class RoomSize
{
    private int userCount;
    private int spectatorCount;
    
    public RoomSize(final int userCount, final int spectatorCount) {
        this.userCount = userCount;
        this.spectatorCount = spectatorCount;
    }
    
    public int getUserCount() {
        return this.userCount;
    }
    
    public int getSpectatorCount() {
        return this.spectatorCount;
    }
    
    public int getTotalUsers() {
        return this.getUserCount() + this.getSpectatorCount();
    }
    
    @Override
    public String toString() {
        return String.format("{ u: %s, s: %s }", this.userCount, this.spectatorCount);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.persistence.room.IRoomStorage;
import com.smartfoxserver.v2.persistence.room.BaseStorageConfig;
import com.smartfoxserver.v2.persistence.room.RoomStorageMode;
import com.smartfoxserver.v2.db.IDBManager;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.util.IFloodFilter;
import com.smartfoxserver.v2.util.IWordFilter;
import com.smartfoxserver.v2.util.IResponseThrottler;
import com.smartfoxserver.v2.controllers.filter.ISystemFilterChain;
import com.smartfoxserver.v2.controllers.SystemRequest;
import java.util.Collection;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.SFSTooManyRoomsException;
import com.smartfoxserver.v2.entities.managers.IZoneManager;
import com.smartfoxserver.v2.entities.managers.IRoomManager;
import java.util.Set;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.security.PrivilegeManager;
import java.util.List;
import com.smartfoxserver.v2.entities.managers.IUserManager;

public interface Zone
{
    IUserManager getUserManager();
    
    boolean isActive();
    
    void setActive(final boolean p0);
    
    void setId(final int p0);
    
    String getName();
    
    int getId();
    
    int getMaxAllowedUsers();
    
    void setMaxAllowedUsers(final int p0);
    
    int getMaxAllowedRooms();
    
    void setMaxAllowedRooms(final int p0);
    
    int getMaxRoomsCreatedPerUserLimit();
    
    void setMaxRoomsCreatedPerUserLimit(final int p0);
    
    int getMaxUserVariablesAllowed();
    
    void setMaxUserVariablesAllowed(final int p0);
    
    int getMaxRoomVariablesAllowed();
    
    void setMaxRoomVariablesAllowed(final int p0);
    
    int getMinRoomNameChars();
    
    void setMinRoomNameChars(final int p0);
    
    int getMaxRoomNameChars();
    
    void setMaxRoomNameChars(final int p0);
    
    int getUserCountChangeUpdateInterval();
    
    void setUserCountChangeUpdateInterval(final int p0);
    
    int getMaxUserIdleTime();
    
    void setMaxUserIdleTime(final int p0);
    
    boolean isCustomLogin();
    
    boolean isForceLogout();
    
    void setForceLogout(final boolean p0);
    
    void setCustomLogin(final boolean p0);
    
    boolean isGuestUserAllowed();
    
    void setGuestUserAllowed(final boolean p0);
    
    boolean isFilterUserNames();
    
    void setFilterUserNames(final boolean p0);
    
    boolean isFilterRoomNames();
    
    void setFilterRoomNames(final boolean p0);
    
    boolean isFilterPrivateMessages();
    
    void setFilterPrivateMessages(final boolean p0);
    
    boolean isFilterBuddyMessages();
    
    void setFilterBuddyMessages(final boolean p0);
    
    int getUserReconnectionSeconds();
    
    void setUserReconnectionSeconds(final int p0);
    
    String getGuestUserNamePrefix();
    
    void setGuestUserNamePrefix(final String p0);
    
    String getDefaultPlayerIdGeneratorClassName();
    
    void setDefaultPlayerIdGeneratorClassName(final String p0);
    
    boolean isUploadEnabled();
    
    void setUploadEnabled(final boolean p0);
    
    boolean isGeoLocationEnabled();
    
    void setGeoLocationEnabled(final boolean p0);
    
    List<String> getPublicGroups();
    
    void setPublicGroups(final List<String> p0);
    
    List<String> getGroups();
    
    List<String> getDefaultGroups();
    
    void setDefaultGroups(final List<String> p0);
    
    PrivilegeManager getPrivilegeManager();
    
    void setPrivilegeManager(final PrivilegeManager p0);
    
    int getUserCount();
    
    int getTotalRoomCount();
    
    int getGameRoomCount();
    
    Room createRoom(final CreateRoomSettings p0) throws SFSCreateRoomException;
    
    Room createRoom(final CreateRoomSettings p0, final User p1) throws SFSCreateRoomException;
    
    boolean isClientAllowedToOverridRoomEvents();
    
    void setClientAllowedToOverridRoomEvents(final boolean p0);
    
    void registerEventsForRoomGroup(final String p0, final Set<SFSRoomEvents> p1);
    
    boolean isGroupEventSet(final String p0, final SFSRoomEvents p1);
    
    Set<SFSRoomEvents> getGroupEvents(final String p0);
    
    IRoomManager getRoomManager();
    
    boolean containsGroup(final String p0);
    
    boolean containsPublicGroup(final String p0);
    
    Object getProperty(final Object p0);
    
    void setProperty(final Object p0, final Object p1);
    
    boolean containsProperty(final Object p0);
    
    void removeProperty(final Object p0);
    
    IZoneManager getZoneManager();
    
    void setZoneManager(final IZoneManager p0);
    
    List<Room> getRoomList();
    
    List<Room> getRoomListFromGroup(final String p0);
    
    Room getRoomById(final int p0);
    
    Room getRoomByName(final String p0);
    
    void addRoom(final Room p0) throws SFSTooManyRoomsException;
    
    void removeRoom(final Room p0);
    
    void removeRoom(final int p0);
    
    void removeRoom(final String p0);
    
    void checkAndRemove(final Room p0);
    
    void changeRoomName(final Room p0, final String p1) throws SFSRoomException;
    
    void changeRoomPasswordState(final Room p0, final String p1);
    
    void changeRoomCapacity(final Room p0, final int p1, final int p2);
    
    void validateUserName(final String p0) throws SFSException;
    
    User getUserById(final int p0);
    
    User getUserByName(final String p0);
    
    User getUserBySession(final ISession p0);
    
    Collection<User> getUsersInGroup(final String p0);
    
    Collection<ISession> getSessionsInGroup(final String p0);
    
    Collection<ISession> getSessionsListeningToGroup(final String p0);
    
    Collection<ISession> getSessionList();
    
    Collection<User> getUserList();
    
    void removeAllUsers();
    
    ISystemFilterChain getFilterChain(final SystemRequest p0);
    
    void setFilterChain(final SystemRequest p0, final ISystemFilterChain p1);
    
    boolean isFilterChainInited();
    
    void resetSystemFilterChain();
    
    void removeUser(final int p0);
    
    void removeUser(final String p0);
    
    void removeUser(final ISession p0);
    
    void removeUser(final User p0);
    
    void removeUserFromRoom(final User p0, final Room p1);
    
    IResponseThrottler getUCountThrottler();
    
    IWordFilter getWordFilter();
    
    IFloodFilter getFloodFilter();
    
    ISFSExtension getExtension();
    
    void setExtension(final ISFSExtension p0);
    
    IDBManager getDBManager();
    
    void setDBManager(final IDBManager p0);
    
    void initRoomPersistence(final RoomStorageMode p0, final BaseStorageConfig p1);
    
    IRoomStorage getRoomPersistenceApi();
    
    void addDisabledSystemEvent(final String p0);
    
    void removeDisabledSystemEvent(final String p0);
    
    boolean isSystemEventAllowed(final String p0);
    
    User login(final LoginData p0) throws SFSLoginException;
    
    ISFSArray getRoomListData();
    
    ISFSArray getRoomListData(final List<String> p0);
    
    BuddyListManager getBuddyListManager();
    
    void setBuddyListManager(final BuddyListManager p0);
    
    boolean isEncrypted();
    
    void setEncrypted(final boolean p0);
    
    int getMaxInvitationsPerRequest();
    
    void setMaxInvitationsPerRequest(final int p0);
    
    boolean isAllowInvitationsOnlyForBuddies();
    
    void setAllowInvitationsOnlyForBuddies(final boolean p0);
    
    int getMaxFailedLogins();
    
    void setMaxFailedLogins(final int p0);
    
    String getDump();
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.exceptions.SFSLoginException;

public interface Loggable
{
    User doLogin(final LoginData p0) throws SFSLoginException;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.invitation;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;

public interface Invitation
{
    int getId();
    
    User getInviter();
    
    User getInvitee();
    
    boolean isExpired();
    
    int getExpiryTime();
    
    int getSecondsForAnswer();
    
    InvitationCallback getCallback();
    
    void setCallback(final InvitationCallback p0);
    
    ISFSObject getParams();
    
    void setParams(final ISFSObject p0);
}

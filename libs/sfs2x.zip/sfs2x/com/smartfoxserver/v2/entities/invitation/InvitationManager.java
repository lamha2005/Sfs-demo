// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.invitation;

import com.smartfoxserver.v2.entities.IDGenerator;
import com.smartfoxserver.v2.exceptions.SFSInvitationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public interface InvitationManager
{
    Invitation findById(final int p0);
    
    void startInvitation(final Invitation p0, final InvitationCallback p1);
    
    void suppressInvitation(final Invitation p0);
    
    void onInvitationResult(final Invitation p0, final InvitationResponse p1, final ISFSObject p2) throws SFSInvitationException;
    
    void onInvitationResult(final int p0, final InvitationResponse p1, final ISFSObject p2) throws SFSInvitationException;
    
    int getMaxInvitationsPerUser();
    
    void setMaxInvitationsPerUser(final int p0);
    
    IDGenerator getIDGenerator();
}

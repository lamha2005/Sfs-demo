// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.invitation;

import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;

public class SFSInvitation implements Invitation
{
    private final int id;
    private final User inviter;
    private final User invitee;
    private final long expiryTime;
    private final int secondsForAnswer;
    private ISFSObject params;
    private InvitationCallback callback;
    
    public static Invitation fromSFSArray(final ISFSArray sfsa) {
        final Invitation invitation = new SFSInvitation(SmartFoxServer.getInstance().getUserManager().getUserById(sfsa.getInt(0)), SmartFoxServer.getInstance().getUserManager().getUserById(sfsa.getInt(1)), sfsa.getShort(2), (sfsa.size() == 4) ? sfsa.getSFSObject(3) : null);
        return invitation;
    }
    
    public SFSInvitation(final User inviter, final User invitee, final int secondsForAnswer) {
        this(inviter, invitee, secondsForAnswer, null);
    }
    
    public SFSInvitation(final User inviter, final User invitee, final int secondsForAnswer, final ISFSObject params) {
        this.id = this.nextUniqueId();
        this.inviter = inviter;
        this.invitee = invitee;
        this.params = params;
        this.secondsForAnswer = secondsForAnswer;
        this.expiryTime = System.currentTimeMillis() + 1000 * secondsForAnswer;
    }
    
    @Override
    public int getId() {
        return this.id;
    }
    
    @Override
    public ISFSObject getParams() {
        return this.params;
    }
    
    @Override
    public void setParams(final ISFSObject params) {
        this.params = params;
    }
    
    @Override
    public User getInviter() {
        return this.inviter;
    }
    
    @Override
    public User getInvitee() {
        return this.invitee;
    }
    
    @Override
    public int getExpiryTime() {
        return (int)this.expiryTime / 1000;
    }
    
    @Override
    public boolean isExpired() {
        return System.currentTimeMillis() > this.expiryTime;
    }
    
    @Override
    public int getSecondsForAnswer() {
        return this.secondsForAnswer;
    }
    
    @Override
    public InvitationCallback getCallback() {
        return this.callback;
    }
    
    @Override
    public void setCallback(final InvitationCallback callback) {
        this.callback = callback;
    }
    
    @Override
    public String toString() {
        return String.format("{ Invitation: %s, From: %s To: %s }", this.id, this.inviter.getName(), this.invitee.getName());
    }
    
    private int nextUniqueId() {
        return SmartFoxServer.getInstance().getInvitationManager().getIDGenerator().generateID();
    }
}

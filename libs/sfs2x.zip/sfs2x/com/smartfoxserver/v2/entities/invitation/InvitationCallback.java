// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.invitation;

import com.smartfoxserver.v2.entities.data.ISFSObject;

public interface InvitationCallback
{
    void onAccepted(final Invitation p0, final ISFSObject p1);
    
    void onRefused(final Invitation p0, final ISFSObject p1);
    
    void onExpired(final Invitation p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.invitation;

import com.smartfoxserver.v2.core.ISFSEventParam;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEvent;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import com.smartfoxserver.v2.exceptions.SFSInvitationException;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.LinkedList;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.entities.SFSIDGenerator;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.entities.IDGenerator;
import java.util.List;
import com.smartfoxserver.v2.entities.User;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import com.smartfoxserver.v2.core.ISFSEventListener;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.bitswarm.service.IService;

public class SFSInvitationManager implements IService, InvitationManager
{
    private static final int INVITATION_CLEANER_INTERVAL = 3;
    protected String serviceName;
    protected final SmartFoxServer sfs;
    protected final Logger log;
    private final ISFSEventListener userEventListener;
    private ScheduledFuture<?> cleanerTask;
    protected final Map<Integer, Invitation> invitationsById;
    protected final Map<User, List<Invitation>> invitationsByOwner;
    protected int maxInvitationsPerUser;
    protected IDGenerator idGen;
    
    public SFSInvitationManager() {
        this.maxInvitationsPerUser = 16;
        this.serviceName = "SFSInvitationManager";
        this.sfs = SmartFoxServer.getInstance();
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.invitationsById = new ConcurrentHashMap<Integer, Invitation>();
        this.invitationsByOwner = new ConcurrentHashMap<User, List<Invitation>>();
        this.userEventListener = new UserExitEventHandler((UserExitEventHandler)null);
    }
    
    public void init(final Object o) {
        this.idGen = new SFSIDGenerator();
        this.sfs.getEventManager().addEventListener(SFSEventType.USER_DISCONNECT, this.userEventListener);
        this.sfs.getEventManager().addEventListener(SFSEventType.USER_LOGOUT, this.userEventListener);
        this.initCleanUpTask();
    }
    
    public void destroy(final Object o) {
        this.sfs.getEventManager().removeEventListener(SFSEventType.USER_DISCONNECT, this.userEventListener);
        this.sfs.getEventManager().removeEventListener(SFSEventType.USER_LOGOUT, this.userEventListener);
        this.invitationsById.clear();
        this.invitationsByOwner.clear();
        if (this.cleanerTask != null) {
            this.cleanerTask.cancel(true);
        }
    }
    
    public String getName() {
        return this.serviceName;
    }
    
    public void setName(final String name) {
        throw new UnsupportedOperationException("Method not supported.");
    }
    
    public void handleMessage(final Object o) {
        throw new UnsupportedOperationException("Method not supported.");
    }
    
    public Invitation findById(final int id) {
        return this.invitationsById.get(id);
    }
    
    public int getMaxInvitationsPerUser() {
        return this.maxInvitationsPerUser;
    }
    
    public void setMaxInvitationsPerUser(final int value) {
        this.maxInvitationsPerUser = value;
    }
    
    public void startInvitation(final Invitation invitation, final InvitationCallback callBack) {
        final List<Invitation> userInvitationList = this.prepareStartInvitation(invitation, callBack);
        if (userInvitationList.size() < this.maxInvitationsPerUser) {
            this.invitationsById.put(invitation.getId(), invitation);
            synchronized (userInvitationList) {
                userInvitationList.add(invitation);
            }
            // monitorexit(userInvitationList)
            invitation.setCallback(callBack);
            if (this.log.isDebugEnabled()) {
                this.log.debug("Invitation: " + invitation + " started.");
            }
            return;
        }
        throw new SFSRuntimeException("The user: " + invitation.getInviter() + " is already running the max allowed number of invitations = " + this.maxInvitationsPerUser);
    }
    
    protected List<Invitation> prepareStartInvitation(final Invitation invitation, final InvitationCallback callBack) {
        if (invitation == null) {
            throw new NullPointerException("Invitation object is null. Please provide a valid object.");
        }
        if (callBack == null) {
            throw new NullPointerException("Callback object is null. Please provide a valid object.");
        }
        if (invitation.getInviter() == null || invitation.getInvitee() == null) {
            throw new IllegalArgumentException("Both Inviter and Invitee must be non-null User objects.");
        }
        final User inviter = invitation.getInviter();
        List<Invitation> userInvitationList = this.invitationsByOwner.get(inviter);
        synchronized (this.invitationsByOwner) {
            if (userInvitationList == null) {
                userInvitationList = new LinkedList<Invitation>();
                this.invitationsByOwner.put(inviter, userInvitationList);
            }
        }
        // monitorexit(this.invitationsByOwner)
        return userInvitationList;
    }
    
    public void suppressInvitation(final Invitation invitation) {
        throw new UnsupportedOperationException("This feature will be available in future implementations.");
    }
    
    public void onInvitationResult(final int invitationId, final InvitationResponse result, final ISFSObject params) throws SFSInvitationException {
        final Invitation invitation = this.findById(invitationId);
        if (invitation == null && result != InvitationResponse.EXPIRED) {
            throw new SFSInvitationException(String.format("Invitation result discarded. Invitation is not managed. ID: %s, Result: %s", invitationId, result), new SFSErrorData(SFSErrorCode.INVITATION_NOT_VALID));
        }
        this.onInvitationResult(invitation, result, params);
    }
    
    public void onInvitationResult(final Invitation invitation, final InvitationResponse result, final ISFSObject params) throws SFSInvitationException {
        String errorMsg = null;
        if (!this.invitationsById.containsKey(invitation.getId())) {
            errorMsg = "Invitation is not managed (maybe removed?)";
        }
        if (invitation.getCallback() == null) {
            errorMsg = "Invitation no longer valid.";
        }
        if (invitation.isExpired()) {
            errorMsg = "Invitation is expired.";
        }
        if (errorMsg != null) {
            throw new SFSInvitationException(errorMsg, new SFSErrorData(SFSErrorCode.INVITATION_NOT_VALID));
        }
        if (result == InvitationResponse.ACCEPT) {
            this.handleAcceptedInvitation(invitation, params);
        }
        else {
            this.handleRefusedInvitation(invitation, params);
        }
    }
    
    public IDGenerator getIDGenerator() {
        return this.idGen;
    }
    
    protected void initCleanUpTask() {
        this.cleanerTask = this.sfs.getTaskScheduler().scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try {
                    SFSInvitationManager.this.cleanExpiredInvitations();
                }
                catch (Exception e) {
                    SFSInvitationManager.this.log.warn("Error trapped in CleanExpiredInvitation: " + e);
                    e.printStackTrace();
                }
            }
        }, 0, 3, TimeUnit.SECONDS);
    }
    
    private void cleanExpiredInvitations() {
        final Iterator<Invitation> iter = this.invitationsById.values().iterator();
        while (iter.hasNext()) {
            final Invitation invitation = iter.next();
            if (invitation.isExpired()) {
                iter.remove();
                this.removeInvitation(invitation);
                if (invitation.getCallback() == null) {
                    continue;
                }
                invitation.getCallback().onExpired(invitation);
            }
        }
    }
    
    protected void handleAcceptedInvitation(final Invitation invitation, final ISFSObject params) {
        this.removeInvitation(invitation);
        final InvitationCallback callback = invitation.getCallback();
        if (callback != null) {
            callback.onAccepted(invitation, params);
        }
    }
    
    protected void handleRefusedInvitation(final Invitation invitation, final ISFSObject params) {
        this.removeInvitation(invitation);
        final InvitationCallback callback = invitation.getCallback();
        if (callback != null) {
            callback.onRefused(invitation, params);
        }
    }
    
    private void handleInviterDisconnected(final User inviter) {
        final List<Invitation> invitationList = this.invitationsByOwner.remove(inviter);
        if (invitationList != null) {
            for (final Invitation invitation : invitationList) {
                this.invitationsById.remove(invitation.getId());
            }
            if (this.log.isDebugEnabled()) {
                this.log.debug("Removed " + invitationList.size() + " invitations for disconnected user: " + inviter);
            }
        }
    }
    
    protected void removeInvitation(final Invitation invitation) {
        this.invitationsById.remove(invitation.getId());
        final List<Invitation> invitationList = this.invitationsByOwner.get(invitation.getInviter());
        if (invitationList != null) {
            synchronized (invitationList) {
                invitationList.remove(invitation);
            }
            // monitorexit(invitationList)
        }
    }
    
    private final class UserExitEventHandler implements ISFSEventListener
    {
        @Override
        public void handleServerEvent(final ISFSEvent event) throws Exception {
            SFSInvitationManager.this.handleInviterDisconnected((User)event.getParameter(SFSEventParam.USER));
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.exceptions.SFSVariableException;
import java.util.List;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import java.util.Set;
import com.smartfoxserver.v2.util.IPlayerIdGenerator;
import com.smartfoxserver.v2.entities.managers.IUserManager;

public interface Room
{
    int getId();
    
    String getGroupId();
    
    void setGroupId(final String p0);
    
    String getName();
    
    void setName(final String p0);
    
    String getPassword();
    
    void setPassword(final String p0);
    
    boolean isPasswordProtected();
    
    boolean isPublic();
    
    int getCapacity();
    
    void setCapacity(final int p0, final int p1);
    
    int getMaxUsers();
    
    void setMaxUsers(final int p0);
    
    int getMaxSpectators();
    
    void setMaxSpectators(final int p0);
    
    int getMaxRoomVariablesAllowed();
    
    void setMaxRoomVariablesAllowed(final int p0);
    
    User getOwner();
    
    void setOwner(final User p0);
    
    RoomSize getSize();
    
    IUserManager getUserManager();
    
    void setUserManager(final IUserManager p0);
    
    Zone getZone();
    
    void setZone(final Zone p0);
    
    boolean isDynamic();
    
    boolean isGame();
    
    boolean isHidden();
    
    void setDynamic(final boolean p0);
    
    void setGame(final boolean p0);
    
    void setGame(final boolean p0, final Class<? extends IPlayerIdGenerator> p1);
    
    void setHidden(final boolean p0);
    
    void setFlags(final Set<SFSRoomSettings> p0);
    
    void setFlag(final SFSRoomSettings p0, final boolean p1);
    
    boolean isFlagSet(final SFSRoomSettings p0);
    
    SFSRoomRemoveMode getAutoRemoveMode();
    
    void setAutoRemoveMode(final SFSRoomRemoveMode p0);
    
    boolean isEmpty();
    
    boolean isFull();
    
    boolean isActive();
    
    void setActive(final boolean p0);
    
    ISFSExtension getExtension();
    
    void setExtension(final ISFSExtension p0);
    
    RoomVariable getVariable(final String p0);
    
    List<RoomVariable> getVariables();
    
    void setVariable(final RoomVariable p0, final boolean p1) throws SFSVariableException;
    
    void setVariable(final RoomVariable p0) throws SFSVariableException;
    
    void setVariables(final List<RoomVariable> p0, final boolean p1);
    
    void setVariables(final List<RoomVariable> p0);
    
    List<RoomVariable> getVariablesCreatedByUser(final User p0);
    
    List<RoomVariable> removeVariablesCreatedByUser(final User p0);
    
    List<RoomVariable> removeVariablesCreatedByUser(final User p0, final boolean p1);
    
    void removeVariable(final String p0);
    
    boolean containsVariable(final String p0);
    
    int getVariablesCount();
    
    Object getProperty(final Object p0);
    
    void setProperty(final Object p0, final Object p1);
    
    boolean containsProperty(final Object p0);
    
    void removeProperty(final Object p0);
    
    User getUserById(final int p0);
    
    User getUserByName(final String p0);
    
    User getUserBySession(final ISession p0);
    
    User getUserByPlayerId(final int p0);
    
    List<User> getUserList();
    
    List<User> getPlayersList();
    
    List<User> getSpectatorsList();
    
    List<ISession> getSessionList();
    
    ISFSArray getUserListData();
    
    ISFSArray getRoomVariablesData(final boolean p0);
    
    void addUser(final User p0, final boolean p1) throws SFSJoinRoomException;
    
    void addUser(final User p0) throws SFSJoinRoomException;
    
    void removeUser(final User p0);
    
    boolean containsUser(final User p0);
    
    boolean containsUser(final String p0);
    
    ISFSArray toSFSArray(final boolean p0);
    
    void switchPlayerToSpectator(final User p0) throws SFSRoomException;
    
    void switchSpectatorToPlayer(final User p0) throws SFSRoomException;
    
    boolean isUseWordsFilter();
    
    void setUseWordsFilter(final boolean p0);
    
    long getLifeTime();
    
    String getDump();
    
    void destroy();
    
    String getPlayerIdGeneratorClassName();
    
    boolean isAllowOwnerInvitations();
    
    void setAllowOwnerInvitations(final boolean p0);
}

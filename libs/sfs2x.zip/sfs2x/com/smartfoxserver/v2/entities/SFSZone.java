// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.Arrays;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.persistence.room.RoomStorageFactory;
import com.smartfoxserver.v2.persistence.room.BaseStorageConfig;
import com.smartfoxserver.v2.persistence.room.RoomStorageMode;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.util.UserCountChangeResponseThrottler;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.Collections;
import java.util.Iterator;
import java.util.HashSet;
import com.smartfoxserver.v2.util.IPlayerIdGenerator;
import com.smartfoxserver.v2.util.DefaultPlayerIdGenerator;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.Collection;
import com.smartfoxserver.v2.exceptions.SFSTooManyRoomsException;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.grid.SFSGrid;
import com.smartfoxserver.v2.util.SFSWordFilter;
import com.smartfoxserver.v2.util.SFSFloodFilter;
import com.smartfoxserver.v2.security.SFSPrivilegeManager;
import java.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import com.smartfoxserver.v2.entities.managers.SFSUserManager;
import com.smartfoxserver.v2.entities.managers.SFSRoomManager;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.persistence.room.IRoomStorage;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import com.smartfoxserver.v2.util.IAdminHelper;
import com.smartfoxserver.v2.controllers.filter.ISystemFilterChain;
import com.smartfoxserver.v2.controllers.SystemRequest;
import java.util.Map;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.util.IResponseThrottler;
import com.smartfoxserver.v2.db.IDBManager;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.security.PrivilegeManager;
import com.smartfoxserver.v2.util.IWordFilter;
import com.smartfoxserver.v2.util.IFloodFilter;
import com.smartfoxserver.v2.entities.managers.IUserManager;
import com.smartfoxserver.v2.entities.managers.IRoomManager;
import com.smartfoxserver.v2.entities.managers.IZoneManager;
import java.util.List;

public final class SFSZone implements Zone
{
    private List<String> disabledSystemEvents;
    private List<String> publicGroups;
    private List<String> defaultGroups;
    private IZoneManager zoneManager;
    private final IRoomManager roomManager;
    private final IUserManager userManager;
    private IFloodFilter floodFilter;
    private IWordFilter wordFilter;
    private PrivilegeManager privilegeManager;
    private BuddyListManager buddyListManager;
    private IDBManager dbManager;
    private IResponseThrottler uCountResponseThrottler;
    private volatile ISFSExtension extension;
    private volatile boolean isActive;
    private boolean customLogin;
    private boolean forceLogout;
    private boolean clientAllowedToOverridRoomEvents;
    private boolean guestUserAllowed;
    private volatile boolean filterUserNames;
    private volatile boolean filterRoomNames;
    private volatile boolean filterPrivateMessages;
    private volatile boolean filterBuddyMessages;
    private volatile Map<SystemRequest, ISystemFilterChain> filterChainByRequestId;
    private IAdminHelper adminHelper;
    private volatile int maxAllowedRooms;
    private volatile int maxAllowedUsers;
    private volatile int maxAllowedUserVariables;
    private volatile int maxAllowedRoomVariables;
    private volatile int maxRoomsCreatedPerUser;
    private volatile int userCountChangeUpdateInterval;
    private volatile int minRoomNameChars;
    private volatile int maxRoomNameChars;
    private volatile int userReconnectionSeconds;
    private int maxUserIdleTime;
    private int maxFailedLogins;
    private final String name;
    private String guestUserNamePrefix;
    private String defaultPlayerIdGeneratorClass;
    private ConcurrentMap<Object, Object> properties;
    private volatile Map<String, Set<SFSRoomEvents>> groupEvents;
    private boolean cryptoActive;
    private boolean allowInvitationsOnlyForBuddies;
    private int maxInvitationsPerRequest;
    private boolean geoLocationEnabled;
    private Logger logger;
    private SmartFoxServer sfs;
    private Integer id;
    private IRoomStorage roomStorage;
    private volatile boolean uploadEnabled;
    private final Loggable loggable;
    private final ILoginFinalizer finalizer;
    
    public SFSZone(final String name) {
        this.isActive = false;
        this.customLogin = false;
        this.forceLogout = false;
        this.clientAllowedToOverridRoomEvents = false;
        this.guestUserAllowed = false;
        this.filterUserNames = false;
        this.filterRoomNames = false;
        this.filterPrivateMessages = false;
        this.filterBuddyMessages = false;
        this.userCountChangeUpdateInterval = 0;
        this.userReconnectionSeconds = 0;
        this.maxUserIdleTime = 0;
        this.maxFailedLogins = 3;
        this.cryptoActive = false;
        this.allowInvitationsOnlyForBuddies = true;
        this.maxInvitationsPerRequest = 5;
        this.geoLocationEnabled = false;
        this.id = null;
        this.name = name;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = SmartFoxServer.getInstance();
        (this.roomManager = new SFSRoomManager()).setOwnerZone(this);
        (this.userManager = new SFSUserManager()).setOwnerZone(this);
        this.disabledSystemEvents = new ArrayList<String>();
        this.publicGroups = new ArrayList<String>();
        this.properties = new ConcurrentHashMap<Object, Object>();
        this.roomManager.addGroup("default");
        this.publicGroups.add("default");
        this.privilegeManager = new SFSPrivilegeManager();
        this.groupEvents = new ConcurrentHashMap<String, Set<SFSRoomEvents>>();
        this.floodFilter = new SFSFloodFilter(this.sfs.getBannedUserManager());
        this.wordFilter = new SFSWordFilter(this.sfs.getBannedUserManager());
        this.loggable = this.sfs.getServiceProvider().getLoginImpl(this);
        final boolean isAdmin = name.equals("--=={{{ AdminZone }}}==--");
        if (SmartFoxServer.grid()) {
            this.finalizer = ((SFSGrid.manager().isLobby() && !isAdmin) ? this.sfs.getServiceProvider().getLoginFinalizer() : new LoginFinalizer((LoginFinalizer)null));
        }
        else {
            this.finalizer = new LoginFinalizer((LoginFinalizer)null);
        }
    }
    
    @Override
    public IRoomManager getRoomManager() {
        return this.roomManager;
    }
    
    @Override
    public IUserManager getUserManager() {
        return this.userManager;
    }
    
    @Override
    public boolean containsGroup(final String groupId) {
        return this.roomManager.containsGroup(groupId);
    }
    
    @Override
    public boolean containsPublicGroup(final String groupId) {
        boolean flag = false;
        synchronized (this.publicGroups) {
            flag = this.publicGroups.contains(groupId);
        }
        // monitorexit(this.publicGroups)
        return flag;
    }
    
    @Override
    public Room createRoom(final CreateRoomSettings params, final User user) throws SFSCreateRoomException {
        return this.roomManager.createRoom(params, user);
    }
    
    @Override
    public Room createRoom(final CreateRoomSettings params) throws SFSCreateRoomException {
        return this.roomManager.createRoom(params);
    }
    
    @Override
    public void changeRoomName(final Room room, final String newName) throws SFSRoomException {
        this.roomManager.changeRoomName(room, newName);
    }
    
    @Override
    public void changeRoomPasswordState(final Room room, final String password) {
        this.roomManager.changeRoomPasswordState(room, password);
    }
    
    @Override
    public void changeRoomCapacity(final Room room, final int newMaxUsers, final int newMaxSpect) {
        this.roomManager.changeRoomCapacity(room, newMaxUsers, newMaxSpect);
    }
    
    @Override
    public void addDisabledSystemEvent(final String eventID) {
        synchronized (this.disabledSystemEvents) {
            this.disabledSystemEvents.add(eventID);
        }
        // monitorexit(this.disabledSystemEvents)
    }
    
    @Override
    public void addRoom(final Room room) throws SFSTooManyRoomsException {
        this.roomManager.addRoom(room);
    }
    
    @Override
    public String getGuestUserNamePrefix() {
        return this.guestUserNamePrefix;
    }
    
    @Override
    public int getUserCount() {
        return this.userManager.getUserCount();
    }
    
    @Override
    public int getTotalRoomCount() {
        return this.roomManager.getTotalRoomCount();
    }
    
    @Override
    public int getGameRoomCount() {
        return this.roomManager.getGameRoomCount();
    }
    
    @Override
    public int getMaxAllowedRooms() {
        return this.maxAllowedRooms;
    }
    
    @Override
    public int getMaxUserVariablesAllowed() {
        return this.maxAllowedUserVariables;
    }
    
    @Override
    public int getMaxAllowedUsers() {
        return this.maxAllowedUsers;
    }
    
    @Override
    public int getMaxRoomsCreatedPerUserLimit() {
        return this.maxRoomsCreatedPerUser;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public int getId() {
        return this.id;
    }
    
    @Override
    public Object getProperty(final Object key) {
        return this.properties.get(key);
    }
    
    @Override
    public void removeProperty(final Object key) {
        this.properties.remove(key);
    }
    
    @Override
    public List<String> getPublicGroups() {
        List<String> newList = null;
        synchronized (this.publicGroups) {
            newList = new ArrayList<String>(this.publicGroups);
        }
        // monitorexit(this.publicGroups)
        return newList;
    }
    
    @Override
    public List<String> getGroups() {
        return this.roomManager.getGroups();
    }
    
    @Override
    public List<String> getDefaultGroups() {
        return new ArrayList<String>(this.defaultGroups);
    }
    
    @Override
    public Room getRoomById(final int id) {
        return this.roomManager.getRoomById(id);
    }
    
    @Override
    public Room getRoomByName(final String name) {
        return this.roomManager.getRoomByName(name);
    }
    
    @Override
    public List<Room> getRoomList() {
        return this.roomManager.getRoomList();
    }
    
    @Override
    public List<Room> getRoomListFromGroup(final String groupId) {
        return this.roomManager.getRoomListFromGroup(groupId);
    }
    
    @Override
    public User getUserById(final int id) {
        return this.userManager.getUserById(id);
    }
    
    @Override
    public User getUserByName(final String name) {
        return this.userManager.getUserByName(name);
    }
    
    @Override
    public User getUserBySession(final ISession session) {
        return this.userManager.getUserBySession(session);
    }
    
    @Override
    public int getUserCountChangeUpdateInterval() {
        return this.userCountChangeUpdateInterval;
    }
    
    @Override
    public IResponseThrottler getUCountThrottler() {
        return this.uCountResponseThrottler;
    }
    
    @Override
    public String getDefaultPlayerIdGeneratorClassName() {
        return this.defaultPlayerIdGeneratorClass;
    }
    
    @Override
    public void setDefaultPlayerIdGeneratorClassName(String className) {
        if (className == null || className.length() == 0) {
            className = "com.smartfoxserver.v2.util.DefaultPlayerIdGenerator";
        }
        this.defaultPlayerIdGeneratorClass = className;
        Class<? extends IPlayerIdGenerator> playerGeneratorClass = DefaultPlayerIdGenerator.class;
        try {
            playerGeneratorClass = (Class<? extends IPlayerIdGenerator>)Class.forName(className);
        }
        catch (ClassNotFoundException e) {
            this.logger.warn("Was not able to instantiate PlayerIdGenerator Class: " + className + ", class is not found. Reverting to default implementation: " + playerGeneratorClass);
        }
        this.roomManager.setDefaultRoomPlayerIdGeneratorClass(playerGeneratorClass);
    }
    
    @Override
    public boolean isUploadEnabled() {
        return this.uploadEnabled;
    }
    
    @Override
    public void setUploadEnabled(final boolean val) {
        this.uploadEnabled = val;
    }
    
    @Override
    public boolean isFilterChainInited() {
        return this.filterChainByRequestId != null;
    }
    
    @Override
    public void resetSystemFilterChain() {
        if (this.isFilterChainInited()) {
            this.filterChainByRequestId.clear();
            this.filterChainByRequestId = null;
        }
    }
    
    @Override
    public ISystemFilterChain getFilterChain(final SystemRequest requestId) {
        if (this.filterChainByRequestId == null) {
            return null;
        }
        return this.filterChainByRequestId.get(requestId);
    }
    
    @Override
    public void setFilterChain(final SystemRequest requestId, final ISystemFilterChain chain) {
        if (this.filterChainByRequestId == null) {
            this.filterChainByRequestId = new ConcurrentHashMap<SystemRequest, ISystemFilterChain>();
        }
        this.filterChainByRequestId.put(requestId, chain);
    }
    
    @Override
    public ISFSExtension getExtension() {
        return this.extension;
    }
    
    @Override
    public void setExtension(final ISFSExtension extension) {
        this.extension = extension;
    }
    
    @Override
    public int getUserReconnectionSeconds() {
        return this.userReconnectionSeconds;
    }
    
    @Override
    public void setUserReconnectionSeconds(final int seconds) {
        this.userReconnectionSeconds = seconds;
    }
    
    @Override
    public int getMaxUserIdleTime() {
        return this.maxUserIdleTime;
    }
    
    @Override
    public void setMaxUserIdleTime(final int seconds) {
        this.maxUserIdleTime = seconds;
    }
    
    @Override
    public Collection<User> getUsersInGroup(final String groupId) {
        final Set<User> userList = new HashSet<User>();
        for (final Room room : this.roomManager.getRoomListFromGroup(groupId)) {
            userList.addAll(room.getUserList());
        }
        return userList;
    }
    
    @Override
    public Collection<ISession> getSessionsInGroup(final String groupId) {
        final Set<ISession> sessionList = new HashSet<ISession>();
        for (final Room room : this.roomManager.getRoomListFromGroup(groupId)) {
            sessionList.addAll(room.getSessionList());
        }
        return sessionList;
    }
    
    @Override
    public Collection<ISession> getSessionsListeningToGroup(final String groupId) {
        final Set<ISession> sessionList = new HashSet<ISession>();
        final List<User> allUsers = this.userManager.getAllUsers();
        for (final User user : allUsers) {
            if (user.isSubscribedToGroup(groupId)) {
                sessionList.add(user.getSession());
            }
        }
        return sessionList;
    }
    
    @Override
    public Collection<ISession> getSessionList() {
        return this.userManager.getAllSessions();
    }
    
    @Override
    public Collection<User> getUserList() {
        return this.userManager.getAllUsers();
    }
    
    @Override
    public IZoneManager getZoneManager() {
        return this.zoneManager;
    }
    
    @Override
    public boolean isActive() {
        return this.isActive;
    }
    
    @Override
    public boolean isClientAllowedToOverridRoomEvents() {
        return this.clientAllowedToOverridRoomEvents;
    }
    
    @Override
    public boolean isCustomLogin() {
        return this.customLogin;
    }
    
    @Override
    public boolean isForceLogout() {
        return this.forceLogout;
    }
    
    @Override
    public boolean isGuestUserAllowed() {
        return this.guestUserAllowed;
    }
    
    @Override
    public boolean isSystemEventAllowed(final String eventID) {
        boolean flag = false;
        synchronized (this.disabledSystemEvents) {
            flag = !this.disabledSystemEvents.contains(eventID);
        }
        // monitorexit(this.disabledSystemEvents)
        return flag;
    }
    
    @Override
    public boolean isFilterUserNames() {
        return this.filterUserNames;
    }
    
    @Override
    public boolean isFilterRoomNames() {
        return this.filterRoomNames;
    }
    
    @Override
    public void setFilterRoomNames(final boolean flag) {
        this.filterRoomNames = flag;
    }
    
    @Override
    public boolean isFilterBuddyMessages() {
        return this.filterBuddyMessages;
    }
    
    @Override
    public void setFilterBuddyMessages(final boolean flag) {
        this.filterBuddyMessages = flag;
    }
    
    @Override
    public boolean containsProperty(final Object key) {
        return this.properties.containsKey(key);
    }
    
    @Override
    public void registerEventsForRoomGroup(final String groupId, final Set<SFSRoomEvents> flags) {
        if (this.roomManager.containsGroup(groupId)) {
            this.groupEvents.put(groupId, flags);
        }
        else {
            this.logger.warn("Cannot register events for room group: " + groupId + ". Group doesn't exists");
        }
    }
    
    @Override
    public boolean isGroupEventSet(final String groupId, final SFSRoomEvents eventToCheck) {
        boolean res = false;
        final Set<SFSRoomEvents> events = this.groupEvents.get(groupId);
        if (events != null) {
            res = events.contains(eventToCheck);
        }
        return res;
    }
    
    @Override
    public Set<SFSRoomEvents> getGroupEvents(final String groupId) {
        return Collections.unmodifiableSet((Set<? extends SFSRoomEvents>)this.groupEvents.get(groupId));
    }
    
    @Override
    public void removeDisabledSystemEvent(final String eventID) {
        synchronized (this.disabledSystemEvents) {
            this.disabledSystemEvents.remove(eventID);
        }
        // monitorexit(this.disabledSystemEvents)
    }
    
    @Override
    public void removeRoom(final int roomId) {
        this.roomManager.removeRoom(roomId);
    }
    
    @Override
    public void removeRoom(final String name) {
        this.roomManager.removeRoom(name);
    }
    
    @Override
    public void removeRoom(final Room room) {
        this.roomManager.removeRoom(room);
    }
    
    @Override
    public void checkAndRemove(final Room room) {
        this.roomManager.checkAndRemove(room);
    }
    
    @Override
    public void removeUserFromRoom(final User user, final Room room) {
        this.roomManager.removeUser(user, room);
    }
    
    @Override
    public int getMinRoomNameChars() {
        return this.minRoomNameChars;
    }
    
    @Override
    public void setMinRoomNameChars(final int minRoomNameChars) {
        this.minRoomNameChars = minRoomNameChars;
    }
    
    @Override
    public int getMaxRoomNameChars() {
        return this.maxRoomNameChars;
    }
    
    @Override
    public void setMaxRoomNameChars(final int maxRoomNameChars) {
        this.maxRoomNameChars = maxRoomNameChars;
    }
    
    @Override
    public void setActive(final boolean flag) {
        if (!flag && this.isActive) {
            this.removeAllUsers();
        }
        this.isActive = flag;
    }
    
    @Override
    public void setId(final int id) {
        if (this.id != null) {
            throw new IllegalStateException("ID is already assigned = " + this.id);
        }
        this.id = id;
    }
    
    @Override
    public void setClientAllowedToOverridRoomEvents(final boolean flag) {
        this.clientAllowedToOverridRoomEvents = flag;
    }
    
    @Override
    public void setCustomLogin(final boolean flag) {
        this.customLogin = flag;
    }
    
    @Override
    public void setForceLogout(final boolean flag) {
        this.forceLogout = flag;
    }
    
    @Override
    public void setGuestUserAllowed(final boolean flag) {
        this.guestUserAllowed = flag;
    }
    
    @Override
    public void setFilterUserNames(final boolean flag) {
        this.filterUserNames = flag;
    }
    
    @Override
    public void setGuestUserNamePrefix(final String prefix) {
        this.guestUserNamePrefix = prefix;
    }
    
    @Override
    public void setMaxAllowedRooms(final int max) {
        if (max < 0) {
            throw new SFSRuntimeException("Negative values are not acceptable for Zone.maxAllowedRooms: " + max);
        }
        this.maxAllowedRooms = max;
    }
    
    @Override
    public void setMaxAllowedUsers(final int max) {
        if (max < 0) {
            throw new SFSRuntimeException("Negative values are not acceptable for Zone.maxAllowedUsers: " + max);
        }
        this.maxAllowedUsers = max;
    }
    
    @Override
    public void setMaxUserVariablesAllowed(final int max) {
        if (max < 0) {
            throw new SFSRuntimeException("Negative values are not acceptable for Zone.maxAllowedUserVariables: " + max);
        }
        this.maxAllowedUserVariables = max;
    }
    
    @Override
    public void setMaxRoomsCreatedPerUserLimit(final int max) {
        if (max < 0) {
            throw new SFSRuntimeException("Negative values are not acceptable for Zone.maxRoomsCreatedPerUser: " + max);
        }
        this.maxRoomsCreatedPerUser = max;
    }
    
    @Override
    public void setProperty(final Object key, final Object value) {
        this.properties.put(key, value);
    }
    
    @Override
    public void setPublicGroups(final List<String> groupIDs) {
        this.publicGroups = groupIDs;
    }
    
    @Override
    public void setDefaultGroups(final List<String> groupIDs) {
        this.defaultGroups = groupIDs;
    }
    
    @Override
    public void setUserCountChangeUpdateInterval(final int interval) {
        if (interval < 0) {
            throw new SFSRuntimeException("Negative values are not acceptable for Zone.userCountChangeUpdateInterval: " + interval);
        }
        synchronized (this) {
            this.userCountChangeUpdateInterval = interval;
        }
        if (this.uCountResponseThrottler == null) {
            this.uCountResponseThrottler = new UserCountChangeResponseThrottler(this.userCountChangeUpdateInterval, this.name);
        }
        else {
            this.uCountResponseThrottler.setInterval(this.userCountChangeUpdateInterval);
        }
    }
    
    @Override
    public void setZoneManager(final IZoneManager manager) {
        this.zoneManager = manager;
    }
    
    @Override
    public void validateUserName(final String name) throws SFSException {
        if (this.userManager.containsName(name)) {
            throw new SFSException("User name is already taken: " + name);
        }
    }
    
    @Override
    public IFloodFilter getFloodFilter() {
        return this.floodFilter;
    }
    
    @Override
    public IWordFilter getWordFilter() {
        return this.wordFilter;
    }
    
    @Override
    public void removeAllUsers() {
        for (final User user : this.userManager.getAllUsers()) {
            this.sfs.getAPIManager().getSFSApi().disconnectUser(user);
        }
    }
    
    @Override
    public void removeUser(final int userId) {
        final User user = this.userManager.getUserById(userId);
        if (user == null) {
            this.logger.info("Can't remove user with Id: " + userId + ". User doesn't exist in Zone: " + this.name);
        }
        else {
            this.removeUser(user);
        }
    }
    
    @Override
    public void removeUser(final ISession session) {
        final User user = this.userManager.getUserBySession(session);
        if (user == null) {
            this.logger.info("Can't remove user with Session: " + session + ". User doesn't exist in Zone: " + this.name);
        }
        else {
            this.removeUser(user);
        }
    }
    
    @Override
    public void removeUser(final String userName) {
        final User user = this.userManager.getUserByName(userName);
        if (user == null) {
            this.logger.info("Can't remove user with Name: " + userName + ". User doesn't exist in Zone: " + this.name);
        }
        else {
            this.removeUser(user);
        }
    }
    
    @Override
    public void removeUser(final User user) {
        user.getSession().setLoggedIn(false);
        this.userManager.disconnectUser(user);
        this.roomManager.removeUser(user);
    }
    
    @Override
    public int getMaxRoomVariablesAllowed() {
        return this.maxAllowedRoomVariables;
    }
    
    @Override
    public void setMaxRoomVariablesAllowed(final int max) {
        this.maxAllowedRoomVariables = max;
    }
    
    @Override
    public PrivilegeManager getPrivilegeManager() {
        return this.privilegeManager;
    }
    
    @Override
    public void setPrivilegeManager(final PrivilegeManager privilegeManager) {
        if (this.privilegeManager != null) {
            throw new SFSRuntimeException("Cannot re-assign the PrivilegeManager in this Zone: " + this.name);
        }
        this.privilegeManager = privilegeManager;
    }
    
    @Override
    public BuddyListManager getBuddyListManager() {
        return this.buddyListManager;
    }
    
    @Override
    public void setBuddyListManager(final BuddyListManager buddyListManager) {
        if (this.buddyListManager != null) {
            throw new SFSRuntimeException("Cannot re-assign the BuddListManager in this Zone: " + this.name);
        }
        this.buddyListManager = buddyListManager;
    }
    
    @Override
    public IDBManager getDBManager() {
        return this.dbManager;
    }
    
    @Override
    public void setDBManager(final IDBManager manager) {
        if (this.dbManager != null) {
            throw new SFSRuntimeException("Cannot re-assign the DBManager in this Zone: " + this.name);
        }
        this.dbManager = manager;
    }
    
    @Override
    public boolean isFilterPrivateMessages() {
        return this.filterPrivateMessages;
    }
    
    @Override
    public void setFilterPrivateMessages(final boolean flag) {
        this.filterPrivateMessages = flag;
    }
    
    @Override
    public User login(final LoginData loginData) throws SFSLoginException {
        final User user = this.loggable.doLogin(loginData);
        this.finalizer.doFinalize(user);
        return user;
    }
    
    @Override
    public ISFSArray getRoomListData() {
        return this.getRoomListData(this.defaultGroups);
    }
    
    @Override
    public ISFSArray getRoomListData(final List<String> groupIds) {
        final ISFSArray roomList = SFSArray.newInstance();
        if (groupIds.size() > 0) {
            for (final String groupId : groupIds) {
                final List<Room> roomsInGroup = this.getRoomListFromGroup(groupId);
                if (roomsInGroup != null) {
                    for (final Room room : roomsInGroup) {
                        roomList.addSFSArray(room.toSFSArray(true));
                    }
                }
            }
        }
        return roomList;
    }
    
    @Override
    public String toString() {
        return "{ Zone: " + this.name + " }";
    }
    
    @Override
    public String getDump() {
        throw new UnsupportedOperationException("Sorry, not implemented yet!");
    }
    
    public IAdminHelper getAdminHelper() {
        return this.adminHelper;
    }
    
    public void setAdminHelper(final IAdminHelper adminHelper) {
        this.adminHelper = adminHelper;
    }
    
    @Override
    public void initRoomPersistence(final RoomStorageMode mode, final BaseStorageConfig config) {
        if (this.roomStorage == null) {
            this.roomStorage = RoomStorageFactory.getStorage(this, mode, config);
        }
    }
    
    @Override
    public IRoomStorage getRoomPersistenceApi() {
        return this.roomStorage;
    }
    
    @Override
    public boolean isEncrypted() {
        return this.cryptoActive;
    }
    
    @Override
    public void setEncrypted(final boolean value) {
        this.cryptoActive = value;
    }
    
    @Override
    public int getMaxInvitationsPerRequest() {
        return this.maxInvitationsPerRequest;
    }
    
    @Override
    public void setMaxInvitationsPerRequest(final int maxInvitationsPerRequest) {
        this.maxInvitationsPerRequest = maxInvitationsPerRequest;
    }
    
    @Override
    public boolean isAllowInvitationsOnlyForBuddies() {
        return this.allowInvitationsOnlyForBuddies;
    }
    
    @Override
    public void setAllowInvitationsOnlyForBuddies(final boolean allowInvitationsOnlyForBuddies) {
        this.allowInvitationsOnlyForBuddies = allowInvitationsOnlyForBuddies;
    }
    
    @Override
    public int getMaxFailedLogins() {
        return this.maxFailedLogins;
    }
    
    @Override
    public void setMaxFailedLogins(final int value) {
        this.maxFailedLogins = value;
    }
    
    @Override
    public boolean isGeoLocationEnabled() {
        return this.geoLocationEnabled;
    }
    
    @Override
    public void setGeoLocationEnabled(final boolean value) {
        this.geoLocationEnabled = value;
    }
    
    private final class LoginFinalizer implements ILoginFinalizer
    {
        @Override
        public void doFinalize(final User user) throws SFSLoginException {
            this.s1(user);
            this.s2(user);
            this.s3(user);
        }
        
        private synchronized void s1(final User user) throws SFSLoginException {
            final boolean dc = SFSZone.this.sfs.getUserManager().getUserBySession(user.getSession()) != null;
            if (dc) {
                final SFSErrorData errorData = new SFSErrorData(SFSErrorCode.LOGIN_ALREADY_LOGGED);
                errorData.setParams(Arrays.asList(user.getName(), SFSZone.this.getName()));
                throw new SFSLoginException("Duplicate login: " + user, errorData);
            }
            SFSZone.this.userManager.addUser(user);
            SFSZone.this.sfs.getUserManager().addUser(user);
        }
        
        private void s2(final User user) {
            if (SFSZone.this.defaultGroups.size() > 0) {
                for (final String groupId : SFSZone.this.defaultGroups) {
                    user.subscribeGroup(groupId);
                }
            }
        }
        
        private void s3(final User user) {
            if (SFSZone.this.buddyListManager.isActive()) {
                final List<BuddyVariable> bvars = SFSZone.this.buddyListManager.getOfflineBuddyVariables(user.getName(), true);
                if (bvars != null) {
                    user.getBuddyProperties().setVariables(bvars);
                }
            }
        }
    }
}

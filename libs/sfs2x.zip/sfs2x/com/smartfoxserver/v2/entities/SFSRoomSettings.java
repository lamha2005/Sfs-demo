// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

public enum SFSRoomSettings
{
    ROOM_NAME_CHANGE("ROOM_NAME_CHANGE", 0), 
    PASSWORD_STATE_CHANGE("PASSWORD_STATE_CHANGE", 1), 
    PUBLIC_MESSAGES("PUBLIC_MESSAGES", 2), 
    CAPACITY_CHANGE("CAPACITY_CHANGE", 3), 
    USER_ENTER_EVENT("USER_ENTER_EVENT", 4), 
    USER_EXIT_EVENT("USER_EXIT_EVENT", 5), 
    USER_COUNT_CHANGE_EVENT("USER_COUNT_CHANGE_EVENT", 6), 
    USER_VARIABLES_UPDATE_EVENT("USER_VARIABLES_UPDATE_EVENT", 7);
    
    private SFSRoomSettings(final String s, final int n) {
    }
}

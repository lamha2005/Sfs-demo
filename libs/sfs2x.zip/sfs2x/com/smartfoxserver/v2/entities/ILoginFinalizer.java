// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.exceptions.SFSLoginException;

public interface ILoginFinalizer
{
    void doFinalize(final User p0) throws SFSLoginException;
}

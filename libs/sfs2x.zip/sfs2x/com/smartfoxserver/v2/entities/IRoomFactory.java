// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.api.CreateRoomSettings;

public interface IRoomFactory
{
    Room createNewRoom(final CreateRoomSettings p0);
}

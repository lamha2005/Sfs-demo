// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import org.apache.commons.io.FileUtils;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class SFSBannedUserStorage implements IBannedUserStorage
{
    private static final String DATA_FOLDER = "bannedusers/";
    private static final String DATA_FILE = "users.bin";
    private final Logger log;
    private volatile boolean isProperlyInited;
    
    public SFSBannedUserStorage() {
        this.isProperlyInited = false;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void init() {
        try {
            this.checkFolderStructure();
            this.isProperlyInited = true;
            this.log.info("BanUserStorage initialized");
        }
        catch (IOException err) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(err);
            emc.setDescription("Unable to initialize the Banned User Manage storage.");
            final File fullPath = new File("data/bannedusers/");
            final String thePath = (fullPath != null) ? fullPath.getAbsolutePath() : "Unable to obtain path. Your installation might be corrupted.";
            emc.setPossibleCauses("Write permissions are probably not available in: " + thePath);
            if (fullPath == null) {
                emc.addInfo("An additional problem was found: SFS2X is not able to determine the absolute path of the storage folder. Should be {your-sfs-folder}/data/bannedusers/");
            }
            this.log.warn(emc.toString());
        }
    }
    
    @Override
    public void destroy() {
    }
    
    @Override
    public BanUserData load() throws Exception {
        this.checkInited();
        final String dataFile = "data/bannedusers/users.bin";
        final FileInputStream fileInStream = new FileInputStream(dataFile);
        final ObjectInputStream objInStream = new ObjectInputStream(fileInStream);
        final BanUserData banUserData = (BanUserData)objInStream.readObject();
        objInStream.close();
        return banUserData;
    }
    
    @Override
    public synchronized void save(final BanUserData data) throws IOException {
        this.checkInited();
        final String dataFile = "data/bannedusers/users.bin";
        final FileOutputStream fileOStream = new FileOutputStream(dataFile);
        final ObjectOutputStream oStream = new ObjectOutputStream(fileOStream);
        oStream.writeObject(data);
        oStream.flush();
        oStream.close();
    }
    
    private void checkFolderStructure() throws IOException {
        final String folderName = "data/bannedusers/";
        final File targetFolder = new File(folderName);
        if (!targetFolder.isDirectory()) {
            FileUtils.forceMkdir(targetFolder);
        }
    }
    
    private void checkInited() {
        if (!this.isProperlyInited) {
            throw new IllegalStateException("Banned User storage class cannot operate correctly because initialization failed. Please check your startup logs. ");
        }
    }
}

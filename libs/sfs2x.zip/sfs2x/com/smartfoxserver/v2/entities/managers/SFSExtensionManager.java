// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import org.apache.commons.vfs.FileChangeEvent;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.controllers.IControllerCommand;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.core.SFSEventSysParam;
import com.smartfoxserver.v2.entities.User;
import org.mozilla.javascript.WrappedException;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.core.SFSSystemEvent;
import com.smartfoxserver.v2.core.ISFSEventParam;
import com.smartfoxserver.v2.core.SFSEventParam;
import java.util.Collection;
import com.smartfoxserver.v2.core.ISFSEvent;
import java.util.concurrent.CopyOnWriteArraySet;
import org.apache.commons.vfs.FileObject;
import org.apache.commons.vfs.FileSystemException;
import java.io.File;
import org.apache.commons.vfs.VFS;
import com.smartfoxserver.v2.extensions.PythonExtension;
import com.smartfoxserver.v2.extensions.JavascriptExtension;
import it.gotoandplay.util.launcher.BootException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.io.IOException;
import com.smartfoxserver.v2.extensions.ExtensionType;
import com.smartfoxserver.v2.extensions.ExtensionReloadMode;
import com.smartfoxserver.v2.exceptions.SFSExtensionException;
import com.smartfoxserver.v2.config.ZoneSettings;
import java.util.ArrayList;
import java.util.List;
import com.smartfoxserver.v2.extensions.ExtensionLevel;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import it.gotoandplay.util.launcher.JarLoader;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.core.ISFSEventManager;
import org.apache.commons.vfs.FileListener;
import org.apache.commons.vfs.impl.DefaultFileMonitor;
import org.apache.commons.vfs.FileSystemManager;
import com.smartfoxserver.v2.api.LoginErrorHandler;
import it.gotoandplay.util.launcher.IClassLoader;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import java.util.Set;
import com.smartfoxserver.v2.core.SFSEventType;
import java.util.Map;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.entities.Zone;
import java.util.concurrent.ConcurrentMap;
import com.smartfoxserver.v2.core.ISFSEventListener;

public final class SFSExtensionManager implements IExtensionManager, ISFSEventListener
{
    private static final String JAR_EXTENSION = "jar";
    private static final String JS_EXTENSION = "js";
    private static final String PY_EXTENSION = "py";
    private final ConcurrentMap<Zone, ISFSExtension> extensionsByZone;
    private final ConcurrentMap<Room, ISFSExtension> extensionsByRoom;
    private final Map<Room, Map<SFSEventType, Set<ISFSEventListener>>> listenersByRoom;
    private final Map<Zone, Map<SFSEventType, Set<ISFSEventListener>>> listenersByZone;
    private final Logger logger;
    private SmartFoxServer sfs;
    private final IClassLoader jarLoader;
    private final LoginErrorHandler loginErrorHandler;
    private FileSystemManager fsManager;
    private DefaultFileMonitor extensionFileMonitor;
    private FileListener extensionFileListener;
    private ISFSEventManager eventManager;
    private boolean vfsFailed;
    private volatile boolean extMonitorActive;
    private boolean inited;
    
    public SFSExtensionManager() {
        this.vfsFailed = false;
        this.extMonitorActive = false;
        this.inited = false;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.jarLoader = (IClassLoader)new JarLoader();
        this.extensionsByZone = new ConcurrentHashMap<Zone, ISFSExtension>();
        this.extensionsByRoom = new ConcurrentHashMap<Room, ISFSExtension>();
        this.listenersByRoom = new ConcurrentHashMap<Room, Map<SFSEventType, Set<ISFSEventListener>>>();
        this.listenersByZone = new ConcurrentHashMap<Zone, Map<SFSEventType, Set<ISFSEventListener>>>();
        this.loginErrorHandler = new LoginErrorHandler();
    }
    
    @Override
    public boolean isExtensionMonitorActive() {
        return this.extMonitorActive;
    }
    
    @Override
    public void setExtensionMonitorActive(final boolean flag) {
        if (this.vfsFailed && flag) {
            this.logger.warn("Cannot activate Extension files monitoring services. Initialization failed at server boot. Check your logs.");
            return;
        }
        this.extMonitorActive = flag;
        if (this.extMonitorActive) {
            this.extensionFileMonitor.start();
            this.logger.debug("Extension File Monitor started");
        }
        else {
            this.extensionFileMonitor.stop();
            this.logger.debug("Extension File Monitor stopped");
        }
    }
    
    @Override
    public synchronized void activateAllExtensions() {
        for (final ISFSExtension extension : this.extensionsByRoom.values()) {
            extension.setActive(true);
        }
        for (final ISFSExtension extension : this.extensionsByZone.values()) {
            extension.setActive(true);
        }
    }
    
    @Override
    public void addExtension(final ISFSExtension extension) {
        if (extension.getLevel() == ExtensionLevel.ZONE) {
            this.extensionsByZone.put(extension.getParentZone(), extension);
        }
        else if (extension.getLevel() == ExtensionLevel.ROOM) {
            this.extensionsByRoom.put(extension.getParentRoom(), extension);
        }
    }
    
    @Override
    public ISFSExtension getRoomExtension(final Room room) {
        return this.extensionsByRoom.get(room);
    }
    
    @Override
    public ISFSExtension getZoneExtension(final Zone zone) {
        return this.extensionsByZone.get(zone);
    }
    
    private List<ISFSExtension> findZoneExtensionByName(final String extName) {
        final List<ISFSExtension> extensions = new ArrayList<ISFSExtension>();
        for (final ISFSExtension ext : this.extensionsByZone.values()) {
            if (extName.equals(ext.getName())) {
                extensions.add(ext);
            }
        }
        return extensions;
    }
    
    @Override
    public void createExtension(final ZoneSettings.ExtensionSettings settings, final ExtensionLevel level, final Zone parentZone, final Room parentRoom) throws SFSExtensionException {
        if (settings.file == null || settings.file.length() == 0) {
            throw new SFSExtensionException("Extension file parameter is missing!");
        }
        if (settings.name == null || settings.name.length() == 0) {
            throw new SFSExtensionException("Extension name parameter is missing!");
        }
        if (settings.type == null) {
            throw new SFSExtensionException("Extension type was not specified: " + settings.name);
        }
        if (settings.reloadMode == null) {
            settings.reloadMode = "";
        }
        ExtensionReloadMode reloadMode = ExtensionReloadMode.valueOf(settings.reloadMode.toUpperCase());
        if (reloadMode == null) {
            reloadMode = ExtensionReloadMode.MANUAL;
        }
        final ExtensionType extensionType = ExtensionType.valueOf(settings.type.toUpperCase());
        ISFSExtension extension;
        if (extensionType == ExtensionType.JAVA) {
            extension = this.createJavaExtension(settings);
        }
        else if (extensionType == ExtensionType.JAVASCRIPT) {
            extension = this.createJSExtension(settings);
        }
        else {
            if (extensionType != ExtensionType.PYTHON) {
                throw new SFSExtensionException("Extension type not supported: " + extensionType);
            }
            extension = this.createPYExtension(settings);
        }
        extension.setLevel(level);
        extension.setName(settings.name);
        extension.setExtensionFileName(settings.file);
        extension.setReloadMode(reloadMode);
        extension.setParentZone(parentZone);
        extension.setParentRoom(parentRoom);
        try {
            if (settings.propertiesFile != null && (settings.propertiesFile.startsWith("../") || settings.propertiesFile.startsWith("/"))) {
                throw new SFSExtensionException("Illegal path for Extension property file. File path outside the extensions/ folder is not valid: " + settings.propertiesFile);
            }
            extension.setPropertiesFileName(settings.propertiesFile);
        }
        catch (IOException e) {
            throw new SFSExtensionException("Unable to load extension properties file: " + settings.propertiesFile);
        }
        try {
            extension.init();
            this.addExtension(extension);
            if (parentRoom != null) {
                parentRoom.setExtension(extension);
            }
            else {
                parentZone.setExtension(extension);
            }
        }
        catch (Exception err) {
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(err);
            msg.setDescription("Extension initialization failed.");
            this.logger.error(msg.toString());
        }
    }
    
    private ISFSExtension createJavaExtension(final ZoneSettings.ExtensionSettings settings) throws SFSExtensionException {
        ISFSExtension extension;
        try {
            final String extensionPath = "extensions/" + settings.name;
            final ClassLoader extensionClassLoader = this.jarLoader.loadClasses(new String[] { extensionPath }, this.getClass().getClassLoader());
            final Class<?> extensionClass = extensionClassLoader.loadClass(settings.file);
            if (!ISFSExtension.class.isAssignableFrom(extensionClass)) {
                throw new SFSExtensionException("Extension does not implement ISFSExtension interface: " + settings.name);
            }
            extension = (ISFSExtension)extensionClass.newInstance();
            extension.setType(ExtensionType.JAVA);
        }
        catch (BootException e) {
            throw new SFSExtensionException("Extension boot error. " + e.getMessage());
        }
        catch (IllegalAccessException e2) {
            throw new SFSExtensionException("Illegal access while instantiating class: " + settings.file);
        }
        catch (InstantiationException e3) {
            throw new SFSExtensionException("Cannot instantiate class: " + settings.file);
        }
        catch (ClassNotFoundException e4) {
            throw new SFSExtensionException("Class not found: " + settings.file);
        }
        return extension;
    }
    
    private ISFSExtension createJSExtension(final ZoneSettings.ExtensionSettings settings) {
        final ISFSExtension extension = new JavascriptExtension();
        extension.setType(ExtensionType.JAVASCRIPT);
        return extension;
    }
    
    private ISFSExtension createPYExtension(final ZoneSettings.ExtensionSettings settings) {
        final ISFSExtension extension = new PythonExtension();
        extension.setType(ExtensionType.PYTHON);
        return extension;
    }
    
    @Override
    public synchronized void deactivateAllExtensions() {
        for (final ISFSExtension extension : this.extensionsByRoom.values()) {
            extension.setActive(false);
        }
        for (final ISFSExtension extension : this.extensionsByZone.values()) {
            extension.setActive(false);
        }
    }
    
    @Override
    public void destroyExtension(final ISFSExtension extension) {
        try {
            extension.destroy();
        }
        finally {
            if (extension.getLevel() == ExtensionLevel.ROOM) {
                this.extensionsByRoom.remove(extension.getParentRoom());
            }
            else {
                this.extensionsByZone.remove(extension.getParentZone());
            }
            this.logger.debug("Removed: " + extension);
        }
        if (extension.getLevel() == ExtensionLevel.ROOM) {
            this.extensionsByRoom.remove(extension.getParentRoom());
        }
        else {
            this.extensionsByZone.remove(extension.getParentZone());
        }
        this.logger.debug("Removed: " + extension);
    }
    
    @Override
    public List<ISFSExtension> getExtensions() {
        final List<ISFSExtension> allOfThem = new ArrayList<ISFSExtension>(this.extensionsByRoom.values());
        allOfThem.addAll(this.extensionsByZone.values());
        return allOfThem;
    }
    
    @Override
    public int getExtensionsCount() {
        return this.extensionsByRoom.size() + this.extensionsByZone.size();
    }
    
    @Override
    public synchronized void init() {
        if (!this.inited) {
            this.sfs = SmartFoxServer.getInstance();
            this.eventManager = this.sfs.getEventManager();
            this.initializeExtensionFileMonitoring();
            SFSEventType[] values;
            for (int length = (values = SFSEventType.values()).length, i = 0; i < length; ++i) {
                final SFSEventType type = values[i];
                this.eventManager.addEventListener(type, this);
            }
            this.inited = true;
            this.logger.debug("Extension Manager started.");
        }
    }
    
    @Override
    public void destroy() {
        SFSEventType[] values;
        for (int length = (values = SFSEventType.values()).length, i = 0; i < length; ++i) {
            final SFSEventType type = values[i];
            this.eventManager.removeEventListener(type, this);
        }
        this.listenersByRoom.clear();
        this.listenersByZone.clear();
        for (final ISFSExtension extension : this.extensionsByRoom.values()) {
            extension.destroy();
        }
        for (final ISFSExtension extension : this.extensionsByZone.values()) {
            extension.destroy();
        }
        this.extensionsByRoom.clear();
        this.extensionsByZone.clear();
        this.logger.debug("Extension Manager stopped.");
    }
    
    private void initializeExtensionFileMonitoring() {
        try {
            this.fsManager = VFS.getManager();
            final File extFolder = new File("extensions/");
            final FileObject directoryToWatch = this.fsManager.resolveFile(extFolder.getAbsolutePath());
            this.extensionFileListener = (FileListener)new ExtensionFileChangeListener((ExtensionFileChangeListener)null);
            (this.extensionFileMonitor = new DefaultFileMonitor(this.extensionFileListener)).setRecursive(true);
            this.extensionFileMonitor.addFile(directoryToWatch);
        }
        catch (FileSystemException e) {
            this.vfsFailed = true;
            final ExceptionMessageComposer composer = new ExceptionMessageComposer((Throwable)e);
            composer.setDescription("Failed activating extension file monitoring services.");
            composer.setPossibleCauses("You might need to adjust the permissions for the extensions folder");
            this.logger.warn(composer.toString());
        }
    }
    
    @Override
    public void reloadExtension(final ISFSExtension extension) {
        this.logger.info("Reloading extension: " + extension);
        final ZoneSettings.ExtensionSettings newSettings = new ZoneSettings.ExtensionSettings();
        newSettings.file = extension.getExtensionFileName();
        newSettings.name = extension.getName();
        newSettings.propertiesFile = extension.getPropertiesFileName();
        newSettings.reloadMode = extension.getReloadMode().toString();
        newSettings.type = extension.getType().toString();
        try {
            this.createExtension(newSettings, ExtensionLevel.ZONE, extension.getParentZone(), extension.getParentRoom());
            extension.destroy();
        }
        catch (Throwable t) {
            final ExceptionMessageComposer composer = new ExceptionMessageComposer(t);
            composer.setDescription("An error occurred while reloading extension: " + extension.getName() + " in " + extension.getParentZone());
            composer.addInfo("The new extension might not function properly.");
            this.logger.error(composer.toString());
        }
    }
    
    @Override
    public void reloadRoomExtension(final String extName, final Room room) {
        throw new UnsupportedOperationException("Sorry, this feature is not implemented yet.");
    }
    
    @Override
    public void reloadZoneExtension(final String extName, final Zone zone) {
        final ISFSExtension extension = this.extensionsByZone.get(zone);
        if (extension != null) {
            this.reloadExtension(extension);
        }
        else {
            this.logger.warn(String.format("Could not find extension to reload: %s, %s", extName, zone));
        }
    }
    
    @Override
    public synchronized void addZoneEventListener(final SFSEventType type, final ISFSEventListener listener, final Zone zone) {
        Map<SFSEventType, Set<ISFSEventListener>> listenersByType = this.listenersByZone.get(zone);
        if (listenersByType == null) {
            listenersByType = new ConcurrentHashMap<SFSEventType, Set<ISFSEventListener>>();
            this.listenersByZone.put(zone, listenersByType);
        }
        Set<ISFSEventListener> listeners = listenersByType.get(type);
        if (listeners == null) {
            listeners = new CopyOnWriteArraySet<ISFSEventListener>();
            listenersByType.put(type, listeners);
        }
        listeners.add(listener);
    }
    
    @Override
    public synchronized void addRoomEventListener(final SFSEventType type, final ISFSEventListener listener, final Room room) {
        Map<SFSEventType, Set<ISFSEventListener>> listenersByType = this.listenersByRoom.get(room);
        if (listenersByType == null) {
            listenersByType = new ConcurrentHashMap<SFSEventType, Set<ISFSEventListener>>();
            this.listenersByRoom.put(room, listenersByType);
        }
        Set<ISFSEventListener> listeners = listenersByType.get(type);
        if (listeners == null) {
            listeners = new CopyOnWriteArraySet<ISFSEventListener>();
            listenersByType.put(type, listeners);
        }
        listeners.add(listener);
    }
    
    @Override
    public void dispatchEvent(final ISFSEvent event, final ExtensionLevel level) {
        if (level == ExtensionLevel.GLOBAL) {
            this.dispatchGlobalEvent(event);
        }
        else if (level == ExtensionLevel.ZONE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (level == ExtensionLevel.ROOM) {
            this.dispatchRoomLevelEvent(event);
        }
    }
    
    private void dispatchGlobalEvent(final ISFSEvent event) {
        final List<ISFSEventListener> allListeners = new ArrayList<ISFSEventListener>();
        final SFSEventType type = event.getType();
        for (final Map<SFSEventType, Set<ISFSEventListener>> zoneListeners : this.listenersByZone.values()) {
            final Set<ISFSEventListener> listeners = zoneListeners.get(type);
            if (listeners != null) {
                allListeners.addAll(listeners);
            }
        }
        for (final Map<SFSEventType, Set<ISFSEventListener>> roomListeners : this.listenersByRoom.values()) {
            final Set<ISFSEventListener> listeners = roomListeners.get(type);
            if (listeners != null) {
                allListeners.addAll(listeners);
            }
        }
        this.dispatchEvent(event, allListeners);
    }
    
    private void dispatchZoneLevelEvent(final ISFSEvent event) {
        final Zone zone = (Zone)event.getParameter(SFSEventParam.ZONE);
        if (zone != null) {
            final Map<SFSEventType, Set<ISFSEventListener>> listenersByType = this.listenersByZone.get(zone);
            if (listenersByType != null) {
                final Set<ISFSEventListener> listeners = listenersByType.get(event.getType());
                this.dispatchEvent(event, listeners);
            }
        }
        else {
            this.logger.info("Zone Event was not dispatched. ZONE param is null: " + event);
        }
    }
    
    private void dispatchRoomLevelEvent(final ISFSEvent event, final Room room) {
        if (room != null) {
            final Map<SFSEventType, Set<ISFSEventListener>> listenersByType = this.listenersByRoom.get(room);
            if (listenersByType != null) {
                final Set<ISFSEventListener> listeners = listenersByType.get(event.getType());
                this.dispatchEvent(event, listeners);
            }
        }
        else {
            this.logger.info("Room Event was not dispatched. ROOM param is null: " + event);
        }
    }
    
    private void dispatchRoomLevelEvent(final ISFSEvent event) {
        final Room room = (Room)event.getParameter(SFSEventParam.ROOM);
        this.dispatchRoomLevelEvent(event, room);
    }
    
    private void dispatchRoomLevelEvent(final ISFSEvent event, final List<Room> roomList) {
        if (roomList != null) {
            for (final Room room : roomList) {
                final Map<SFSEventType, Set<ISFSEventListener>> listenersByType = this.listenersByRoom.get(room);
                if (listenersByType != null) {
                    final Set<ISFSEventListener> listeners = listenersByType.get(event.getType());
                    this.dispatchEvent(event, listeners);
                }
            }
        }
        else {
            this.logger.info("Multi Room Event was not dispatched. RoomList param is null: " + event);
        }
    }
    
    private void dispatchEvent(final ISFSEvent event, final Collection<ISFSEventListener> listeners) {
        if (listeners != null && listeners.size() > 0) {
            for (final ISFSEventListener listener : listeners) {
                try {
                    listener.handleServerEvent(event);
                    if (!(event instanceof SFSSystemEvent)) {
                        continue;
                    }
                    this.executeEventCommand((SFSSystemEvent)event);
                }
                catch (WrappedException jsWrappedException) {
                    final Throwable t = jsWrappedException.getWrappedException();
                    if (!(t instanceof SFSLoginException)) {
                        throw jsWrappedException;
                    }
                    this.handleLoginException((SFSSystemEvent)event, (SFSLoginException)t);
                }
                catch (SFSLoginException logErr) {
                    this.handleLoginException((SFSSystemEvent)event, logErr);
                }
                catch (Exception e) {
                    final ExceptionMessageComposer composer = new ExceptionMessageComposer(e);
                    composer.setDescription("Error during event handling: " + e + ", Listener: " + listener);
                    this.logger.warn(composer.toString());
                }
            }
        }
    }
    
    @Override
    public void removeListenerFromZone(final ISFSEventListener listener, final Zone zone) {
        final Map<SFSEventType, Set<ISFSEventListener>> listenersByType = this.listenersByZone.get(zone);
        if (listenersByType != null) {
            for (final Set<ISFSEventListener> listenersByEvent : listenersByType.values()) {
                listenersByEvent.remove(listener);
            }
        }
    }
    
    @Override
    public void removeListenerFromRoom(final ISFSEventListener listener, final Room room) {
        final Map<SFSEventType, Set<ISFSEventListener>> listenersByType = this.listenersByRoom.get(room);
        if (listenersByType != null) {
            this.listenersByRoom.remove(room);
            for (final Set<ISFSEventListener> listenersByEvent : listenersByType.values()) {
                listenersByEvent.remove(listener);
            }
        }
    }
    
    @Override
    public void removeZoneEventListener(final SFSEventType type, final ISFSEventListener listener, final Zone zone) {
        this.removeEventListener(this.listenersByZone.get(zone), type, listener);
    }
    
    @Override
    public void removeRoomEventListener(final SFSEventType type, final ISFSEventListener listener, final Room room) {
        this.removeEventListener(this.listenersByRoom.get(room), type, listener);
    }
    
    private void removeEventListener(final Map<SFSEventType, Set<ISFSEventListener>> listenersByType, final SFSEventType type, final ISFSEventListener listener) {
        if (listenersByType != null) {
            final Set<ISFSEventListener> listeners = listenersByType.get(type);
            if (listeners != null) {
                listeners.remove(listener);
            }
        }
    }
    
    @Override
    public void handleServerEvent(final ISFSEvent event) {
        final SFSEventType type = event.getType();
        if (type == SFSEventType.SERVER_READY) {
            this.dispatchEvent(event, ExtensionLevel.GLOBAL);
        }
        else if (type == SFSEventType.USER_LOGIN) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.USER_JOIN_ZONE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.USER_LOGOUT) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.USER_JOIN_ROOM) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event);
        }
        else if (type == SFSEventType.USER_LEAVE_ROOM) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event);
        }
        else if (type == SFSEventType.ROOM_ADDED) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.ROOM_REMOVED) {
            final Room theRoom = (Room)event.getParameter(SFSEventParam.ROOM);
            this.extensionsByRoom.remove(theRoom);
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.USER_DISCONNECT) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event, (List<Room>)event.getParameter(SFSEventParam.JOINED_ROOMS));
        }
        else if (type == SFSEventType.USER_RECONNECTION_TRY) {
            this.dispatchZoneLevelEvent(event);
            final User user = (User)event.getParameter(SFSEventParam.USER);
            this.dispatchRoomLevelEvent(event, user.getJoinedRooms());
        }
        else if (type == SFSEventType.USER_RECONNECTION_SUCCESS) {
            this.dispatchZoneLevelEvent(event);
            final User user = (User)event.getParameter(SFSEventParam.USER);
            this.dispatchRoomLevelEvent(event, user.getJoinedRooms());
        }
        else if (type == SFSEventType.PUBLIC_MESSAGE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.PRIVATE_MESSAGE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.ROOM_VARIABLES_UPDATE) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event);
        }
        else if (type == SFSEventType.USER_VARIABLES_UPDATE) {
            this.dispatchZoneLevelEvent(event);
            final User user = (User)event.getParameter(SFSEventParam.USER);
            if (user.getJoinedRooms().size() > 0) {
                for (final Room joinedRoom : user.getJoinedRooms()) {
                    this.dispatchRoomLevelEvent(event, joinedRoom);
                }
            }
        }
        else if (type == SFSEventType.SPECTATOR_TO_PLAYER) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event);
        }
        else if (type == SFSEventType.PLAYER_TO_SPECTATOR) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event);
        }
        else if (type == SFSEventType.BUDDY_ADD) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.BUDDY_BLOCK) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.BUDDY_LIST_INIT) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.BUDDY_MESSAGE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.BUDDY_ONLINE_STATE_UPDATE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.BUDDY_REMOVE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.BUDDY_VARIABLES_UPDATE) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.GAME_INVITATION_SUCCESS) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event);
        }
        else if (type == SFSEventType.GAME_INVITATION_FAILURE) {
            this.dispatchZoneLevelEvent(event);
            this.dispatchRoomLevelEvent(event);
        }
        else if (type == SFSEventType.FILE_UPLOAD) {
            this.dispatchZoneLevelEvent(event);
        }
        else if (type == SFSEventType.__TRACE_MESSAGE) {
            this.dispatchZoneLevelEvent(event);
        }
    }
    
    private void executeEventCommand(final SFSSystemEvent sysEvent) throws Exception {
        final Class<?> commandClass = (Class<?>)sysEvent.getSysParameter(SFSEventSysParam.NEXT_COMMAND);
        final IRequest request = (IRequest)sysEvent.getSysParameter(SFSEventSysParam.REQUEST_OBJ);
        if (commandClass != null && request != null) {
            final IControllerCommand command = (IControllerCommand)commandClass.newInstance();
            command.execute(request);
        }
    }
    
    private void handleLoginException(final SFSSystemEvent event, final SFSLoginException err) {
        final ExceptionMessageComposer emc = new ExceptionMessageComposer(err);
        emc.setDescription("Extension's Login Handler exception");
        this.logger.warn(emc.toString());
        final ISession sender = ((IRequest)event.getSysParameter(SFSEventSysParam.REQUEST_OBJ)).getSender();
        this.loginErrorHandler.execute(sender, err);
    }
    
    private final class ExtensionFileChangeListener implements FileListener
    {
        public void fileChanged(final FileChangeEvent fileEvent) throws Exception {
            final String changedFileExtension = fileEvent.getFile().getName().getExtension();
            if (changedFileExtension.equalsIgnoreCase("jar") || changedFileExtension.equalsIgnoreCase("py")) {
                final String extName = fileEvent.getFile().getName().getParent().getBaseName();
                final List<ISFSExtension> reloadableExtensions = SFSExtensionManager.this.findZoneExtensionByName(extName);
                if (reloadableExtensions.size() > 0) {
                    for (final ISFSExtension theExtension : reloadableExtensions) {
                        if (theExtension != null && theExtension.getReloadMode() == ExtensionReloadMode.AUTO) {
                            SFSExtensionManager.this.reloadExtension(theExtension);
                        }
                    }
                }
            }
        }
        
        public void fileCreated(final FileChangeEvent arg0) throws Exception {
        }
        
        public void fileDeleted(final FileChangeEvent arg0) throws Exception {
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.entities.SFSRoomRemoveMode;
import com.smartfoxserver.v2.util.filters.FilteredMessage;
import com.smartfoxserver.v2.util.IWordFilter;
import com.smartfoxserver.v2.util.filters.WordsFilterMode;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.Iterator;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import java.util.Collection;
import com.smartfoxserver.v2.config.ZoneSettings;
import org.apache.commons.lang.StringUtils;
import com.smartfoxserver.v2.extensions.ExtensionLevel;
import com.smartfoxserver.v2.extensions.ExtensionType;
import java.util.Set;
import com.smartfoxserver.v2.exceptions.SFSExtensionException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.entities.SFSRoom;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.mmo.MMORoom;
import java.util.EnumSet;
import com.smartfoxserver.v2.entities.SFSRoomSettings;
import com.smartfoxserver.v2.mmo.CreateMMORoomSettings;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.util.DefaultPlayerIdGenerator;
import com.smartfoxserver.v2.util.IPlayerIdGenerator;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.IRoomFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.List;
import com.smartfoxserver.v2.entities.Room;
import java.util.Map;
import com.smartfoxserver.v2.core.BaseCoreService;

public final class SFSRoomManager extends BaseCoreService implements IRoomManager
{
    private final Map<Integer, Room> roomsById;
    private final Map<String, Room> roomsByName;
    private final Map<String, List<Room>> roomsByGroup;
    private final List<String> groups;
    private final AtomicInteger gameRoomCounter;
    private final IRoomFactory roomFactory;
    private Logger logger;
    private SmartFoxServer sfs;
    private Zone ownerZone;
    private Class<? extends IPlayerIdGenerator> playerIdGeneratorClass;
    
    public SFSRoomManager() {
        this.playerIdGeneratorClass = DefaultPlayerIdGenerator.class;
        this.sfs = SmartFoxServer.getInstance();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.roomsById = new ConcurrentHashMap<Integer, Room>();
        this.roomsByName = new ConcurrentHashMap<String, Room>();
        this.roomsByGroup = new ConcurrentHashMap<String, List<Room>>();
        this.groups = new LinkedList<String>();
        this.gameRoomCounter = new AtomicInteger();
        this.roomFactory = this.sfs.getServiceProvider().getRoomFactory();
    }
    
    @Override
    public Room createRoom(final CreateRoomSettings params) throws SFSCreateRoomException {
        return this.createRoom(params, null);
    }
    
    @Override
    public Room createRoom(final CreateRoomSettings params, final User owner) throws SFSCreateRoomException {
        final String roomName = params.getName();
        try {
            this.validateRoomName(roomName);
        }
        catch (SFSRoomException roomExc) {
            throw new SFSCreateRoomException(roomExc.getMessage(), roomExc.getErrorData());
        }
        final Room newRoom = this.roomFactory.createNewRoom(params);
        newRoom.setZone(this.ownerZone);
        newRoom.setGroupId(params.getGroupId());
        newRoom.setPassword(params.getPassword());
        newRoom.setDynamic(params.isDynamic());
        newRoom.setHidden(params.isHidden());
        newRoom.setMaxUsers(params.getMaxUsers());
        newRoom.setAllowOwnerInvitations(params.allowOwnerOnlyInvitation());
        if (params.isGame()) {
            newRoom.setMaxSpectators(params.getMaxSpectators());
        }
        else {
            newRoom.setMaxSpectators(0);
        }
        newRoom.setGame(params.isGame(), (params.getCustomPlayerIdGeneratorClass() == null) ? this.playerIdGeneratorClass : params.getCustomPlayerIdGeneratorClass());
        newRoom.setMaxRoomVariablesAllowed(params.getMaxVariablesAllowed());
        if (params.getRoomVariables() != null) {
            newRoom.setVariables(params.getRoomVariables());
        }
        Set<SFSRoomSettings> roomSettings = params.getRoomSettings();
        if (roomSettings == null) {
            if (params instanceof CreateMMORoomSettings) {
                roomSettings = EnumSet.of(SFSRoomSettings.USER_COUNT_CHANGE_EVENT, SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT, SFSRoomSettings.PUBLIC_MESSAGES);
            }
            else {
                roomSettings = EnumSet.of(SFSRoomSettings.USER_ENTER_EVENT, SFSRoomSettings.USER_EXIT_EVENT, SFSRoomSettings.USER_COUNT_CHANGE_EVENT, SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT, SFSRoomSettings.PUBLIC_MESSAGES);
            }
        }
        if (newRoom instanceof MMORoom) {
            if (roomSettings.contains(SFSRoomSettings.USER_ENTER_EVENT)) {
                roomSettings.remove(SFSRoomSettings.USER_ENTER_EVENT);
            }
            if (roomSettings.contains(SFSRoomSettings.USER_EXIT_EVENT)) {
                roomSettings.remove(SFSRoomSettings.USER_EXIT_EVENT);
            }
        }
        newRoom.setUseWordsFilter(params.isUseWordsFilter());
        newRoom.setFlags(roomSettings);
        newRoom.setOwner(owner);
        newRoom.setAutoRemoveMode(params.getAutoRemoveMode());
        if (this.roomsById.size() >= this.ownerZone.getMaxAllowedRooms()) {
            final SFSErrorData errorData = new SFSErrorData(SFSErrorCode.CREATE_ROOM_ZONE_FULL);
            throw new SFSCreateRoomException("Zone is full. Can't add any more rooms.", errorData);
        }
        if (params.getRoomProperties() != null) {
            ((SFSRoom)newRoom).setProperties(params.getRoomProperties());
        }
        this.addRoom(newRoom);
        newRoom.setActive(true);
        if (params.getExtension() != null && params.getExtension().getId() != null && params.getExtension().getId().length() > 0) {
            try {
                this.createRoomExtension(newRoom, params.getExtension());
            }
            catch (SFSExtensionException e) {
                final ExceptionMessageComposer message = new ExceptionMessageComposer(e);
                message.setDescription("Failure while creating room extension.");
                message.setPossibleCauses("If the CreateRoom request was sent from client make sure that the extension name matches the name of an existing extension");
                this.logger.warn(message.toString());
            }
        }
        if (newRoom.isGame()) {
            this.gameRoomCounter.incrementAndGet();
        }
        this.logger.info(String.format("Room created: %s, %s, type = %s", newRoom.getZone().toString(), newRoom.toString(), newRoom.getClass().getSimpleName()));
        return newRoom;
    }
    
    private void createRoomExtension(final Room room, final CreateRoomSettings.RoomExtensionSettings params) throws SFSExtensionException {
        if (params == null) {
            return;
        }
        ExtensionType extType = ExtensionType.JAVA;
        final ExtensionLevel extLevel = ExtensionLevel.ROOM;
        final String className = params.getClassName();
        if (StringUtils.endsWithIgnoreCase(className, ".py")) {
            extType = ExtensionType.PYTHON;
        }
        final ZoneSettings.ExtensionSettings extSettings = new ZoneSettings.ExtensionSettings();
        extSettings.name = params.getId();
        extSettings.file = className;
        extSettings.propertiesFile = params.getPropertiesFile();
        extSettings.reloadMode = "AUTO";
        extSettings.type = extType.toString();
        this.sfs.getExtensionManager().createExtension(extSettings, extLevel, room.getZone(), room);
    }
    
    @Override
    public Class<? extends IPlayerIdGenerator> getDefaultRoomPlayerIdGenerator() {
        return this.playerIdGeneratorClass;
    }
    
    @Override
    public void setDefaultRoomPlayerIdGeneratorClass(final Class<? extends IPlayerIdGenerator> customIdGeneratorClass) {
        this.playerIdGeneratorClass = customIdGeneratorClass;
    }
    
    @Override
    public void addGroup(final String groupId) {
        synchronized (this.groups) {
            this.groups.add(groupId);
        }
        // monitorexit(this.groups)
    }
    
    @Override
    public void addRoom(final Room room) {
        this.roomsById.put(room.getId(), room);
        this.roomsByName.put(room.getName(), room);
        synchronized (this.groups) {
            if (!this.groups.contains(room.getGroupId())) {
                this.groups.add(room.getGroupId());
            }
        }
        // monitorexit(this.groups)
        this.addRoomToGroup(room);
    }
    
    @Override
    public boolean containsGroup(final String groupId) {
        boolean flag = false;
        synchronized (this.groups) {
            flag = this.groups.contains(groupId);
        }
        // monitorexit(this.groups)
        return flag;
    }
    
    @Override
    public List<String> getGroups() {
        List<String> groupsCopy = null;
        synchronized (this.groups) {
            groupsCopy = new LinkedList<String>(this.groups);
        }
        // monitorexit(this.groups)
        return groupsCopy;
    }
    
    @Override
    public Room getRoomById(final int id) {
        return this.roomsById.get(id);
    }
    
    @Override
    public Room getRoomByName(final String name) {
        return this.roomsByName.get(name);
    }
    
    @Override
    public List<Room> getRoomList() {
        return new LinkedList<Room>(this.roomsByName.values());
    }
    
    @Override
    public List<Room> getRoomListFromGroup(final String groupId) {
        final List<Room> roomList = this.roomsByGroup.get(groupId);
        List<Room> copyOfRoomList = null;
        if (roomList != null) {
            synchronized (roomList) {
                copyOfRoomList = new LinkedList<Room>(roomList);
                // monitorexit(roomList)
                return copyOfRoomList;
            }
        }
        copyOfRoomList = new LinkedList<Room>();
        return copyOfRoomList;
    }
    
    @Override
    public int getGameRoomCount() {
        return this.gameRoomCounter.get();
    }
    
    @Override
    public int getTotalRoomCount() {
        return this.roomsById.size();
    }
    
    @Override
    public void removeGroup(final String groupId) {
        synchronized (this.groups) {
            this.groups.remove(groupId);
        }
        // monitorexit(this.groups)
    }
    
    @Override
    public void removeRoom(final int roomId) {
        final Room room = this.roomsById.get(roomId);
        if (room == null) {
            this.logger.warn("Can't remove requested room. ID = " + roomId + ". Room was not found.");
        }
        else {
            this.removeRoom(room);
        }
    }
    
    @Override
    public void removeRoom(final String name) {
        final Room room = this.roomsByName.get(name);
        if (room == null) {
            this.logger.warn("Can't remove requested room. Name = " + name + ". Room was not found.");
        }
        else {
            this.removeRoom(room);
        }
    }
    
    @Override
    public void removeRoom(final Room room) {
        try {
            final ISFSExtension roomExtension = room.getExtension();
            if (roomExtension != null) {
                this.sfs.getExtensionManager().destroyExtension(roomExtension);
            }
        }
        finally {
            room.destroy();
            final boolean wasRemoved = this.roomsById.remove(room.getId()) != null;
            this.roomsByName.remove(room.getName());
            this.removeRoomFromGroup(room);
            if (wasRemoved && room.isGame()) {
                this.gameRoomCounter.decrementAndGet();
            }
            this.logger.info(String.format("Room removed: %s, %s, Duration: %s", room.getZone().toString(), room.toString(), room.getLifeTime()));
        }
        room.destroy();
        final boolean wasRemoved = this.roomsById.remove(room.getId()) != null;
        this.roomsByName.remove(room.getName());
        this.removeRoomFromGroup(room);
        if (wasRemoved && room.isGame()) {
            this.gameRoomCounter.decrementAndGet();
        }
        this.logger.info(String.format("Room removed: %s, %s, Duration: %s", room.getZone().toString(), room.toString(), room.getLifeTime()));
    }
    
    @Override
    public boolean containsRoom(final int id, final String groupId) {
        final Room room = this.roomsById.get(id);
        return this.isRoomContainedInGroup(room, groupId);
    }
    
    @Override
    public boolean containsRoom(final int id) {
        return this.roomsById.containsKey(id);
    }
    
    @Override
    public boolean containsRoom(final Room room, final String groupId) {
        return this.isRoomContainedInGroup(room, groupId);
    }
    
    @Override
    public boolean containsRoom(final Room room) {
        return this.roomsById.containsValue(room);
    }
    
    @Override
    public boolean containsRoom(final String name, final String groupId) {
        final Room room = this.roomsByName.get(name);
        return this.isRoomContainedInGroup(room, groupId);
    }
    
    @Override
    public boolean containsRoom(final String name) {
        return this.roomsByName.containsKey(name);
    }
    
    @Override
    public Zone getOwnerZone() {
        return this.ownerZone;
    }
    
    @Override
    public void setOwnerZone(final Zone zone) {
        this.ownerZone = zone;
    }
    
    @Override
    public void removeUser(final User user) {
        for (final Room room : user.getJoinedRooms()) {
            this.removeUser(user, room);
        }
    }
    
    @Override
    public void removeUser(final User user, final Room room) {
        try {
            if (!room.containsUser(user)) {
                throw new SFSRuntimeException("Can't remove user: " + user + ", from: " + room);
            }
            room.removeUser(user);
            this.logger.debug("User: " + user.getName() + " removed from Room: " + room.getName());
        }
        finally {
            this.handleAutoRemove(room);
        }
        this.handleAutoRemove(room);
    }
    
    @Override
    public void checkAndRemove(final Room room) {
        this.handleAutoRemove(room);
    }
    
    @Override
    public void changeRoomName(final Room room, final String newName) throws SFSRoomException {
        if (room == null) {
            throw new IllegalArgumentException("Can't change name. Room is Null!");
        }
        if (!this.containsRoom(room)) {
            throw new IllegalArgumentException(room + " is not managed by this Zone: " + this.ownerZone);
        }
        this.validateRoomName(newName);
        final String oldName = room.getName();
        room.setName(newName);
        this.roomsByName.put(newName, room);
        this.roomsByName.remove(oldName);
    }
    
    @Override
    public void changeRoomPasswordState(final Room room, final String password) {
        if (room == null) {
            throw new IllegalArgumentException("Can't change password. Room is Null!");
        }
        if (!this.containsRoom(room)) {
            throw new IllegalArgumentException(room + " is not managed by this Zone: " + this.ownerZone);
        }
        room.setPassword(password);
    }
    
    @Override
    public void changeRoomCapacity(final Room room, final int newMaxUsers, final int newMaxSpect) {
        if (room == null) {
            throw new IllegalArgumentException("Can't change password. Room is Null!");
        }
        if (!this.containsRoom(room)) {
            throw new IllegalArgumentException(room + " is not managed by this Zone: " + this.ownerZone);
        }
        if (newMaxUsers > 0) {
            room.setMaxUsers(newMaxUsers);
        }
        if (newMaxSpect >= 0) {
            room.setMaxSpectators(newMaxSpect);
        }
    }
    
    private void handleAutoRemove(final Room room) {
        if (room.isEmpty() && room.isDynamic()) {
            switch (room.getAutoRemoveMode()) {
                case DEFAULT: {
                    if (room.isGame()) {
                        this.removeWhenEmpty(room);
                        break;
                    }
                    this.removeWhenEmptyAndCreatorIsGone(room);
                    break;
                }
                case WHEN_EMPTY: {
                    this.removeWhenEmpty(room);
                    break;
                }
                case WHEN_EMPTY_AND_CREATOR_IS_GONE: {
                    this.removeWhenEmptyAndCreatorIsGone(room);
                    break;
                }
            }
        }
    }
    
    private void removeWhenEmpty(final Room room) {
        if (room.isEmpty()) {
            this.sfs.getAPIManager().getSFSApi().removeRoom(room);
        }
    }
    
    private void removeWhenEmptyAndCreatorIsGone(final Room room) {
        final User owner = room.getOwner();
        if (owner != null && !owner.isConnected()) {
            this.sfs.getAPIManager().getSFSApi().removeRoom(room);
        }
    }
    
    private boolean isRoomContainedInGroup(final Room room, final String groupId) {
        boolean flag = false;
        if (room != null && room.getGroupId().equals(groupId) && this.containsGroup(groupId)) {
            flag = true;
        }
        return flag;
    }
    
    private void addRoomToGroup(final Room room) {
        final String groupId = room.getGroupId();
        List<Room> roomList = this.roomsByGroup.get(groupId);
        if (roomList == null) {
            roomList = new LinkedList<Room>();
            this.roomsByGroup.put(groupId, roomList);
        }
        synchronized (roomList) {
            roomList.add(room);
        }
    }
    
    private void removeRoomFromGroup(final Room room) {
        final List<Room> roomList = this.roomsByGroup.get(room.getGroupId());
        if (roomList != null) {
            synchronized (roomList) {
                roomList.remove(room);
                // monitorexit(roomList)
                return;
            }
        }
        this.logger.info("Cannot remove room: " + room.getName() + " from it's group: " + room.getGroupId() + ". The group was not found.");
    }
    
    private void validateRoomName(final String roomName) throws SFSRoomException {
        if (this.containsRoom(roomName)) {
            final SFSErrorData errorData = new SFSErrorData(SFSErrorCode.ROOM_DUPLICATE_NAME);
            errorData.addParameter(roomName);
            final String message = String.format("A room with the same name already exists: %s", roomName);
            throw new SFSRoomException(message, errorData);
        }
        final int nameLen = roomName.length();
        final int minLen = this.ownerZone.getMinRoomNameChars();
        final int maxLen = this.ownerZone.getMaxRoomNameChars();
        if (nameLen < minLen || nameLen > maxLen) {
            final SFSErrorData errorData2 = new SFSErrorData(SFSErrorCode.ROOM_NAME_BAD_SIZE);
            errorData2.addParameter(String.valueOf(minLen));
            errorData2.addParameter(String.valueOf(maxLen));
            errorData2.addParameter(String.valueOf(nameLen));
            final String message2 = String.format("Room name length is out of valid range. Min: %s, Max: %s, Found: %s (%s)", minLen, maxLen, nameLen, roomName);
            throw new SFSRoomException(message2, errorData2);
        }
        final IWordFilter wordFilter = this.ownerZone.getWordFilter();
        if (this.ownerZone.isFilterRoomNames() && wordFilter.isActive() && wordFilter.getFilterMode() == WordsFilterMode.BLACK_LIST) {
            final FilteredMessage filteredName = wordFilter.apply(roomName);
            if (filteredName.getOccurrences() > 0) {
                final SFSErrorData errorData3 = new SFSErrorData(SFSErrorCode.ROOM_NAME_CONTAINS_BADWORDS);
                errorData3.addParameter(roomName);
                final String message3 = String.format("Room name contains bad words: %s", roomName);
                throw new SFSRoomException(message3, errorData3);
            }
        }
    }
}

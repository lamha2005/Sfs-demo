// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.entities.BannedUser;
import java.util.Map;
import java.io.Serializable;

public class BanUserData implements Serializable
{
    private static final long serialVersionUID = -5727904595766376640L;
    private final Map<String, Map<String, BannedUser>> bannedUsersByNameAndZone;
    private final Map<String, BannedUser> bannedUsersByIp;
    
    public BanUserData(final Map<String, Map<String, BannedUser>> bannedUsersByNameAndZone, final Map<String, BannedUser> bannedUsersByIp) {
        this.bannedUsersByNameAndZone = bannedUsersByNameAndZone;
        this.bannedUsersByIp = bannedUsersByIp;
    }
    
    public Map<String, Map<String, BannedUser>> getBannedUsersByNameAndZone() {
        return this.bannedUsersByNameAndZone;
    }
    
    public Map<String, BannedUser> getBannedUsersByIp() {
        return this.bannedUsersByIp;
    }
}

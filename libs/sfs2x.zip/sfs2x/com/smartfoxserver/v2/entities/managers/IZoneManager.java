// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.config.ZoneSettings;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.entities.Zone;
import java.util.List;
import com.smartfoxserver.v2.core.ICoreService;

public interface IZoneManager extends ICoreService
{
    List<Zone> getZoneList();
    
    Zone getZoneByName(final String p0);
    
    Zone getZoneById(final int p0);
    
    void initializeZones() throws SFSException;
    
    void addZone(final Zone p0);
    
    Zone createZone(final ZoneSettings p0) throws SFSException;
    
    Room createRoom(final Zone p0, final ZoneSettings.RoomSettings p1) throws SFSException;
    
    void toggleZone(final String p0, final boolean p1);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import java.util.Collection;
import com.smartfoxserver.v2.mmo.Vec3D;
import java.util.Set;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.mmo.MMOHelper;
import com.smartfoxserver.v2.entities.variables.SFSRoomVariable;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import org.apache.commons.lang.ArrayUtils;
import com.smartfoxserver.v2.entities.SFSRoomSettings;
import java.util.HashSet;
import com.smartfoxserver.v2.entities.SFSRoomRemoveMode;
import com.smartfoxserver.v2.mmo.CreateMMORoomSettings;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.db.IDBManager;
import com.smartfoxserver.v2.db.SFSDBManager;
import com.smartfoxserver.v2.db.DBConfig;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.buddylist.storage.BuddyStorage;
import com.smartfoxserver.v2.security.PrivilegeManager;
import com.smartfoxserver.v2.security.SFSPermissionProfile;
import com.smartfoxserver.v2.security.SystemPermission;
import com.smartfoxserver.v2.util.IFloodFilter;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.util.IWordFilter;
import com.smartfoxserver.v2.util.filters.WordsFilterMode;
import com.smartfoxserver.v2.util.stats.ZoneTrafficMeter;
import com.smartfoxserver.v2.exceptions.SFSExtensionException;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.extensions.ExtensionLevel;
import java.util.Arrays;
import com.smartfoxserver.v2.entities.SFSZone;
import java.util.concurrent.TimeUnit;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.config.ZoneSettings;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.util.stats.ITrafficMeter;
import com.smartfoxserver.v2.config.IConfigurator;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.Zone;
import java.util.concurrent.ConcurrentMap;
import org.slf4j.Logger;
import com.smartfoxserver.v2.core.BaseCoreService;

public class SFSZoneManager extends BaseCoreService implements IZoneManager
{
    protected String defaultBuddyStorageClass;
    protected Logger logger;
    protected ConcurrentMap<String, Zone> zones;
    protected SmartFoxServer sfs;
    protected IConfigurator configurator;
    private boolean inited;
    private final ConcurrentMap<String, ITrafficMeter> trafficMonitors;
    private final TrafficMeterExecutor trafficMeterExecutor;
    
    public SFSZoneManager() {
        this.defaultBuddyStorageClass = "com.smartfoxserver.v2.buddylist.storage.FSBuddyStorage";
        this.inited = false;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        if (this.zones == null) {
            this.zones = new ConcurrentHashMap<String, Zone>();
        }
        this.trafficMonitors = new ConcurrentHashMap<String, ITrafficMeter>();
        this.trafficMeterExecutor = new TrafficMeterExecutor(this.trafficMonitors.values());
        Runtime.getRuntime().addShutdownHook(new ShutDownHandler((ShutDownHandler)null));
    }
    
    @Override
    public synchronized void init(final Object o) {
        if (!this.inited) {
            super.init(o);
            this.sfs = SmartFoxServer.getInstance();
            this.configurator = this.sfs.getConfigurator();
            this.inited = true;
        }
    }
    
    @Override
    public void addZone(final Zone zone) {
        if (this.zones.containsKey(zone.getName())) {
            throw new SFSRuntimeException("Zone already exists: " + zone.getName() + ". Can't add the same zone more than once.");
        }
        this.zones.put(zone.getName(), zone);
    }
    
    @Override
    public Zone getZoneByName(final String name) {
        return this.zones.get(name);
    }
    
    @Override
    public Zone getZoneById(final int id) {
        Zone theZone = null;
        for (final Zone zone : this.zones.values()) {
            if (zone.getId() == id) {
                theZone = zone;
                break;
            }
        }
        return theZone;
    }
    
    @Override
    public List<Zone> getZoneList() {
        return new ArrayList<Zone>(this.zones.values());
    }
    
    @Override
    public synchronized void initializeZones() throws SFSException {
        final List<ZoneSettings> zoneSettings = this.configurator.loadZonesConfiguration();
        for (final ZoneSettings settings : zoneSettings) {
            this.logger.info(String.format("%n%n%s%n >> Zone: %s %n%s%n", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", settings.name, "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
            this.addZone(this.createZone(settings));
        }
        this.activateTrafficMonitors();
    }
    
    @Override
    public void toggleZone(final String name, final boolean isActive) {
        final Zone theZone = this.getZoneByName(name);
        theZone.setActive(isActive);
    }
    
    public ITrafficMeter getZoneTrafficMeter(final String zoneName) {
        return this.trafficMonitors.get(zoneName);
    }
    
    protected void activateTrafficMonitors() {
        this.sfs.getTaskScheduler().scheduleAtFixedRate(this.trafficMeterExecutor, 0, 5, TimeUnit.MINUTES);
    }
    
    @Override
    public Zone createZone(final ZoneSettings settings) throws SFSException {
        final Zone zone = new SFSZone(settings.name);
        zone.setId(settings.getId());
        zone.setCustomLogin(settings.isCustomLogin);
        zone.setForceLogout(settings.isForceLogout);
        zone.setFilterUserNames(settings.isFilterUserNames);
        zone.setFilterRoomNames(settings.isFilterRoomNames);
        zone.setFilterPrivateMessages(settings.isFilterPrivateMessages);
        zone.setFilterBuddyMessages(settings.isFilterBuddyMessages);
        zone.setGuestUserAllowed(settings.allowGuestUsers);
        zone.setGuestUserNamePrefix(settings.guestUserNamePrefix);
        zone.setMaxAllowedRooms(settings.maxRooms);
        zone.setEncrypted(settings.isEncrypted);
        zone.setMaxFailedLogins(settings.maxFailedLogins);
        zone.setMaxAllowedUsers(settings.maxUsers);
        zone.setMaxUserVariablesAllowed(settings.maxUserVariablesAllowed);
        zone.setMaxRoomVariablesAllowed(settings.maxRoomVariablesAllowed);
        zone.setMinRoomNameChars(settings.minRoomNameChars);
        zone.setMaxRoomNameChars(settings.maxRoomNameChars);
        zone.setMaxRoomsCreatedPerUserLimit(settings.maxRoomsCreatedPerUser);
        zone.setDefaultPlayerIdGeneratorClassName(settings.defaultPlayerIdGeneratorClass);
        zone.setUserCountChangeUpdateInterval(settings.userCountChangeUpdateInterval);
        zone.setUserReconnectionSeconds(settings.userReconnectionSeconds);
        zone.setUploadEnabled(settings.allowUploads);
        zone.setAllowInvitationsOnlyForBuddies(settings.allowInvitationsOnlyForBuddies);
        zone.setMaxInvitationsPerRequest(settings.maxUsersPerJoinInvitationRequest);
        zone.setGeoLocationEnabled(settings.geoLocationEnabled);
        int theZoneIdleTime = this.sfs.getConfigurator().getServerSettings().userMaxIdleTime;
        if (settings.overrideMaxUserIdleTime > 0) {
            if (settings.overrideMaxUserIdleTime >= this.sfs.getConfigurator().getServerSettings().sessionMaxIdleTime) {
                theZoneIdleTime = settings.overrideMaxUserIdleTime;
            }
            else {
                this.logger.warn(String.format("%s - Could not override maxUserIdleTime. The provided value (%s sec) is < sessionMaxIdleTime (%s sec). You must provide a value > sessionMaxIdleTime. Please double check your configuration.", zone, settings.overrideMaxUserIdleTime, this.sfs.getConfigurator().getServerSettings().sessionMaxIdleTime));
            }
        }
        zone.setMaxUserIdleTime(theZoneIdleTime);
        List<String> defaultRoomGroups = null;
        if (settings.defaultRoomGroups != null) {
            final String[] defaultGroups = settings.defaultRoomGroups.split("\\,");
            defaultRoomGroups = Arrays.asList(defaultGroups);
        }
        else {
            defaultRoomGroups = new ArrayList<String>();
        }
        if (defaultRoomGroups.size() == 0) {
            defaultRoomGroups.add("default");
        }
        zone.setDefaultGroups(defaultRoomGroups);
        List<String> publicRoomGroups = null;
        if (settings.publicRoomGroups != null) {
            final String[] publicGroups = settings.publicRoomGroups.split("\\,");
            publicRoomGroups = Arrays.asList(publicGroups);
        }
        else {
            publicRoomGroups = new ArrayList<String>();
        }
        if (publicRoomGroups.size() == 0) {
            publicRoomGroups.add("default");
        }
        zone.setPublicGroups(publicRoomGroups);
        zone.setZoneManager(this);
        for (final String eventName : settings.disabledSystemEvents) {
            zone.addDisabledSystemEvent(eventName);
        }
        this.configureWordsFilter(zone, settings.wordsFilter);
        this.configureFloodFilter(zone, settings.floodFilter);
        this.configureZonePermissions(zone, settings.privilegeManager);
        if (settings.databaseManager != null) {
            this.configureDBManager(zone, settings.databaseManager);
        }
        this.configureBuddyListManager(zone, settings.buddyList);
        for (final ZoneSettings.RoomSettings roomSettings : settings.rooms) {
            try {
                this.createRoom(zone, roomSettings);
            }
            catch (SFSException e) {
                this.logger.warn("Error while creating Room: " + roomSettings.name + " -> " + e.getMessage());
            }
        }
        if (settings.extension != null && settings.extension.name != null && settings.extension.name.length() > 0) {
            try {
                this.sfs.getExtensionManager().createExtension(settings.extension, ExtensionLevel.ZONE, zone, null);
            }
            catch (SFSExtensionException err) {
                final String extName = (settings.extension.name == null) ? "{Unknown}" : settings.extension.name;
                throw new SFSException("Extension creation failure: " + extName + " - " + err.getMessage());
            }
        }
        zone.setActive(true);
        this.trafficMonitors.put(zone.getName(), new ZoneTrafficMeter(zone));
        return zone;
    }
    
    private void configureWordsFilter(final Zone zone, final ZoneSettings.WordFilterSettings settings) {
        final IWordFilter wordFilter = zone.getWordFilter();
        wordFilter.setBanDurationMinutes(settings.banDuration);
        wordFilter.setBanMessage(settings.banMessage);
        wordFilter.setBanMode(BanMode.fromString(settings.banMode));
        wordFilter.setBannedUserManager(this.sfs.getBannedUserManager());
        wordFilter.setFilterMode(WordsFilterMode.fromString(settings.filterMode));
        wordFilter.setUseWarnings(settings.useWarnings);
        wordFilter.setWarningMessage(settings.warningMessage);
        wordFilter.setKickMessage(settings.kickMessage);
        wordFilter.setKicksBeforeBan(settings.kicksBeforeBan);
        wordFilter.setKicksBeforeBanMinutes(settings.kicksBeforeBanMinutes);
        wordFilter.setMaskCharacter(settings.hideBadWordWithCharacter);
        wordFilter.setMaxBadWordsPerMessage(settings.maxBadWordsPerMessage);
        wordFilter.setName(String.valueOf(zone.getName()) + "-WordFilter");
        wordFilter.setSecondsBeforeBanOrKick(settings.secondsBeforeBanOrKick);
        wordFilter.setWarningsBeforeKick(settings.warningsBeforeKick);
        wordFilter.setWordsFile(settings.wordsFile);
        wordFilter.setActive(settings.isActive);
        wordFilter.init((Object)null);
    }
    
    private void configureFloodFilter(final Zone zone, final ZoneSettings.FloodFilterSettings settings) {
        final IFloodFilter floodFilter = zone.getFloodFilter();
        floodFilter.setActive(settings.isActive);
        floodFilter.setBanDurationMinutes(settings.banDurationMinutes);
        floodFilter.setBanMessage(settings.banMessage);
        floodFilter.setBanMode(BanMode.fromString(settings.banMode));
        floodFilter.setLogFloodingAttempts(settings.logFloodingAttempts);
        floodFilter.setMaxFloodingAttempts(settings.maxFloodingAttempts);
        floodFilter.setSecondsBeforeBan(settings.secondsBeforeBan);
        if (settings.requestFilters != null) {
            for (final ZoneSettings.RequestFilterSettings item : settings.requestFilters) {
                floodFilter.addRequestFilter(SystemRequest.valueOf(item.reqName), item.maxRequestsPerSecond);
            }
        }
    }
    
    private void configureZonePermissions(final Zone zone, final ZoneSettings.PrivilegeManagerSettings settings) {
        final PrivilegeManager privilegeManager = zone.getPrivilegeManager();
        privilegeManager.setActive(settings.active);
        if (settings.active) {
            for (final ZoneSettings.PermissionProfile profileSetting : settings.profiles) {
                final List<SystemRequest> deniedReq = new ArrayList<SystemRequest>();
                for (final String reqName : profileSetting.deniedRequests) {
                    deniedReq.add(SystemRequest.valueOf(reqName));
                }
                final List<SystemRequest> deniedSysReq = new ArrayList<SystemRequest>();
                final List<SystemPermission> sysFlags = new ArrayList<SystemPermission>();
                if (profileSetting.deniedRequests != null) {
                    for (final String sysReqName : profileSetting.deniedRequests) {
                        deniedSysReq.add(SystemRequest.valueOf(sysReqName));
                    }
                }
                if (profileSetting.permissionFlags != null) {
                    for (final String flagName : profileSetting.permissionFlags) {
                        sysFlags.add(SystemPermission.valueOf(flagName));
                    }
                }
                privilegeManager.setPermissionProfile(new SFSPermissionProfile(profileSetting.id, profileSetting.name, deniedSysReq, sysFlags));
            }
        }
    }
    
    private void configureBuddyListManager(final Zone zone, final ZoneSettings.BuddyListSettings settings) {
        final BuddyListManager buddyListManager = this.sfs.getServiceProvider().getBuddyListManagerImpl(zone, settings.active);
        zone.setBuddyListManager(buddyListManager);
        if (buddyListManager.isActive()) {
            buddyListManager.setBuddyListMaxSize(settings.maxItemsPerList);
            buddyListManager.setMaxBuddyVariables(settings.maxBuddyVariables);
            buddyListManager.setOfflineBuddyVariablesCacheSize(settings.offlineBuddyVariablesCacheSize);
            buddyListManager.setAllowOfflineBuddyVariables(settings.allowOfflineBuddyVariables);
            buddyListManager.setBuddyStates(settings.buddyStates);
            buddyListManager.setUseTempBuddies(settings.useTempBuddies);
            buddyListManager.setApplyBadWordsFilter(settings.badWordsFilter.isActive);
            String customClass = null;
            if (settings.customStorageClass != null && settings.customStorageClass.length() > 0) {
                customClass = settings.customStorageClass;
            }
            else {
                customClass = this.defaultBuddyStorageClass;
            }
            try {
                final Class<?> storageClass = Class.forName(customClass);
                if (!BuddyStorage.class.isAssignableFrom(storageClass)) {
                    throw new SFSRuntimeException("Specified BuddyList Storage class: " + customClass + " does not implement the BuddyStorage interface");
                }
                buddyListManager.setStorageHandler((BuddyStorage)storageClass.newInstance());
                buddyListManager.init((Object)null);
            }
            catch (ClassNotFoundException e) {
                throw new SFSRuntimeException("BuddyList storage class: " + customClass + " was not found.");
            }
            catch (InstantiationException e2) {
                throw new SFSRuntimeException("BuddyList storage class: " + customClass + " could not be instantiated.");
            }
            catch (IllegalAccessException e3) {
                throw new SFSRuntimeException("Illegal access for BuddyList storage class: " + customClass);
            }
        }
    }
    
    private void configureDBManager(final Zone zone, final DBConfig settings) {
        final IDBManager dbManager = new SFSDBManager(settings);
        zone.setDBManager(dbManager);
        dbManager.init((Object)zone);
    }
    
    @Override
    public Room createRoom(final Zone zone, final ZoneSettings.RoomSettings roomSettings) throws SFSException {
        final boolean isMMO = roomSettings.mmoSettings != null && roomSettings.mmoSettings.isActive;
        CreateRoomSettings params;
        if (!isMMO) {
            params = new CreateRoomSettings();
        }
        else {
            params = new CreateMMORoomSettings();
        }
        params.setName(roomSettings.name);
        params.setGroupId(roomSettings.groupId);
        params.setPassword(roomSettings.password);
        params.setAutoRemoveMode(SFSRoomRemoveMode.fromString(roomSettings.autoRemoveMode));
        params.setMaxUsers(roomSettings.maxUsers);
        params.setMaxSpectators(roomSettings.maxSpectators);
        params.setMaxVariablesAllowed(roomSettings.permissions.maxRoomVariablesAllowed);
        params.setDynamic(roomSettings.isDynamic);
        params.setGame(roomSettings.isGame);
        params.setHidden(roomSettings.isHidden);
        params.setUseWordsFilter(roomSettings.badWordsFilter.isActive);
        params.setAllowOwnerOnlyInvitation(roomSettings.allowOwnerInvitation);
        final Set<SFSRoomSettings> sfsRoomSettings = new HashSet<SFSRoomSettings>();
        final String[] settings = (String[])ArrayUtils.addAll((Object[])roomSettings.permissions.flags.split("\\,"), (Object[])roomSettings.events.split("\\,"));
        String[] array;
        for (int length = (array = settings).length, i = 0; i < length; ++i) {
            final String item = array[i];
            try {
                sfsRoomSettings.add(SFSRoomSettings.valueOf(item.toUpperCase()));
            }
            catch (IllegalArgumentException argError) {
                this.logger.warn("RoomSetting literal not found: " + item);
            }
        }
        params.setRoomSettings(sfsRoomSettings);
        final List<RoomVariable> variables = new ArrayList<RoomVariable>();
        for (final ZoneSettings.RoomVariableDefinition varDef : roomSettings.roomVariables) {
            final RoomVariable sfsRoomVar = SFSRoomVariable.newFromStringLiteral(varDef.name, varDef.type, varDef.value);
            sfsRoomVar.setPrivate(varDef.isPrivate);
            sfsRoomVar.setPersistent(varDef.isPersistent);
            sfsRoomVar.setGlobal(varDef.isGlobal);
            sfsRoomVar.setHidden(varDef.isHidden);
            variables.add(sfsRoomVar);
        }
        params.setRoomVariables(variables);
        if (isMMO) {
            final Vec3D defaultAOI = MMOHelper.stringToVec3D(roomSettings.mmoSettings.defaultAOI, roomSettings.mmoSettings.forceFloats);
            final Vec3D lowerMapLimit = MMOHelper.stringToVec3D(roomSettings.mmoSettings.lowerMapLimit, roomSettings.mmoSettings.forceFloats);
            final Vec3D higherMapLimit = MMOHelper.stringToVec3D(roomSettings.mmoSettings.higherMapLimit, roomSettings.mmoSettings.forceFloats);
            final CreateMMORoomSettings cmrs = (CreateMMORoomSettings)params;
            cmrs.setDefaultAOI(defaultAOI);
            cmrs.setUserMaxLimboSeconds(roomSettings.mmoSettings.userMaxLimboSeconds);
            cmrs.setProximityListUpdateMillis(roomSettings.mmoSettings.proximityListUpdateMillis);
            cmrs.setSendAOIEntryPoint(roomSettings.mmoSettings.sendAOIEntryPoint);
            if (lowerMapLimit != null && higherMapLimit != null) {
                cmrs.setMapLimits(new CreateMMORoomSettings.MapLimits(lowerMapLimit, higherMapLimit));
            }
        }
        final Room room = this.sfs.getAPIManager().getSFSApi().createRoom(zone, params, null, false, null, false, false);
        if (roomSettings.extension != null && roomSettings.extension.name != null && roomSettings.extension.name.length() > 0) {
            try {
                this.sfs.getExtensionManager().createExtension(roomSettings.extension, ExtensionLevel.ROOM, zone, room);
            }
            catch (SFSExtensionException err) {
                final String extName = (roomSettings.extension.name == null) ? "{Unknown}" : roomSettings.extension.name;
                throw new SFSException("Room Extension creation failure: " + extName + " - " + err.getMessage() + " - Room: " + room);
            }
        }
        return room;
    }
    
    private final class ShutDownHandler extends Thread
    {
        @Override
        public void run() {
            SFSZoneManager.this.logger.info("BuddyList saveAll...");
            for (final Zone zone : SFSZoneManager.this.zones.values()) {
                try {
                    zone.getBuddyListManager().saveAll();
                }
                catch (Exception e) {
                    SFSZoneManager.this.logger.warn(e.toString());
                }
            }
        }
    }
    
    private static class TrafficMeterExecutor implements Runnable
    {
        private final Logger log;
        private final Collection<ITrafficMeter> trafficMonitors;
        
        public TrafficMeterExecutor(final Collection<ITrafficMeter> trafficMonitors) {
            this.trafficMonitors = trafficMonitors;
            this.log = LoggerFactory.getLogger((Class)this.getClass());
        }
        
        @Override
        public void run() {
            try {
                final long t1 = System.nanoTime();
                for (final ITrafficMeter monitor : this.trafficMonitors) {
                    monitor.onTick();
                }
                final long t2 = System.nanoTime();
                if (this.log.isDebugEnabled()) {
                    this.log.debug("Traffic Monitor update: " + (t2 - t1) / 1000000.0 + "ms.");
                }
            }
            catch (Exception e) {
                this.log.warn("Unexpected exception: " + e + ". Task will not be interrupted.");
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import java.io.IOException;
import java.util.ArrayList;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.LinkedList;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.SFSBannedUser;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import com.smartfoxserver.bitswarm.util.scheduling.Task;
import java.util.Collection;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.Arrays;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.util.UsersUtil;
import com.smartfoxserver.v2.util.ClientDisconnectionReason;
import com.smartfoxserver.v2.entities.User;
import java.util.concurrent.TimeUnit;
import java.io.FileNotFoundException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.BannedUser;
import java.util.List;
import java.util.Map;
import com.smartfoxserver.v2.core.BaseCoreService;

public final class SFSBannedUserManager extends BaseCoreService implements IBannedUserManager
{
    private static String STORAGE_DEFAULT_CLASS;
    private static final int KICK_TIMER_CLEANER_TASK_INTERVAL = 12;
    private static final long KICK_TIMER_MAX_LENGTH = 86400000L;
    private static final int BAN_AUTOSAVE_INTERVAL = 1;
    private static final int BAN_EXPIRER_TASK_INTERVAL = 2;
    private final Map<String, Map<String, List<Long>>> kickHistoryByZone;
    private Map<String, Map<String, BannedUser>> bannedUsersByNameAndZone;
    private Map<String, BannedUser> bannedUsersByIp;
    private SmartFoxServer sfs;
    private final Runnable kickHistoryCleanerTask;
    private final Runnable banExpirerTask;
    private final Runnable banAutoSaverTask;
    private final Thread shutDownHandler;
    private final Logger logger;
    private boolean autoRemoveBan;
    private boolean persistent;
    private IBannedUserStorage storage;
    
    static {
        SFSBannedUserManager.STORAGE_DEFAULT_CLASS = "com.smartfoxserver.v2.entities.managers.SFSBannedUserStorage";
    }
    
    public SFSBannedUserManager() {
        this.logger = LoggerFactory.getLogger((Class)SFSBannedUserManager.class);
        this.kickHistoryByZone = new ConcurrentHashMap<String, Map<String, List<Long>>>();
        this.kickHistoryCleanerTask = new KickHistoryCleanerTask((KickHistoryCleanerTask)null);
        this.banExpirerTask = new BanExpirerTask((BanExpirerTask)null);
        this.banAutoSaverTask = new BanDataAutoSaveTask((BanDataAutoSaveTask)null);
        this.shutDownHandler = new ShutDownHandler((ShutDownHandler)null);
        this.autoRemoveBan = false;
        this.persistent = false;
    }
    
    @Override
    public void init(final Object o) {
        super.init(o);
        try {
            final Class<?> clazz = Class.forName(SFSBannedUserManager.STORAGE_DEFAULT_CLASS);
            this.storage = (IBannedUserStorage)clazz.newInstance();
        }
        catch (Exception e) {
            final ExceptionMessageComposer composer = new ExceptionMessageComposer(e);
            composer.setDescription("the specified persistence class for the BannedUserManager cannot be found or instantiated");
            composer.setPossibleCauses("double check the fully qualified class name and make sure it implements the IBannedUserPersister interface.");
            this.logger.error(composer.toString());
        }
        this.storage.init();
        try {
            final BanUserData storageData = this.storage.load();
            this.bannedUsersByIp = storageData.getBannedUsersByIp();
            this.bannedUsersByNameAndZone = storageData.getBannedUsersByNameAndZone();
            this.logger.info("BanUser data loaded: " + this.getTotalRecords() + " records.");
        }
        catch (Exception e) {
            this.bannedUsersByIp = new ConcurrentHashMap<String, BannedUser>();
            this.bannedUsersByNameAndZone = new ConcurrentHashMap<String, Map<String, BannedUser>>();
            if (e instanceof FileNotFoundException) {
                this.logger.info("No BannedUser data available, starting with a clean DB.");
            }
            else {
                this.logger.warn("Failure loading the BannedUser DB: " + e);
            }
        }
        this.sfs = SmartFoxServer.getInstance();
        this.sfs.getTaskScheduler().scheduleAtFixedRate(this.kickHistoryCleanerTask, 12, 12, TimeUnit.HOURS);
        this.sfs.getTaskScheduler().scheduleAtFixedRate(this.banExpirerTask, 2, 2, TimeUnit.HOURS);
        this.sfs.getTaskScheduler().scheduleAtFixedRate(this.banAutoSaverTask, 1, 1, TimeUnit.HOURS);
        Runtime.getRuntime().addShutdownHook(this.shutDownHandler);
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        this.storage.destroy();
    }
    
    @Override
    public void kickUser(final User userToKick, final User modUser, final String kickMessage, final int delaySeconds) {
        this.kickUser(userToKick, modUser, kickMessage, delaySeconds, false);
    }
    
    @Override
    public void kickUser(final User userToKick, User modUser, String kickMessage, final int delaySeconds, final boolean isBan) {
        if (userToKick.isBeingKicked()) {
            return;
        }
        userToKick.setBeingKicked(true);
        final IDisconnectionReason disconnectionReason = isBan ? ClientDisconnectionReason.BAN : ClientDisconnectionReason.KICK;
        this.addUserToKickHistory(userToKick);
        userToKick.setReconnectionSeconds(0);
        if (delaySeconds <= 0) {
            userToKick.disconnect(disconnectionReason);
            return;
        }
        if (kickMessage == null || kickMessage.length() == 0) {
            kickMessage = userToKick.getZone().getWordFilter().getKickMessage();
        }
        modUser = ((modUser == null) ? UsersUtil.getServerModerator() : modUser);
        this.sfs.getAPIManager().getSFSApi().sendModeratorMessage(modUser, kickMessage, null, Arrays.asList(userToKick.getSession()));
        final Task kickTask = new Task((Object)"kickTask");
        kickTask.getParameters().put("user", userToKick);
        this.sfs.getTaskScheduler().schedule(new KickTaskRunner(userToKick, disconnectionReason), delaySeconds, TimeUnit.SECONDS);
    }
    
    @Override
    public void banUser(final User userToBan, User modUser, final int durationMinutes, final BanMode mode, final String reason, String banMessage, final int delaySeconds) {
        modUser = ((modUser == null) ? UsersUtil.getServerModerator() : modUser);
        final BannedUser bannedUser = new SFSBannedUser(userToBan, durationMinutes, mode, reason, modUser.getName());
        this.addBannedUser(bannedUser);
        if (banMessage == null || banMessage.length() == 0) {
            banMessage = userToBan.getZone().getWordFilter().getBanMessage();
        }
        this.kickUser(userToBan, modUser, banMessage, delaySeconds, true);
        final String msg = String.format("User: %s is banned. Reason: %s", userToBan.getName(), reason);
        this.logger.info(msg);
    }
    
    @Override
    public void banUser(final String userName, final String zoneName, final int durationMinutes, final BanMode mode, final String reason, final String adminName) {
        final BannedUser bannedUser = new SFSBannedUser(userName, zoneName, durationMinutes, mode, reason, adminName);
        this.addBannedUser(bannedUser);
    }
    
    @Override
    public void banUser(final String userName, final String zoneName, final int durationMinutes, final BanMode mode, final String reason) {
        this.banUser(userName, zoneName, durationMinutes, mode, reason, null);
    }
    
    private void addBannedUser(final BannedUser banned) {
        final String zoneName = banned.getZoneName();
        final BanMode mode = banned.getMode();
        String banKey = null;
        Map<String, BannedUser> bannedUsersMap = null;
        if (mode == BanMode.BY_ADDRESS) {
            banKey = banned.getIpAddress();
            bannedUsersMap = this.bannedUsersByIp;
        }
        else {
            banKey = banned.getName();
            Map<String, BannedUser> bannedUsersByName = null;
            synchronized (this) {
                bannedUsersByName = this.bannedUsersByNameAndZone.get(zoneName);
                if (bannedUsersByName == null) {
                    bannedUsersByName = new ConcurrentHashMap<String, BannedUser>();
                    this.bannedUsersByNameAndZone.put(zoneName, bannedUsersByName);
                }
            }
            bannedUsersMap = bannedUsersByName;
        }
        bannedUsersMap.put(banKey, banned);
    }
    
    @Override
    public int getKickCount(final String name, final String zoneName, final int rangeInSeconds) {
        int kickCount = 0;
        final long timeRangeMillis = rangeInSeconds * 1000;
        final long rangeCheck = System.currentTimeMillis() - timeRangeMillis;
        final Map<String, List<Long>> kickHistory = this.kickHistoryByZone.get(zoneName);
        if (kickHistory != null) {
            final List<Long> kickTimeList = kickHistory.get(name);
            if (kickTimeList != null && kickTimeList.size() > 0) {
                for (final long kickTime : kickTimeList) {
                    if (kickTime > rangeCheck) {
                        ++kickCount;
                    }
                }
            }
        }
        return kickCount;
    }
    
    @Override
    public boolean isIpBanned(final String ipAddress) {
        boolean isBanned = false;
        final BannedUser bUser = this.bannedUsersByIp.get(ipAddress);
        if (bUser != null && !bUser.isExpired()) {
            isBanned = true;
        }
        return isBanned;
    }
    
    @Override
    public boolean isNameBanned(final String userName, final String zoneName) {
        final Map<String, BannedUser> bannedUsersByName = this.bannedUsersByNameAndZone.get(zoneName);
        boolean isBanned = false;
        if (bannedUsersByName != null) {
            final BannedUser bUser = bannedUsersByName.get(userName);
            if (bUser != null && !bUser.isExpired()) {
                isBanned = true;
            }
        }
        return isBanned;
    }
    
    @Override
    public void removeBannedUser(final String id, final String zoneName, final BanMode mode) {
        if (mode == BanMode.BY_ADDRESS) {
            this.bannedUsersByIp.remove(id);
        }
        else {
            final Map<String, BannedUser> bannedUsersByName = this.bannedUsersByNameAndZone.get(zoneName);
            if (bannedUsersByName != null) {
                bannedUsersByName.remove(id);
            }
        }
    }
    
    @Override
    public List<BannedUser> getBannedUsersByIp() {
        return new LinkedList<BannedUser>(this.bannedUsersByIp.values());
    }
    
    @Override
    public List<BannedUser> getBannedUsersByName(final String zoneName) {
        final Map<String, BannedUser> bannedUsersByName = this.bannedUsersByNameAndZone.get(zoneName);
        final List<BannedUser> theList = new LinkedList<BannedUser>();
        if (bannedUsersByName != null) {
            theList.addAll(bannedUsersByName.values());
        }
        return theList;
    }
    
    @Override
    public boolean isAutoRemoveBan() {
        return this.autoRemoveBan;
    }
    
    @Override
    public boolean isPersistent() {
        return this.persistent;
    }
    
    @Override
    public void setAutoRemoveBan(final boolean flag) {
        this.autoRemoveBan = flag;
    }
    
    @Override
    public void setPersistent(final boolean flag) {
        this.persistent = flag;
    }
    
    @Override
    public void setPersistenceClass(final String className) {
        if (this.active) {
            throw new SFSRuntimeException("Cannot change the BannedUserManager persistence class at runtime! Please change it in the configuration and restart the server.");
        }
        if (className != null && className.length() > 0) {
            SFSBannedUserManager.STORAGE_DEFAULT_CLASS = className;
        }
    }
    
    @Override
    public void sendWarningMessage(final User recipient, User senderMod, final String message) {
        if (senderMod == null) {
            senderMod = UsersUtil.getServerModerator();
        }
        this.sfs.getAPIManager().getSFSApi().sendModeratorMessage(senderMod, message, null, Arrays.asList(recipient.getSession()));
    }
    
    private void addUserToKickHistory(final User user) {
        final String zoneName = user.getZone().getName();
        Map<String, List<Long>> kickHistory = this.kickHistoryByZone.get(zoneName);
        if (kickHistory == null) {
            kickHistory = new ConcurrentHashMap<String, List<Long>>();
            this.kickHistoryByZone.put(zoneName, kickHistory);
        }
        List<Long> kickTimeList = kickHistory.get(user.getName());
        if (kickTimeList == null) {
            kickTimeList = new ArrayList<Long>();
            kickHistory.put(user.getName(), kickTimeList);
        }
        synchronized (kickTimeList) {
            kickTimeList.add(System.currentTimeMillis());
        }
    }
    
    private int getTotalRecords() {
        int tot = this.bannedUsersByIp.size();
        for (final Map<String, BannedUser> map : this.bannedUsersByNameAndZone.values()) {
            tot += map.size();
        }
        return tot;
    }
    
    private final class KickHistoryCleanerTask implements Runnable
    {
        @Override
        public void run() {
            if (SFSBannedUserManager.this.logger.isDebugEnabled()) {
                SFSBannedUserManager.this.logger.debug("KickCleanerTask running");
            }
            try {
                final long timeRange = System.currentTimeMillis() - 86400000L;
                for (final Map<String, List<Long>> kickHistory : SFSBannedUserManager.this.kickHistoryByZone.values()) {
                    final Iterator<List<Long>> iter = kickHistory.values().iterator();
                    while (iter.hasNext()) {
                        final List<Long> kickTimeList = iter.next();
                        if (kickTimeList.size() > 0) {
                            synchronized (kickTimeList) {
                                final Iterator<Long> iter2 = kickTimeList.iterator();
                                while (iter2.hasNext()) {
                                    final long kickTime = iter2.next();
                                    if (kickTime < timeRange) {
                                        iter2.remove();
                                    }
                                }
                                if (kickTimeList.size() == 0) {
                                    iter.remove();
                                }
                            }
                            // monitorexit(kickTimeList)
                        }
                    }
                }
            }
            catch (Exception e) {
                SFSBannedUserManager.this.logger.warn("Unexpected exception: " + e);
            }
        }
    }
    
    private final class BanExpirerTask implements Runnable
    {
        @Override
        public void run() {
            try {
                if (SFSBannedUserManager.this.logger.isDebugEnabled()) {
                    SFSBannedUserManager.this.logger.debug("BanExpirer running");
                }
                this.cleanExpiredBanByIP();
                this.cleanExpiredBanByName();
            }
            catch (Exception err) {
                SFSBannedUserManager.this.logger.warn("Problem in BanExpirer iteration: " + err);
            }
        }
        
        private void cleanExpiredBanByIP() {
            final int removedItems = this.expirerLoop(SFSBannedUserManager.this.bannedUsersByIp);
            if (removedItems > 0) {
                SFSBannedUserManager.this.logger.debug("Removed " + removedItems + " expired banned users by IP");
            }
        }
        
        private void cleanExpiredBanByName() {
            int removedItems = 0;
            for (final Map<String, BannedUser> bannedUsersByZone : SFSBannedUserManager.this.bannedUsersByNameAndZone.values()) {
                removedItems += this.expirerLoop(bannedUsersByZone);
            }
            if (removedItems > 0) {
                SFSBannedUserManager.this.logger.debug("Removed " + removedItems + " expired banned users by name ");
            }
        }
        
        private int expirerLoop(final Map<String, BannedUser> data) {
            int count = 0;
            for (final Map.Entry<String, BannedUser> entry : data.entrySet()) {
                final BannedUser bUser = entry.getValue();
                if (bUser.isExpired()) {
                    data.remove(entry.getKey());
                    ++count;
                }
            }
            return count;
        }
    }
    
    private final class BanDataAutoSaveTask implements Runnable
    {
        @Override
        public void run() {
            try {
                final long t1 = System.currentTimeMillis();
                SFSBannedUserManager.this.storage.save(new BanUserData(SFSBannedUserManager.this.bannedUsersByNameAndZone, SFSBannedUserManager.this.bannedUsersByIp));
                if (SFSBannedUserManager.this.logger.isDebugEnabled()) {
                    SFSBannedUserManager.this.logger.debug("Ban User data autosave done in " + (System.currentTimeMillis() - t1) + "ms.");
                }
            }
            catch (Exception e) {
                SFSBannedUserManager.this.logger.warn("Banned User Data auto-save failed: " + e);
            }
        }
    }
    
    private final class ShutDownHandler extends Thread
    {
        @Override
        public void run() {
            try {
                SFSBannedUserManager.this.storage.save(new BanUserData(SFSBannedUserManager.this.bannedUsersByNameAndZone, SFSBannedUserManager.this.bannedUsersByIp));
                SFSBannedUserManager.this.logger.info("BanUser data saved.");
            }
            catch (IOException e) {
                SFSBannedUserManager.this.logger.warn("Failed saving BanUserData on server quit: " + e);
            }
        }
    }
    
    static final class KickTaskRunner implements Runnable
    {
        private final User target;
        private final IDisconnectionReason reason;
        
        public KickTaskRunner(final User target, final IDisconnectionReason reason) {
            this.target = target;
            this.reason = reason;
        }
        
        @Override
        public void run() {
            if (this.target != null) {
                this.target.disconnect(this.reason);
            }
        }
    }
}

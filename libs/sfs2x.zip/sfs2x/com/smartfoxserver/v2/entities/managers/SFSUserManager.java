// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.api.ISFSApi;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import com.smartfoxserver.v2.util.ClientDisconnectionReason;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.entities.User;
import java.util.concurrent.ConcurrentMap;
import com.smartfoxserver.v2.core.BaseCoreService;

public final class SFSUserManager extends BaseCoreService implements IUserManager
{
    private final ConcurrentMap<String, User> usersByName;
    private final ConcurrentMap<ISession, User> usersBySession;
    private final ConcurrentMap<Integer, User> usersById;
    private Room ownerRoom;
    private Zone ownerZone;
    private Logger logger;
    private int highestCCU;
    
    public SFSUserManager() {
        this.highestCCU = 0;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.usersBySession = new ConcurrentHashMap<ISession, User>();
        this.usersByName = new ConcurrentHashMap<String, User>();
        this.usersById = new ConcurrentHashMap<Integer, User>();
        this.name = "UserManagerService";
        this.active = true;
    }
    
    @Override
    public void addUser(final User user) {
        if (this.containsId(user.getId())) {
            throw new SFSRuntimeException("Can't add User: " + user.getName() + " - Already exists in Room: " + this.ownerRoom + ", Zone: " + this.ownerZone);
        }
        this.usersById.put(user.getId(), user);
        this.usersByName.put(user.getName(), user);
        this.usersBySession.put(user.getSession(), user);
        if (this.usersById.size() > this.highestCCU) {
            this.highestCCU = this.usersById.size();
        }
    }
    
    @Override
    public User getUserById(final int id) {
        return this.usersById.get(id);
    }
    
    @Override
    public User getUserByName(final String name) {
        return this.usersByName.get(name);
    }
    
    @Override
    public User getUserBySession(final ISession session) {
        return this.usersBySession.get(session);
    }
    
    @Override
    public void removeUser(final int userId) {
        final User user = this.usersById.get(userId);
        if (user == null) {
            this.logger.warn("Can't remove user with ID: " + userId + ". User was not found.");
        }
        else {
            this.removeUser(user);
        }
    }
    
    @Override
    public void removeUser(final String name) {
        final User user = this.usersByName.get(name);
        if (user == null) {
            this.logger.warn("Can't remove user with name: " + name + ". User was not found.");
        }
        else {
            this.removeUser(user);
        }
    }
    
    @Override
    public void removeUser(final ISession session) {
        final User user = this.usersBySession.get(session);
        if (user == null) {
            throw new SFSRuntimeException("Can't remove user with session: " + session + ". User was not found.");
        }
        this.removeUser(user);
    }
    
    @Override
    public void removeUser(final User user) {
        this.usersById.remove(user.getId());
        this.usersByName.remove(user.getName());
        this.usersBySession.remove(user.getSession());
    }
    
    @Override
    public boolean containsId(final int userId) {
        return this.usersById.containsKey(userId);
    }
    
    @Override
    public boolean containsName(final String name) {
        return this.usersByName.containsKey(name);
    }
    
    @Override
    public boolean containsSessions(final ISession session) {
        return this.usersBySession.containsKey(session);
    }
    
    @Override
    public boolean containsUser(final User user) {
        return this.usersById.containsValue(user);
    }
    
    @Override
    public Room getOwnerRoom() {
        return this.ownerRoom;
    }
    
    @Override
    public void setOwnerRoom(final Room ownerRoom) {
        this.ownerRoom = ownerRoom;
    }
    
    @Override
    public Zone getOwnerZone() {
        return this.ownerZone;
    }
    
    @Override
    public void setOwnerZone(final Zone ownerZone) {
        this.ownerZone = ownerZone;
    }
    
    @Override
    public List<User> getAllUsers() {
        return new ArrayList<User>(this.usersById.values());
    }
    
    @Override
    public List<ISession> getAllSessions() {
        return new ArrayList<ISession>((Collection<? extends ISession>)this.usersBySession.keySet());
    }
    
    @Override
    public Collection<User> getDirectUserList() {
        return Collections.unmodifiableCollection(this.usersById.values());
    }
    
    @Override
    public Collection<ISession> getDirectSessionList() {
        return Collections.unmodifiableCollection((Collection<? extends ISession>)this.usersBySession.keySet());
    }
    
    @Override
    public int getUserCount() {
        return this.usersById.values().size();
    }
    
    @Override
    public int getNPCCount() {
        int npcCount = 0;
        for (final User user : this.usersById.values()) {
            if (user.isNpc()) {
                ++npcCount;
            }
        }
        return npcCount;
    }
    
    @Override
    public void disconnectUser(final int userId) {
        final User user = this.usersById.get(userId);
        if (user == null) {
            this.logger.warn("Can't disconnect user with id: " + userId + ". User was not found.");
        }
        else {
            this.disconnectUser(user);
        }
    }
    
    @Override
    public void disconnectUser(final ISession session) {
        final User user = this.usersBySession.get(session);
        if (user == null) {
            this.logger.warn("Can't disconnect user with session: " + session + ". User was not found.");
        }
        else {
            this.disconnectUser(user);
        }
    }
    
    @Override
    public void disconnectUser(final String name) {
        final User user = this.usersByName.get(name);
        if (user == null) {
            this.logger.warn("Can't disconnect user with name: " + name + ". User was not found.");
        }
        else {
            this.disconnectUser(user);
        }
    }
    
    @Override
    public void disconnectUser(final User user) {
        this.removeUser(user);
    }
    
    @Override
    public int getHighestCCU() {
        return this.highestCCU;
    }
    
    @Override
    public List<ISession> sessionsFromNames(final List<String> names) {
        final List<ISession> sessions = new LinkedList<ISession>();
        for (final String name : names) {
            final User user = this.getUserByName(name);
            if (user != null) {
                sessions.add(user.getSession());
            }
        }
        return sessions;
    }
    
    public void purgeOrphanedUsers() {
        final ISessionManager mgr = SmartFoxServer.getInstance().getSessionManager();
        final ISFSApi api = SmartFoxServer.getInstance().getAPIManager().getSFSApi();
        int tot = 0;
        for (final ISession session : this.usersBySession.keySet()) {
            if (!mgr.containsSession(session)) {
                final User evictable = this.usersBySession.get(session);
                api.disconnectUser(evictable, ClientDisconnectionReason.KICK);
                ++tot;
            }
        }
        this.logger.info("Evicted " + tot + " users.");
    }
    
    private String getOwnerDetails() {
        final StringBuilder sb = new StringBuilder();
        if (this.ownerZone != null) {
            sb.append("Zone: ").append(this.ownerZone.getName());
        }
        else if (this.ownerRoom != null) {
            sb.append("Zone: ").append(this.ownerRoom.getZone().getName()).append("Room: ").append(this.ownerRoom.getName()).append(", Room Id: ").append(this.ownerRoom.getId());
        }
        return sb.toString();
    }
}

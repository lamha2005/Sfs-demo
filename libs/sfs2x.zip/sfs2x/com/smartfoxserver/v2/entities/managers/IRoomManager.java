// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.util.IPlayerIdGenerator;
import java.util.List;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.core.ICoreService;

public interface IRoomManager extends ICoreService
{
    void addRoom(final Room p0);
    
    Room createRoom(final CreateRoomSettings p0) throws SFSCreateRoomException;
    
    Room createRoom(final CreateRoomSettings p0, final User p1) throws SFSCreateRoomException;
    
    List<String> getGroups();
    
    void addGroup(final String p0);
    
    void removeGroup(final String p0);
    
    boolean containsGroup(final String p0);
    
    boolean containsRoom(final int p0);
    
    boolean containsRoom(final String p0);
    
    boolean containsRoom(final Room p0);
    
    boolean containsRoom(final int p0, final String p1);
    
    boolean containsRoom(final String p0, final String p1);
    
    boolean containsRoom(final Room p0, final String p1);
    
    Room getRoomById(final int p0);
    
    Room getRoomByName(final String p0);
    
    List<Room> getRoomList();
    
    List<Room> getRoomListFromGroup(final String p0);
    
    int getGameRoomCount();
    
    int getTotalRoomCount();
    
    void setDefaultRoomPlayerIdGeneratorClass(final Class<? extends IPlayerIdGenerator> p0);
    
    Class<? extends IPlayerIdGenerator> getDefaultRoomPlayerIdGenerator();
    
    void checkAndRemove(final Room p0);
    
    void removeRoom(final Room p0);
    
    void removeRoom(final int p0);
    
    void removeRoom(final String p0);
    
    Zone getOwnerZone();
    
    void setOwnerZone(final Zone p0);
    
    void removeUser(final User p0);
    
    void removeUser(final User p0, final Room p1);
    
    void changeRoomName(final Room p0, final String p1) throws SFSRoomException;
    
    void changeRoomPasswordState(final Room p0, final String p1);
    
    void changeRoomCapacity(final Room p0, final int p1, final int p2);
}

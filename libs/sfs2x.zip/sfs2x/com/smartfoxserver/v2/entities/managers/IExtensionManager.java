// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.ISFSEventListener;
import com.smartfoxserver.v2.core.SFSEventType;
import java.util.List;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.exceptions.SFSExtensionException;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.extensions.ExtensionLevel;
import com.smartfoxserver.v2.config.ZoneSettings;

public interface IExtensionManager
{
    void createExtension(final ZoneSettings.ExtensionSettings p0, final ExtensionLevel p1, final Zone p2, final Room p3) throws SFSExtensionException;
    
    void destroyExtension(final ISFSExtension p0);
    
    void addExtension(final ISFSExtension p0);
    
    ISFSExtension getRoomExtension(final Room p0);
    
    ISFSExtension getZoneExtension(final Zone p0);
    
    int getExtensionsCount();
    
    List<ISFSExtension> getExtensions();
    
    void init();
    
    void destroy();
    
    void activateAllExtensions();
    
    void deactivateAllExtensions();
    
    void reloadExtension(final ISFSExtension p0);
    
    void reloadRoomExtension(final String p0, final Room p1);
    
    void reloadZoneExtension(final String p0, final Zone p1);
    
    void addZoneEventListener(final SFSEventType p0, final ISFSEventListener p1, final Zone p2);
    
    void addRoomEventListener(final SFSEventType p0, final ISFSEventListener p1, final Room p2);
    
    void removeZoneEventListener(final SFSEventType p0, final ISFSEventListener p1, final Zone p2);
    
    void removeRoomEventListener(final SFSEventType p0, final ISFSEventListener p1, final Room p2);
    
    void removeListenerFromZone(final ISFSEventListener p0, final Zone p1);
    
    void removeListenerFromRoom(final ISFSEventListener p0, final Room p1);
    
    void dispatchEvent(final ISFSEvent p0, final ExtensionLevel p1);
    
    boolean isExtensionMonitorActive();
    
    void setExtensionMonitorActive(final boolean p0);
}

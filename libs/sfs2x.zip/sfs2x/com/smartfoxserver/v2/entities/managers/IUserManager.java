// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import java.util.Collection;
import java.util.List;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.core.ICoreService;

public interface IUserManager extends ICoreService
{
    User getUserByName(final String p0);
    
    User getUserById(final int p0);
    
    User getUserBySession(final ISession p0);
    
    List<User> getAllUsers();
    
    Collection<User> getDirectUserList();
    
    List<ISession> getAllSessions();
    
    Collection<ISession> getDirectSessionList();
    
    void addUser(final User p0);
    
    void removeUser(final User p0);
    
    void removeUser(final String p0);
    
    void removeUser(final int p0);
    
    void removeUser(final ISession p0);
    
    void disconnectUser(final User p0);
    
    void disconnectUser(final String p0);
    
    void disconnectUser(final int p0);
    
    void disconnectUser(final ISession p0);
    
    boolean containsId(final int p0);
    
    boolean containsName(final String p0);
    
    boolean containsSessions(final ISession p0);
    
    boolean containsUser(final User p0);
    
    Zone getOwnerZone();
    
    void setOwnerZone(final Zone p0);
    
    Room getOwnerRoom();
    
    void setOwnerRoom(final Room p0);
    
    int getUserCount();
    
    int getNPCCount();
    
    int getHighestCCU();
    
    List<ISession> sessionsFromNames(final List<String> p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.User;
import java.util.Iterator;
import java.util.List;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.concurrent.TimeUnit;
import com.smartfoxserver.v2.util.stats.NetworkTrafficMeter;
import com.smartfoxserver.v2.util.stats.TrafficType;
import com.smartfoxserver.v2.util.stats.SFSTrafficStats;
import java.util.concurrent.ScheduledFuture;
import com.smartfoxserver.v2.util.stats.ITrafficStats;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.v2.util.stats.INetworkTrafficMeter;

public class SFSStatsManager implements IStatsManager
{
    private INetworkTrafficMeter inMeter;
    private INetworkTrafficMeter outMeter;
    private BitSwarmEngine engine;
    private SmartFoxServer sfs;
    private NetworkStatsExecutor statsExecutor;
    private ITrafficStats trafficStats;
    private ScheduledFuture<?> taskControl;
    
    public void init(final Object o) {
        this.engine = BitSwarmEngine.getInstance();
        this.sfs = SmartFoxServer.getInstance();
        this.trafficStats = new SFSTrafficStats();
        this.inMeter = new NetworkTrafficMeter(TrafficType.INCOMING);
        this.outMeter = new NetworkTrafficMeter(TrafficType.OUTGOING);
        this.statsExecutor = new NetworkStatsExecutor();
        this.taskControl = this.sfs.getTaskScheduler().scheduleAtFixedRate(this.statsExecutor, 0, 1, TimeUnit.MINUTES);
    }
    
    public void destroy(final Object o) {
        this.taskControl.cancel(true);
    }
    
    @Override
    public ITrafficStats getTrafficStats() {
        return this.trafficStats;
    }
    
    @Override
    public long getTotalInPackets() {
        return this.trafficStats.getReadPackets();
    }
    
    @Override
    public long getTotalOutPackets() {
        return this.trafficStats.getWrittenPackets();
    }
    
    @Override
    public long getTotalInBytes() {
        return this.trafficStats.getReadBytes();
    }
    
    @Override
    public long getTotalOutBytes() {
        return this.trafficStats.getWrittenBytes();
    }
    
    @Override
    public long getTotalOutgoingDroppedPackets() {
        return this.engine.getSocketWriter().getDroppedPacketsCount();
    }
    
    @Override
    public INetworkTrafficMeter getIncomingTrafficMeter() {
        return this.inMeter;
    }
    
    @Override
    public INetworkTrafficMeter getOutgoingTrafficMeter() {
        return this.outMeter;
    }
    
    @Override
    public long getTotalIncomingDroppedPackets() {
        return this.engine.getSocketReader().getIOHandler().getIncomingDroppedPackets();
    }
    
    @Override
    public ConnectionStats getSessionStats() {
        final List<ISession> allSessions = (List<ISession>)this.sfs.getSessionManager().getAllLocalSessions();
        int socketCount = 0;
        final int npcCount = 0;
        int bboxCount = 0;
        int wsCount = 0;
        for (final ISession session : allSessions) {
            if (session.getType() == SessionType.BLUEBOX) {
                ++bboxCount;
            }
            else if (session.getType() == SessionType.WEBSOCKET) {
                ++wsCount;
            }
            else {
                ++socketCount;
            }
        }
        return new ConnectionStats(socketCount + wsCount, npcCount, bboxCount, wsCount);
    }
    
    @Override
    public ConnectionStats getUserStats() {
        final List<User> allUsers = this.sfs.getUserManager().getAllUsers();
        int socketCount = 0;
        int npcCount = 0;
        int bboxCount = 0;
        int wsCount = 0;
        for (final User user : allUsers) {
            if (!user.isLocal()) {
                continue;
            }
            if (user.isNpc()) {
                ++npcCount;
            }
            else {
                final SessionType type = user.getSession().getType();
                if (type == SessionType.BLUEBOX) {
                    ++bboxCount;
                }
                else if (type == SessionType.WEBSOCKET) {
                    ++wsCount;
                }
                else {
                    ++socketCount;
                }
            }
        }
        return new ConnectionStats(socketCount + wsCount, npcCount, bboxCount, wsCount);
    }
    
    @Override
    public boolean isActive() {
        return true;
    }
    
    public String getName() {
        return "StatsManager Service";
    }
    
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException("Not available");
    }
    
    public void setName(final String name) {
        throw new UnsupportedOperationException("Not available");
    }
    
    private class NetworkStatsExecutor implements Runnable
    {
        private final Logger log;
        
        public NetworkStatsExecutor() {
            this.log = LoggerFactory.getLogger((Class)NetworkStatsExecutor.class);
        }
        
        @Override
        public void run() {
            try {
                SFSStatsManager.this.inMeter.onTick();
                SFSStatsManager.this.outMeter.onTick();
            }
            catch (Exception e) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
                emc.setDescription("Unexpected exception, NetworkStatsExecutor will retry on next cycle.");
                this.log.warn(emc.toString());
            }
        }
    }
}

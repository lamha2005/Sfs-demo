// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import java.util.Hashtable;
import javax.mail.Transport;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.mail.Message;
import java.util.Date;
import javax.mail.Address;
import java.util.ArrayList;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.MessagingException;
import com.smartfoxserver.v2.entities.Email;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import javax.mail.PasswordAuthentication;
import javax.mail.Authenticator;
import java.util.Properties;
import org.slf4j.LoggerFactory;
import javax.mail.Session;
import org.slf4j.Logger;
import java.util.concurrent.ScheduledExecutorService;
import com.smartfoxserver.v2.config.MailerSettings;

public class SFSPostOffice implements IMailerService
{
    private static final String MAIL_PROTOCOL = "smtp";
    private static final String ADDRESS_SEPARATOR = ",";
    private MailerSettings config;
    private ScheduledExecutorService executor;
    private final Logger logger;
    private Session session;
    
    public SFSPostOffice() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    public void init(final Object o) {
        if (o == null || !(o instanceof MailerSettings)) {
            throw new IllegalArgumentException("Invalid MailerServer configuration.");
        }
        this.logger.info("PostOffice service started");
        this.config = (MailerSettings)o;
        final Properties props = new Properties();
        props.setProperty("mail.transport.protocol", "smtp");
        props.setProperty("mail.host", this.config.mailHost);
        props.setProperty("mail.user", this.config.mailUser);
        props.setProperty("mail.password", this.config.mailPass);
        props.setProperty("mail.smtp.port", String.valueOf(this.config.smtpPort));
        props.setProperty("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.starttls.enable", "true");
        Authenticator passAuth = null;
        if (this.config.smtpPort == 465) {
            ((Hashtable<String, String>)props).put("mail.smtp.socketFactory.port", "465");
            ((Hashtable<String, String>)props).put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            passAuth = new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SFSPostOffice.this.config.mailUser, SFSPostOffice.this.config.mailPass);
                }
            };
        }
        this.session = Session.getDefaultInstance(props, passAuth);
        this.executor = new ScheduledThreadPoolExecutor(this.config.workerThreads);
    }
    
    public void destroy(final Object o) {
        this.executor.shutdownNow();
    }
    
    public String getName() {
        return "SFSPostOffice";
    }
    
    @Override
    public MailerSettings getConfiguration() {
        return this.config;
    }
    
    @Override
    public void sendMail(final Email email, final IMailerCallbackHandler callBack) throws MessagingException {
        this.sendMail(email, callBack, 0);
    }
    
    @Override
    public void sendMail(final Email email) throws MessagingException {
        this.sendMail(email, null, 0);
    }
    
    @Override
    public void sendMail(final Email email, final IMailerCallbackHandler callBack, final int delaySeconds) throws MessagingException {
        final MimeMessage message = new MimeMessage(this.session);
        message.setContent((Object)email.getMessage(), "text/html; charset=utf-8");
        if (email.getPriority() > 0) {
            message.setHeader("X-Priority", String.valueOf(email.getPriority()));
        }
        message.setSubject(email.getSubject(), "utf-8");
        final Address fromAddress = (Address)new InternetAddress(email.getFromAddress());
        final List<Address> recipients = new ArrayList<Address>();
        if (email.getToAddress().indexOf(",") != -1) {
            final String[] toAddresses = email.getToAddress().split("\\,");
            String[] array;
            for (int length = (array = toAddresses).length, i = 0; i < length; ++i) {
                final String item = array[i];
                recipients.add((Address)new InternetAddress(item));
            }
        }
        else {
            recipients.add((Address)new InternetAddress(email.getToAddress()));
        }
        message.setSentDate(new Date());
        message.setFrom(fromAddress);
        for (final Address addr : recipients) {
            message.addRecipient(Message.RecipientType.TO, addr);
        }
        this.executor.schedule(new MailDelivery(message, email, callBack), delaySeconds, TimeUnit.SECONDS);
    }
    
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException("Not supported by this service!");
    }
    
    public void setName(final String name) {
        throw new UnsupportedOperationException("Not supported by this service!");
    }
    
    private final class MailDelivery implements Runnable
    {
        final Email email;
        final IMailerCallbackHandler handler;
        final MimeMessage message;
        
        public MailDelivery(final MimeMessage message, final Email email, final IMailerCallbackHandler handler) {
            this.email = email;
            this.handler = handler;
            this.message = message;
        }
        
        @Override
        public void run() {
            try {
                final Transport smtp = SFSPostOffice.this.session.getTransport("smtp");
                smtp.connect(SFSPostOffice.this.config.mailHost, SFSPostOffice.this.config.smtpPort, SFSPostOffice.this.config.mailUser, SFSPostOffice.this.config.mailPass);
                smtp.sendMessage((Message)this.message, this.message.getAllRecipients());
                smtp.close();
                this.handler.onSuccess(this.email);
            }
            catch (Exception e) {
                this.handler.onError(this.email, e);
                SFSPostOffice.this.logger.warn(String.format("Failed sending email: %s, %s", this.email, e));
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

public class ConnectionStats
{
    private final int socketSessionCount;
    private final int npcSessionCount;
    private final int tunnelledSessionCount;
    private final int webSocketSessionCount;
    
    public ConnectionStats(final int socketSessionCount, final int npcSessionCount, final int tunnelledSessionCount, final int wesbSocketSessionCount) {
        this.socketSessionCount = socketSessionCount;
        this.npcSessionCount = npcSessionCount;
        this.tunnelledSessionCount = tunnelledSessionCount;
        this.webSocketSessionCount = wesbSocketSessionCount;
    }
    
    public int getSocketCount() {
        return this.socketSessionCount;
    }
    
    public int getNpcCount() {
        return this.npcSessionCount;
    }
    
    public int getTunnelledCount() {
        return this.tunnelledSessionCount;
    }
    
    public int getWebSocketSessionCount() {
        return this.webSocketSessionCount;
    }
}

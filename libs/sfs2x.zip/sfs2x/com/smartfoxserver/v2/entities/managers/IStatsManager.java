// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.util.stats.ITrafficStats;
import com.smartfoxserver.v2.util.stats.INetworkTrafficMeter;
import com.smartfoxserver.v2.core.ICoreService;

public interface IStatsManager extends ICoreService
{
    long getTotalOutBytes();
    
    long getTotalInBytes();
    
    long getTotalOutPackets();
    
    long getTotalInPackets();
    
    long getTotalOutgoingDroppedPackets();
    
    long getTotalIncomingDroppedPackets();
    
    INetworkTrafficMeter getIncomingTrafficMeter();
    
    INetworkTrafficMeter getOutgoingTrafficMeter();
    
    ConnectionStats getSessionStats();
    
    ConnectionStats getUserStats();
    
    ITrafficStats getTrafficStats();
}

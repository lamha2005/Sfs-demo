// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

public enum BanMode
{
    BY_ADDRESS("BY_ADDRESS", 0, 0), 
    BY_NAME("BY_NAME", 1, 1);
    
    private int id;
    
    private BanMode(final String s, final int n, final int id) {
        this.id = id;
    }
    
    public static BanMode fromId(final int id) {
        if (id == 0) {
            return BanMode.BY_ADDRESS;
        }
        return BanMode.BY_NAME;
    }
    
    public static BanMode fromString(final String id) {
        BanMode mode = BanMode.BY_NAME;
        if (id.equalsIgnoreCase("ip")) {
            mode = BanMode.BY_ADDRESS;
        }
        return mode;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.core.ICoreService;

public interface ILSManager extends ICoreService
{
    Object execute(final String p0, final Object p1) throws SFSException;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import java.io.IOException;

public interface IBannedUserStorage
{
    void init();
    
    void destroy();
    
    BanUserData load() throws Exception;
    
    void save(final BanUserData p0) throws IOException;
}

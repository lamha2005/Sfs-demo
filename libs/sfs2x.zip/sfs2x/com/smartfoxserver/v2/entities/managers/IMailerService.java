// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.config.MailerSettings;
import javax.mail.MessagingException;
import com.smartfoxserver.v2.entities.Email;
import com.smartfoxserver.bitswarm.service.IService;

public interface IMailerService extends IService
{
    void sendMail(final Email p0) throws MessagingException;
    
    void sendMail(final Email p0, final IMailerCallbackHandler p1) throws MessagingException;
    
    void sendMail(final Email p0, final IMailerCallbackHandler p1, final int p2) throws MessagingException;
    
    MailerSettings getConfiguration();
}

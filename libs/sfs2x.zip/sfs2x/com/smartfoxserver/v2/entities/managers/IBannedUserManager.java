// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.entities.BannedUser;
import java.util.List;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.core.ICoreService;

public interface IBannedUserManager extends ICoreService
{
    boolean isAutoRemoveBan();
    
    void setAutoRemoveBan(final boolean p0);
    
    boolean isPersistent();
    
    void setPersistent(final boolean p0);
    
    void setPersistenceClass(final String p0);
    
    void kickUser(final User p0, final User p1, final String p2, final int p3);
    
    void kickUser(final User p0, final User p1, final String p2, final int p3, final boolean p4);
    
    void banUser(final User p0, final User p1, final int p2, final BanMode p3, final String p4, final String p5, final int p6);
    
    void banUser(final String p0, final String p1, final int p2, final BanMode p3, final String p4);
    
    void banUser(final String p0, final String p1, final int p2, final BanMode p3, final String p4, final String p5);
    
    void sendWarningMessage(final User p0, final User p1, final String p2);
    
    int getKickCount(final String p0, final String p1, final int p2);
    
    boolean isNameBanned(final String p0, final String p1);
    
    boolean isIpBanned(final String p0);
    
    void removeBannedUser(final String p0, final String p1, final BanMode p2);
    
    List<BannedUser> getBannedUsersByIp();
    
    List<BannedUser> getBannedUsersByName(final String p0);
}

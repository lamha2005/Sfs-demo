// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities.managers;

import com.smartfoxserver.v2.entities.Email;

public interface IMailerCallbackHandler
{
    void onError(final Email p0, final Exception p1);
    
    void onSuccess(final Email p0);
}

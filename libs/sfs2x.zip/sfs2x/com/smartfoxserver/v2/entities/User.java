// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import java.util.Set;
import com.smartfoxserver.v2.util.Country;
import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.mmo.BaseMMOItem;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.exceptions.SFSVariableException;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import java.util.Map;
import java.util.List;
import com.smartfoxserver.v2.buddylist.BuddyProperties;
import com.smartfoxserver.bitswarm.sessions.ISession;

public interface User
{
    int getId();
    
    ISession getSession();
    
    String getIpAddress();
    
    String getName();
    
    BuddyProperties getBuddyProperties();
    
    void setName(final String p0);
    
    boolean isLocal();
    
    boolean isNpc();
    
    long getLoginTime();
    
    void setLastLoginTime(final long p0);
    
    Room getLastJoinedRoom();
    
    List<Room> getJoinedRooms();
    
    void addJoinedRoom(final Room p0);
    
    void removeJoinedRoom(final Room p0);
    
    boolean isJoinedInRoom(final Room p0);
    
    void addCreatedRoom(final Room p0);
    
    void removeCreatedRoom(final Room p0);
    
    List<Room> getCreatedRooms();
    
    void subscribeGroup(final String p0);
    
    void unsubscribeGroup(final String p0);
    
    List<String> getSubscribedGroups();
    
    boolean isSubscribedToGroup(final String p0);
    
    Zone getZone();
    
    void setZone(final Zone p0);
    
    int getPlayerId();
    
    int getPlayerId(final Room p0);
    
    void setPlayerId(final int p0, final Room p1);
    
    Map<Room, Integer> getPlayerIds();
    
    boolean isPlayer();
    
    boolean isSpectator();
    
    boolean isPlayer(final Room p0);
    
    boolean isSpectator(final Room p0);
    
    boolean isJoining();
    
    void setJoining(final boolean p0);
    
    boolean isConnected();
    
    void setConnected(final boolean p0);
    
    boolean isSuperUser();
    
    int getMaxAllowedVariables();
    
    void setMaxAllowedVariables(final int p0);
    
    Object getProperty(final Object p0);
    
    void setProperty(final Object p0, final Object p1);
    
    boolean containsProperty(final Object p0);
    
    void removeProperty(final Object p0);
    
    int getOwnedRoomsCount();
    
    boolean isBeingKicked();
    
    void setBeingKicked(final boolean p0);
    
    short getPrivilegeId();
    
    void setPrivilegeId(final short p0);
    
    UserVariable getVariable(final String p0);
    
    List<UserVariable> getVariables();
    
    void setVariable(final UserVariable p0) throws SFSVariableException;
    
    void setVariables(final List<UserVariable> p0) throws SFSVariableException;
    
    void removeVariable(final String p0);
    
    boolean containsVariable(final String p0);
    
    int getVariablesCount();
    
    int getBadWordsWarnings();
    
    void setBadWordsWarnings(final int p0);
    
    int getFloodWarnings();
    
    void setFloodWarnings(final int p0);
    
    long getLastRequestTime();
    
    void setLastRequestTime(final long p0);
    
    void updateLastRequestTime();
    
    ISFSArray getUserVariablesData();
    
    ISFSArray toSFSArray(final Room p0);
    
    ISFSArray toSFSArray();
    
    void disconnect(final IDisconnectionReason p0);
    
    String getDump();
    
    int getReconnectionSeconds();
    
    void setReconnectionSeconds(final int p0);
    
    List<User> getLastProxyList();
    
    void setLastProxyList(final List<User> p0);
    
    List<BaseMMOItem> getLastMMOItemsList();
    
    void setLastMMOItemsList(final List<BaseMMOItem> p0);
    
    MMORoom getCurrentMMORoom();
    
    Country getCountry();
    
    void addPersistentRoomVarReference(final Room p0);
    
    Set<Integer> getPersistentRoomVarReferences();
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.entities.variables.VariableType;
import com.smartfoxserver.v2.exceptions.SFSVariableException;
import java.util.Collection;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import com.smartfoxserver.v2.entities.managers.SFSUserManager;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.util.IAdminHelper;
import org.slf4j.Logger;
import java.util.Set;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import com.smartfoxserver.v2.util.IPlayerIdGenerator;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.entities.managers.IUserManager;
import java.util.concurrent.atomic.AtomicInteger;

public class SFSRoom implements Room
{
    private static AtomicInteger autoID;
    private int id;
    private String groupId;
    private String name;
    private String password;
    private boolean passwordProtected;
    private int maxUsers;
    private int maxSpectators;
    private int maxRoomVariablesAllowed;
    private User owner;
    private IUserManager userManager;
    private Zone zone;
    private volatile ISFSExtension extension;
    private boolean dynamic;
    private boolean game;
    private boolean hidden;
    private volatile boolean active;
    private SFSRoomRemoveMode autoRemoveMode;
    private IPlayerIdGenerator playerIdGenerator;
    private final long lifeTime;
    private final Lock switchUserLock;
    private final Map<Object, Object> properties;
    private final Map<String, RoomVariable> variables;
    private Set<SFSRoomSettings> flags;
    private volatile boolean userWordsFilter;
    protected Logger logger;
    private boolean isGameFlagInited;
    private IAdminHelper adminHelper;
    private boolean allowOwnerInvitation;
    
    static {
        SFSRoom.autoID = new AtomicInteger(0);
    }
    
    private static int getNewID() {
        return SFSRoom.autoID.getAndIncrement();
    }
    
    public SFSRoom(final String name) {
        this(name, null);
    }
    
    public SFSRoom(final String name, final Class<?> customPlayerIdGeneratorClass) {
        this.isGameFlagInited = false;
        this.allowOwnerInvitation = true;
        this.id = getNewID();
        this.name = name;
        this.active = false;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.properties = new ConcurrentHashMap<Object, Object>();
        this.variables = new ConcurrentHashMap<String, RoomVariable>();
        this.userManager = new SFSUserManager();
        this.switchUserLock = new ReentrantLock();
        this.lifeTime = System.currentTimeMillis();
    }
    
    @Override
    public int getId() {
        return this.id;
    }
    
    @Override
    public String getGroupId() {
        if (this.groupId != null && this.groupId.length() > 0) {
            return this.groupId;
        }
        return "default";
    }
    
    @Override
    public void setGroupId(final String groupId) {
        this.groupId = groupId;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public String getPassword() {
        return this.password;
    }
    
    @Override
    public void setPassword(final String password) {
        this.password = password;
        if (this.password != null && this.password.length() > 0) {
            this.passwordProtected = true;
        }
        else {
            this.passwordProtected = false;
        }
    }
    
    @Override
    public boolean isPasswordProtected() {
        return this.passwordProtected;
    }
    
    @Override
    public boolean isPublic() {
        return !this.passwordProtected;
    }
    
    @Override
    public int getMaxUsers() {
        return this.maxUsers;
    }
    
    @Override
    public void setMaxUsers(final int maxUsers) {
        this.maxUsers = maxUsers;
        if (this.isGame() && this.playerIdGenerator != null) {
            this.playerIdGenerator.onRoomResize();
        }
    }
    
    @Override
    public int getMaxSpectators() {
        return this.maxSpectators;
    }
    
    @Override
    public void setMaxSpectators(final int maxSpectators) {
        this.maxSpectators = maxSpectators;
    }
    
    @Override
    public User getOwner() {
        return this.owner;
    }
    
    @Override
    public void setOwner(final User owner) {
        this.owner = owner;
    }
    
    @Override
    public IUserManager getUserManager() {
        return this.userManager;
    }
    
    @Override
    public void setUserManager(final IUserManager userManager) {
        this.userManager = userManager;
    }
    
    @Override
    public Zone getZone() {
        return this.zone;
    }
    
    @Override
    public void setZone(final Zone zone) {
        this.zone = zone;
        this.instantiateRoomIdGenerator();
    }
    
    @Override
    public boolean isDynamic() {
        return this.dynamic;
    }
    
    @Override
    public void setDynamic(final boolean dynamic) {
        this.dynamic = dynamic;
    }
    
    @Override
    public boolean isGame() {
        return this.game;
    }
    
    @Override
    public void setGame(final boolean game, final Class<? extends IPlayerIdGenerator> customPlayerIdGeneratorClass) {
        if (this.isGameFlagInited) {
            throw new IllegalStateException(String.valueOf(this.toString()) + ", isGame flag cannot be reset");
        }
        this.game = game;
        this.isGameFlagInited = true;
        if (this.game) {
            try {
                (this.playerIdGenerator = (IPlayerIdGenerator)customPlayerIdGeneratorClass.newInstance()).setParentRoom(this);
                this.playerIdGenerator.init();
            }
            catch (InstantiationException err) {
                this.logger.warn(String.format("Cannot instantiate Player ID Generator: %s, Reason: %s -- Room might not function correctly.", customPlayerIdGeneratorClass, err));
            }
            catch (IllegalAccessException err2) {
                this.logger.warn(String.format("Illegal Access to Player ID Generator Class: %s, Reason: %s -- Room might not function correctly.", customPlayerIdGeneratorClass, err2));
            }
        }
    }
    
    @Override
    public void setGame(final boolean game) {
        this.setGame(game, null);
    }
    
    @Override
    public boolean isHidden() {
        return this.hidden;
    }
    
    @Override
    public void setHidden(final boolean hidden) {
        this.hidden = hidden;
    }
    
    @Override
    public boolean isActive() {
        return this.active;
    }
    
    @Override
    public void setActive(final boolean flag) {
        this.active = flag;
    }
    
    @Override
    public SFSRoomRemoveMode getAutoRemoveMode() {
        return this.autoRemoveMode;
    }
    
    @Override
    public void setAutoRemoveMode(final SFSRoomRemoveMode autoRemoveMode) {
        this.autoRemoveMode = autoRemoveMode;
    }
    
    @Override
    public List<User> getPlayersList() {
        final List<User> playerList = new ArrayList<User>();
        for (final User user : this.userManager.getAllUsers()) {
            if (user.isPlayer(this)) {
                playerList.add(user);
            }
        }
        return playerList;
    }
    
    @Override
    public Object getProperty(final Object key) {
        return this.properties.get(key);
    }
    
    @Override
    public RoomSize getSize() {
        int uCount = 0;
        int sCount = 0;
        if (this.game) {
            for (final User user : this.userManager.getAllUsers()) {
                if (user.isSpectator(this)) {
                    ++sCount;
                }
                else {
                    ++uCount;
                }
            }
        }
        else {
            uCount = this.userManager.getUserCount();
        }
        return new RoomSize(uCount, sCount);
    }
    
    @Override
    public void removeProperty(final Object key) {
        this.properties.remove(key);
    }
    
    @Override
    public List<User> getSpectatorsList() {
        final List<User> specList = new ArrayList<User>();
        for (final User user : this.userManager.getAllUsers()) {
            if (user.isSpectator(this)) {
                specList.add(user);
            }
        }
        return specList;
    }
    
    @Override
    public User getUserById(final int id) {
        return this.userManager.getUserById(id);
    }
    
    @Override
    public User getUserByName(final String name) {
        return this.userManager.getUserByName(name);
    }
    
    @Override
    public User getUserBySession(final ISession session) {
        return this.userManager.getUserBySession(session);
    }
    
    @Override
    public User getUserByPlayerId(final int playerId) {
        User user = null;
        for (final User u : this.userManager.getAllUsers()) {
            if (u.getPlayerId(this) == playerId) {
                user = u;
                break;
            }
        }
        return user;
    }
    
    @Override
    public List<User> getUserList() {
        return this.userManager.getAllUsers();
    }
    
    @Override
    public List<ISession> getSessionList() {
        return this.userManager.getAllSessions();
    }
    
    @Override
    public int getVariablesCount() {
        return this.variables.size();
    }
    
    @Override
    public RoomVariable getVariable(final String varName) {
        return this.variables.get(varName);
    }
    
    @Override
    public List<RoomVariable> getVariables() {
        return new ArrayList<RoomVariable>(this.variables.values());
    }
    
    @Override
    public List<RoomVariable> getVariablesCreatedByUser(final User user) {
        final List<RoomVariable> varList = new ArrayList<RoomVariable>();
        for (final RoomVariable rVar : this.variables.values()) {
            if (rVar.getOwner() == user) {
                varList.add(rVar);
            }
        }
        return varList;
    }
    
    @Override
    public boolean containsProperty(final Object key) {
        return this.properties.containsKey(key);
    }
    
    @Override
    public void removeVariable(final String varName) {
        this.variables.remove(varName);
        if (this.logger.isDebugEnabled()) {
            this.logger.debug("RoomVar deleted: " + varName + " in " + this);
        }
    }
    
    @Override
    public List<RoomVariable> removeVariablesCreatedByUser(final User user) {
        return this.removeVariablesCreatedByUser(user, false);
    }
    
    @Override
    public List<RoomVariable> removeVariablesCreatedByUser(final User user, final boolean isLeaveRoom) {
        final List<RoomVariable> removedVars = new ArrayList<RoomVariable>();
        for (final RoomVariable rVar : this.getVariablesCreatedByUser(user)) {
            if (isLeaveRoom && rVar.isPersistent()) {
                continue;
            }
            this.removeVariable(rVar.getName());
            rVar.setNull();
            removedVars.add(rVar);
        }
        return removedVars;
    }
    
    @Override
    public int getCapacity() {
        return this.maxUsers + this.maxSpectators;
    }
    
    @Override
    public void setCapacity(final int maxUser, final int maxSpectators) {
        this.maxUsers = maxUser;
        this.maxSpectators = maxSpectators;
    }
    
    @Override
    public void setMaxRoomVariablesAllowed(final int max) {
        this.maxRoomVariablesAllowed = max;
    }
    
    @Override
    public int getMaxRoomVariablesAllowed() {
        return this.maxRoomVariablesAllowed;
    }
    
    @Override
    public void setFlags(final Set<SFSRoomSettings> settings) {
        this.flags = settings;
    }
    
    @Override
    public boolean isFlagSet(final SFSRoomSettings flag) {
        return this.flags.contains(flag);
    }
    
    @Override
    public void setFlag(final SFSRoomSettings flag, final boolean state) {
        if (state) {
            this.flags.add(flag);
        }
        else {
            this.flags.remove(flag);
        }
    }
    
    @Override
    public boolean isUseWordsFilter() {
        return this.userWordsFilter;
    }
    
    @Override
    public void setUseWordsFilter(final boolean useWordsFilter) {
        this.userWordsFilter = useWordsFilter;
    }
    
    @Override
    public void setProperty(final Object key, final Object value) {
        this.properties.put(key, value);
    }
    
    @Override
    public void setVariables(final List<RoomVariable> variables) {
        this.setVariables(variables, false);
    }
    
    @Override
    public void setVariables(final List<RoomVariable> variables, final boolean overrideOwnership) {
        for (final RoomVariable var : variables) {
            try {
                this.setVariable(var);
            }
            catch (SFSVariableException e) {
                this.logger.warn(e.getMessage());
            }
        }
    }
    
    @Override
    public void setVariable(final RoomVariable roomVariable) throws SFSVariableException {
        this.setVariable(roomVariable, false);
    }
    
    @Override
    public boolean isAllowOwnerInvitations() {
        return this.allowOwnerInvitation;
    }
    
    @Override
    public void setAllowOwnerInvitations(final boolean flag) {
        this.allowOwnerInvitation = flag;
    }
    
    @Override
    public void destroy() {
    }
    
    @Override
    public void setVariable(final RoomVariable roomVariable, final boolean overrideOwnership) throws SFSVariableException {
        if (this.maxRoomVariablesAllowed < 1) {
            throw new SFSVariableException("Room Variables are disabled: " + this.toString());
        }
        final String varName = roomVariable.getName();
        final RoomVariable oldVariable = this.variables.get(varName);
        if (roomVariable.getType() == VariableType.NULL) {
            if (oldVariable == null) {
                throw new SFSVariableException("Cannot delete non-existent Room Variable called: " + roomVariable.getName() + ", Owner: " + roomVariable.getOwner());
            }
            this.deleteVariable(oldVariable, roomVariable, overrideOwnership);
        }
        else {
            if (oldVariable != null) {
                this.modifyVariable(oldVariable, roomVariable, overrideOwnership);
            }
            else {
                this.addVariable(roomVariable, overrideOwnership);
            }
            if (roomVariable.getOwner() != null && roomVariable.isPersistent()) {
                roomVariable.getOwner().addPersistentRoomVarReference(this);
            }
        }
    }
    
    private void addVariable(final RoomVariable var, final boolean overrideOwnership) throws SFSVariableException {
        if (this.variables.size() >= this.maxRoomVariablesAllowed) {
            throw new SFSVariableException(String.format("The max number of variables (%s) for this Room: %s was reached. Discarding variable: %s", this.maxRoomVariablesAllowed, this.name, var.getName()));
        }
        this.variables.put(var.getName(), var);
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(String.format("RoomVar created: %s in %s ", var, this));
        }
    }
    
    private void modifyVariable(final RoomVariable oldVariable, final RoomVariable newVariable, final boolean overrideOwnership) throws SFSVariableException {
        if (overrideOwnership) {
            this.overwriteVariable(oldVariable, newVariable);
        }
        else if (oldVariable.isPrivate()) {
            if (oldVariable.getOwner() != newVariable.getOwner()) {
                throw new SFSVariableException(String.format("Variable: %s cannot be changed by user: %s", oldVariable, newVariable.getOwner()));
            }
            this.overwriteVariable(oldVariable, newVariable);
        }
        else {
            this.overwriteVariable(oldVariable, newVariable);
        }
    }
    
    private void overwriteVariable(final RoomVariable oldRv, final RoomVariable newRv) {
        if (oldRv.getOwner() == null) {
            newRv.setOwner(null);
        }
        newRv.setHidden(oldRv.isHidden());
        newRv.setGlobal(oldRv.isGlobal());
        this.variables.put(newRv.getName(), newRv);
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(String.format("RoomVar changed: %s in %s ", newRv, this));
        }
    }
    
    private void deleteVariable(final RoomVariable oldVariable, final RoomVariable newVariable, final boolean overrideOwnership) throws SFSVariableException {
        if (overrideOwnership) {
            this.removeVariable(oldVariable.getName());
        }
        else if (oldVariable.isPrivate()) {
            if (oldVariable.getOwner() != newVariable.getOwner()) {
                throw new SFSVariableException("Variable: " + oldVariable + " cannot be deleted by user: " + newVariable.getOwner());
            }
            this.removeVariable(oldVariable.getName());
        }
        else {
            this.removeVariable(oldVariable.getName());
        }
    }
    
    @Override
    public boolean containsVariable(final String varName) {
        return this.variables.containsKey(varName);
    }
    
    @Override
    public boolean containsUser(final String name) {
        return this.userManager.containsName(name);
    }
    
    @Override
    public boolean containsUser(final User user) {
        return this.userManager.containsUser(user);
    }
    
    @Override
    public void addUser(final User user) throws SFSJoinRoomException {
        this.addUser(user, false);
    }
    
    @Override
    public void addUser(final User user, final boolean asSpectator) throws SFSJoinRoomException {
        if (this.userManager.containsId(user.getId())) {
            final String message = String.format("User already joined: %s, Room: %s, Zone: %s", user, this, this.getZone());
            final SFSErrorData data = new SFSErrorData(SFSErrorCode.JOIN_ALREADY_JOINED);
            data.addParameter(this.name);
            throw new SFSJoinRoomException(message, data);
        }
        boolean okToAdd = false;
        synchronized (this) {
            final RoomSize roomSize = this.getSize();
            if (this.isGame() && asSpectator) {
                okToAdd = (roomSize.getSpectatorCount() < this.maxSpectators);
            }
            else {
                okToAdd = (roomSize.getUserCount() < this.maxUsers);
            }
            if (!okToAdd) {
                final String message2 = String.format("Room is full: %s, Zone: %s - Can't add User: %s ", this.name, this.zone, user);
                final SFSErrorData data2 = new SFSErrorData(SFSErrorCode.JOIN_ROOM_FULL);
                data2.addParameter(this.name);
                throw new SFSJoinRoomException(message2, data2);
            }
            this.userManager.addUser(user);
        }
        user.addJoinedRoom(this);
        if (this.isGame()) {
            if (asSpectator) {
                user.setPlayerId(-1, this);
            }
            else {
                user.setPlayerId(this.playerIdGenerator.getPlayerSlot(), this);
            }
        }
        else {
            user.setPlayerId(0, this);
        }
    }
    
    @Override
    public void removeUser(final User user) {
        if (this.isGame()) {
            this.playerIdGenerator.freePlayerSlot(user.getPlayerId(this));
        }
        this.userManager.removeUser(user);
        user.removeJoinedRoom(this);
    }
    
    @Override
    public void switchPlayerToSpectator(final User user) throws SFSRoomException {
        if (!this.isGame()) {
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SWITCH_NOT_A_GAME_ROOM);
            errData.addParameter(this.name);
            throw new SFSRoomException("Not supported in a non-game room", errData);
        }
        if (!this.userManager.containsUser(user)) {
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SWITCH_NOT_JOINED_IN_ROOM);
            errData.addParameter(this.name);
            throw new SFSRoomException(String.format("%s is not joined in %s", user, this));
        }
        if (user.isSpectator(this)) {
            this.logger.warn(String.format("PlayerToSpectator refused, %s is already a spectator in %s", user, this));
            return;
        }
        this.switchUserLock.lock();
        try {
            if (this.getSize().getSpectatorCount() >= this.maxSpectators) {
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SWITCH_NO_SPECTATOR_SLOTS_AVAILABLE);
                errData.addParameter(this.name);
                throw new SFSRoomException("All Spectators slots are already occupied!", errData);
            }
            final int currentPlayerId = user.getPlayerId(this);
            user.setPlayerId(-1, this);
            this.playerIdGenerator.freePlayerSlot(currentPlayerId);
        }
        finally {
            this.switchUserLock.unlock();
        }
        this.switchUserLock.unlock();
    }
    
    @Override
    public void switchSpectatorToPlayer(final User user) throws SFSRoomException {
        if (!this.isGame()) {
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SWITCH_NOT_A_GAME_ROOM);
            errData.addParameter(this.name);
            throw new SFSRoomException("Not supported in a non-game room", errData);
        }
        if (!this.userManager.containsUser(user)) {
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SWITCH_NOT_JOINED_IN_ROOM);
            errData.addParameter(this.name);
            throw new SFSRoomException(String.format("%s is not joined in %s", user, this));
        }
        if (user.isPlayer(this)) {
            this.logger.warn(String.format("SpectatorToPlayer refused, %s is already a player in %s", user, this));
            return;
        }
        this.switchUserLock.lock();
        try {
            if (this.getSize().getUserCount() >= this.maxUsers) {
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SWITCH_NO_PLAYER_SLOTS_AVAILABLE);
                errData.addParameter(this.name);
                throw new SFSRoomException("All Player slots are already occupied!", errData);
            }
            user.setPlayerId(this.playerIdGenerator.getPlayerSlot(), this);
        }
        finally {
            this.switchUserLock.unlock();
        }
        this.switchUserLock.unlock();
    }
    
    @Override
    public long getLifeTime() {
        return System.currentTimeMillis() - this.lifeTime;
    }
    
    @Override
    public boolean isEmpty() {
        return this.userManager.getUserCount() == 0;
    }
    
    @Override
    public boolean isFull() {
        if (this.isGame()) {
            return this.getSize().getUserCount() == this.maxUsers;
        }
        return this.userManager.getUserCount() == this.maxUsers;
    }
    
    @Override
    public ISFSArray getUserListData() {
        final ISFSArray userListData = SFSArray.newInstance();
        for (final User user : this.userManager.getAllUsers()) {
            final ISFSArray userObj = SFSArray.newInstance();
            userObj.addInt(user.getId());
            userObj.addUtfString(user.getName());
            userObj.addShort(user.getPrivilegeId());
            userObj.addShort((short)user.getPlayerId(this));
            userObj.addSFSArray(user.getUserVariablesData());
            userListData.addSFSArray(userObj);
        }
        return userListData;
    }
    
    @Override
    public ISFSArray getRoomVariablesData(final boolean globalsOnly) {
        final ISFSArray variablesData = SFSArray.newInstance();
        for (final RoomVariable var : this.variables.values()) {
            if (var.isHidden()) {
                continue;
            }
            if (globalsOnly && !var.isGlobal()) {
                continue;
            }
            variablesData.addSFSArray(var.toSFSArray());
        }
        return variablesData;
    }
    
    @Override
    public String toString() {
        return String.format("[ Room: %s, Id: %s, Group: %s, isGame: %s ]", this.name, this.id, this.groupId, this.game);
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (!(obj instanceof Room)) {
            return false;
        }
        final Room room = (Room)obj;
        boolean isEqual = false;
        if (room.getId() == this.id) {
            isEqual = true;
        }
        return isEqual;
    }
    
    @Override
    public ISFSExtension getExtension() {
        return this.extension;
    }
    
    @Override
    public void setExtension(final ISFSExtension extension) {
        this.extension = extension;
    }
    
    @Override
    public ISFSArray toSFSArray(final boolean globalRoomVarsOnly) {
        final RoomSize roomSize = this.getSize();
        final ISFSArray roomObj = SFSArray.newInstance();
        roomObj.addInt(this.id);
        roomObj.addUtfString(this.name);
        roomObj.addUtfString(this.groupId);
        roomObj.addBool(this.isGame());
        roomObj.addBool(this.isHidden());
        roomObj.addBool(this.isPasswordProtected());
        roomObj.addShort((short)roomSize.getUserCount());
        roomObj.addShort((short)this.maxUsers);
        roomObj.addSFSArray(this.getRoomVariablesData(globalRoomVarsOnly));
        if (this.isGame()) {
            roomObj.addShort((short)roomSize.getSpectatorCount());
            roomObj.addShort((short)this.maxSpectators);
        }
        return roomObj;
    }
    
    @Override
    public String getDump() {
        final StringBuilder sb = new StringBuilder("/////////////// Room Dump ////////////////").append("\n");
        sb.append("\tName: ").append(this.name).append("\n").append("\tId: ").append(this.id).append("\n").append("\tGroupId: ").append(this.groupId).append("\n").append("\tPassword: ").append(this.password).append("\n").append("\tOwner: ").append((this.owner == null) ? "[[ SERVER ]]" : this.owner.toString()).append("\n").append("\tisDynamic: ").append(this.dynamic).append("\n").append("\tisGame: ").append(this.game).append("\n").append("\tisHidden: ").append(this.hidden).append("\n").append("\tsize: ").append(this.getSize()).append("\n").append("\tMaxUser: ").append(this.maxUsers).append("\n").append("\tMaxSpect: ").append(this.maxSpectators).append("\n").append("\tMaxVars: ").append(this.maxRoomVariablesAllowed).append("\n").append("\tRemoveMode: ").append(this.autoRemoveMode).append("\n").append("\tPlayerIdGen: ").append(this.playerIdGenerator).append("\n").append("\tSettings: ").append("\n");
        SFSRoomSettings[] values;
        for (int length = (values = SFSRoomSettings.values()).length, i = 0; i < length; ++i) {
            final SFSRoomSettings setting = values[i];
            sb.append("\t\t").append(setting).append(": ").append(this.flags.contains(setting)).append("\n");
        }
        if (this.variables.size() > 0) {
            sb.append("\tRoomVariables: ").append("\n");
            for (final RoomVariable var : this.variables.values()) {
                sb.append("\t\t").append(var.toString()).append("\n");
            }
        }
        if (this.properties.size() > 0) {
            sb.append("\tProperties: ").append("\n");
            for (final Object key : this.properties.keySet()) {
                sb.append("\t\t").append(key).append(": ").append(this.properties.get(key)).append("\n");
            }
        }
        if (this.extension != null) {
            sb.append("\tExtension: ").append("\n");
            sb.append("\t\t").append("Name: ").append(this.extension.getName()).append("\n");
            sb.append("\t\t").append("Class: ").append(this.extension.getExtensionFileName()).append("\n");
            sb.append("\t\t").append("Type: ").append(this.extension.getType()).append("\n");
            sb.append("\t\t").append("Props: ").append(this.extension.getPropertiesFileName()).append("\n");
        }
        sb.append("/////////////// End Dump /////////////////").append("\n");
        return sb.toString();
    }
    
    public IAdminHelper getAdminHelper() {
        return this.adminHelper;
    }
    
    public void setAdminHelper(final IAdminHelper helper) {
        this.adminHelper = helper;
    }
    
    @Override
    public String getPlayerIdGeneratorClassName() {
        return this.playerIdGenerator.getClass().getName();
    }
    
    public void setProperties(final Map<Object, Object> props) {
        this.properties.clear();
        this.properties.putAll(props);
    }
    
    private void instantiateRoomIdGenerator() {
        String className = this.zone.getDefaultPlayerIdGeneratorClassName();
        if (className == null) {
            className = "com.smartfoxserver.v2.util.DefaultPlayerIdGenerator";
        }
        try {
            final Class<?> theClass = Class.forName(className);
            this.playerIdGenerator = (IPlayerIdGenerator)theClass.newInstance();
        }
        catch (Exception e) {
            this.logger.error("Could not instantiate the IPlayerIdGenerator object. Room: " + this + ", class: " + className + ", err: " + e);
        }
    }
    
    private void populateTransientFields() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.extension = null;
    }
}

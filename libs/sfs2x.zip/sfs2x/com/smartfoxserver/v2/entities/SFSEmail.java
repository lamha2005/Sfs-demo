// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

public class SFSEmail implements Email
{
    private final String from;
    private final String to;
    private final String subject;
    private final String message;
    private final int priority;
    
    public SFSEmail(final String from, final String to, final String subject, final String message) {
        this(from, to, subject, message, 0);
    }
    
    public SFSEmail(final String from, final String to, final String subject, final String message, final int priority) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.message = message;
        this.priority = priority;
    }
    
    @Override
    public String getFromAddress() {
        return this.from;
    }
    
    @Override
    public String getToAddress() {
        return this.to;
    }
    
    @Override
    public String getSubject() {
        return this.subject;
    }
    
    @Override
    public String getMessage() {
        return this.message;
    }
    
    @Override
    public int getPriority() {
        return this.priority;
    }
    
    @Override
    public String toString() {
        return String.format("{ Email To: %s, From: %s, Subject: %s }", this.to, this.from, this.subject);
    }
}

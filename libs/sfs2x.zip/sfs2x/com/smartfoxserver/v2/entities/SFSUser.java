// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.util.Country;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.exceptions.SFSVariableException;
import com.smartfoxserver.v2.entities.variables.VariableType;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import java.util.Collection;
import com.smartfoxserver.v2.security.SystemPermission;
import org.slf4j.LoggerFactory;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.mmo.BaseMMOItem;
import java.util.List;
import org.slf4j.Logger;
import com.smartfoxserver.v2.buddylist.BuddyProperties;
import com.smartfoxserver.v2.util.IAdminHelper;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import java.util.concurrent.ConcurrentMap;
import java.util.LinkedList;
import java.util.Set;
import com.smartfoxserver.bitswarm.sessions.ISession;

public class SFSUser implements User
{
    private int id;
    private ISession session;
    private String name;
    private short privilegeId;
    private volatile long lastLoginTime;
    private final Set<String> registeredGroups;
    private final LinkedList<Room> joinedRooms;
    private final Set<Room> createdRooms;
    private final ConcurrentMap<Integer, Integer> playerIdByRoomId;
    private final ConcurrentMap<Object, Object> properties;
    private final ConcurrentMap<String, UserVariable> variables;
    private volatile int ownedRoomsCount;
    private volatile int badWordsWarnings;
    private volatile int floodWarnings;
    private volatile boolean beingKicked;
    private volatile boolean connected;
    private boolean joining;
    private int maxVariablesAllowed;
    private IAdminHelper adminHelper;
    private BuddyProperties buddyProperties;
    private Zone currentZone;
    private Logger logger;
    private volatile List<User> proxyList;
    private volatile List<BaseMMOItem> mmoItemsList;
    private volatile MMORoom lastJoinedMMORoom;
    private final Set<Integer> persistentRoomVarReferences;
    
    public SFSUser(final ISession session) {
        this("", session);
    }
    
    public SFSUser(final String name, final ISession session) {
        this.privilegeId = 0;
        this.lastLoginTime = 0L;
        this.ownedRoomsCount = 0;
        this.badWordsWarnings = 0;
        this.floodWarnings = 0;
        this.beingKicked = false;
        this.connected = false;
        this.joining = false;
        this.maxVariablesAllowed = 0;
        this.id = SmartFoxServer.getInstance().getUIDGenerator().generateID();
        this.name = name;
        this.session = session;
        this.beingKicked = false;
        this.joinedRooms = new LinkedList<Room>();
        this.properties = new ConcurrentHashMap<Object, Object>();
        this.playerIdByRoomId = new ConcurrentHashMap<Integer, Integer>();
        this.variables = new ConcurrentHashMap<String, UserVariable>();
        this.registeredGroups = new HashSet<String>();
        this.createdRooms = new HashSet<Room>();
        this.persistentRoomVarReferences = new HashSet<Integer>();
        this.updateLastRequestTime();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public BuddyProperties getBuddyProperties() {
        return this.buddyProperties;
    }
    
    @Override
    public int getId() {
        return this.id;
    }
    
    @Override
    public short getPrivilegeId() {
        return this.privilegeId;
    }
    
    @Override
    public void setPrivilegeId(final short id) {
        this.privilegeId = id;
    }
    
    @Override
    public boolean isSuperUser() {
        return this.currentZone.getPrivilegeManager().isFlagSet(this, SystemPermission.SuperUser);
    }
    
    @Override
    public boolean isConnected() {
        return this.connected;
    }
    
    @Override
    public boolean isLocal() {
        return this.session.isLocal();
    }
    
    @Override
    public synchronized void setConnected(final boolean flag) {
        this.connected = flag;
    }
    
    @Override
    public synchronized boolean isJoining() {
        return this.joining;
    }
    
    @Override
    public synchronized void setJoining(final boolean flag) {
        this.joining = flag;
    }
    
    @Override
    public String getIpAddress() {
        return this.session.getAddress();
    }
    
    @Override
    public int getMaxAllowedVariables() {
        return this.maxVariablesAllowed;
    }
    
    @Override
    public synchronized void setMaxAllowedVariables(final int max) {
        this.maxVariablesAllowed = max;
    }
    
    @Override
    public void addCreatedRoom(final Room room) {
        synchronized (this.createdRooms) {
            this.createdRooms.add(room);
        }
        // monitorexit(this.createdRooms)
    }
    
    @Override
    public List<Room> getCreatedRooms() {
        List<Room> rooms = null;
        synchronized (this.createdRooms) {
            rooms = new LinkedList<Room>(this.createdRooms);
        }
        // monitorexit(this.createdRooms)
        return rooms;
    }
    
    @Override
    public void removeCreatedRoom(final Room room) {
        synchronized (this.createdRooms) {
            this.createdRooms.remove(room);
        }
        // monitorexit(this.createdRooms)
    }
    
    @Override
    public void addJoinedRoom(final Room room) {
        synchronized (this.joinedRooms) {
            if (!this.joinedRooms.contains(room)) {
                this.joinedRooms.add(room);
            }
        }
        // monitorexit(this.joinedRooms)
    }
    
    @Override
    public void removeJoinedRoom(final Room room) {
        synchronized (this.joinedRooms) {
            this.joinedRooms.remove(room);
        }
        // monitorexit(this.joinedRooms)
        this.playerIdByRoomId.remove(room.getId());
    }
    
    @Override
    public int getOwnedRoomsCount() {
        return this.ownedRoomsCount;
    }
    
    @Override
    public void subscribeGroup(final String id) {
        synchronized (this.registeredGroups) {
            this.registeredGroups.add(id);
        }
        // monitorexit(this.registeredGroups)
    }
    
    @Override
    public void unsubscribeGroup(final String id) {
        synchronized (this.registeredGroups) {
            this.registeredGroups.remove(id);
        }
        // monitorexit(this.registeredGroups)
    }
    
    @Override
    public List<String> getSubscribedGroups() {
        List<String> theGroups = null;
        synchronized (this.registeredGroups) {
            theGroups = new LinkedList<String>(this.registeredGroups);
        }
        // monitorexit(this.registeredGroups)
        return theGroups;
    }
    
    @Override
    public boolean isSubscribedToGroup(final String id) {
        boolean found = false;
        synchronized (this.registeredGroups) {
            found = this.registeredGroups.contains(id);
        }
        // monitorexit(this.registeredGroups)
        return found;
    }
    
    @Override
    public void disconnect(final IDisconnectionReason reason) {
        SmartFoxServer.getInstance().getAPIManager().getSFSApi().disconnectUser(this, reason);
    }
    
    @Override
    public boolean isNpc() {
        return this.session.getType() == SessionType.VOID;
    }
    
    @Override
    public List<Room> getJoinedRooms() {
        final List<Room> rooms;
        synchronized (this.joinedRooms) {
            rooms = new LinkedList<Room>(this.joinedRooms);
        }
        // monitorexit(this.joinedRooms)
        return rooms;
    }
    
    @Override
    public Zone getZone() {
        return this.currentZone;
    }
    
    @Override
    public void setZone(final Zone currentZone) {
        if (this.currentZone != null) {
            throw new IllegalStateException("The User Zone is already set. It cannot be modified at Runtime. " + this);
        }
        this.currentZone = currentZone;
        if (currentZone.getBuddyListManager().isActive()) {
            (this.buddyProperties = SmartFoxServer.getInstance().getServiceProvider().getBuddyPropertiesImpl()).init(this.name);
        }
    }
    
    @Override
    public Room getLastJoinedRoom() {
        Room lastRoom = null;
        synchronized (this.joinedRooms) {
            if (this.joinedRooms.size() > 0) {
                lastRoom = this.joinedRooms.getLast();
            }
        }
        // monitorexit(this.joinedRooms)
        return lastRoom;
    }
    
    @Override
    public boolean isJoinedInRoom(final Room room) {
        boolean found = false;
        synchronized (this.joinedRooms) {
            found = this.joinedRooms.contains(room);
        }
        // monitorexit(this.joinedRooms)
        return found;
    }
    
    @Override
    public long getLoginTime() {
        return this.lastLoginTime;
    }
    
    @Override
    public void setLastLoginTime(final long lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public int getPlayerId() {
        final Room theRoom = this.getLastJoinedRoom();
        if (theRoom == null) {
            return 0;
        }
        return this.playerIdByRoomId.get(theRoom.getId());
    }
    
    @Override
    public int getPlayerId(final Room room) {
        if (room == null) {
            return 0;
        }
        Integer playerId = this.playerIdByRoomId.get(room.getId());
        if (playerId == null) {
            this.logger.info("Can't find playerID -- User: " + this.name + " is not joined in the requested Room: " + room);
            playerId = 0;
        }
        return playerId;
    }
    
    @Override
    public Map<Room, Integer> getPlayerIds() {
        final Map<Room, Integer> allPlayerIds = new HashMap<Room, Integer>();
        synchronized (this.joinedRooms) {
            for (final Room room : this.joinedRooms) {
                allPlayerIds.put(room, this.getPlayerId(room));
            }
        }
        // monitorexit(this.joinedRooms)
        return allPlayerIds;
    }
    
    @Override
    public void setPlayerId(final int id, final Room room) {
        this.playerIdByRoomId.put(room.getId(), id);
    }
    
    @Override
    public boolean isPlayer() {
        return this.isPlayer(this.getLastJoinedRoom());
    }
    
    @Override
    public boolean isSpectator() {
        return this.isSpectator(this.getLastJoinedRoom());
    }
    
    @Override
    public boolean isPlayer(final Room room) {
        return this.getPlayerId(room) > 0;
    }
    
    @Override
    public boolean isSpectator(final Room room) {
        return this.getPlayerId(room) < 0;
    }
    
    @Override
    public Object getProperty(final Object key) {
        return this.properties.get(key);
    }
    
    @Override
    public void setProperty(final Object key, final Object val) {
        this.properties.put(key, val);
    }
    
    @Override
    public boolean containsProperty(final Object key) {
        return this.properties.containsKey(key);
    }
    
    @Override
    public void removeProperty(final Object key) {
        this.properties.remove(key);
    }
    
    @Override
    public ISession getSession() {
        return this.session;
    }
    
    @Override
    public int getVariablesCount() {
        return this.variables.size();
    }
    
    @Override
    public UserVariable getVariable(final String varName) {
        return this.variables.get(varName);
    }
    
    @Override
    public void setVariable(final UserVariable var) throws SFSVariableException {
        final String varName = var.getName();
        if (var.getType() == VariableType.NULL) {
            this.removeVariable(varName);
        }
        else {
            if (!this.containsVariable(varName) && this.variables.size() >= this.maxVariablesAllowed) {
                throw new SFSVariableException("The max number of variables (" + this.maxVariablesAllowed + ") for this User: " + this.name + " was reached. Discarding variable: " + varName);
            }
            this.variables.put(varName, var);
            if (this.logger.isDebugEnabled()) {
                this.logger.debug(String.format("UserVar set: %s, %s ", var, this));
            }
        }
    }
    
    @Override
    public void setVariables(final List<UserVariable> userVariables) throws SFSVariableException {
        for (final UserVariable uVar : userVariables) {
            this.setVariable(uVar);
        }
    }
    
    @Override
    public boolean containsVariable(final String varName) {
        return this.variables.containsKey(varName);
    }
    
    @Override
    public List<UserVariable> getVariables() {
        return new LinkedList<UserVariable>(this.variables.values());
    }
    
    @Override
    public void removeVariable(final String varName) {
        this.variables.remove(varName);
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(String.format("UserVar removed: %s, %s", varName, this));
        }
    }
    
    @Override
    public String toString() {
        return String.format("( User Name: %s, Id: %s, Priv: %s, Sess: %s ) ", this.name, this.id, this.privilegeId, this.session.getFullIpAddress());
    }
    
    @Override
    public long getLastRequestTime() {
        return this.session.getLastLoggedInActivityTime();
    }
    
    @Override
    public synchronized void updateLastRequestTime() {
        this.setLastRequestTime(System.currentTimeMillis());
    }
    
    @Override
    public void setLastRequestTime(final long lastRequestTime) {
        this.session.setLastLoggedInActivityTime(lastRequestTime);
    }
    
    @Override
    public int getBadWordsWarnings() {
        return this.badWordsWarnings;
    }
    
    @Override
    public void setBadWordsWarnings(final int badWordsWarnings) {
        this.badWordsWarnings = badWordsWarnings;
    }
    
    @Override
    public int getFloodWarnings() {
        return this.floodWarnings;
    }
    
    @Override
    public void setFloodWarnings(final int floodWarnings) {
        this.floodWarnings = floodWarnings;
    }
    
    public long getLastLoginTime() {
        return this.lastLoginTime;
    }
    
    @Override
    public boolean isBeingKicked() {
        return this.beingKicked;
    }
    
    @Override
    public void setBeingKicked(final boolean flag) {
        this.beingKicked = flag;
    }
    
    @Override
    public ISFSArray getUserVariablesData() {
        final ISFSArray variablesData = SFSArray.newInstance();
        for (final UserVariable var : this.variables.values()) {
            if (!var.isHidden()) {
                if (var.isPrivate()) {
                    continue;
                }
                variablesData.addSFSArray(var.toSFSArray());
            }
        }
        return variablesData;
    }
    
    @Override
    public int getReconnectionSeconds() {
        return this.session.getReconnectionSeconds();
    }
    
    @Override
    public void setReconnectionSeconds(final int seconds) {
        this.session.setReconnectionSeconds(seconds);
    }
    
    @Override
    public ISFSArray toSFSArray(final Room room) {
        final ISFSArray userObj = SFSArray.newInstance();
        userObj.addInt(this.id);
        userObj.addUtfString(this.name);
        userObj.addShort(this.privilegeId);
        userObj.addShort((short)this.getPlayerId(room));
        userObj.addSFSArray(this.getUserVariablesData());
        return userObj;
    }
    
    @Override
    public ISFSArray toSFSArray() {
        return this.toSFSArray(this.getLastJoinedRoom());
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (!(obj instanceof User)) {
            return false;
        }
        final User user = (User)obj;
        return user.getId() == this.id;
    }
    
    @Override
    public String getDump() {
        final StringBuilder sb = new StringBuilder("/////////////// User Dump ////////////////").append("\n");
        sb.append("\tName: ").append(this.name).append("\n").append("\tId: ").append(this.id).append("\n").append("\tHash: ").append(this.session.getHashId()).append("\n").append("\tZone: ").append(this.getZone()).append("\n").append("\tIP Address: ").append(this.getIpAddress()).append("\n").append("\tPrivilegeId: ").append(this.getPrivilegeId()).append("\n").append("\tisSubscribed Groups: ").append(this.getSubscribedGroups()).append("\n").append("\tLast Joined Room: ").append(this.getLastJoinedRoom()).append("\n").append("\tJoined Rooms: ").append(this.getJoinedRooms()).append("\n");
        if (this.variables.size() > 0) {
            sb.append("\tUserVariables: ").append("\n");
            for (final UserVariable var : this.variables.values()) {
                sb.append("\t\t").append(var.toString()).append("\n");
            }
        }
        if (this.properties.size() > 0) {
            sb.append("\tProperties: ").append("\n");
            for (final Object key : this.properties.keySet()) {
                sb.append("\t\t").append(key).append(": ").append(this.properties.get(key)).append("\n");
            }
        }
        sb.append("/////////////// End Dump /////////////////").append("\n");
        return sb.toString();
    }
    
    public IAdminHelper getAdminHelper() {
        return this.adminHelper;
    }
    
    public void setAdminHelper(final IAdminHelper adminHelper) {
        this.adminHelper = adminHelper;
    }
    
    @Override
    public List<User> getLastProxyList() {
        return this.proxyList;
    }
    
    @Override
    public void setLastProxyList(final List<User> proxyList) {
        this.proxyList = proxyList;
    }
    
    @Override
    public List<BaseMMOItem> getLastMMOItemsList() {
        return this.mmoItemsList;
    }
    
    @Override
    public void setLastMMOItemsList(final List<BaseMMOItem> mmoItemsList) {
        this.mmoItemsList = mmoItemsList;
    }
    
    @Override
    public MMORoom getCurrentMMORoom() {
        Room mmoRoom = null;
        for (final Room r : this.getJoinedRooms()) {
            if (r instanceof MMORoom) {
                mmoRoom = r;
                break;
            }
        }
        return (MMORoom)mmoRoom;
    }
    
    @Override
    public Country getCountry() {
        return (Country)this.session.getSystemProperty("GeoLocation");
    }
    
    @Override
    public void addPersistentRoomVarReference(final Room target) {
        synchronized (this.persistentRoomVarReferences) {
            this.persistentRoomVarReferences.add(target.getId());
        }
        // monitorexit(this.persistentRoomVarReferences)
    }
    
    @Override
    public Set<Integer> getPersistentRoomVarReferences() {
        return this.persistentRoomVarReferences;
    }
    
    private void populateTransientFields() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
}

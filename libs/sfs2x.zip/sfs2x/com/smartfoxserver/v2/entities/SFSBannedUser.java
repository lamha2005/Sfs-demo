// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.entities.managers.BanMode;
import java.io.Serializable;

public class SFSBannedUser implements BannedUser, Serializable
{
    private static final long serialVersionUID = -8591228575994508738L;
    protected long banTimeMillis;
    protected int banDurationMinutes;
    protected String name;
    protected String ipAddress;
    protected BanMode mode;
    protected String reason;
    protected String zoneName;
    protected String adminName;
    
    public SFSBannedUser() {
    }
    
    public SFSBannedUser(final User user, final int durationMinutes, final BanMode mode, final String reason, final String adminName) {
        this(user.getName(), user.getZone().getName(), durationMinutes, mode, reason, adminName);
        this.ipAddress = user.getIpAddress();
    }
    
    public SFSBannedUser(final User user, final int durationMinutes, final BanMode mode) {
        this(user, durationMinutes, mode, null, null);
        this.ipAddress = user.getIpAddress();
    }
    
    public SFSBannedUser(final String userName, final String zoneName, int durationMinutes, final BanMode mode, final String reason, final String adminName) {
        this.banTimeMillis = System.currentTimeMillis();
        if (durationMinutes < 1) {
            LoggerFactory.getLogger((Class)this.getClass()).warn("Invalid ban duration: " + durationMinutes + ", Automatically converted to 24hrs.");
            durationMinutes = 1440;
        }
        this.banDurationMinutes = durationMinutes;
        this.name = userName;
        this.ipAddress = null;
        this.mode = mode;
        this.zoneName = zoneName;
        this.adminName = ((adminName != null) ? adminName : "[Server]");
        this.reason = ((reason != null) ? reason : "{Unknown}");
    }
    
    public SFSBannedUser(final String userName, final String zoneName, final int durationMinutes, final BanMode mode) {
        this(userName, zoneName, durationMinutes, mode, null, null);
    }
    
    @Override
    public String getZoneName() {
        return this.zoneName;
    }
    
    @Override
    public long getBanTimeMillis() {
        return this.banTimeMillis;
    }
    
    @Override
    public String getIpAddress() {
        return this.ipAddress;
    }
    
    @Override
    public BanMode getMode() {
        return this.mode;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public String getReason() {
        return this.reason;
    }
    
    @Override
    public String getAdminName() {
        return this.adminName;
    }
    
    @Override
    public int getBanDurationMinutes() {
        return this.banDurationMinutes;
    }
    
    @Override
    public boolean isExpired() {
        return System.currentTimeMillis() > this.banTimeMillis + this.getBanDurationMillis();
    }
    
    @Override
    public ISFSArray toSFSArray() {
        final ISFSArray sfsa = new SFSArray();
        sfsa.addUtfString(this.name);
        sfsa.addUtfString((this.zoneName == null) ? "" : this.zoneName);
        sfsa.addUtfString(this.mode.toString());
        sfsa.addUtfString((this.reason == null) ? "" : this.reason);
        sfsa.addUtfString((this.adminName == null) ? "" : this.adminName);
        sfsa.addUtfString((this.ipAddress == null) ? "" : this.ipAddress);
        sfsa.addLong(this.banTimeMillis);
        sfsa.addLong(this.getBanDurationMillis());
        return sfsa;
    }
    
    @Override
    public String toString() {
        return String.format("BannedUser [name: %s, ip: %s, mode: %s, reason: %s]", this.name, this.ipAddress, this.mode, this.reason);
    }
    
    private Long getBanDurationMillis() {
        return this.banDurationMinutes * 60L * 1000L;
    }
}

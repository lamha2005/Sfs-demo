// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.sessions.ISession;

public class LoginData
{
    public ISession session;
    public String userName;
    public String password;
    public boolean forceLogout;
    public ISFSObject paramsOut;
    
    public LoginData() {
    }
    
    public LoginData(final ISession session, final String userName) {
        this.session = session;
        this.userName = userName;
    }
    
    public LoginData(final ISession session, final String userName, final String password) {
        this(session, userName);
        this.password = password;
    }
    
    public LoginData(final ISession session, final String userName, final String password, final ISFSObject paramsOut, final boolean forceLogout) {
        this(session, userName, password);
        this.forceLogout = forceLogout;
        this.paramsOut = paramsOut;
    }
}

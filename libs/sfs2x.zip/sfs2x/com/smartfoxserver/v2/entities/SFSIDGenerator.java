// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import java.util.concurrent.atomic.AtomicInteger;

public class SFSIDGenerator implements IDGenerator
{
    private final AtomicInteger autoID;
    
    public SFSIDGenerator() {
        this.autoID = new AtomicInteger(0);
    }
    
    @Override
    public int generateID() {
        return this.autoID.getAndIncrement();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.managers.BanMode;

public interface BannedUser
{
    long getBanTimeMillis();
    
    int getBanDurationMinutes();
    
    String getName();
    
    String getZoneName();
    
    String getIpAddress();
    
    BanMode getMode();
    
    String getReason();
    
    String getAdminName();
    
    boolean isExpired();
    
    ISFSArray toSFSArray();
}

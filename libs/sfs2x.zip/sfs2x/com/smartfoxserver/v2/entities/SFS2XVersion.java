// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

public class SFS2XVersion implements IVersion
{
    @Override
    public String get() {
        return "2.12.5";
    }
}

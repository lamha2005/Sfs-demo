// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.entities;

public enum SFSRoomEvents
{
    ROOM_NAME_CHANGE("ROOM_NAME_CHANGE", 0), 
    ROOM_CAPACITY_CHANGE("ROOM_CAPACITY_CHANGE", 1), 
    PASSWORD_STATE_CHANGE("PASSWORD_STATE_CHANGE", 2), 
    USER_COUNT_CHANGE("USER_COUNT_CHANGE", 3), 
    ROOM_VARIABLES_UPDATE("ROOM_VARIABLES_UPDATE", 4);
    
    private SFSRoomEvents(final String s, final int n) {
    }
}

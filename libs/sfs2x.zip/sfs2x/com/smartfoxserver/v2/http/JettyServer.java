// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.http;

import org.eclipse.jetty.start.Main;
import java.util.HashMap;
import java.util.Map;

public class JettyServer implements IHttpServer
{
    private Map<String, Object> attributes;
    private boolean _isRunning;
    
    public JettyServer() {
        this._isRunning = false;
    }
    
    public void init(final Object o) {
        this.attributes = new HashMap<String, Object>();
        System.setProperty("jetty.home", "./lib/jetty/");
        System.setProperty("jetty.base", "./lib/jetty/");
    }
    
    public void destroy(final Object o) {
    }
    
    @Override
    public boolean isRunning() {
        return this._isRunning;
    }
    
    @Override
    public void start() throws Exception {
        Main.main(new String[0]);
        this._isRunning = true;
    }
    
    @Override
    public void setAttribute(final String key, final Object value) {
        this.attributes.put(key, value);
    }
    
    @Override
    public Object getAttribute(final String key) {
        return this.attributes.get(key);
    }
    
    public void handleMessage(final Object message) {
    }
    
    public String getName() {
        return "Jetty Web Server";
    }
    
    public void setName(final String name) {
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.http;

import com.smartfoxserver.bitswarm.service.IService;

public interface IHttpServer extends IService
{
    void start() throws Exception;
    
    void setAttribute(final String p0, final Object p1);
    
    Object getAttribute(final String p0);
    
    boolean isRunning();
}

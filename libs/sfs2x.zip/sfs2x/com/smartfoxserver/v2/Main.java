// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2;

public class Main
{
    public static void main(final String[] args) {
        boolean useConsole = false;
        if (args.length > 0) {
            useConsole = args[0].equalsIgnoreCase("console");
        }
        final SmartFoxServer sfs2X = SmartFoxServer.getInstance();
        if (useConsole) {
            sfs2X.startDebugConsole();
        }
        sfs2X.start();
    }
}

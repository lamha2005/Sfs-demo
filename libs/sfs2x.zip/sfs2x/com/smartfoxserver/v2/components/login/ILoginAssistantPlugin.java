// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.login;

public interface ILoginAssistantPlugin
{
    void execute(final LoginData p0) throws Exception;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.login;

import java.util.Iterator;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.api.ISFSApi;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.db.IDBManager;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.core.ISFSEventParam;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.core.ISFSEvent;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.core.ISFSEventListener;

final class LoginAssistantEventHandler implements ISFSEventListener
{
    private final LoginConfiguration config;
    private final ISFSExtension extension;
    private final Logger log;
    
    public LoginAssistantEventHandler(final LoginConfiguration config, final ISFSExtension extension) {
        this.log = LoggerFactory.getLogger("com.smartfoxserver.v2.components.login.LoginAssistant");
        this.config = config;
        this.extension = extension;
    }
    
    @Override
    public void handleServerEvent(final ISFSEvent event) throws Exception {
        final ISession _session = (ISession)event.getParameter(SFSEventParam.SESSION);
        final String _userName = (String)event.getParameter(SFSEventParam.LOGIN_NAME);
        final String _password = (String)event.getParameter(SFSEventParam.LOGIN_PASSWORD);
        final ISFSObject _inData = (ISFSObject)event.getParameter(SFSEventParam.LOGIN_IN_DATA);
        final ISFSObject _outData = (ISFSObject)event.getParameter(SFSEventParam.LOGIN_OUT_DATA);
        if (this.config.allowGuests && _userName.length() == 0 && _password.length() == 0) {
            return;
        }
        final IDBManager dbm = (this.config.customDBManager == null) ? this.extension.getParentZone().getDBManager() : this.config.customDBManager;
        final String sql = this.prepareSelect();
        final Object[] params = { _userName };
        if (this.log.isDebugEnabled()) {
            this.log.debug("Login SQL: " + sql);
        }
        final ISFSArray result = dbm.executeQuery(sql, params);
        if (result.size() == 0) {
            this.raiseNameError(_userName);
        }
        if (this.log.isDebugEnabled()) {
            this.log.debug("Query Result: " + result.getDump());
        }
        final LoginData loginData = this.populateLoginData(result);
        loginData.session = _session;
        loginData.clientIncomingData = _inData;
        loginData.clientOutGoingData = _outData;
        if (this.config.preProcessPlugin != null) {
            try {
                this.config.preProcessPlugin.execute(loginData);
            }
            catch (PasswordCheckException pce) {
                this.throwPasswordException(_userName);
            }
        }
        final ISFSApi api = SmartFoxServer.getInstance().getAPIManager().getSFSApi();
        if (this.config.activationField != null && !loginData.isActive) {
            this.raiseActivationError(_userName);
        }
        if (this.config.useCaseSensitiveNameChecks && !loginData.userName.equals(_userName)) {
            this.raiseNameError(_userName);
        }
        if (!this.config.customPasswordCheck && !api.checkSecurePassword(_session, loginData.password, _password)) {
            this.throwPasswordException(_userName);
        }
        if (this.config.postProcessPlugin != null) {
            this.config.postProcessPlugin.execute(loginData);
        }
        if (this.config.nickNameField != null) {
            _outData.putUtfString("$FS_NEW_LOGIN_NAME", loginData.nickName);
        }
    }
    
    private void raiseNameError(final String name) throws SFSLoginException {
        final SFSErrorData data = new SFSErrorData(SFSErrorCode.LOGIN_BAD_USERNAME);
        data.addParameter(name);
        throw new SFSLoginException("Login failed. User not found: " + name, data);
    }
    
    private void raiseActivationError(final String name) throws SFSLoginException {
        final SFSErrorData data = new SFSErrorData(SFSErrorCode.GENERIC_ERROR);
        data.addParameter(this.config.activationErrorMessage);
        throw new SFSLoginException("Account is not active. User: " + name, data);
    }
    
    private LoginData populateLoginData(final ISFSArray result) {
        final LoginData data = new LoginData();
        final ISFSObject record = result.getSFSObject(0);
        data.userName = record.getUtfString(this.config.userNameField);
        data.password = record.getUtfString(this.config.passwordField);
        if (this.config.nickNameField != null) {
            data.nickName = record.getUtfString(this.config.nickNameField);
        }
        if (this.config.activationField != null) {
            data.isActive = record.getUtfString(this.config.activationField).equalsIgnoreCase("Y");
        }
        if (this.config.extraFields != null) {
            data.extraFields = record;
        }
        return data;
    }
    
    private String prepareSelect() {
        final StringBuilder sb = new StringBuilder("SELECT ").append(this.config.userNameField).append(",").append(this.config.passwordField);
        if (this.config.nickNameField != null) {
            sb.append(",").append(this.config.nickNameField);
        }
        if (this.config.activationField != null) {
            sb.append(",").append(this.config.activationField);
        }
        if (this.config.extraFields != null) {
            for (final String item : this.config.extraFields) {
                sb.append(",").append(item);
            }
        }
        sb.append(" FROM ").append(this.config.loginTable).append(" WHERE ").append(this.config.userNameField).append("=").append("?");
        return sb.toString();
    }
    
    private void throwPasswordException(final String userName) throws SFSLoginException {
        final SFSErrorData data = new SFSErrorData(SFSErrorCode.LOGIN_BAD_PASSWORD);
        data.addParameter(userName);
        throw new SFSLoginException("Login failed. Password don't match for User: " + userName, data);
    }
}

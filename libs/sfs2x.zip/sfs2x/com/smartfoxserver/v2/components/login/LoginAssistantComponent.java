// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.login;

import com.smartfoxserver.v2.core.ISFSEventListener;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.extensions.ExtensionLevel;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.extensions.ISFSExtension;

public class LoginAssistantComponent
{
    private final ISFSExtension extension;
    private final LoginConfiguration config;
    private final LoginAssistantEventHandler handler;
    
    public LoginAssistantComponent(final ISFSExtension ext) {
        if (ext == null) {
            throw new SFSRuntimeException("Invalid Extension Reference. Can't be null.");
        }
        if (ext.getLevel() == ExtensionLevel.ROOM) {
            throw new SFSRuntimeException("LoginAssistant doesn't work with ROOM LEVEL Extensions!");
        }
        this.extension = ext;
        this.config = new LoginConfiguration();
        this.handler = new LoginAssistantEventHandler(this.config, this.extension);
        this.extension.addEventListener(SFSEventType.USER_LOGIN, this.handler);
        this.extension.getParentZone().setCustomLogin(true);
    }
    
    public void destroy() {
        this.extension.removeEventListener(SFSEventType.USER_LOGIN, this.handler);
    }
    
    public LoginConfiguration getConfig() {
        return this.config;
    }
}

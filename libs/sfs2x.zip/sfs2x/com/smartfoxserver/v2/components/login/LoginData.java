// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.login;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.sessions.ISession;

public final class LoginData
{
    public ISession session;
    public String userName;
    public String password;
    public String nickName;
    public boolean isActive;
    public ISFSObject extraFields;
    public ISFSObject clientIncomingData;
    public ISFSObject clientOutGoingData;
}

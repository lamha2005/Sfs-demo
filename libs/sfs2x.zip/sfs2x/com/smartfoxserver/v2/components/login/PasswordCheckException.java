// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.login;

public class PasswordCheckException extends RuntimeException
{
    private static final long serialVersionUID = 1L;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.login;

import com.smartfoxserver.v2.db.IDBManager;
import java.util.List;

public final class LoginConfiguration
{
    public String loginTable;
    public String userNameField;
    public String passwordField;
    public boolean customPasswordCheck;
    public boolean useCaseSensitiveNameChecks;
    public boolean allowGuests;
    public String nickNameField;
    public String activationField;
    public String activationErrorMessage;
    public List<String> extraFields;
    public ILoginAssistantPlugin preProcessPlugin;
    public ILoginAssistantPlugin postProcessPlugin;
    public IDBManager customDBManager;
    
    public LoginConfiguration() {
        this.loginTable = "users";
        this.userNameField = "username";
        this.passwordField = "password";
        this.customPasswordCheck = false;
        this.useCaseSensitiveNameChecks = false;
        this.allowGuests = true;
        this.nickNameField = null;
        this.activationField = null;
        this.activationErrorMessage = "Your account is not active. Please check your email for the activation code.";
        this.extraFields = null;
        this.preProcessPlugin = null;
        this.postProcessPlugin = null;
        this.customDBManager = null;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import java.sql.SQLException;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.Arrays;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class CustomFieldPasswordRecovery implements IPasswordRecovery
{
    private static final String KEY_RECOVERY_MATCH_FIELD = "field";
    private static final String KEY_RECOVERY_MATCH_VALUE = "value";
    private final Logger log;
    
    public CustomFieldPasswordRecovery() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public ISFSObject recover(final SignUpAssistantComponent suac, final User user, final ISFSObject params) throws SQLException {
        ISFSObject dbParams = null;
        final SignUpConfiguration config = suac.getConfig();
        final String matchField = params.getUtfString("field");
        final String matchValue = params.getUtfString("value");
        if (matchField == null) {
            throw new IllegalArgumentException("No field name was specified for password recovery: " + user);
        }
        if (matchValue == null) {
            throw new IllegalArgumentException("No search value was specified for password recovery: " + user);
        }
        if (!config.passwordRecovery.allowedRecoveryFields.contains(matchField)) {
            throw new IllegalArgumentException("Provided field for password recovery is not allowed: " + matchField);
        }
        final String sql = String.format("SELECT %s, %s, %s FROM %s WHERE %s=?", config.usernameField, config.passwordField, config.emailField, config.signUpTable, matchField);
        final Object[] sqlParams = { matchValue };
        if (config.logSQL) {
            this.log.info("Password Recovery SQL: " + sql.toString() + ", " + Arrays.asList(sqlParams));
        }
        final ISFSArray res = suac.getDbManager().executeQuery(sql, sqlParams);
        if (res.size() > 0) {
            final ISFSObject row = dbParams = res.getSFSObject(0);
        }
        return dbParams;
    }
}

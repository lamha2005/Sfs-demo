// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import java.sql.SQLException;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.Arrays;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class LegacyPasswordRecovery implements IPasswordRecovery
{
    private final Logger log;
    
    public LegacyPasswordRecovery() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public ISFSObject recover(final SignUpAssistantComponent suac, final User user, final ISFSObject params) throws SQLException {
        ISFSObject dbParams = null;
        final SignUpConfiguration config = suac.getConfig();
        final String userName = params.getUtfString(config.usernameField);
        if (userName == null) {
            throw new IllegalArgumentException("No user name specified for Password Recovery request: " + user);
        }
        final String sql = String.format("SELECT %s, %s, %s FROM %s WHERE %s=?", config.usernameField, config.passwordField, config.emailField, config.signUpTable, config.usernameField);
        final Object[] sqlParams = { userName };
        if (config.logSQL) {
            this.log.info("Password Recovery SQL: " + sql.toString() + ", " + Arrays.asList(sqlParams));
        }
        final ISFSArray res = suac.getDbManager().executeQuery(sql, sqlParams);
        if (res.size() > 0) {
            final ISFSObject row = res.getSFSObject(0);
            final String dbUserName = row.getUtfString(config.usernameField);
            if (config.passwordRecovery.useCaseSensitiveNameCheck && !userName.equals(dbUserName)) {
                throw new IllegalArgumentException("Password Recovery Error: the provided user name does not match DB user name.");
            }
            dbParams = row;
        }
        return dbParams;
    }
}

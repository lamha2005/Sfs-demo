// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import com.smartfoxserver.v2.entities.User;

public interface IPasswordManager
{
    String encodePassword(final String p0);
    
    String[] generateRandom(final User p0);
}

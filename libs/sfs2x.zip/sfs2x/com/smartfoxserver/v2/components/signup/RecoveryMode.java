// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

public enum RecoveryMode
{
    SEND_OLD("SEND_OLD", 0), 
    GENERATE_NEW("GENERATE_NEW", 1);
    
    private RecoveryMode(final String s, final int n) {
    }
}

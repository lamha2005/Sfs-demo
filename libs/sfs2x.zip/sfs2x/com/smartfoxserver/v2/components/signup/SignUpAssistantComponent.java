// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import javax.mail.MessagingException;
import com.smartfoxserver.v2.entities.managers.IMailerCallbackHandler;
import com.smartfoxserver.v2.entities.Email;
import com.smartfoxserver.v2.entities.SFSEmail;
import com.smartfoxserver.v2.util.MD5;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.db.IDBManager;
import java.util.Arrays;
import com.smartfoxserver.v2.entities.managers.IMailerService;
import java.sql.SQLException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import org.slf4j.LoggerFactory;
import java.util.Random;
import org.slf4j.Logger;
import com.smartfoxserver.v2.annotations.MultiHandler;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

@MultiHandler
public class SignUpAssistantComponent extends BaseClientRequestHandler
{
    static final String LOGGER_ID = "com.smartfoxserver.v2.components.signup.SignUpAssistant";
    private static final String SESSION_DBID = "$SignUp.DBID";
    public static final String COMMAND_PREFIX = "$SignUp";
    private static final String CMD_SUBMIT = "Submit";
    private static final String CMD_RECOVER = "Recover";
    private static final String CMD_ACTIVATE = "Activate";
    private static final String CMD_RESEND_ACTIVATION_EMAIL = "ResendEmail";
    private static final String KEY_ACTIVATION_PARAMS = "ActivationParams";
    private static final String KEY_ACTIVATION_EMAIL_COUNT = "ActivationEmailCount";
    private final Logger log;
    private final SignUpConfiguration config;
    private final ISignUpValidator submitValidator;
    private final Random random;
    private final IPasswordManager passwordManager;
    private EmailCallbackHandler emailCallbackHandler;
    
    public SignUpAssistantComponent() {
        this.log = LoggerFactory.getLogger("com.smartfoxserver.v2.components.signup.SignUpAssistant");
        this.config = new SignUpConfiguration();
        this.passwordManager = new PasswordManager(this.config);
        this.submitValidator = new SignUpValidator(this.config);
        this.random = new Random();
    }
    
    public SignUpConfiguration getConfig() {
        return this.config;
    }
    
    @Override
    public void handleClientRequest(final User sender, final ISFSObject params) {
        final String cmd = params.getUtfString("__[[REQUEST_ID]]__");
        if (cmd.equals("Submit")) {
            this.handleSubmit(sender, params);
        }
        else if (cmd.equals("Recover")) {
            this.handlePasswordRecover(sender, params);
        }
        else if (cmd.equals("Activate")) {
            this.handleActivation(sender, params);
        }
        else if (cmd.equals("ResendEmail")) {
            this.handleResendActivationEmail(sender, params);
        }
        else {
            this.log.warn("Unknown sign up command: " + cmd);
        }
    }
    
    private void handleResendActivationEmail(final User sender, final ISFSObject userParams) {
        if (this.config.activationCodeField == null) {
            return;
        }
        ISFSObject params = null;
        ISFSObject response = null;
        try {
            params = (ISFSObject)sender.getSession().getSystemProperty("ActivationParams");
            if (params == null) {
                final IMailerService emailer = SmartFoxServer.getInstance().getMailService();
                if (emailer == null || !emailer.getConfiguration().isActive) {
                    return;
                }
                if (!userParams.containsKey(this.config.emailField)) {
                    this.log.warn("Missing email in request, from: " + sender);
                    return;
                }
                response = new SFSObject();
                params = this.loadParamsFromDB(userParams);
                sender.getSession().setSystemProperty("ActivationParams", (Object)params);
                if (this.config.postProcessPlugin != null) {
                    this.config.postProcessPlugin.execute(sender, response, this.config);
                }
            }
            AtomicInteger count = (AtomicInteger)sender.getSession().getSystemProperty("ActivationEmailCount");
            if (count == null) {
                count = new AtomicInteger(1);
                sender.getSession().setSystemProperty("ActivationEmailCount", (Object)count);
            }
            if (params == null || count == null) {
                this.log.warn("Cannot resend email, user never completed the signup process: " + sender);
                return;
            }
            if (count.incrementAndGet() <= this.config.emailResponse.maxResendTimes) {
                if (this.log.isDebugEnabled()) {
                    this.log.debug("Resending confirmation email for user: " + sender + ", attempt #" + count.get());
                }
                this.sendConfirmationEmail(params);
                if (response != null) {
                    response.putBool("success", true);
                }
            }
            else {
                this.log.warn("User has requested too many email resend: " + sender);
            }
        }
        catch (SignUpValidationException sve) {
            final String errorMessage = String.format(this.config.errorMessages.get(sve.getCode()), sve.getParams());
            this.log.warn(String.valueOf(errorMessage) + ", from " + sender);
            response.putUtfString("errorMessage", errorMessage);
        }
        catch (SQLException sqle) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(sqle);
            emc.setDescription("A SQL error occurred during the EmailResend process");
            emc.addInfo("User info: " + sender.toString());
            this.log.warn(emc.toString());
            response.putUtfString("errorMessage", String.format(this.config.errorMessages.get(SignUpErrorCodes.INVALID_EMAIL), ""));
        }
        catch (Exception e) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
            emc.setDescription("Unexpected exception occurred during the EmailResend process");
            this.log.warn(emc.toString());
            return;
        }
        if (response != null) {
            this.send("$SignUp.ResendEmail", response, sender);
        }
    }
    
    private void handleActivation(final User sender, final ISFSObject params) {
        if (this.config.activationCodeField == null) {
            return;
        }
        final IDBManager dbManager = this.getDbManager();
        final ISFSObject response = new SFSObject();
        try {
            this.checkValidation(dbManager, sender, params);
            final String activationCode = params.getUtfString(this.config.activationCodeField);
            final String sql = String.format("UPDATE %s SET %s=? WHERE %s=?", this.config.signUpTable, this.config.userIsActiveField, this.config.activationCodeField);
            final Object[] sqlParams = { "Y", activationCode };
            if (this.config.logSQL) {
                this.log.info("Activation SQL: " + sql.toString() + ", " + Arrays.asList(sqlParams));
            }
            dbManager.executeUpdate(sql, sqlParams);
            response.putBool("success", true);
        }
        catch (SignUpValidationException sve) {
            final String errorMessage = String.format(this.config.errorMessages.get(sve.getCode()), sve.getParams());
            this.log.warn(String.valueOf(errorMessage) + ", from: " + sender);
            response.putUtfString("errorMessage", errorMessage);
        }
        catch (SQLException sqle) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(sqle);
            emc.setDescription("A SQL error occurred during the Activation process");
            emc.addInfo("User info: " + sender.toString());
            this.log.warn(emc.toString());
            response.putUtfString("errorMessage", String.format(this.config.errorMessages.get(SignUpErrorCodes.GENERIC_DB_ERROR), ""));
        }
        catch (Exception e) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
            emc.setDescription("Unexpected exception occurred during the Activation process");
            this.log.warn(emc.toString());
            return;
        }
        this.send("$SignUp.Activate", response, sender);
    }
    
    private void checkValidation(final IDBManager dbManager, final User sender, final ISFSObject params) throws SignUpValidationException, SQLException {
        final String activationCode = params.getUtfString(this.config.activationCodeField);
        if (activationCode == null || activationCode.length() != 32) {
            throw new SignUpValidationException(SignUpErrorCodes.ACTIVATION_INVALID_CODE, new Object[0]);
        }
        final String sql = String.format("SELECT %s, %s FROM %s WHERE %s=?", this.config.idField, this.config.activationCodeField, this.config.signUpTable, this.config.activationCodeField);
        final Object[] sqlParams = { activationCode };
        if (this.config.logSQL) {
            this.log.info("Activation SQL: " + sql.toString() + ", " + Arrays.asList(sqlParams));
        }
        final ISFSArray result = dbManager.executeQuery(sql, sqlParams);
        if (result.size() < 1) {
            throw new SignUpValidationException(SignUpErrorCodes.ACTIVATION_INVALID_CODE, new Object[0]);
        }
    }
    
    private void handleSubmit(final User user, final ISFSObject params) {
        final IDBManager dbManager = this.getDbManager();
        ISFSObject response = new SFSObject();
        try {
            this.submitValidator.validate(dbManager, params);
            if (this.config.preProcessPlugin != null) {
                this.config.preProcessPlugin.execute(user, params, this.config);
            }
            if (this.config.activationCodeField != null) {
                this.generateActivationCode(params);
            }
            final long id = this.writeToDatabase(dbManager, params);
            response = new SFSObject();
            response.putBool("success", true);
            user.getSession().setProperty("$SignUp.DBID", (Object)id);
            user.getSession().setSystemProperty("ActivationParams", (Object)params);
            if (this.config.postProcessPlugin != null) {
                this.config.postProcessPlugin.execute(user, response, this.config);
            }
            final IMailerService emailer = SmartFoxServer.getInstance().getMailService();
            if (this.config.emailResponse.isActive && emailer != null && emailer.getConfiguration().isActive) {
                user.getSession().setSystemProperty("ActivationEmailCount", (Object)new AtomicInteger(1));
                this.sendConfirmationEmail(params);
            }
        }
        catch (SignUpValidationException sve) {
            final String errorMessage = String.format(this.config.errorMessages.get(sve.getCode()), sve.getParams());
            this.log.warn(String.valueOf(errorMessage) + ", from " + user);
            response.putUtfString("errorMessage", errorMessage);
        }
        catch (SQLException sqle) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(sqle);
            emc.setDescription("A SQL error occurred during the SignUp process");
            emc.addInfo("User info: " + user.toString());
            this.log.warn(emc.toString());
            response.putUtfString("errorMessage", String.format(this.config.errorMessages.get(SignUpErrorCodes.GENERIC_DB_ERROR), new Object[0]));
        }
        catch (Throwable e) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
            emc.setDescription("Unexpected exception occurred during the SignUp process");
            emc.addInfo("User info: " + user.toString());
            this.log.warn(emc.toString());
            return;
        }
        this.send("$SignUp.Submit", response, user);
    }
    
    private long writeToDatabase(final IDBManager dbManager, final ISFSObject params) throws SQLException {
        final String thePassword = this.passwordManager.encodePassword(params.getUtfString(this.config.passwordField));
        final List<Object> sqlParams = new ArrayList<Object>();
        sqlParams.add(params.getUtfString(this.config.usernameField));
        sqlParams.add(thePassword);
        final StringBuilder placeHolders = new StringBuilder("?,?");
        final StringBuilder sql = new StringBuilder("INSERT INTO ").append(this.config.signUpTable).append(" (");
        sql.append(this.config.usernameField).append(",").append(this.config.passwordField);
        if (this.config.isEmailRequired) {
            sql.append(",").append(this.config.emailField);
            placeHolders.append(",?");
            sqlParams.add(params.getUtfString(this.config.emailField));
        }
        if (this.config.activationCodeField != null) {
            sql.append(",").append(this.config.activationCodeField);
            placeHolders.append(",?");
            sqlParams.add(params.getUtfString(this.config.activationCodeField));
        }
        if (this.config.extraFields != null) {
            for (final String item : this.config.extraFields) {
                if (params.containsKey(item)) {
                    sql.append(",").append(item);
                    placeHolders.append(",?");
                    sqlParams.add(params.get(item).getObject());
                }
            }
        }
        sql.append(") VALUES (").append((CharSequence)placeHolders).append(")");
        if (this.config.logSQL) {
            this.log.info("SignUp SQL: " + sql.toString() + ", " + sqlParams);
        }
        final Object id = dbManager.executeInsert(sql.toString(), sqlParams.toArray());
        if (id instanceof String) {
            return Long.parseLong((String)id);
        }
        return ((Number)id).longValue();
    }
    
    private ISFSObject loadParamsFromDB(final ISFSObject userParams) throws SQLException, SignUpValidationException {
        final String email = userParams.getUtfString(this.config.emailField);
        final String sql = String.format("SELECT * FROM %s WHERE %s=?", this.config.signUpTable, this.config.emailField);
        final Object[] sqlParams = { email };
        if (this.config.logSQL) {
            this.log.info("Email Resend SQL: " + sql.toString() + ", " + Arrays.asList(sqlParams));
        }
        final ISFSArray res = this.getDbManager().executeQuery(sql, sqlParams);
        if (res.size() < 1) {
            throw new SignUpValidationException(SignUpErrorCodes.INVALID_EMAIL, new Object[] { email });
        }
        return res.getSFSObject(0);
    }
    
    private void generateActivationCode(final ISFSObject params) {
        final String code = String.valueOf(params.getUtfString(this.config.usernameField)) + System.currentTimeMillis() + this.random.nextDouble();
        params.putUtfString(this.config.activationCodeField, MD5.getInstance().getHash(code));
    }
    
    private void sendConfirmationEmail(final ISFSObject params) {
        final EmailComposer composer = new EmailComposer(this.getParentExtension().getCurrentFolder(), this.config, params);
        final SFSEmail email = new SFSEmail(this.config.emailResponse.fromAddress, params.getUtfString(this.config.emailField), this.config.emailResponse.subject, composer.generate());
        if (this.emailCallbackHandler == null) {
            this.emailCallbackHandler = new EmailCallbackHandler();
        }
        try {
            SmartFoxServer.getInstance().getMailService().sendMail(email, this.emailCallbackHandler);
            this.log.info("Email sent: " + email);
        }
        catch (MessagingException e) {
            this.log.warn("An error occurred while sending a SignUp email to: " + email.getToAddress() + " -- " + e);
        }
    }
    
    private void handlePasswordRecover(final User user, final ISFSObject params) {
        if (!this.config.passwordRecovery.isActive) {
            return;
        }
        if (this.config.passwordMode == PasswordMode.MD5) {
            this.config.passwordRecovery.mode = RecoveryMode.GENERATE_NEW;
        }
        final ISFSObject response = new SFSObject();
        try {
            if (this.config.passwordRecovery.mode == RecoveryMode.SEND_OLD) {
                this.sendOldPassword(user, params);
            }
            else {
                this.generateNewPassword(user, params);
            }
            response.putBool("success", true);
        }
        catch (SignUpValidationException sve) {
            final String errorMessage = String.format(this.config.errorMessages.get(sve.getCode()), sve.getParams());
            this.log.warn(String.valueOf(errorMessage) + " - From: " + user);
            response.putUtfString("errorMessage", errorMessage);
        }
        catch (SQLException sqle) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(sqle);
            emc.setDescription("A SQL error occurred during the Password Recovery process");
            emc.addInfo("User info: " + user.toString());
            this.log.warn(emc.toString());
            response.putUtfString("errorMessage", String.format(this.config.errorMessages.get(SignUpErrorCodes.GENERIC_DB_ERROR), new Object[0]));
        }
        this.send("$SignUp.Recover", response, user);
    }
    
    private void sendOldPassword(final User user, final ISFSObject params) throws SignUpValidationException, SQLException {
        final ISFSObject dbParams = this.getOldPassword(user, params);
        if (dbParams == null) {
            throw new SignUpValidationException(SignUpErrorCodes.RECOVER_NO_USER, new Object[] { params.getUtfString(this.config.usernameField) });
        }
        this.sendRecoveryEmail(dbParams);
    }
    
    private void generateNewPassword(final User user, final ISFSObject params) throws SignUpValidationException, SQLException {
        final ISFSObject dbParams = this.getOldPassword(user, params);
        if (dbParams == null) {
            throw new SignUpValidationException(SignUpErrorCodes.RECOVER_NO_USER, new Object[] { params.getUtfString(this.config.usernameField) });
        }
        final String password = this.setNewRandomPassword(user, params);
        dbParams.putUtfString(this.config.passwordField, password);
        this.sendRecoveryEmail(dbParams);
    }
    
    private String setNewRandomPassword(final User user, final ISFSObject params) throws SQLException {
        final String[] result = this.passwordManager.generateRandom(user);
        final String clearPassword = result[0];
        final String encodedPassword = result[1];
        final String sql = String.format("UPDATE %s SET %s=? WHERE %s=?", this.config.signUpTable, this.config.passwordField, this.config.usernameField);
        final Object[] sqlParams = { (encodedPassword == null) ? clearPassword : encodedPassword, params.getUtfString(this.config.usernameField) };
        if (this.config.logSQL) {
            this.log.info("Password Recovery SQL: " + sql.toString() + ", " + Arrays.asList(sqlParams));
        }
        this.getDbManager().executeUpdate(sql, sqlParams);
        return clearPassword;
    }
    
    private ISFSObject getOldPassword(final User user, final ISFSObject params) throws SQLException {
        IPasswordRecovery recoveryTool;
        if (this.config.passwordRecovery.allowedRecoveryFields == null) {
            recoveryTool = new LegacyPasswordRecovery();
        }
        else {
            recoveryTool = new CustomFieldPasswordRecovery();
        }
        return recoveryTool.recover(this, user, params);
    }
    
    private void sendRecoveryEmail(final ISFSObject params) {
        final RecoveryEmailComposer composer = new RecoveryEmailComposer(this.getParentExtension().getCurrentFolder(), this.config, params);
        final SFSEmail email = new SFSEmail(this.config.passwordRecovery.email.fromAddress, params.getUtfString(this.config.emailField), this.config.passwordRecovery.email.subject, composer.generate());
        if (this.emailCallbackHandler == null) {
            this.emailCallbackHandler = new EmailCallbackHandler();
        }
        try {
            SmartFoxServer.getInstance().getMailService().sendMail(email, this.emailCallbackHandler);
            this.log.info("Email sent: " + email);
        }
        catch (MessagingException e) {
            this.log.warn("An error occurred while sending an email to: " + email.getToAddress() + " -- " + e);
        }
    }
    
    public IDBManager getDbManager() {
        return (this.config.customDbManager != null) ? this.config.customDbManager : this.getParentExtension().getParentZone().getDBManager();
    }
}

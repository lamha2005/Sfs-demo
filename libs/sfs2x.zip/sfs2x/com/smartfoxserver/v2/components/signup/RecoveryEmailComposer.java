// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import java.util.Iterator;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.File;
import com.smartfoxserver.v2.entities.data.ISFSObject;

final class RecoveryEmailComposer
{
    private static final String TOKEN_USER_NAME = "${userName}";
    private static final String TOKEN_USER_PASS = "${password}";
    private final SignUpConfiguration config;
    private final String path;
    private final ISFSObject params;
    
    public RecoveryEmailComposer(final String path, final SignUpConfiguration config, final ISFSObject params) {
        this.config = config;
        this.path = path;
        this.params = params;
    }
    
    public String generate() {
        final File emailTemplate = new File(String.valueOf(this.path) + "/" + this.config.passwordRecovery.email.template);
        String html = null;
        try {
            html = FileUtils.readFileToString(emailTemplate);
            html = html.replace("${userName}", this.params.getUtfString(this.config.usernameField));
            html = html.replace("${password}", this.params.getUtfString(this.config.passwordField));
            if (this.config.passwordRecovery.email.customEmailFields != null) {
                for (final String key : this.config.passwordRecovery.email.customEmailFields.keySet()) {
                    if (key.startsWith("${") && key.endsWith("}")) {
                        html = html.replace(key, this.config.passwordRecovery.email.customEmailFields.get(key));
                    }
                }
            }
        }
        catch (IOException e) {
            throw new IllegalStateException("The email template could not be found at: " + emailTemplate);
        }
        return html;
    }
}

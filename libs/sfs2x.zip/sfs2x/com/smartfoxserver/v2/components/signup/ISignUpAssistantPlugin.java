// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;

public interface ISignUpAssistantPlugin
{
    void execute(final User p0, final ISFSObject p1, final SignUpConfiguration p2) throws SignUpValidationException;
}

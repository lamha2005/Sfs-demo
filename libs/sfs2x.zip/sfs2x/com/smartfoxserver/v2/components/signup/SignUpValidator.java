// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.sql.SQLException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.db.IDBManager;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class SignUpValidator implements ISignUpValidator
{
    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    private final SignUpConfiguration config;
    private final Pattern pattern;
    private Matcher matcher;
    private IDBManager dbManager;
    private final Logger log;
    
    public SignUpValidator(final SignUpConfiguration config) {
        this.dbManager = null;
        this.config = config;
        this.pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        this.log = LoggerFactory.getLogger("com.smartfoxserver.v2.components.signup.SignUpAssistant");
    }
    
    @Override
    public void validate(final IDBManager dbManager, final ISFSObject data) throws SignUpValidationException {
        this.dbManager = dbManager;
        this.checkMissingParameters(data);
        this.checkFormalIntegrity(data);
        this.checkDuplicateFields(data);
    }
    
    private void checkMissingParameters(final ISFSObject data) throws SignUpValidationException {
        if (!data.containsKey(this.config.usernameField) || data.getUtfString(this.config.usernameField).length() < 1) {
            throw new SignUpValidationException(SignUpErrorCodes.MISSING_USERNAME, new Object[0]);
        }
        if (!data.containsKey(this.config.passwordField) || data.getUtfString(this.config.passwordField).length() < 1) {
            throw new SignUpValidationException(SignUpErrorCodes.MISSING_PASSWORD, new Object[0]);
        }
        if (this.config.isEmailRequired && (!data.containsKey(this.config.emailField) || data.getUtfString(this.config.emailField).length() < 1)) {
            throw new SignUpValidationException(SignUpErrorCodes.MISSING_EMAIL, new Object[0]);
        }
    }
    
    private void checkFormalIntegrity(final ISFSObject data) throws SignUpValidationException {
        final String userName = data.getUtfString(this.config.usernameField);
        if (userName == null) {
            throw new SignUpValidationException(SignUpErrorCodes.MISSING_USERNAME, new Object[0]);
        }
        if (userName.length() < this.config.minUserNameLength) {
            throw new SignUpValidationException(SignUpErrorCodes.USERNAME_TOO_SHORT, new Object[] { String.valueOf(this.config.minUserNameLength) });
        }
        if (userName.length() > this.config.maxUserNameLength) {
            throw new SignUpValidationException(SignUpErrorCodes.USERNAME_TOO_LONG, new Object[] { String.valueOf(this.config.maxUserNameLength) });
        }
        final String pass = data.getUtfString(this.config.passwordField);
        if (pass == null) {
            throw new SignUpValidationException(SignUpErrorCodes.MISSING_PASSWORD, new Object[0]);
        }
        if (pass.length() < this.config.minPasswordLength) {
            throw new SignUpValidationException(SignUpErrorCodes.PASSWORD_TOO_SHORT, new Object[] { String.valueOf(this.config.minPasswordLength) });
        }
        if (pass.length() > this.config.maxPasswordLength) {
            throw new SignUpValidationException(SignUpErrorCodes.PASSWORD_TOO_LONG, new Object[] { String.valueOf(this.config.maxPasswordLength) });
        }
        if (this.config.isEmailRequired) {
            final String email = data.getUtfString(this.config.emailField);
            if (email.length() > this.config.maxEmailLength || !this.isValidEmail(email)) {
                throw new SignUpValidationException(SignUpErrorCodes.INVALID_EMAIL, new Object[] { email });
            }
        }
    }
    
    private void checkDuplicateFields(final ISFSObject data) throws SignUpValidationException {
        String sql = null;
        if (this.config.checkForDuplicateUserNames) {
            sql = String.format("SELECT %s FROM %s WHERE %s=?", this.config.usernameField, this.config.signUpTable, this.config.usernameField);
            try {
                final String name = data.getUtfString(this.config.usernameField);
                final ISFSArray res = this.dbManager.executeQuery(sql, new Object[] { name });
                if (res.size() > 0) {
                    throw new SignUpValidationException(SignUpErrorCodes.USERNAME_ALREADY_IN_USE, new Object[] { name });
                }
            }
            catch (SQLException e) {
                this.log.warn("Unexpected SQL Error while checking for duplicate user names: " + e);
            }
        }
        if (this.config.checkForDuplicateEmails) {
            sql = String.format("SELECT %s FROM %s WHERE %s=?", this.config.emailField, this.config.signUpTable, this.config.emailField);
            try {
                final String email = data.getUtfString(this.config.emailField);
                final ISFSArray res = this.dbManager.executeQuery(sql, new Object[] { email });
                if (res.size() > 0) {
                    throw new SignUpValidationException(SignUpErrorCodes.EMAIL_ALREADY_IN_USE, new Object[] { email });
                }
            }
            catch (SQLException e) {
                this.log.warn("Unexpected SQL Error while checking for duplicate user names: " + e);
            }
        }
    }
    
    public boolean isValidEmail(final String email) {
        this.matcher = this.pattern.matcher(email);
        return this.matcher.matches();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import java.util.HashMap;
import java.util.List;
import com.smartfoxserver.v2.db.IDBManager;
import java.util.Map;

public class SignUpConfiguration
{
    public final Map<SignUpErrorCodes, String> errorMessages;
    public IDBManager customDbManager;
    public String signUpTable;
    public String idField;
    public String usernameField;
    public String passwordField;
    public String emailField;
    public PasswordMode passwordMode;
    public String activationCodeField;
    public String userIsActiveField;
    public List<String> extraFields;
    public ISignUpAssistantPlugin preProcessPlugin;
    public ISignUpAssistantPlugin postProcessPlugin;
    public boolean checkForDuplicateUserNames;
    public boolean checkForDuplicateEmails;
    public boolean isEmailRequired;
    public EmailConfig emailResponse;
    public int minUserNameLength;
    public int maxUserNameLength;
    public int minPasswordLength;
    public int maxPasswordLength;
    public int maxEmailLength;
    public boolean logSQL;
    public PasswordRecovery passwordRecovery;
    
    public SignUpConfiguration() {
        this.errorMessages = new HashMap<SignUpErrorCodes, String>();
        this.customDbManager = null;
        this.signUpTable = "users";
        this.idField = "id";
        this.usernameField = "username";
        this.passwordField = "password";
        this.emailField = "email";
        this.passwordMode = PasswordMode.PLAIN_TEXT;
        this.activationCodeField = null;
        this.userIsActiveField = "active";
        this.extraFields = null;
        this.preProcessPlugin = null;
        this.postProcessPlugin = null;
        this.checkForDuplicateUserNames = true;
        this.checkForDuplicateEmails = true;
        this.isEmailRequired = true;
        this.emailResponse = new EmailConfig();
        this.minUserNameLength = 4;
        this.maxUserNameLength = 30;
        this.minPasswordLength = 6;
        this.maxPasswordLength = 30;
        this.maxEmailLength = 50;
        this.logSQL = false;
        this.passwordRecovery = new PasswordRecovery();
        this.populateDefaultErrorMessages();
    }
    
    private void populateDefaultErrorMessages() {
        this.errorMessages.put(SignUpErrorCodes.MISSING_USERNAME, "User name is required");
        this.errorMessages.put(SignUpErrorCodes.MISSING_PASSWORD, "Password is required");
        this.errorMessages.put(SignUpErrorCodes.MISSING_EMAIL, "An email is required");
        this.errorMessages.put(SignUpErrorCodes.USERNAME_ALREADY_IN_USE, "Username: %s is already in use");
        this.errorMessages.put(SignUpErrorCodes.USERNAME_TOO_SHORT, "User name is too short, min. amount of characters is %s");
        this.errorMessages.put(SignUpErrorCodes.USERNAME_TOO_LONG, "User name is too long, max. amount of characters is %s");
        this.errorMessages.put(SignUpErrorCodes.PASSWORD_TOO_SHORT, "Password is too short, min. amount of characters is %s");
        this.errorMessages.put(SignUpErrorCodes.PASSWORD_TOO_LONG, "Password is too long, max. amount of characters is %s");
        this.errorMessages.put(SignUpErrorCodes.INVALID_EMAIL, "Email address: %s  is invalid");
        this.errorMessages.put(SignUpErrorCodes.EMAIL_ALREADY_IN_USE, "Email address: %s is already in use");
        this.errorMessages.put(SignUpErrorCodes.RECOVER_NO_USER, "Password recovery error, username %s was not found");
        this.errorMessages.put(SignUpErrorCodes.ACTIVATION_NO_ID, "Invalid Activation. Session doesn't contain a database ID");
        this.errorMessages.put(SignUpErrorCodes.ACTIVATION_INVALID_CODE, "Invalid Activation Code received");
        this.errorMessages.put(SignUpErrorCodes.GENERIC_DB_ERROR, "Unexpected Database Error. Please contact our support");
        this.errorMessages.put(SignUpErrorCodes.CUSTOM_ERROR, "%s");
    }
    
    public static final class PasswordRecovery
    {
        public boolean isActive;
        public boolean useCaseSensitiveNameCheck;
        public List<String> allowedRecoveryFields;
        public RecoveryMode mode;
        public EmailConfig email;
        
        public PasswordRecovery() {
            this.isActive = false;
            this.useCaseSensitiveNameCheck = true;
            this.allowedRecoveryFields = null;
            this.mode = RecoveryMode.SEND_OLD;
            this.email = new EmailConfig();
        }
    }
    
    public static final class EmailConfig
    {
        public boolean isActive;
        public String template;
        public String fromAddress;
        public String subject;
        public Map<String, String> customEmailFields;
        public int maxResendTimes;
        
        public EmailConfig() {
            this.isActive = false;
            this.template = "template.html";
            this.customEmailFields = null;
            this.maxResendTimes = 3;
        }
    }
}

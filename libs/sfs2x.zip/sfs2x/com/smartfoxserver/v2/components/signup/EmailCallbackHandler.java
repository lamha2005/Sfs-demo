// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import com.smartfoxserver.v2.entities.Email;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.managers.IMailerCallbackHandler;

final class EmailCallbackHandler implements IMailerCallbackHandler
{
    private final Logger log;
    
    EmailCallbackHandler() {
        this.log = LoggerFactory.getLogger("com.smartfoxserver.v2.components.signup.SignUpAssistant");
    }
    
    @Override
    public void onSuccess(final Email email) {
        if (this.log.isDebugEnabled()) {
            this.log.info("Email successfully sent to: " + email.getToAddress());
        }
    }
    
    @Override
    public void onError(final Email email, final Exception e) {
        this.log.warn("An error occurred while sending an email to: " + email.getToAddress() + " -- " + e);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.db.IDBManager;

public interface ISignUpValidator
{
    void validate(final IDBManager p0, final ISFSObject p1) throws SignUpValidationException;
}

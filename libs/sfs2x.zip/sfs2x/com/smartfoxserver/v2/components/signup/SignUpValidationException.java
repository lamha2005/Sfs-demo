// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

public class SignUpValidationException extends Exception
{
    private static final long serialVersionUID = 1593973269968552498L;
    private SignUpErrorCodes code;
    private Object[] params;
    
    public SignUpValidationException(final SignUpErrorCodes code, final Object... params) {
        this.code = code;
        this.params = params;
    }
    
    public SignUpErrorCodes getCode() {
        return this.code;
    }
    
    public Object[] getParams() {
        return this.params;
    }
}

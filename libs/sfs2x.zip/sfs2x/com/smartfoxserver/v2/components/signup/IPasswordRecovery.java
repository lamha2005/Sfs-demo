// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import java.sql.SQLException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;

public interface IPasswordRecovery
{
    ISFSObject recover(final SignUpAssistantComponent p0, final User p1, final ISFSObject p2) throws SQLException;
}

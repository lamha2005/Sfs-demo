// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

public enum PasswordMode
{
    PLAIN_TEXT("PLAIN_TEXT", 0), 
    MD5("MD5", 1);
    
    private PasswordMode(final String s, final int n) {
    }
}

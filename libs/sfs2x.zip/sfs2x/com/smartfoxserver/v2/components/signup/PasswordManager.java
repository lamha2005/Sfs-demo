// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.components.signup;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.util.MD5;

final class PasswordManager implements IPasswordManager
{
    private static final int PLAIN_RANDOM_PASS_LEN = 10;
    private final SignUpConfiguration cfg;
    
    public PasswordManager(final SignUpConfiguration cfg) {
        this.cfg = cfg;
    }
    
    @Override
    public String encodePassword(final String original) {
        if (this.cfg.passwordMode == PasswordMode.MD5) {
            return MD5.getInstance().getHash(original);
        }
        return original;
    }
    
    @Override
    public String[] generateRandom(final User user) {
        final String newRandomPass = MD5.getInstance().getHash(String.valueOf(user.getName()) + user.getSession().getHashId() + System.currentTimeMillis()).substring(0, 10);
        String md5Password = null;
        if (this.cfg.passwordMode == PasswordMode.MD5) {
            md5Password = MD5.getInstance().getHash(newRandomPass);
        }
        return new String[] { newRandomPass, md5Password };
    }
}

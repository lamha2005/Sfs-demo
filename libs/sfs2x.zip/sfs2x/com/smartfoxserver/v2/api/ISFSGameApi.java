// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.invitation.InvitationResponse;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.List;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;
import com.smartfoxserver.v2.entities.invitation.Invitation;
import java.util.Collection;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.game.CreateSFSGameSettings;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.api.response.ISFSGameResponseApi;

public interface ISFSGameApi
{
    ISFSGameResponseApi getResponseAPI();
    
    Room createGame(final Zone p0, final CreateSFSGameSettings p1, final User p2) throws SFSCreateRoomException;
    
    Room createGame(final Zone p0, final CreateSFSGameSettings p1, final User p2, final boolean p3, final boolean p4) throws SFSCreateRoomException;
    
    Room quickJoinGame(final User p0, final MatchExpression p1, final Zone p2, final String p3) throws SFSJoinRoomException;
    
    Room quickJoinGame(final User p0, final MatchExpression p1, final Zone p2, final String p3, final Room p4) throws SFSJoinRoomException;
    
    Room quickJoinGame(final User p0, final MatchExpression p1, final Collection<Room> p2, final Room p3) throws SFSJoinRoomException;
    
    void sendInvitation(final Invitation p0, final InvitationCallback p1);
    
    void sendInvitation(final User p0, final List<User> p1, final int p2, final InvitationCallback p3, final ISFSObject p4);
    
    void replyToInvitation(final User p0, final int p1, final InvitationResponse p2, final ISFSObject p3, final boolean p4);
    
    void sendJoinRoomInvitation(final Room p0, final User p1, final List<User> p2, final int p3, final boolean p4, final boolean p5, final ISFSObject p6);
    
    void sendJoinRoomInvitation(final Room p0, final User p1, final List<User> p2, final int p3, final boolean p4, final boolean p5);
    
    void sendJoinRoomInvitation(final Room p0, final User p1, final List<User> p2, final int p3);
    
    void setSFS(final SmartFoxServer p0);
}

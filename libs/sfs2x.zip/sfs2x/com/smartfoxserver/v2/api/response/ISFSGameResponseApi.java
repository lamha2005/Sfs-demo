// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.invitation.InvitationResponse;
import com.smartfoxserver.v2.entities.invitation.Invitation;

public interface ISFSGameResponseApi
{
    void notifyInivitation(final Invitation p0);
    
    void notifyInvitationResponse(final Invitation p0, final InvitationResponse p1, final ISFSObject p2);
}

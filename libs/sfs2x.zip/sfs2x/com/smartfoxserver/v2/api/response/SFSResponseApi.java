// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.mmo.MMOHelper;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import java.util.Arrays;
import java.util.LinkedList;
import com.smartfoxserver.v2.entities.variables.UserVariableChanges;
import com.smartfoxserver.v2.mmo.Vec3D;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import com.smartfoxserver.v2.entities.RoomSize;
import com.smartfoxserver.v2.entities.Zone;
import java.util.Iterator;
import java.util.Set;
import com.smartfoxserver.v2.entities.SFSRoomSettings;
import java.util.HashSet;
import java.util.ArrayList;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.bitswarm.data.TransportType;
import java.util.Collection;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.List;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class SFSResponseApi implements ISFSResponseApi
{
    private final Logger log;
    private final int SEARCH_RESULT_LIMIT = 50;
    
    public SFSResponseApi() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void sendExtResponse(final String cmdName, final ISFSObject params, final List<ISession> recipients, final Room room, final boolean sendUDP) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putUtfString("c", cmdName);
        resObj.putSFSObject("p", (params != null) ? params : new SFSObject());
        if (room != null) {
            resObj.putInt("r", room.getId());
        }
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.CallExtension.getId());
        response.setTargetController((Object)DefaultConstants.CORE_EXTENSIONS_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)recipients);
        if (sendUDP) {
            response.setTransportType(TransportType.UDP);
        }
        response.write();
    }
    
    @Override
    public void sendPingPongResponse(final ISession recipient) {
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.PingPong.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)new SFSObject());
        response.setRecipients(recipient);
        response.write();
    }
    
    @Override
    public void notifyRoomAdded(final Room newRoom) {
        final Collection<ISession> recipients = newRoom.getZone().getSessionsListeningToGroup(newRoom.getGroupId());
        final ISFSObject resObj = SFSObject.newInstance();
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.CreateRoom.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)recipients);
        resObj.putSFSArray("r", newRoom.toSFSArray(true));
        response.write();
    }
    
    @Override
    public void notifyRoomRemoved(final Room room) {
        final Collection<ISession> recipients = room.getZone().getSessionsListeningToGroup(room.getGroupId());
        if (recipients.size() > 0) {
            final ISFSObject resObj = SFSObject.newInstance();
            final IResponse response = (IResponse)new Response();
            response.setId(SystemRequest.OnRoomLost.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)resObj);
            response.setRecipients((Collection)recipients);
            resObj.putInt("r", room.getId());
            response.write();
        }
    }
    
    @Override
    public void notifyJoinRoomSuccess(final User recipient, final Room joinedRoom) {
        final ISFSObject resObj = SFSObject.newInstance();
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.JoinRoom.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(recipient.getSession());
        resObj.putSFSArray("r", joinedRoom.toSFSArray(false));
        resObj.putSFSArray("ul", (joinedRoom instanceof MMORoom) ? new SFSArray() : joinedRoom.getUserListData());
        response.write();
    }
    
    @Override
    public void notifyUserExitRoom(final User user, final Room room, final boolean sendToEveryOne) {
        final List<ISession> recipients = new ArrayList<ISession>();
        if (sendToEveryOne) {
            recipients.addAll(room.getSessionList());
        }
        final ISFSObject resObj = SFSObject.newInstance();
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.OnUserExitRoom.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)recipients);
        resObj.putInt("u", user.getId());
        resObj.putInt("r", room.getId());
        response.write();
    }
    
    @Override
    public void notifyUserLost(final User user, final List<Room> joinedRooms) {
        final Set<ISession> recipients = new HashSet<ISession>();
        for (final Room room : joinedRooms) {
            if (room.isFlagSet(SFSRoomSettings.USER_EXIT_EVENT)) {
                recipients.addAll(room.getSessionList());
            }
        }
        if (recipients.size() > 0) {
            final ISFSObject resObj = SFSObject.newInstance();
            final IResponse response = (IResponse)new Response();
            response.setId(SystemRequest.OnUserLost.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)resObj);
            response.setRecipients((Collection)recipients);
            resObj.putInt("u", user.getId());
            response.write();
        }
    }
    
    @Override
    public void notifyUserCountChange(final Zone zone, final Room room) {
        if (!room.isFlagSet(SFSRoomSettings.USER_COUNT_CHANGE_EVENT)) {
            return;
        }
        final String groupId = room.getGroupId();
        final Collection<ISession> recipients = zone.getSessionsListeningToGroup(groupId);
        if (recipients.size() > 0) {
            final ISFSObject resObj = SFSObject.newInstance();
            final RoomSize roomSize = room.getSize();
            resObj.putInt("r", room.getId());
            resObj.putShort("uc", (short)roomSize.getUserCount());
            if (room.isGame()) {
                resObj.putShort("sc", (short)roomSize.getSpectatorCount());
            }
            final IResponse response = (IResponse)new Response();
            response.setId(SystemRequest.OnRoomCountChange.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)resObj);
            response.setRecipients((Collection)recipients);
            zone.getUCountThrottler().enqueueResponse(response);
        }
    }
    
    @Override
    public void notifyUserEnterRoom(final User user, final Room room) {
        if (!room.isFlagSet(SFSRoomSettings.USER_ENTER_EVENT)) {
            return;
        }
        final List<ISession> recipients = room.getSessionList();
        recipients.remove(user.getSession());
        if (recipients.size() > 0) {
            final ISFSObject resObj = SFSObject.newInstance();
            resObj.putInt("r", room.getId());
            resObj.putSFSArray("u", user.toSFSArray(room));
            final IResponse response = (IResponse)new Response();
            response.setId(SystemRequest.OnEnterRoom.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)resObj);
            response.setRecipients((Collection)recipients);
            response.write();
        }
    }
    
    @Override
    public void notifyRoomVariablesUpdate(final Room targetRoom, final List<RoomVariable> listOfChanges) {
        final List<ISession> roomRecipients = targetRoom.getSessionList();
        IResponse response = null;
        final ISFSObject roomResponseObj = SFSObject.newInstance();
        final ISFSArray roomVariablesData = SFSArray.newInstance();
        final ISFSArray zoneVariablesData = SFSArray.newInstance();
        for (final RoomVariable var : listOfChanges) {
            if (var.isHidden()) {
                continue;
            }
            final ISFSArray varData = var.toSFSArray();
            if (var.isGlobal()) {
                zoneVariablesData.addSFSArray(varData);
            }
            roomVariablesData.addSFSArray(varData);
        }
        if (roomVariablesData.size() > 0) {
            roomResponseObj.putInt("r", targetRoom.getId());
            roomResponseObj.putSFSArray("vl", roomVariablesData);
            response = (IResponse)new Response();
            response.setId(SystemRequest.SetRoomVariables.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)roomResponseObj);
            response.setRecipients((Collection)roomRecipients);
            if (this.log.isDebugEnabled()) {
                this.log.debug("Room Recipients: " + roomRecipients);
            }
            response.write();
        }
        if (zoneVariablesData.size() > 0) {
            final Zone zone = targetRoom.getZone();
            final Collection<ISession> globalRecipients = zone.getSessionsListeningToGroup(targetRoom.getGroupId());
            globalRecipients.removeAll(roomRecipients);
            final ISFSObject zoneResponseObj = SFSObject.newInstance();
            zoneResponseObj.putInt("r", targetRoom.getId());
            zoneResponseObj.putSFSArray("vl", zoneVariablesData);
            response = (IResponse)new Response();
            response.setId(SystemRequest.SetRoomVariables.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)zoneResponseObj);
            response.setRecipients((Collection)globalRecipients);
            if (this.log.isDebugEnabled()) {
                this.log.debug("RoomVars Global Recipients: " + globalRecipients);
            }
            response.write();
        }
    }
    
    @Override
    public void notifyUserVariablesUpdate(final User user, final List<UserVariable> varList) {
        this.notifyUserVariablesUpdate(user, varList, null);
    }
    
    @Override
    public void notifyUserVariablesUpdate(final User user, final UserVariableChanges varList, final Vec3D aoi) {
        final boolean usePrivateVars = varList.privateVarList.size() > 0;
        final ISession userSession = user.getSession();
        final List<Room> allRooms = user.getJoinedRooms();
        Collection<ISession> recipients = null;
        if (allRooms.size() == 0) {
            recipients = new LinkedList<ISession>();
            recipients.add(userSession);
        }
        else if (allRooms.size() == 1) {
            if (user.getLastJoinedRoom().isFlagSet(SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT)) {
                recipients = this.getRoomRecipients(user.getLastJoinedRoom(), user, aoi);
            }
        }
        else {
            final Set<ISession> sessionSet = new HashSet<ISession>();
            for (final Room room : allRooms) {
                if (room.isFlagSet(SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT)) {
                    final List<ISession> allOfThem = this.getRoomRecipients(room, user, aoi);
                    if (allOfThem == null) {
                        continue;
                    }
                    sessionSet.addAll(allOfThem);
                }
            }
            recipients = sessionSet;
        }
        if (usePrivateVars) {
            this.sendUserVarsUpdate(user, varList.getCombined(), Arrays.asList(userSession));
            recipients.remove(userSession);
        }
        if (recipients != null && recipients.size() > 0) {
            this.sendUserVarsUpdate(user, varList.publicVarList, recipients);
        }
    }
    
    private void sendUserVarsUpdate(final User sender, final List<UserVariable> varList, final Collection<ISession> recipients) {
        final ISFSObject responseObj = SFSObject.newInstance();
        final ISFSArray userVariablesData = SFSArray.newInstance();
        for (final UserVariable var : varList) {
            userVariablesData.addSFSArray(var.toSFSArray());
        }
        responseObj.putSFSArray("vl", userVariablesData);
        responseObj.putInt("u", sender.getId());
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.SetUserVariables.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)responseObj);
        response.setRecipients((Collection)recipients);
        response.write();
    }
    
    @Override
    public void notifyUserVariablesUpdate(final User user, final List<UserVariable> varList, final Vec3D aoi) {
        final List<Room> allRooms = user.getJoinedRooms();
        Collection<ISession> recipients = null;
        if (allRooms.size() == 0) {
            recipients = Arrays.asList(user.getSession());
        }
        else if (allRooms.size() == 1) {
            if (user.getLastJoinedRoom().isFlagSet(SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT)) {
                recipients = this.getRoomRecipients(user.getLastJoinedRoom(), user, aoi);
            }
        }
        else {
            final Set<ISession> sessionSet = new HashSet<ISession>();
            for (final Room room : allRooms) {
                if (room.isFlagSet(SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT)) {
                    final List<ISession> allOfThem = this.getRoomRecipients(room, user, aoi);
                    if (allOfThem == null) {
                        continue;
                    }
                    sessionSet.addAll(allOfThem);
                }
            }
            recipients = sessionSet;
        }
        if (recipients != null && recipients.size() > 0) {
            final ISFSObject responseObj = SFSObject.newInstance();
            final ISFSArray userVariablesData = SFSArray.newInstance();
            for (final UserVariable var : varList) {
                userVariablesData.addSFSArray(var.toSFSArray());
            }
            responseObj.putSFSArray("vl", userVariablesData);
            responseObj.putInt("u", user.getId());
            final IResponse response = (IResponse)new Response();
            response.setId(SystemRequest.SetUserVariables.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)responseObj);
            response.setRecipients((Collection)recipients);
            response.write();
        }
    }
    
    @Override
    public void notifyGroupSubscribeSuccess(final User user, final String groupId) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putUtfString("g", groupId);
        resObj.putSFSArray("rl", user.getZone().getRoomListData(Arrays.asList(groupId)));
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.SubscribeRoomGroup.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(user.getSession());
        response.write();
    }
    
    @Override
    public void notifyGroupUnsubscribeSuccess(final User user, final String groupId) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putUtfString("g", groupId);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.UnsubscribeRoomGroup.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(user.getSession());
        response.write();
    }
    
    @Override
    public void notifyClientSideDisconnection(final User user, final IDisconnectionReason reason) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putByte("dr", reason.getByteValue());
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.OnClientDisconnection.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(user.getSession());
        response.write();
    }
    
    @Override
    public void notifyRoomNameChange(final Room room) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putInt("r", room.getId());
        resObj.putUtfString("n", room.getName());
        final Zone zone = room.getZone();
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.ChangeRoomName.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)zone.getSessionsListeningToGroup(room.getGroupId()));
        response.write();
    }
    
    @Override
    public void notifyRoomPasswordChange(final Room room, final User sender, final boolean isStateChanged) {
        final Zone zone = room.getZone();
        Collection<ISession> recipients = null;
        if (isStateChanged) {
            recipients = zone.getSessionsListeningToGroup(room.getGroupId());
        }
        else if (sender != null) {
            recipients = Arrays.asList(sender.getSession());
        }
        if (recipients != null) {
            final ISFSObject resObj = SFSObject.newInstance();
            resObj.putInt("r", room.getId());
            resObj.putBool("p", room.isPasswordProtected());
            final IResponse response = (IResponse)new Response();
            response.setId(SystemRequest.ChangeRoomPassword.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)resObj);
            response.setRecipients((Collection)recipients);
            response.write();
        }
    }
    
    @Override
    public void notifyRoomCapacityChange(final Room room) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putInt("r", room.getId());
        resObj.putInt("u", room.getMaxUsers());
        resObj.putInt("s", room.getMaxSpectators());
        final Zone zone = room.getZone();
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.ChangeRoomCapacity.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)zone.getSessionsListeningToGroup(room.getGroupId()));
        response.write();
    }
    
    @Override
    public void notifyLogout(final ISession recipient, final String zoneName) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putUtfString("zn", zoneName);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.Logout.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(recipient);
        response.write();
    }
    
    @Override
    public void notifySpectatorToPlayer(final ISession recipient, final Room room, final int userId, final int playerId) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putInt("r", room.getId());
        resObj.putInt("u", userId);
        resObj.putShort("p", (short)playerId);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.SpectatorToPlayer.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)room.getSessionList());
        response.write();
    }
    
    @Override
    public void notifyPlayerToSpectator(final ISession recipient, final Room room, final int userId) {
        final ISFSObject resObj = SFSObject.newInstance();
        resObj.putInt("r", room.getId());
        resObj.putInt("u", userId);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.PlayerToSpectator.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)room.getSessionList());
        response.write();
    }
    
    @Override
    public void notifyFilteredRoomList(final ISession recipient, final Collection<Room> roomList) {
        int itemCount = roomList.size();
        if (itemCount > 50) {
            itemCount = 50;
            this.log.info(String.format("FindRooms request returned a too large result set: %s, the limit for a client request is: %s", roomList.size(), 50));
        }
        final ISFSObject resObj = SFSObject.newInstance();
        final ISFSArray roomListData = SFSArray.newInstance();
        int cnt = 0;
        for (final Room room : roomList) {
            if (cnt >= itemCount) {
                break;
            }
            roomListData.addSFSArray(room.toSFSArray(true));
            ++cnt;
        }
        resObj.putSFSArray("fr", roomListData);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.FindRooms.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(recipient);
        response.write();
    }
    
    @Override
    public void notifyFilteredUserList(final ISession recipient, final Collection<User> userList) {
        int itemCount = userList.size();
        if (itemCount > 50) {
            itemCount = 50;
            this.log.info(String.format("FindRooms request returned a too large result set: %s, the limit for a client request is: %s", userList.size(), 50));
        }
        final ISFSObject resObj = SFSObject.newInstance();
        final ISFSArray userListData = SFSArray.newInstance();
        int cnt = 0;
        for (final User user : userList) {
            if (cnt >= itemCount) {
                break;
            }
            userListData.addSFSArray(user.toSFSArray());
            ++cnt;
        }
        resObj.putSFSArray("fu", userListData);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.FindUsers.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(recipient);
        response.write();
    }
    
    @Override
    public void notifyReconnectionFailure(final ISession recipient) {
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.OnReconnectionFailure.getId());
        response.setRecipients(recipient);
        response.setContent((Object)new SFSObject());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.write();
    }
    
    @Override
    public void notifyRequestError(final SFSException err, final User recipient, final SystemRequest requestType) {
        this.notifyRequestError(err.getErrorData(), recipient, requestType);
    }
    
    @Override
    public void notifyRequestError(final SFSErrorData errData, final User recipient, final SystemRequest requestType) {
        if (recipient != null) {
            final ISFSObject resObj = SFSObject.newInstance();
            final IResponse response = (IResponse)new Response();
            response.setId(requestType.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)resObj);
            response.setRecipients(recipient.getSession());
            resObj.putShort("ec", errData.getCode().getId());
            resObj.putUtfStringArray("ep", errData.getParams());
            response.write();
        }
        else {
            final ExceptionMessageComposer composer = new ExceptionMessageComposer(new NullPointerException("Can't send error notification to client."));
            composer.setDescription("Attempting to send: " + errData.getCode() + " in response to: " + requestType);
            composer.setPossibleCauses("Recipient is NULL!");
            this.log.warn(composer.toString());
        }
    }
    
    private List<ISession> getRoomRecipients(final Room targetRoom, final User sender, final Vec3D aoi) {
        List<ISession> sessions = null;
        if (targetRoom instanceof MMORoom) {
            if (aoi != null) {
                sessions = MMOHelper.getProximitySessionList((MMORoom)targetRoom, sender, aoi);
            }
            else {
                sessions = MMOHelper.getProximitySessionList(sender);
            }
            if (sessions == null) {
                sessions = new LinkedList<ISession>();
            }
            sessions.add(sender.getSession());
        }
        else {
            sessions = targetRoom.getSessionList();
        }
        return sessions;
    }
}

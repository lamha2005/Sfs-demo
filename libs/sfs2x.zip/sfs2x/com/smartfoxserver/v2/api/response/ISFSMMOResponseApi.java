// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.mmo.IMMOItemVariable;
import java.util.List;
import com.smartfoxserver.v2.mmo.BaseMMOItem;
import com.smartfoxserver.v2.mmo.MMOUpdateDelta;
import com.smartfoxserver.v2.entities.Room;

public interface ISFSMMOResponseApi
{
    void notifyProximityListUpdate(final Room p0, final MMOUpdateDelta p1);
    
    void notifyItemVariablesUpdate(final BaseMMOItem p0, final List<IMMOItemVariable> p1);
}

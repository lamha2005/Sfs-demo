// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.mmo.Vec3D;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.mmo.MMOHelper;
import com.smartfoxserver.v2.mmo.IMMOItemVariable;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.Iterator;
import java.util.List;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.mmo.BaseMMOItem;
import com.smartfoxserver.v2.entities.data.SFSArray;
import java.util.Collection;
import com.smartfoxserver.v2.entities.User;
import java.util.LinkedList;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.mmo.MMOUpdateDelta;
import com.smartfoxserver.v2.entities.Room;

public class SFSMMOResponseApi implements ISFSMMOResponseApi
{
    @Override
    public void notifyProximityListUpdate(final Room room, final MMOUpdateDelta delta) {
        final MMORoom mmoRoom = (MMORoom)room;
        final ISFSObject sfso = new SFSObject();
        sfso.putInt("r", mmoRoom.getId());
        if (delta.getMinusUserList() != null && delta.getMinusUserList().size() > 0) {
            final List<Integer> minusList = new LinkedList<Integer>();
            for (final User item : delta.getMinusUserList()) {
                minusList.add(item.getId());
            }
            sfso.putIntArray("m", minusList);
        }
        if (delta.getPlusUserList() != null && delta.getPlusUserList().size() > 0) {
            final ISFSArray plusList = new SFSArray();
            for (final User item : delta.getPlusUserList()) {
                final ISFSArray encodedUser = item.toSFSArray();
                if (mmoRoom.isSendAOIEntryPoint()) {
                    this.addExtraEntryPoint(encodedUser, item);
                }
                plusList.addSFSArray(encodedUser);
            }
            sfso.putSFSArray("p", plusList);
        }
        if (delta.getMinusItemList() != null && delta.getMinusItemList().size() > 0) {
            final List<Integer> minusList = new LinkedList<Integer>();
            for (final BaseMMOItem item2 : delta.getMinusItemList()) {
                minusList.add(item2.getId());
            }
            sfso.putIntArray("n", minusList);
        }
        if (delta.getPlusItemList() != null && delta.getPlusItemList().size() > 0) {
            final ISFSArray plusList = new SFSArray();
            for (final BaseMMOItem item2 : delta.getPlusItemList()) {
                final ISFSArray encodedItem = item2.toSFSArray();
                if (mmoRoom.isSendAOIEntryPoint()) {
                    this.addExtraEntryPoint(encodedItem, item2);
                }
                plusList.addSFSArray(encodedItem);
            }
            sfso.putSFSArray("q", plusList);
        }
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.SetUserPosition.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)sfso);
        response.setRecipients(delta.getRecipient().getSession());
        response.write();
    }
    
    @Override
    public void notifyItemVariablesUpdate(final BaseMMOItem item, final List<IMMOItemVariable> listOfChanges) {
        final MMORoom mmoRoom = item.getRoom();
        final ISFSObject sfso = new SFSObject();
        sfso.putInt("i", item.getId());
        sfso.putInt("r", mmoRoom.getId());
        final ISFSArray encodedVars = new SFSArray();
        for (final IMMOItemVariable var : listOfChanges) {
            if (var.isHidden()) {
                continue;
            }
            encodedVars.addSFSArray(var.toSFSArray());
        }
        sfso.putSFSArray("v", encodedVars);
        final List<User> users = mmoRoom.getProximityList(MMOHelper.getMMOItemLocation(item));
        final List<ISession> recipients = new LinkedList<ISession>();
        for (final User user : users) {
            recipients.add(user.getSession());
        }
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.OnMMOItemVariablesUpdate.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)sfso);
        response.setRecipients((Collection)recipients);
        response.write();
    }
    
    private void addExtraEntryPoint(final ISFSArray encodedUser, final User target) {
        final Vec3D pos = (Vec3D)target.getProperty("_uLoc");
        if (pos != null) {
            if (pos.isFloat()) {
                encodedUser.addFloatArray(pos.toFloatArray());
            }
            else {
                encodedUser.addIntArray(pos.toIntArray());
            }
        }
    }
    
    private void addExtraEntryPoint(final ISFSArray encodedItem, final BaseMMOItem target) {
        final Vec3D pos = MMOHelper.getMMOItemLocation(target);
        if (pos != null) {
            if (pos.isFloat()) {
                encodedItem.addFloatArray(pos.toFloatArray());
            }
            else {
                encodedItem.addIntArray(pos.toIntArray());
            }
        }
    }
}

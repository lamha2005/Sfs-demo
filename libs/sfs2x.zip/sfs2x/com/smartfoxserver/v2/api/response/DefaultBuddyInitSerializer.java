// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.buddylist.BuddyList;

public class DefaultBuddyInitSerializer implements IBuddyInitResponseSerializer
{
    @Override
    public ISFSArray serialize(final BuddyList buddyList) {
        return buddyList.toSFSArray();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.buddylist.BuddyOnlineState;
import com.smartfoxserver.v2.buddylist.Buddy;
import com.smartfoxserver.bitswarm.io.IResponse;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.List;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import com.smartfoxserver.v2.entities.data.SFSArray;
import java.util.Collection;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.buddylist.BuddyList;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.ISFSEventListener;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.managers.IUserManager;
import com.smartfoxserver.v2.grid.IGridBuddyEventDispatcher;
import com.smartfoxserver.v2.api.ISFSBuddyResponseApi;

public class SFSBuddyResponseApi implements ISFSBuddyResponseApi
{
    private IGridBuddyEventDispatcher gridEventDispatcher;
    private IBuddyInitResponseSerializer initResponseSerializer;
    private IUserManager userManager;
    
    public SFSBuddyResponseApi() {
        SmartFoxServer.getInstance().getEventManager().addEventListener(SFSEventType.SERVER_READY, new ISFSEventListener() {
            @Override
            public void handleServerEvent(final ISFSEvent event) throws Exception {
                SFSBuddyResponseApi.access$0(SFSBuddyResponseApi.this, SmartFoxServer.getInstance().getUserManager());
                SFSBuddyResponseApi.access$1(SFSBuddyResponseApi.this, SmartFoxServer.getInstance().getServiceProvider().getGridBuddyEventDisptacher());
                SFSBuddyResponseApi.access$2(SFSBuddyResponseApi.this, SmartFoxServer.getInstance().getServiceProvider().getBuddyInitResponseSerializer());
            }
        });
    }
    
    @Override
    public IGridBuddyEventDispatcher getGridEventDispatcher() {
        return this.gridEventDispatcher;
    }
    
    @Override
    public void notifyBuddyListInited(final BuddyList buddyList) {
        final User owner = buddyList.getOwner();
        final ISFSObject resObj = new SFSObject();
        resObj.putSFSArray("bl", this.initResponseSerializer.serialize(buddyList));
        final List<String> buddyStates = buddyList.getBuddyListManager().getBuddyStates();
        if (buddyStates != null && buddyStates.size() > 0) {
            resObj.putUtfStringArray("bs", buddyStates);
        }
        final ISFSArray myBuddyVariables = new SFSArray();
        resObj.putSFSArray("mv", myBuddyVariables);
        final List<BuddyVariable> vars = buddyList.getOwner().getBuddyProperties().getVariables();
        if (vars != null) {
            for (final BuddyVariable bVar : vars) {
                myBuddyVariables.addSFSArray(bVar.toSFSArray());
            }
        }
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.InitBuddyList.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(owner.getSession());
        response.write();
    }
    
    @Override
    public void notifyAddBuddy(final Buddy buddy, final User recipient) {
        final ISFSObject resObj = new SFSObject();
        resObj.putSFSArray("bn", buddy.toSFSArray());
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.AddBuddy.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(recipient.getSession());
        response.write();
    }
    
    @Override
    public void notifyRemoveBuddy(final String buddyName, final User recipient) {
        final ISFSObject resObj = new SFSObject();
        resObj.putUtfString("bn", buddyName);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.RemoveBuddy.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(recipient.getSession());
        response.write();
    }
    
    @Override
    public void notifyBuddyBlockStatus(final Buddy buddy, final User recipient) {
        final ISFSObject resObj = new SFSObject();
        resObj.putUtfString("bn", buddy.getName());
        resObj.putBool("bs", buddy.isBlocked());
        if (!buddy.isBlocked()) {
            resObj.putSFSArray("bd", buddy.toSFSArray());
        }
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.BlockBuddy.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(recipient.getSession());
        response.write();
    }
    
    @Override
    public void notifyBuddyOnlineStateChange(final User user, final BuddyOnlineState state) {
        this.notifyBuddyOnlineStateChange(user, state, false);
    }
    
    @Override
    public void notifyBuddyOnlineStateChange(final User user, final BuddyOnlineState state, final boolean excludeUser) {
        final String buddyName = user.getName();
        List<String> targetNames = null;
        List<ISession> localRecipients;
        if (SmartFoxServer.grid()) {
            targetNames = user.getZone().getBuddyListManager().getRecipientNamesForUpdate(buddyName);
            localRecipients = this.userManager.sessionsFromNames(targetNames);
        }
        else {
            localRecipients = user.getZone().getBuddyListManager().getClientsWatchingBuddy(buddyName);
        }
        if (!excludeUser) {
            localRecipients.add(user.getSession());
        }
        final boolean noLocalRecipients = localRecipients.size() == 0;
        if (noLocalRecipients && !SmartFoxServer.grid()) {
            return;
        }
        final ISFSObject resObj = new SFSObject();
        resObj.putUtfString("bn", buddyName);
        resObj.putByte("o", (byte)state.ordinal());
        resObj.putInt("bi", (state == BuddyOnlineState.ONLINE) ? user.getId() : -1);
        if (!noLocalRecipients) {
            final IResponse response = (IResponse)new Response();
            response.setId(SystemRequest.GoOnline.getId());
            response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
            response.setContent((Object)resObj);
            response.setRecipients((Collection)localRecipients);
            response.write();
        }
        if (this.gridEventDispatcher != null) {
            this.gridEventDispatcher.dispatchBuddyOnline(buddyName, targetNames, resObj);
        }
    }
    
    @Override
    public void notifyBuddyVariablesUpdate(final User user, final List<BuddyVariable> vars) {
        final String buddyName = user.getName();
        List<String> targetNames = null;
        List<ISession> localRecipients;
        if (SmartFoxServer.grid()) {
            targetNames = user.getZone().getBuddyListManager().getRecipientNamesForUpdate(buddyName);
            localRecipients = this.userManager.sessionsFromNames(targetNames);
        }
        else {
            localRecipients = user.getZone().getBuddyListManager().getClientsWatchingBuddy(buddyName);
        }
        localRecipients.add(user.getSession());
        final ISFSArray buddyVarsData = new SFSArray();
        for (final BuddyVariable var : vars) {
            buddyVarsData.addSFSArray(var.toSFSArray());
        }
        final ISFSObject resObj = new SFSObject();
        resObj.putUtfString("bn", buddyName);
        resObj.putSFSArray("bv", buddyVarsData);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.SetBuddyVariables.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)localRecipients);
        response.write();
        if (this.gridEventDispatcher != null) {
            this.gridEventDispatcher.dispatchBuddyVariables(buddyName, targetNames, resObj);
        }
    }
    
    static /* synthetic */ void access$0(final SFSBuddyResponseApi sfsBuddyResponseApi, final IUserManager userManager) {
        sfsBuddyResponseApi.userManager = userManager;
    }
    
    static /* synthetic */ void access$1(final SFSBuddyResponseApi sfsBuddyResponseApi, final IGridBuddyEventDispatcher gridEventDispatcher) {
        sfsBuddyResponseApi.gridEventDispatcher = gridEventDispatcher;
    }
    
    static /* synthetic */ void access$2(final SFSBuddyResponseApi sfsBuddyResponseApi, final IBuddyInitResponseSerializer initResponseSerializer) {
        sfsBuddyResponseApi.initResponseSerializer = initResponseSerializer;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.buddylist.BuddyList;

public interface IBuddyInitResponseSerializer
{
    ISFSArray serialize(final BuddyList p0);
}

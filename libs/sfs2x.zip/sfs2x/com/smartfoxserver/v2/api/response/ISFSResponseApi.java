// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import java.util.Collection;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import com.smartfoxserver.v2.entities.variables.UserVariableChanges;
import com.smartfoxserver.v2.mmo.Vec3D;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.List;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public interface ISFSResponseApi
{
    void sendExtResponse(final String p0, final ISFSObject p1, final List<ISession> p2, final Room p3, final boolean p4);
    
    void sendPingPongResponse(final ISession p0);
    
    void notifyRoomAdded(final Room p0);
    
    void notifyRoomRemoved(final Room p0);
    
    void notifyJoinRoomSuccess(final User p0, final Room p1);
    
    void notifyUserExitRoom(final User p0, final Room p1, final boolean p2);
    
    void notifyUserLost(final User p0, final List<Room> p1);
    
    void notifyUserCountChange(final Zone p0, final Room p1);
    
    void notifyUserEnterRoom(final User p0, final Room p1);
    
    void notifyRoomVariablesUpdate(final Room p0, final List<RoomVariable> p1);
    
    void notifyUserVariablesUpdate(final User p0, final List<UserVariable> p1);
    
    void notifyUserVariablesUpdate(final User p0, final List<UserVariable> p1, final Vec3D p2);
    
    void notifyUserVariablesUpdate(final User p0, final UserVariableChanges p1, final Vec3D p2);
    
    void notifyGroupSubscribeSuccess(final User p0, final String p1);
    
    void notifyGroupUnsubscribeSuccess(final User p0, final String p1);
    
    void notifyClientSideDisconnection(final User p0, final IDisconnectionReason p1);
    
    void notifyRoomNameChange(final Room p0);
    
    void notifyRoomPasswordChange(final Room p0, final User p1, final boolean p2);
    
    void notifyRoomCapacityChange(final Room p0);
    
    void notifyLogout(final ISession p0, final String p1);
    
    void notifySpectatorToPlayer(final ISession p0, final Room p1, final int p2, final int p3);
    
    void notifyPlayerToSpectator(final ISession p0, final Room p1, final int p2);
    
    void notifyReconnectionFailure(final ISession p0);
    
    void notifyFilteredRoomList(final ISession p0, final Collection<Room> p1);
    
    void notifyFilteredUserList(final ISession p0, final Collection<User> p1);
    
    void notifyRequestError(final SFSErrorData p0, final User p1, final SystemRequest p2);
    
    void notifyRequestError(final SFSException p0, final User p1, final SystemRequest p2);
}

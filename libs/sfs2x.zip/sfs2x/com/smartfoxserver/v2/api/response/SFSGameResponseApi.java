// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api.response;

import com.smartfoxserver.v2.entities.invitation.InvitationResponse;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.util.UsersUtil;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.invitation.Invitation;

public class SFSGameResponseApi implements ISFSGameResponseApi
{
    @Override
    public void notifyInivitation(final Invitation invitation) {
        final ISFSObject resObj = SFSObject.newInstance();
        final User inviter = invitation.getInviter();
        final User invitee = invitation.getInvitee();
        if (UsersUtil.usersSeeEachOthers(inviter, invitee)) {
            resObj.putInt("ui", inviter.getId());
        }
        else {
            resObj.putSFSArray("u", inviter.toSFSArray());
        }
        resObj.putShort("t", (short)invitation.getSecondsForAnswer());
        resObj.putInt("ii", invitation.getId());
        if (invitation.getParams() != null) {
            resObj.putSFSObject("p", invitation.getParams());
        }
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.InviteUser.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(invitee.getSession());
        response.write();
    }
    
    @Override
    public void notifyInvitationResponse(final Invitation invitation, final InvitationResponse invitationResponse, final ISFSObject params) {
        final ISFSObject resObj = SFSObject.newInstance();
        final User inviter = invitation.getInviter();
        final User invitee = invitation.getInvitee();
        if (UsersUtil.usersSeeEachOthers(inviter, invitee)) {
            resObj.putInt("ui", invitee.getId());
        }
        else {
            resObj.putSFSArray("u", invitee.toSFSArray());
        }
        resObj.putByte("ri", (byte)invitationResponse.getId());
        if (params != null) {
            resObj.putSFSObject("p", params);
        }
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.InvitationReply.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(inviter.getSession());
        response.write();
    }
}

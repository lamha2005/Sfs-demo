// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

public enum GenericMessageType
{
    PUBLIC_MSG("PUBLIC_MSG", 0, 0), 
    PRIVATE_MSG("PRIVATE_MSG", 1, 1), 
    MODERATOR_MSG("MODERATOR_MSG", 2, 2), 
    ADMING_MSG("ADMING_MSG", 3, 3), 
    OBJECT_MSG("OBJECT_MSG", 4, 4), 
    BUDDY_MSG("BUDDY_MSG", 5, 5);
    
    private int id;
    
    private GenericMessageType(final String s, final int n, final int id) {
        this.id = id;
    }
    
    public int getId() {
        return this.id;
    }
    
    public static GenericMessageType fromId(final int id) {
        GenericMessageType type = null;
        GenericMessageType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final GenericMessageType item = values[i];
            if (item.getId() == id) {
                type = item;
                break;
            }
        }
        return type;
    }
}

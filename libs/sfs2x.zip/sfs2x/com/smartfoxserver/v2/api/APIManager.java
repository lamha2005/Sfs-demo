// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.bitswarm.service.IService;

public class APIManager implements IService
{
    private final String serviceName = "APIManager";
    private SmartFoxServer sfs;
    private ISFSApi sfsApi;
    private ISFSBuddyApi buddyApi;
    private ISFSGameApi gameApi;
    private ISFSMMOApi mmoApi;
    
    public void init(final Object o) {
        this.sfs = SmartFoxServer.getInstance();
        this.sfsApi = new SFSApi(this.sfs);
        this.buddyApi = new SFSBuddyApi(this.sfs);
        this.mmoApi = new SFSMMOApi(this.sfs);
        (this.gameApi = this.sfs.getServiceProvider().getGameApi()).setSFS(this.sfs);
    }
    
    public ISFSApi getSFSApi() {
        return this.sfsApi;
    }
    
    public ISFSBuddyApi getBuddyApi() {
        return this.buddyApi;
    }
    
    public ISFSGameApi getGameApi() {
        return this.gameApi;
    }
    
    public ISFSMMOApi getMMOApi() {
        return this.mmoApi;
    }
    
    public void destroy(final Object arg0) {
    }
    
    public String getName() {
        return "APIManager";
    }
    
    public void handleMessage(final Object msg) {
        throw new UnsupportedOperationException("Not supported");
    }
    
    public void setName(final String arg0) {
        throw new UnsupportedOperationException("Not supported");
    }
}

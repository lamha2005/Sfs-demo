// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import java.util.List;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import java.util.Collection;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import com.smartfoxserver.v2.entities.managers.BanMode;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.util.TaskScheduler;
import com.smartfoxserver.v2.api.response.ISFSResponseApi;

public interface ISFSApi
{
    ISFSResponseApi getResponseAPI();
    
    TaskScheduler getSystemScheduler();
    
    TaskScheduler getNewScheduler(final int p0);
    
    boolean checkSecurePassword(final ISession p0, final String p1, final String p2);
    
    User login(final ISession p0, final String p1, final String p2, final String p3, final ISFSObject p4);
    
    User login(final ISession p0, final String p1, final String p2, final String p3, final ISFSObject p4, final boolean p5);
    
    void logout(final User p0);
    
    User createNPC(final String p0, final Zone p1, final boolean p2) throws SFSLoginException;
    
    void kickUser(final User p0, final User p1, final String p2, final int p3);
    
    void banUser(final User p0, final User p1, final String p2, final BanMode p3, final int p4, final int p5);
    
    void disconnectUser(final User p0);
    
    void disconnectUser(final User p0, final IDisconnectionReason p1);
    
    void disconnect(final ISession p0);
    
    Room createRoom(final Zone p0, final CreateRoomSettings p1, final User p2) throws SFSCreateRoomException;
    
    Room createRoom(final Zone p0, final CreateRoomSettings p1, final User p2, final boolean p3, final Room p4) throws SFSCreateRoomException;
    
    Room createRoom(final Zone p0, final CreateRoomSettings p1, final User p2, final boolean p3, final Room p4, final boolean p5, final boolean p6) throws SFSCreateRoomException;
    
    List<User> findUsers(final Collection<User> p0, final MatchExpression p1, final int p2);
    
    List<Room> findRooms(final Collection<Room> p0, final MatchExpression p1, final int p2);
    
    User getUserById(final int p0);
    
    User getUserByName(final String p0);
    
    User getUserBySession(final ISession p0);
    
    void joinRoom(final User p0, final Room p1) throws SFSJoinRoomException;
    
    void joinRoom(final User p0, final Room p1, final String p2, final boolean p3, final Room p4) throws SFSJoinRoomException;
    
    void joinRoom(final User p0, final Room p1, final String p2, final boolean p3, final Room p4, final boolean p5, final boolean p6) throws SFSJoinRoomException;
    
    void leaveRoom(final User p0, final Room p1);
    
    void leaveRoom(final User p0, final Room p1, final boolean p2, final boolean p3);
    
    void removeRoom(final Room p0);
    
    void removeRoom(final Room p0, final boolean p1, final boolean p2);
    
    void sendPublicMessage(final Room p0, final User p1, final String p2, final ISFSObject p3);
    
    void sendPrivateMessage(final User p0, final User p1, final String p2, final ISFSObject p3);
    
    void sendBuddyMessage(final User p0, final User p1, final String p2, final ISFSObject p3) throws SFSBuddyListException;
    
    void sendGenericMessage(final GenericMessageType p0, final User p1, final int p2, final String p3, final ISFSObject p4, final Collection<ISession> p5);
    
    void sendModeratorMessage(final User p0, final String p1, final ISFSObject p2, final Collection<ISession> p3);
    
    void sendAdminMessage(final User p0, final String p1, final ISFSObject p2, final Collection<ISession> p3);
    
    void sendObjectMessage(final Room p0, final User p1, final ISFSObject p2, final Collection<User> p3);
    
    void sendExtensionResponse(final String p0, final ISFSObject p1, final List<User> p2, final Room p3, final boolean p4);
    
    void sendExtensionResponse(final String p0, final ISFSObject p1, final User p2, final Room p3, final boolean p4);
    
    void setRoomVariables(final User p0, final Room p1, final List<RoomVariable> p2);
    
    void setRoomVariables(final User p0, final Room p1, final List<RoomVariable> p2, final boolean p3, final boolean p4, final boolean p5);
    
    void setUserVariables(final User p0, final List<UserVariable> p1);
    
    void setUserVariables(final User p0, final List<UserVariable> p1, final boolean p2, final boolean p3);
    
    void changeRoomName(final User p0, final Room p1, final String p2) throws SFSRoomException;
    
    void changeRoomPassword(final User p0, final Room p1, final String p2) throws SFSRoomException;
    
    void changeRoomCapacity(final User p0, final Room p1, final int p2, final int p3) throws SFSRoomException;
    
    void subscribeRoomGroup(final User p0, final String p1);
    
    void unsubscribeRoomGroup(final User p0, final String p1);
    
    void spectatorToPlayer(final User p0, final Room p1, final boolean p2, final boolean p3) throws SFSRoomException;
    
    void playerToSpectator(final User p0, final Room p1, final boolean p2, final boolean p3) throws SFSRoomException;
}

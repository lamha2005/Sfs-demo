// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import com.smartfoxserver.v2.mmo.IMMOItemVariable;
import java.util.List;
import com.smartfoxserver.v2.mmo.BaseMMOItem;
import com.smartfoxserver.v2.mmo.Vec3D;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.api.response.ISFSMMOResponseApi;

public interface ISFSMMOApi
{
    ISFSMMOResponseApi getResponseAPI();
    
    void sendObjectMessage(final Room p0, final User p1, final ISFSObject p2, final Vec3D p3);
    
    void sendPublicMessage(final Room p0, final User p1, final String p2, final ISFSObject p3, final Vec3D p4);
    
    void setUserPosition(final User p0, final Vec3D p1, final Room p2);
    
    void setMMOItemPosition(final BaseMMOItem p0, final Vec3D p1, final Room p2);
    
    void removeMMOItem(final BaseMMOItem p0);
    
    void setMMOItemVariables(final BaseMMOItem p0, final List<IMMOItemVariable> p1);
    
    void setMMOItemVariables(final BaseMMOItem p0, final List<IMMOItemVariable> p1, final boolean p2);
}

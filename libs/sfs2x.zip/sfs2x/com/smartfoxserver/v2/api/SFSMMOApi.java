// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import java.util.Iterator;
import java.util.LinkedList;
import com.smartfoxserver.v2.mmo.IMMOItemVariable;
import java.util.List;
import com.smartfoxserver.v2.mmo.BaseMMOItem;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.mmo.Vec3D;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.api.response.SFSMMOResponseApi;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.api.response.ISFSMMOResponseApi;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;

public class SFSMMOApi implements ISFSMMOApi
{
    protected final SmartFoxServer sfs;
    protected final Logger log;
    protected final SFSApi sfsAPI;
    protected final ISFSMMOResponseApi mmoResponseApi;
    
    public SFSMMOApi(final SmartFoxServer sfs) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = sfs;
        this.sfsAPI = (SFSApi)sfs.getAPIManager().getSFSApi();
        this.mmoResponseApi = new SFSMMOResponseApi();
    }
    
    @Override
    public ISFSMMOResponseApi getResponseAPI() {
        return this.mmoResponseApi;
    }
    
    @Override
    public void sendObjectMessage(final Room targetRoom, final User sender, final ISFSObject message, final Vec3D aoi) {
        this.sfsAPI.sendObjectMessage(targetRoom, sender, message, aoi);
    }
    
    @Override
    public void sendPublicMessage(final Room targetRoom, final User sender, final String message, final ISFSObject params, final Vec3D aoi) {
        this.sfsAPI.sendPublicMessage(targetRoom, sender, message, params, aoi);
    }
    
    @Override
    public void setUserPosition(final User user, final Vec3D pos, final Room targetRoom) {
        if (!(targetRoom instanceof MMORoom)) {
            throw new SFSRuntimeException(String.format("Room is not an MMORoom! %s, %s ", targetRoom, user));
        }
        if (!user.getJoinedRooms().contains(targetRoom)) {
            throw new SFSRuntimeException(String.format("%s is not joined in %s ", user, targetRoom));
        }
        if (pos == null) {
            throw new SFSRuntimeException("Passed Vec3D position is null!");
        }
        final MMORoom mmoRoom = (MMORoom)targetRoom;
        if (mmoRoom.getMapLowerLimit() != null) {
            this.checkMMORoomLimits(pos, mmoRoom, user);
        }
        user.setProperty("_uLoc", pos);
        mmoRoom.updateUser(user);
    }
    
    @Override
    public void setMMOItemPosition(final BaseMMOItem item, final Vec3D pos, final Room targetRoom) {
        if (!(targetRoom instanceof MMORoom)) {
            throw new SFSRuntimeException(String.format("Room is not an MMORoom! %s, %s ", targetRoom));
        }
        if (pos == null) {
            throw new SFSRuntimeException("Passed Vec3D position is null!");
        }
        final MMORoom mmoRoom = (MMORoom)targetRoom;
        if (mmoRoom.getMapLowerLimit() != null) {
            this.checkMMORoomLimits(pos, mmoRoom, null);
        }
        mmoRoom.updateItem(item, pos);
    }
    
    @Override
    public void removeMMOItem(final BaseMMOItem item) {
        final MMORoom targetRoom = item.getRoom();
        if (targetRoom == null) {
            throw new IllegalStateException("Cannot remove MMOItem because it doesn't belong to any Room:  " + item);
        }
        item.getRoom().removeMMOItem(item);
    }
    
    @Override
    public void setMMOItemVariables(final BaseMMOItem item, final List<IMMOItemVariable> variables) {
        this.setMMOItemVariables(item, variables, true);
    }
    
    @Override
    public void setMMOItemVariables(final BaseMMOItem item, final List<IMMOItemVariable> variables, final boolean fireClientEvent) {
        final List<IMMOItemVariable> listOfChanges = this.executeSetItemVariables(item, variables);
        if (listOfChanges.size() > 0 && fireClientEvent) {
            this.mmoResponseApi.notifyItemVariablesUpdate(item, listOfChanges);
        }
    }
    
    private void checkMMORoomLimits(final Vec3D pos, final MMORoom room, final User sender) {
        if (pos.isFloat() != room.getDefaultAOI().isFloat()) {
            throw new SFSRuntimeException(String.format("Provided position doesn't match coordinate type used in %s. Expected: %s, Found: %s", room, room.getDefaultAOI().isFloat() ? "Float" : "Int", pos.isFloat() ? "Float" : "Int"));
        }
        final Vec3D min = room.getMapLowerLimit();
        final Vec3D max = room.getMapHigherLimit();
        boolean withinLimits;
        if (pos.isFloat()) {
            final boolean x_Ok = pos.floatX() <= max.floatX() && pos.floatX() >= min.floatX();
            final boolean y_Ok = pos.floatY() <= max.floatY() && pos.floatY() >= min.floatY();
            final boolean z_Ok = pos.floatZ() <= max.floatZ() && pos.floatZ() >= min.floatZ();
            withinLimits = (x_Ok && y_Ok && z_Ok);
        }
        else {
            final boolean x_Ok = pos.intX() <= max.intX() && pos.intX() >= min.intX();
            final boolean y_Ok = pos.intY() <= max.intY() && pos.intY() >= min.intY();
            final boolean z_Ok = pos.intZ() <= max.intZ() && pos.intZ() >= min.intZ();
            withinLimits = (x_Ok && y_Ok && z_Ok);
        }
        if (!withinLimits) {
            throw new SFSRuntimeException(String.format("Position %s in %s falls outside the room's limits. User: %s", pos, room, sender));
        }
    }
    
    private List<IMMOItemVariable> executeSetItemVariables(final BaseMMOItem item, final List<IMMOItemVariable> variables) {
        if (item == null) {
            throw new SFSRuntimeException("The MMOItem is null!");
        }
        if (variables == null) {
            throw new SFSRuntimeException("Missing variables list!");
        }
        if (item.getRoom() == null) {
            throw new IllegalArgumentException("MMOItem: " + item + " needs to be added to an MMORoom before its variables can be updated!");
        }
        final List<IMMOItemVariable> listOfChanges = new LinkedList<IMMOItemVariable>();
        for (final IMMOItemVariable var : variables) {
            item.setVariable(var);
            if (!var.isHidden()) {
                listOfChanges.add(var);
            }
        }
        return listOfChanges;
    }
}

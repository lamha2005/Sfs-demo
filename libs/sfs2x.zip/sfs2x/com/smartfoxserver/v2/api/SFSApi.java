// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import java.util.Set;
import com.smartfoxserver.v2.entities.variables.UserVariableChanges;
import com.smartfoxserver.v2.entities.variables.UserVariable;
import com.smartfoxserver.v2.entities.variables.Variable;
import com.smartfoxserver.v2.entities.variables.Variables;
import com.smartfoxserver.v2.exceptions.SFSVariableException;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import java.util.LinkedList;
import com.smartfoxserver.v2.mmo.MMOHelper;
import com.smartfoxserver.v2.buddylist.Buddy;
import com.smartfoxserver.v2.buddylist.BuddyList;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.ArrayList;
import com.smartfoxserver.v2.util.UsersUtil;
import com.smartfoxserver.v2.util.filters.FilteredMessage;
import com.smartfoxserver.v2.mmo.Vec3D;
import com.smartfoxserver.v2.entities.SFSRoomSettings;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.game.SFSGame;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.mmo.CreateMMORoomSettings;
import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.exceptions.SFSLoginInterruptedException;
import java.util.concurrent.TimeUnit;
import com.smartfoxserver.v2.security.IPermissionProfile;
import com.smartfoxserver.v2.entities.LoginData;
import java.util.Arrays;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.util.CryptoUtils;
import java.util.Iterator;
import java.util.Map;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEvent;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.util.ClientDisconnectionReason;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEventParam;
import java.util.HashMap;
import com.smartfoxserver.v2.protocol.binary.ProtocolUtils;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.List;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.entities.Room;
import java.util.Collection;
import com.smartfoxserver.v2.entities.managers.BanMode;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.util.TaskScheduler;
import com.smartfoxserver.v2.api.response.SFSResponseApi;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.api.response.ISFSResponseApi;
import com.smartfoxserver.v2.entities.match.MatchingUtils;
import com.smartfoxserver.v2.entities.managers.IUserManager;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;

public class SFSApi implements ISFSApi
{
    protected final SmartFoxServer sfs;
    protected final Logger log;
    protected IUserManager globalUserManager;
    private final LoginErrorHandler loginErrorHandler;
    private final MatchingUtils matcher;
    protected final ISFSResponseApi responseAPI;
    
    public SFSApi(final SmartFoxServer sfs) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = sfs;
        this.globalUserManager = sfs.getUserManager();
        this.loginErrorHandler = new LoginErrorHandler();
        this.matcher = MatchingUtils.getInstance();
        this.responseAPI = new SFSResponseApi();
    }
    
    @Override
    public TaskScheduler getSystemScheduler() {
        return this.sfs.getTaskScheduler();
    }
    
    @Override
    public TaskScheduler getNewScheduler(final int threadPoolSize) {
        return new TaskScheduler(threadPoolSize);
    }
    
    @Override
    public ISFSResponseApi getResponseAPI() {
        return this.responseAPI;
    }
    
    @Override
    public User getUserById(final int userId) {
        return this.globalUserManager.getUserById(userId);
    }
    
    @Override
    public User getUserByName(final String name) {
        return this.globalUserManager.getUserByName(name);
    }
    
    @Override
    public User getUserBySession(final ISession session) {
        return this.globalUserManager.getUserBySession(session);
    }
    
    @Override
    public void kickUser(final User userToKick, final User modUser, final String kickMessage, final int delaySeconds) {
        this.log.info("Kicking user: " + userToKick);
        this.sfs.getBannedUserManager().kickUser(userToKick, modUser, kickMessage, delaySeconds);
    }
    
    @Override
    public void banUser(final User userToBan, final User modUser, final String banMessage, final BanMode mode, final int durationMinutes, final int delaySeconds) {
        this.sfs.getBannedUserManager().banUser(userToBan, modUser, durationMinutes, mode, "", banMessage, delaySeconds);
    }
    
    @Override
    public List<Room> findRooms(final Collection<Room> roomList, final MatchExpression expression, final int limit) {
        return this.matcher.matchRooms(roomList, expression, limit);
    }
    
    @Override
    public List<User> findUsers(final Collection<User> userList, final MatchExpression expression, final int limit) {
        return this.matcher.matchUsers(userList, expression, limit);
    }
    
    @Override
    public void disconnect(final ISession session) {
        if (session == null) {
            throw new SFSRuntimeException("Unexpected, cannot disconnect session. Session object is null.");
        }
        final User lostUser = this.globalUserManager.getUserBySession(session);
        if (lostUser != null) {
            this.disconnectUser(lostUser);
        }
        else if (session.isConnected()) {
            try {
                session.close();
            }
            catch (IOException err) {
                throw new SFSRuntimeException(err);
            }
        }
    }
    
    @Override
    public void disconnectUser(final User user, final IDisconnectionReason reason) {
        user.getSession().setSystemProperty("disconnectionReason", (Object)reason);
        this.responseAPI.notifyClientSideDisconnection(user, reason);
    }
    
    @Override
    public void disconnectUser(final User user) {
        if (user == null) {
            throw new SFSRuntimeException("Cannot disconnect user, User object is null.");
        }
        final ISession session = user.getSession();
        final Zone zone = user.getZone();
        final List<Room> joinedRooms = user.getJoinedRooms();
        final Map<Room, Integer> playerIds = user.getPlayerIds();
        try {
            if (session.isConnected()) {
                session.close();
            }
            if (session.getType() == SessionType.BLUEBOX) {
                session.setLastLoggedInActivityTime(0L);
                session.setLastActivityTime(0L);
            }
            user.setConnected(false);
            if (session.getDatagramChannel() != null && session.getCryptoKey() != null) {
                final Integer udpPort = (Integer)session.getSystemProperty("UDPPort");
                ProtocolUtils.getUDPSessionTracker().remove(String.valueOf(session.getAddress()) + ":" + udpPort.toString());
            }
        }
        catch (IOException err) {
            throw new SFSRuntimeException(err);
        }
        finally {
            if (zone != null) {
                zone.removeUser(user);
            }
            this.globalUserManager.removeUser(user);
            this.responseAPI.notifyUserLost(user, joinedRooms);
            user.setConnected(false);
            this.updateRoomsAfterUserIsGone(zone, joinedRooms, user);
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, zone);
            evtParams.put(SFSEventParam.USER, user);
            evtParams.put(SFSEventParam.JOINED_ROOMS, joinedRooms);
            evtParams.put(SFSEventParam.PLAYER_IDS_BY_ROOM, playerIds);
            final IDisconnectionReason disconnectionReason = (IDisconnectionReason)user.getSession().getSystemProperty("disconnectionReason");
            evtParams.put(SFSEventParam.DISCONNECTION_REASON, (disconnectionReason == null) ? ClientDisconnectionReason.UNKNOWN : disconnectionReason);
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_DISCONNECT, evtParams));
            for (final Room r : user.getCreatedRooms()) {
                if (r != null && !joinedRooms.contains(r)) {
                    zone.checkAndRemove(r);
                }
            }
            this.log.info(String.format("User disconnected: %s, %s, SessionLen: %s, Type: %s", user.getZone().toString(), user.toString(), System.currentTimeMillis() - user.getLoginTime(), user.getSession().getSystemProperty("ClientType")));
        }
        if (zone != null) {
            zone.removeUser(user);
        }
        this.globalUserManager.removeUser(user);
        this.responseAPI.notifyUserLost(user, joinedRooms);
        user.setConnected(false);
        this.updateRoomsAfterUserIsGone(zone, joinedRooms, user);
        final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
        evtParams.put(SFSEventParam.ZONE, zone);
        evtParams.put(SFSEventParam.USER, user);
        evtParams.put(SFSEventParam.JOINED_ROOMS, joinedRooms);
        evtParams.put(SFSEventParam.PLAYER_IDS_BY_ROOM, playerIds);
        final IDisconnectionReason disconnectionReason = (IDisconnectionReason)user.getSession().getSystemProperty("disconnectionReason");
        evtParams.put(SFSEventParam.DISCONNECTION_REASON, (disconnectionReason == null) ? ClientDisconnectionReason.UNKNOWN : disconnectionReason);
        this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_DISCONNECT, evtParams));
        for (final Room r : user.getCreatedRooms()) {
            if (r != null && !joinedRooms.contains(r)) {
                zone.checkAndRemove(r);
            }
        }
        this.log.info(String.format("User disconnected: %s, %s, SessionLen: %s, Type: %s", user.getZone().toString(), user.toString(), System.currentTimeMillis() - user.getLoginTime(), user.getSession().getSystemProperty("ClientType")));
    }
    
    @Override
    public void removeRoom(final Room room) {
        this.removeRoom(room, true, true);
    }
    
    @Override
    public void removeRoom(final Room room, final boolean fireClientEvent, final boolean fireServerEvent) {
        room.getZone().removeRoom(room);
        if (room.getOwner() != null) {
            room.getOwner().removeCreatedRoom(room);
        }
        if (fireClientEvent) {
            this.responseAPI.notifyRoomRemoved(room);
        }
        if (fireServerEvent) {
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, room.getZone());
            evtParams.put(SFSEventParam.ROOM, room);
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.ROOM_REMOVED, evtParams));
        }
    }
    
    @Override
    public boolean checkSecurePassword(final ISession session, final String originalPass, final String encryptedPass) {
        return originalPass != null && originalPass.length() >= 1 && encryptedPass != null && encryptedPass.length() >= 1 && encryptedPass.equalsIgnoreCase(CryptoUtils.getClientPassword(session, originalPass));
    }
    
    @Override
    public User login(final ISession sender, final String name, final String pass, final String zoneName, final ISFSObject paramsOut) {
        return this.login(sender, name, pass, zoneName, paramsOut, false);
    }
    
    @Override
    public User login(final ISession sender, final String name, final String pass, final String zoneName, final ISFSObject paramsOut, final boolean forceLogout) {
        if (!this.sfs.getSessionManager().containsSession(sender)) {
            this.log.warn("Login failed: " + name + " , session is already expired!");
            return null;
        }
        final ISFSObject resObj = SFSObject.newInstance();
        User user = null;
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.Login.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(sender);
        final Zone zone = this.sfs.getZoneManager().getZoneByName(zoneName);
        if (zone == null) {
            resObj.putShort("ec", SFSErrorCode.LOGIN_BAD_ZONENAME.getId());
            resObj.putUtfStringArray("ep", Arrays.asList(zoneName));
            response.write();
            this.log.info("Bad login request, Zone: " + zoneName + " does not exist. Requested by: " + sender);
            return null;
        }
        try {
            user = zone.login(new LoginData(sender, name, pass, paramsOut, forceLogout));
            user.setConnected(true);
            sender.setLoggedIn(true);
            final IPermissionProfile profile = (IPermissionProfile)sender.getProperty("$permission");
            if (profile != null) {
                user.setPrivilegeId(profile.getId());
            }
            this.log.info(String.format("User login: %s, %s, Type: %s", zone.toString(), user.toString(), user.getSession().getSystemProperty("ClientType")));
            if (user.isNpc()) {
                return user;
            }
            user.updateLastRequestTime();
            resObj.putInt("id", user.getId());
            resObj.putUtfString("zn", zone.getName());
            resObj.putUtfString("un", user.getName());
            resObj.putShort("rs", (short)zone.getUserReconnectionSeconds());
            resObj.putShort("pi", user.getPrivilegeId());
            resObj.putSFSArray("rl", zone.getRoomListData());
            if (paramsOut != null && paramsOut.size() > 0) {
                resObj.putSFSObject("p", paramsOut);
            }
            response.write();
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, zone);
            evtParams.put(SFSEventParam.USER, user);
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_JOIN_ZONE, evtParams));
        }
        catch (SFSLoginInterruptedException e) {
            if (e.isStop()) {
                return null;
            }
            this.sfs.getTaskScheduler().schedule(new Runnable() {
                @Override
                public void run() {
                    SFSApi.this.login(sender, name, pass, zoneName, paramsOut);
                }
            }, 2000, TimeUnit.MILLISECONDS);
        }
        catch (SFSLoginException err) {
            this.log.info("Login error: " + err.getMessage() + ". Requested by: " + sender);
            this.loginErrorHandler.execute(sender, err);
        }
        return user;
    }
    
    @Override
    public void logout(final User user) {
        if (user == null) {
            throw new SFSRuntimeException("Cannot logout null user.");
        }
        final Zone zone = user.getZone();
        final List<Room> joinedRooms = user.getJoinedRooms();
        final Map<Room, Integer> playerIds = user.getPlayerIds();
        user.setConnected(false);
        if (zone.getUserReconnectionSeconds() > 0) {
            user.setReconnectionSeconds(0);
        }
        zone.removeUser(user);
        this.globalUserManager.removeUser(user);
        this.responseAPI.notifyUserLost(user, joinedRooms);
        this.updateRoomsAfterUserIsGone(zone, joinedRooms, user);
        for (final Room r : user.getCreatedRooms()) {
            if (r != null && !joinedRooms.contains(r)) {
                zone.checkAndRemove(r);
            }
        }
        this.responseAPI.notifyLogout(user.getSession(), zone.getName());
        final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
        evtParams.put(SFSEventParam.ZONE, zone);
        evtParams.put(SFSEventParam.USER, user);
        evtParams.put(SFSEventParam.JOINED_ROOMS, joinedRooms);
        evtParams.put(SFSEventParam.PLAYER_IDS_BY_ROOM, playerIds);
        this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_LOGOUT, evtParams));
        user.getSession().setCreationTime(System.currentTimeMillis());
        this.log.info(String.format("User logout: %s, %s, SessionLen: %s, Type: %s", user.getZone().toString(), user.toString(), System.currentTimeMillis() - user.getLoginTime(), user.getSession().getSystemProperty("ClientType")));
    }
    
    @Override
    public User createNPC(final String userName, final Zone zone, final boolean forceLogin) throws SFSLoginException {
        final ISession socketLessSession = this.sfs.getSessionManager().createConnectionlessSession();
        final User npcUser = zone.login(new LoginData(socketLessSession, userName));
        npcUser.setConnected(true);
        socketLessSession.setLoggedIn(true);
        return npcUser;
    }
    
    @Override
    public Room createRoom(final Zone zone, final CreateRoomSettings params, final User owner) throws SFSCreateRoomException {
        return this.createRoom(zone, params, owner, false, null, true, true);
    }
    
    @Override
    public Room createRoom(final Zone zone, final CreateRoomSettings params, final User owner, final boolean joinIt, final Room roomToLeave) throws SFSCreateRoomException {
        return this.createRoom(zone, params, owner, joinIt, roomToLeave, true, true);
    }
    
    @Override
    public Room createRoom(final Zone zone, final CreateRoomSettings params, final User owner, final boolean joinIt, final Room roomToLeave, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSCreateRoomException {
        Room theRoom = null;
        try {
            final String groupId = params.getGroupId();
            if (groupId == null || groupId.length() == 0) {
                params.setGroupId("default");
            }
            theRoom = zone.createRoom(params, owner);
            if (owner != null) {
                owner.addCreatedRoom(theRoom);
                owner.updateLastRequestTime();
            }
            if (theRoom instanceof MMORoom) {
                this.configureMMORoom((MMORoom)theRoom, (CreateMMORoomSettings)params);
            }
            if (fireClientEvent) {
                this.responseAPI.notifyRoomAdded(theRoom);
            }
            if (fireServerEvent) {
                final Map<ISFSEventParam, Object> eventParams = new HashMap<ISFSEventParam, Object>();
                eventParams.put(SFSEventParam.ZONE, zone);
                eventParams.put(SFSEventParam.ROOM, theRoom);
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.ROOM_ADDED, eventParams));
            }
        }
        catch (SFSCreateRoomException err) {
            if (fireClientEvent) {
                this.responseAPI.notifyRequestError(err, owner, SystemRequest.CreateRoom);
            }
            final String message = String.format("Room creation error. %s, %s, %s", err.getMessage(), zone, owner);
            throw new SFSCreateRoomException(message);
        }
        if (theRoom != null && owner != null && joinIt) {
            try {
                this.joinRoom(owner, theRoom, theRoom.getPassword(), false, roomToLeave, true, true);
            }
            catch (SFSJoinRoomException e) {
                this.log.warn("Unable to join the just created Room: " + theRoom + ", reason: " + e.getMessage());
            }
        }
        return theRoom;
    }
    
    @Override
    public void joinRoom(final User user, final Room room) throws SFSJoinRoomException {
        this.joinRoom(user, room, "", false, user.getLastJoinedRoom());
    }
    
    @Override
    public void joinRoom(final User user, final Room roomToJoin, final String password, final boolean asSpectator, final Room roomToLeave) throws SFSJoinRoomException {
        this.joinRoom(user, roomToJoin, password, asSpectator, roomToLeave, true, true);
    }
    
    @Override
    public void joinRoom(final User user, final Room roomToJoin, final String password, final boolean asSpectator, final Room roomToLeave, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSJoinRoomException {
        boolean previousRoomIsMMO = false;
        try {
            if (user.isJoining()) {
                throw new SFSRuntimeException("Join request discarded. User is already in a join transaction: " + user);
            }
            user.setJoining(true);
            if (roomToJoin == null) {
                throw new SFSJoinRoomException("Requested room doesn't exist", new SFSErrorData(SFSErrorCode.JOIN_BAD_ROOM));
            }
            if (!roomToJoin.isActive()) {
                final String message = String.format("Room is currently locked, %s", roomToJoin);
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.JOIN_ROOM_LOCKED);
                errData.addParameter(roomToJoin.getName());
                throw new SFSJoinRoomException(message, errData);
            }
            final boolean isSFSGame = roomToJoin instanceof SFSGame;
            final boolean isMMO = roomToJoin instanceof MMORoom;
            previousRoomIsMMO = (roomToLeave != null && roomToLeave instanceof MMORoom);
            if (isMMO) {
                final Room previousMMORoom = this.checkMultiMMOJoin(user, roomToJoin, roomToLeave);
                if (previousMMORoom != null) {
                    throw new SFSJoinRoomException("Cannot join another MMORoom. Multi MMORoom join is not supported. User is already joined in: " + previousMMORoom);
                }
                user.setProperty("_uJoinTime", System.currentTimeMillis());
                if (previousRoomIsMMO && user.getLastProxyList() != null) {
                    user.getSession().setSystemProperty("PreviousMMORoomState", (Object)new MMORoom.PreviousMMORoomState(roomToLeave.getId(), user.getLastProxyList()));
                }
            }
            if (isSFSGame) {
                try {
                    this.checkSFSGameAccess((SFSGame)roomToJoin, user, asSpectator);
                }
                catch (SFSRoomException e) {
                    throw new SFSJoinRoomException(e.getMessage(), e.getErrorData());
                }
            }
            boolean doorIsOpen = true;
            if (roomToJoin.isPasswordProtected()) {
                doorIsOpen = roomToJoin.getPassword().equals(password);
            }
            if (!doorIsOpen) {
                final String message2 = String.format("Room password is wrong, %s", roomToJoin);
                final SFSErrorData data = new SFSErrorData(SFSErrorCode.JOIN_BAD_PASSWORD);
                data.addParameter(roomToJoin.getName());
                throw new SFSJoinRoomException(message2, data);
            }
            roomToJoin.addUser(user, asSpectator);
            if (this.sfs.getConfigurator().getServerSettings().statsExtraLoggingEnabled) {
                this.log.info(String.format("Room joined: %s, %s, %s, asSpect: %s", roomToJoin, roomToJoin.getZone(), user, asSpectator));
            }
            user.updateLastRequestTime();
            if (fireClientEvent) {
                this.responseAPI.notifyJoinRoomSuccess(user, roomToJoin);
                if (!isMMO) {
                    this.responseAPI.notifyUserEnterRoom(user, roomToJoin);
                }
                this.responseAPI.notifyUserCountChange(user.getZone(), roomToJoin);
            }
            if (fireServerEvent) {
                final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                evtParams.put(SFSEventParam.ZONE, user.getZone());
                evtParams.put(SFSEventParam.ROOM, roomToJoin);
                evtParams.put(SFSEventParam.USER, user);
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_JOIN_ROOM, evtParams));
            }
            if (roomToLeave != null) {
                this.leaveRoom(user, roomToLeave);
            }
        }
        catch (SFSJoinRoomException err) {
            if (fireClientEvent) {
                this.responseAPI.notifyRequestError(err, user, SystemRequest.JoinRoom);
            }
            final String message3 = String.format("Join Error - %s", err.getMessage());
            throw new SFSJoinRoomException(message3);
        }
        finally {
            user.setJoining(false);
            if (previousRoomIsMMO) {
                user.getSession().removeSystemProperty("PreviousMMORoomState");
            }
        }
        user.setJoining(false);
        if (previousRoomIsMMO) {
            user.getSession().removeSystemProperty("PreviousMMORoomState");
        }
    }
    
    @Override
    public void leaveRoom(final User user, final Room room) {
        this.leaveRoom(user, room, true, true);
    }
    
    @Override
    public void leaveRoom(final User user, Room room, final boolean fireClientEvent, final boolean fireServerEvent) {
        if (room == null) {
            room = user.getLastJoinedRoom();
            if (room == null) {
                throw new SFSRuntimeException("LeaveRoom failed: user is not joined in any room. " + user);
            }
        }
        if (!room.containsUser(user)) {
            return;
        }
        final Zone zone = user.getZone();
        final int playerId = user.getPlayerId(room);
        user.updateLastRequestTime();
        if (fireClientEvent) {
            this.responseAPI.notifyUserExitRoom(user, room, room.isFlagSet(SFSRoomSettings.USER_EXIT_EVENT));
        }
        zone.removeUserFromRoom(user, room);
        final boolean roomWasRemoved = zone.getRoomById(room.getId()) == null;
        if (!roomWasRemoved && room.isActive()) {
            this.responseAPI.notifyUserCountChange(user.getZone(), room);
            this.responseAPI.notifyRoomVariablesUpdate(room, room.removeVariablesCreatedByUser(user, true));
        }
        if (fireServerEvent) {
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, user.getZone());
            evtParams.put(SFSEventParam.ROOM, room);
            evtParams.put(SFSEventParam.USER, user);
            evtParams.put(SFSEventParam.PLAYER_ID, playerId);
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_LEAVE_ROOM, evtParams));
        }
    }
    
    void sendPublicMessage(final Room targetRoom, final User sender, String message, final ISFSObject params, final Vec3D aoi) {
        if (targetRoom == null) {
            throw new IllegalArgumentException("The target Room is null");
        }
        if (!sender.isJoinedInRoom(targetRoom)) {
            throw new IllegalStateException("Sender " + sender + " is not joined the target room " + targetRoom);
        }
        if (!targetRoom.isFlagSet(SFSRoomSettings.PUBLIC_MESSAGES)) {
            throw new IllegalArgumentException("Room does not support public messages: " + targetRoom + ", Requested by: " + sender);
        }
        if (message.length() == 0) {
            this.log.warn("Empty public message request (len == 0) discarded, sender: " + sender);
            return;
        }
        final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
        evtParams.put(SFSEventParam.ZONE, sender.getZone());
        evtParams.put(SFSEventParam.ROOM, targetRoom);
        evtParams.put(SFSEventParam.USER, sender);
        evtParams.put(SFSEventParam.MESSAGE, message);
        evtParams.put(SFSEventParam.OBJECT, params);
        this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.PUBLIC_MESSAGE, evtParams));
        final Zone zone = sender.getZone();
        if (zone.getWordFilter().isActive() && targetRoom.isUseWordsFilter()) {
            final FilteredMessage filtered = targetRoom.getZone().getWordFilter().apply(message, sender);
            if (filtered == null) {
                message = "";
            }
            else {
                message = filtered.getMessage();
            }
        }
        final List<ISession> recipients = this.getPublicMessageRecipientList(sender, targetRoom, aoi);
        if (recipients != null) {
            this.sendGenericMessage(GenericMessageType.PUBLIC_MSG, sender, targetRoom.getId(), message, params, recipients);
        }
    }
    
    @Override
    public void sendPublicMessage(final Room targetRoom, final User sender, final String message, final ISFSObject params) {
        this.sendPublicMessage(targetRoom, sender, message, params, null);
    }
    
    @Override
    public void sendPrivateMessage(final User sender, final User recipient, String message, final ISFSObject params) {
        if (sender == null) {
            throw new IllegalArgumentException("PM sender is null.");
        }
        if (recipient == null) {
            throw new IllegalArgumentException("PM recipient is null");
        }
        if (sender == recipient) {
            throw new IllegalStateException("PM sender and receiver are the same. Why?");
        }
        if (message.length() == 0) {
            this.log.info("Empty private message request (len == 0) discarded");
            return;
        }
        final Zone zone = sender.getZone();
        final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
        evtParams.put(SFSEventParam.ZONE, zone);
        evtParams.put(SFSEventParam.USER, sender);
        evtParams.put(SFSEventParam.RECIPIENT, recipient);
        evtParams.put(SFSEventParam.MESSAGE, message);
        evtParams.put(SFSEventParam.OBJECT, params);
        this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.PRIVATE_MESSAGE, evtParams));
        if (zone.getWordFilter().isActive() && zone.isFilterPrivateMessages()) {
            final FilteredMessage filtered = zone.getWordFilter().apply(message, sender);
            if (filtered == null) {
                message = "";
            }
            else {
                message = filtered.getMessage();
            }
        }
        ISFSArray senderData = null;
        if (!UsersUtil.usersSeeEachOthers(sender, recipient)) {
            senderData = sender.toSFSArray(sender.getLastJoinedRoom());
        }
        final List<ISession> messageRecipients = new ArrayList<ISession>();
        messageRecipients.add(recipient.getSession());
        messageRecipients.add(sender.getSession());
        this.sendGenericMessage(GenericMessageType.PRIVATE_MSG, sender, -1, message, params, messageRecipients, senderData);
    }
    
    @Override
    public void sendBuddyMessage(final User sender, final User recipient, String message, final ISFSObject params) throws SFSBuddyListException {
        if (sender == null) {
            throw new IllegalArgumentException("BuddyMessage sender is null.");
        }
        if (recipient == null) {
            throw new IllegalArgumentException("BuddyMessage recipient is null");
        }
        if (sender == recipient) {
            throw new IllegalStateException("BuddyMessage sender and receiver are the same. Why?");
        }
        final String senderName = sender.getName();
        final String recipientName = recipient.getName();
        final BuddyListManager manager = sender.getZone().getBuddyListManager();
        final BuddyList senderBuddyList = manager.getBuddyList(senderName);
        final Buddy recipientBuddy = senderBuddyList.getBuddy(recipientName);
        final BuddyList recipientBuddyList = manager.getBuddyList(recipientName);
        final Buddy senderBuddy = (recipientBuddyList != null) ? recipientBuddyList.getBuddy(senderName) : null;
        final boolean recipientIsInSenderList = recipientBuddy != null;
        final boolean recipientIsNotBlockedInSenderList = !recipientBuddy.isBlocked();
        final boolean senderIsNotBlockedInRecipientList = senderBuddy == null || !senderBuddy.isBlocked();
        final boolean recipientIsOnline = recipient.getBuddyProperties().isOnline();
        final Zone zone = sender.getZone();
        final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
        evtParams.put(SFSEventParam.ZONE, zone);
        evtParams.put(SFSEventParam.USER, sender);
        evtParams.put(SFSEventParam.RECIPIENT, recipient);
        evtParams.put(SFSEventParam.MESSAGE, message);
        evtParams.put(SFSEventParam.OBJECT, params);
        this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.BUDDY_MESSAGE, evtParams));
        if (zone.getWordFilter().isActive() && zone.isFilterBuddyMessages()) {
            final FilteredMessage filtered = zone.getWordFilter().apply(message, sender);
            if (filtered == null) {
                message = "";
            }
            else {
                message = filtered.getMessage();
            }
        }
        final boolean goodToGo = recipientIsInSenderList && recipientIsNotBlockedInSenderList && senderIsNotBlockedInRecipientList && recipientIsOnline;
        if (goodToGo) {
            if (manager.getUseTempBuddies() && senderBuddy == null && recipientBuddyList != null) {
                this.sfs.getAPIManager().getBuddyApi().addBuddy(recipient, senderName, true, true, false);
            }
            final List<ISession> msgRecipients = new ArrayList<ISession>();
            msgRecipients.add(recipient.getSession());
            msgRecipients.add(sender.getSession());
            this.sendGenericMessage(GenericMessageType.BUDDY_MSG, sender, -1, message, params, msgRecipients);
            return;
        }
        String errorMessage = null;
        if (!recipientIsInSenderList) {
            errorMessage = String.format("Recipient %s is not found in sender's list: %s", recipientName, senderName);
        }
        else if (!recipientIsNotBlockedInSenderList) {
            errorMessage = String.format("Recipient %s is blocked in sender's list: %s", recipientName, senderName);
        }
        else if (!senderIsNotBlockedInRecipientList) {
            errorMessage = String.format("Sender %s is blocked in recipient's list: %s", senderName, recipientName);
        }
        else if (!recipientIsOnline) {
            errorMessage = String.format("Recipient %s is not online", recipientName);
        }
        if (errorMessage == null) {
            errorMessage = "Unexpected error";
        }
        throw new SFSBuddyListException(errorMessage);
    }
    
    @Override
    public void sendModeratorMessage(final User sender, final String message, final ISFSObject params, final Collection<ISession> recipients) {
        this.sendSuperUserMessage(GenericMessageType.MODERATOR_MSG, sender, message, params, recipients);
    }
    
    @Override
    public void sendAdminMessage(final User sender, final String message, final ISFSObject params, final Collection<ISession> recipients) {
        this.sendSuperUserMessage(GenericMessageType.ADMING_MSG, sender, message, params, recipients);
    }
    
    private void sendSuperUserMessage(final GenericMessageType type, User sender, final String message, final ISFSObject params, final Collection<ISession> recipients) {
        if (recipients.size() == 0) {
            throw new IllegalStateException("Mod Message discarded. No recipients");
        }
        if (message.length() == 0) {
            throw new IllegalStateException("Mod Message discarded. Empty message");
        }
        if (sender == null) {
            switch (type) {
                case ADMING_MSG: {
                    sender = UsersUtil.getServerAdmin();
                    break;
                }
                default: {
                    sender = UsersUtil.getServerModerator();
                    break;
                }
            }
        }
        this.sendGenericMessage(type, sender, -1, message, params, recipients, sender.toSFSArray(null));
    }
    
    void sendObjectMessage(final Room targetRoom, final User sender, final ISFSObject message, final Vec3D aoi) {
        if (targetRoom == null) {
            throw new IllegalArgumentException("The target Room is null");
        }
        if (!sender.isJoinedInRoom(targetRoom)) {
            throw new IllegalStateException("Sender " + sender + " is not joined the target room " + targetRoom);
        }
        if (!(targetRoom instanceof MMORoom)) {
            throw new IllegalArgumentException("The target Room is not an MMORoom");
        }
        List<ISession> recipientList = null;
        if (aoi != null) {
            recipientList = MMOHelper.getProximitySessionList((MMORoom)targetRoom, sender, aoi);
        }
        else {
            recipientList = MMOHelper.getProximitySessionList(sender);
        }
        this.sendGenericMessage(GenericMessageType.OBJECT_MSG, sender, targetRoom.getId(), null, message, recipientList);
    }
    
    @Override
    public void sendObjectMessage(final Room targetRoom, final User sender, final ISFSObject message, final Collection<User> recipients) {
        if (targetRoom == null) {
            throw new IllegalArgumentException("The target Room is null");
        }
        if (!sender.isJoinedInRoom(targetRoom)) {
            throw new IllegalStateException("Sender " + sender + " is not joined the target room " + targetRoom);
        }
        List<ISession> recipientList = null;
        if (recipients == null) {
            recipientList = targetRoom.getSessionList();
            recipientList.remove(sender.getSession());
        }
        else {
            recipientList = new LinkedList<ISession>();
            for (final User user : recipients) {
                if (targetRoom.containsUser(user)) {
                    recipientList.add(user.getSession());
                }
            }
        }
        this.sendGenericMessage(GenericMessageType.OBJECT_MSG, sender, targetRoom.getId(), null, message, recipientList);
    }
    
    @Override
    public void sendExtensionResponse(final String cmdName, final ISFSObject params, final List<User> recipients, final Room room, final boolean useUDP) {
        final List<ISession> sessions = new LinkedList<ISession>();
        for (final User user : recipients) {
            sessions.add(user.getSession());
        }
        this.responseAPI.sendExtResponse(cmdName, params, sessions, room, useUDP);
    }
    
    @Override
    public void sendExtensionResponse(final String cmdName, final ISFSObject params, final User recipient, final Room room, final boolean useUDP) {
        final List<ISession> msgRecipients = new LinkedList<ISession>();
        msgRecipients.add(recipient.getSession());
        this.responseAPI.sendExtResponse(cmdName, params, msgRecipients, room, useUDP);
    }
    
    @Override
    public void setRoomVariables(final User user, final Room targetRoom, final List<RoomVariable> variables) {
        this.setRoomVariables(user, targetRoom, variables, true, true, false);
    }
    
    @Override
    public void setRoomVariables(final User user, final Room targetRoom, final List<RoomVariable> variables, final boolean fireClientEvent, final boolean fireServerEvent, final boolean overrideOwnership) {
        if (targetRoom == null) {
            throw new SFSRuntimeException("The target Room is null!");
        }
        if (variables == null) {
            throw new SFSRuntimeException("Missing variables list!");
        }
        final List<RoomVariable> listOfChanges = new ArrayList<RoomVariable>();
        for (final RoomVariable var : variables) {
            try {
                targetRoom.setVariable(var, overrideOwnership);
                listOfChanges.add(var);
            }
            catch (SFSVariableException e) {
                this.log.warn(e.getMessage());
            }
        }
        if (user != null) {
            user.updateLastRequestTime();
        }
        if (listOfChanges.size() > 0 && fireClientEvent) {
            this.responseAPI.notifyRoomVariablesUpdate(targetRoom, listOfChanges);
        }
        if (listOfChanges.size() > 0 && fireServerEvent) {
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, targetRoom.getZone());
            evtParams.put(SFSEventParam.ROOM, targetRoom);
            evtParams.put(SFSEventParam.USER, user);
            evtParams.put(SFSEventParam.VARIABLES, listOfChanges);
            evtParams.put(SFSEventParam.VARIABLES_MAP, Variables.toVariablesMap(listOfChanges));
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.ROOM_VARIABLES_UPDATE, evtParams));
        }
    }
    
    @Override
    public void setUserVariables(final User owner, final List<UserVariable> variables) {
        this.setUserVariables(owner, variables, true, true);
    }
    
    @Override
    public void setUserVariables(final User owner, final List<UserVariable> variables, final boolean fireClientEvent, final boolean fireServerEvent) {
        final UserVariableChanges listOfChanges = this.executeSetUserVariables(owner, variables);
        this.fireUserVariablesEvent(owner, listOfChanges, null, fireClientEvent, fireServerEvent);
    }
    
    void setUserVariables(final User owner, final List<UserVariable> variables, final Vec3D aoi, final boolean fireClientEvent, final boolean fireServerEvent) {
        final UserVariableChanges listOfChanges = this.executeSetUserVariables(owner, variables);
        this.fireUserVariablesEvent(owner, listOfChanges, aoi, fireClientEvent, fireServerEvent);
    }
    
    private void updateRoomsAfterUserIsGone(final Zone zone, final List<Room> joinedRooms, final User userGone) {
        for (final Room r : joinedRooms) {
            final boolean goodToGo = r != null && r.isActive();
            if (goodToGo) {
                this.responseAPI.notifyUserCountChange(zone, r);
                this.responseAPI.notifyRoomVariablesUpdate(r, r.removeVariablesCreatedByUser(userGone));
            }
        }
        final Set<Integer> persistentRoomVarRef = userGone.getPersistentRoomVarReferences();
        synchronized (persistentRoomVarRef) {
            for (final Integer id : persistentRoomVarRef) {
                final Room target = zone.getRoomById(id);
                if (target != null && !joinedRooms.contains(target)) {
                    this.responseAPI.notifyRoomVariablesUpdate(target, target.removeVariablesCreatedByUser(userGone));
                }
            }
        }
        // monitorexit(persistentRoomVarRef)
    }
    
    private UserVariableChanges executeSetUserVariables(final User owner, final List<UserVariable> variables) {
        if (owner == null) {
            throw new SFSRuntimeException("The User is null!");
        }
        if (variables == null) {
            throw new SFSRuntimeException("Missing variables list!");
        }
        final UserVariableChanges listOfChanges = new UserVariableChanges();
        for (final UserVariable var : variables) {
            try {
                owner.setVariable(var);
                if (var.isHidden()) {
                    continue;
                }
                if (var.isPrivate()) {
                    listOfChanges.privateVarList.add(var);
                }
                else {
                    listOfChanges.publicVarList.add(var);
                }
            }
            catch (SFSVariableException e) {
                this.log.warn(e.getMessage());
            }
        }
        owner.updateLastRequestTime();
        return listOfChanges;
    }
    
    private void fireUserVariablesEvent(final User owner, final UserVariableChanges listOfChanges, final Vec3D aoi, final boolean fireClientEvent, final boolean fireServerEvent) {
        final boolean needsUpdate = listOfChanges.needsUpdate();
        if (needsUpdate && fireClientEvent) {
            this.responseAPI.notifyUserVariablesUpdate(owner, listOfChanges, aoi);
        }
        if (needsUpdate && fireServerEvent) {
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            final List<UserVariable> varChangesList = listOfChanges.getCombined();
            evtParams.put(SFSEventParam.ZONE, owner.getZone());
            evtParams.put(SFSEventParam.USER, owner);
            evtParams.put(SFSEventParam.VARIABLES, varChangesList);
            evtParams.put(SFSEventParam.VARIABLES_MAP, Variables.toVariablesMap(varChangesList));
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_VARIABLES_UPDATE, evtParams));
        }
    }
    
    private void fireUserVariablesEvent(final User owner, final List<UserVariable> listOfChanges, final Vec3D aoi, final boolean fireClientEvent, final boolean fireServerEvent) {
        if (listOfChanges.size() > 0 && fireClientEvent) {
            this.responseAPI.notifyUserVariablesUpdate(owner, listOfChanges, aoi);
        }
        if (listOfChanges.size() > 0 && fireServerEvent) {
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, owner.getZone());
            evtParams.put(SFSEventParam.USER, owner);
            evtParams.put(SFSEventParam.VARIABLES, listOfChanges);
            evtParams.put(SFSEventParam.VARIABLES_MAP, Variables.toVariablesMap(listOfChanges));
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.USER_VARIABLES_UPDATE, evtParams));
        }
    }
    
    @Override
    public void changeRoomName(final User owner, final Room targetRoom, final String newName) throws SFSRoomException {
        if (targetRoom.isFlagSet(SFSRoomSettings.ROOM_NAME_CHANGE)) {
            try {
                if (!this.canUserChangeAttributesInThisRoom(owner, targetRoom)) {
                    final SFSErrorData errorData = new SFSErrorData(SFSErrorCode.ROOM_NAME_CHANGE_PERMISSION_ERR);
                    errorData.addParameter(targetRoom.getName());
                    final String message = String.format("Room name change not permitted. Room: %s, User: %s", targetRoom, owner);
                    throw new SFSRoomException(message, errorData);
                }
                targetRoom.getZone().changeRoomName(targetRoom, newName);
                this.responseAPI.notifyRoomNameChange(targetRoom);
                if (owner != null) {
                    owner.updateLastRequestTime();
                }
                return;
            }
            catch (SFSRoomException err) {
                if (owner != null) {
                    this.responseAPI.notifyRequestError(err, owner, SystemRequest.ChangeRoomName);
                }
                throw err;
            }
            throw new SFSRoomException(String.format("Attempt to change name to a Room that doesn't support it. %s, %s", targetRoom, owner));
        }
        throw new SFSRoomException(String.format("Attempt to change name to a Room that doesn't support it. %s, %s", targetRoom, owner));
    }
    
    @Override
    public void changeRoomPassword(final User owner, final Room targetRoom, final String newPassword) throws SFSRoomException {
        if (targetRoom.isFlagSet(SFSRoomSettings.PASSWORD_STATE_CHANGE)) {
            try {
                if (!this.canUserChangeAttributesInThisRoom(owner, targetRoom)) {
                    final SFSErrorData errorData = new SFSErrorData(SFSErrorCode.ROOM_PASS_CHANGE_PERMISSION_ERR);
                    errorData.addParameter(targetRoom.getName());
                    final String message = String.format("Room password change not permitted. Room: %s, User: %s", targetRoom, owner);
                    throw new SFSRoomException(message, errorData);
                }
                final boolean previousState = targetRoom.isPasswordProtected();
                targetRoom.getZone().changeRoomPasswordState(targetRoom, newPassword);
                final boolean newState = targetRoom.isPasswordProtected();
                this.responseAPI.notifyRoomPasswordChange(targetRoom, owner, previousState ^ newState);
                if (owner != null) {
                    owner.updateLastRequestTime();
                }
                return;
            }
            catch (SFSRoomException err) {
                if (owner != null) {
                    this.responseAPI.notifyRequestError(err, owner, SystemRequest.ChangeRoomPassword);
                }
                throw err;
            }
            throw new SFSRoomException(String.format("Attempt to change password to a Room that doesn't support it. %s, %s", targetRoom, owner));
        }
        throw new SFSRoomException(String.format("Attempt to change password to a Room that doesn't support it. %s, %s", targetRoom, owner));
    }
    
    @Override
    public void changeRoomCapacity(final User owner, final Room targetRoom, final int maxUsers, final int maxSpectators) throws SFSRoomException {
        if (targetRoom.isFlagSet(SFSRoomSettings.CAPACITY_CHANGE)) {
            try {
                if (!this.canUserChangeAttributesInThisRoom(owner, targetRoom)) {
                    final SFSErrorData errorData = new SFSErrorData(SFSErrorCode.ROOM_CAPACITY_CHANGE_PERMISSION_ERR);
                    errorData.addParameter(targetRoom.getName());
                    final String message = String.format("Room capacity change not allowed. Room: %s, User: %s", targetRoom, owner);
                    throw new SFSRoomException(message, errorData);
                }
                final Zone zone = targetRoom.getZone();
                if (maxUsers > 0) {
                    zone.changeRoomCapacity(targetRoom, maxUsers, maxSpectators);
                }
                this.responseAPI.notifyRoomCapacityChange(targetRoom);
                if (owner != null) {
                    owner.updateLastRequestTime();
                }
                return;
            }
            catch (SFSRoomException err) {
                if (owner != null) {
                    this.responseAPI.notifyRequestError(err, owner, SystemRequest.ChangeRoomCapacity);
                }
                throw err;
            }
            throw new SFSRoomException(String.format("Attempt to change capacity in a Room that doesn't support it. %s, %s", targetRoom, owner));
        }
        throw new SFSRoomException(String.format("Attempt to change capacity in a Room that doesn't support it. %s, %s", targetRoom, owner));
    }
    
    private boolean canUserChangeAttributesInThisRoom(final User user, final Room targetRoom) {
        return user == null || user == targetRoom.getOwner() || user.isSuperUser();
    }
    
    @Override
    public void subscribeRoomGroup(final User user, final String groupId) {
        final Zone zone = user.getZone();
        try {
            if (!zone.containsGroup(groupId) && !zone.containsPublicGroup(groupId)) {
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SUBSCRIBE_GROUP_NOT_FOUND);
                errData.addParameter(groupId);
                throw new SFSException(String.format("User: %s is request subscription to non-existing group: %s", user.getName(), groupId), errData);
            }
            if (user.isSubscribedToGroup(groupId)) {
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SUBSCRIBE_GROUP_ALREADY_SUBSCRIBED);
                errData.addParameter(groupId);
                throw new SFSException(String.format("User: %s is already subscribed to group: %s", user.getName(), groupId), errData);
            }
            user.subscribeGroup(groupId);
            this.responseAPI.notifyGroupSubscribeSuccess(user, groupId);
        }
        catch (SFSException err) {
            this.responseAPI.notifyRequestError(err, user, SystemRequest.SubscribeRoomGroup);
        }
    }
    
    @Override
    public void unsubscribeRoomGroup(final User user, final String groupId) {
        final Zone zone = user.getZone();
        try {
            if (!zone.containsGroup(groupId) && !zone.containsPublicGroup(groupId)) {
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SUBSCRIBE_GROUP_NOT_FOUND);
                errData.addParameter(groupId);
                throw new SFSException(String.format("Can't unsubscribe user: %s from group: %s. Group doesn't exist", user.getName(), groupId), errData);
            }
            if (!user.isSubscribedToGroup(groupId)) {
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.UNSUBSCRIBE_GROUP_NOT_SUBSCRIBED);
                errData.addParameter(groupId);
                throw new SFSException(String.format("Can't unsubscribe user: %s from group: %s. Group is not subscribed.", user.getName(), groupId), errData);
            }
            user.unsubscribeGroup(groupId);
            this.responseAPI.notifyGroupUnsubscribeSuccess(user, groupId);
        }
        catch (SFSException err) {
            this.responseAPI.notifyRequestError(err, user, SystemRequest.UnsubscribeRoomGroup);
        }
    }
    
    private void sendGenericMessage(final GenericMessageType type, final User sender, final int targetRoomId, final String message, final ISFSObject params, final Collection<ISession> recipients, final ISFSArray senderData) {
        if (sender != null) {
            sender.updateLastRequestTime();
        }
        final ISFSObject resObj = SFSObject.newInstance();
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.GenericMessage.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients((Collection)recipients);
        resObj.putByte("t", (byte)type.getId());
        resObj.putInt("r", targetRoomId);
        resObj.putInt("u", sender.getId());
        if (message != null) {
            resObj.putUtfString("m", message);
        }
        if (params != null) {
            resObj.putSFSObject("p", params);
        }
        if (senderData != null) {
            resObj.putSFSArray("sd", senderData);
        }
        response.write();
    }
    
    @Override
    public void sendGenericMessage(final GenericMessageType type, final User sender, final int targetRoomId, final String message, final ISFSObject params, final Collection<ISession> recipients) {
        this.sendGenericMessage(type, sender, targetRoomId, message, params, recipients, null);
    }
    
    @Override
    public void spectatorToPlayer(final User user, final Room targetRoom, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSRoomException {
        if (targetRoom == null) {
            throw new IllegalArgumentException("A target room was not specified (null)");
        }
        if (user == null) {
            throw new IllegalArgumentException("A user was not specified (null)");
        }
        user.updateLastRequestTime();
        try {
            if (targetRoom instanceof SFSGame) {
                this.checkSFSGameAccess((SFSGame)targetRoom, user, false);
            }
            targetRoom.switchSpectatorToPlayer(user);
            if (fireClientEvent) {
                this.responseAPI.notifySpectatorToPlayer(user.getSession(), targetRoom, user.getId(), user.getPlayerId(targetRoom));
                this.responseAPI.notifyUserCountChange(user.getZone(), targetRoom);
            }
            if (fireServerEvent) {
                final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                evtParams.put(SFSEventParam.ZONE, user.getZone());
                evtParams.put(SFSEventParam.ROOM, targetRoom);
                evtParams.put(SFSEventParam.USER, user);
                evtParams.put(SFSEventParam.PLAYER_ID, user.getPlayerId(targetRoom));
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.SPECTATOR_TO_PLAYER, evtParams));
            }
        }
        catch (SFSRoomException err) {
            if (fireClientEvent) {
                this.responseAPI.notifyRequestError(err, user, SystemRequest.SpectatorToPlayer);
            }
            final String message = String.format("SpectatorToPlayer Error - %s", err.getMessage());
            throw new SFSRoomException(message, err.getErrorData());
        }
    }
    
    @Override
    public void playerToSpectator(final User user, final Room targetRoom, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSRoomException {
        if (targetRoom == null) {
            throw new IllegalArgumentException("A target room was not specified (null)");
        }
        if (user == null) {
            throw new IllegalArgumentException("A user was not specified (null)");
        }
        user.updateLastRequestTime();
        try {
            if (targetRoom instanceof SFSGame) {
                this.checkSFSGameAccess((SFSGame)targetRoom, user, true);
            }
            targetRoom.switchPlayerToSpectator(user);
            if (fireClientEvent) {
                this.responseAPI.notifyPlayerToSpectator(user.getSession(), targetRoom, user.getId());
                this.responseAPI.notifyUserCountChange(user.getZone(), targetRoom);
            }
            if (fireServerEvent) {
                final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                evtParams.put(SFSEventParam.ZONE, user.getZone());
                evtParams.put(SFSEventParam.ROOM, targetRoom);
                evtParams.put(SFSEventParam.USER, user);
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.PLAYER_TO_SPECTATOR, evtParams));
            }
        }
        catch (SFSRoomException err) {
            if (fireClientEvent) {
                this.responseAPI.notifyRequestError(err, user, SystemRequest.PlayerToSpectator);
            }
            final String message = String.format("PlayerToSpectator Error - %s", err.getMessage());
            throw new SFSRoomException(message, err.getErrorData());
        }
    }
    
    private void checkSFSGameAccess(final SFSGame gameRoom, final User user, final boolean asSpectator) throws SFSRoomException {
        MatchExpression expression = null;
        if (asSpectator) {
            expression = gameRoom.getSpectatorMatchExpression();
        }
        else if (gameRoom.isPublic()) {
            expression = gameRoom.getPlayerMatchExpression();
        }
        if (expression == null) {
            return;
        }
        if (!this.matcher.matchUser(user, expression)) {
            final String message = String.format("User does not match the MatchExpression of the Game Room: %s", expression);
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.JOIN_GAME_ACCESS_DENIED);
            errData.addParameter(gameRoom.getName());
            throw new SFSRoomException(message, errData);
        }
    }
    
    private void configureMMORoom(final MMORoom room, final CreateMMORoomSettings settings) {
        if (settings.getMapLimits() != null) {
            room.setMapLimits(settings.getMapLimits().getLowerLimit(), settings.getMapLimits().getHigherLimit());
        }
        room.setUserLimboMaxSeconds(settings.getUserMaxLimboSeconds());
        room.setSendAOIEntryPoint(settings.isSendAOIEntryPoint());
    }
    
    private List<ISession> getPublicMessageRecipientList(final User sender, final Room targetRoom, final Vec3D aoi) {
        List<ISession> recipients = null;
        if (targetRoom instanceof MMORoom) {
            if (aoi != null) {
                recipients = MMOHelper.getProximitySessionList((MMORoom)targetRoom, sender, aoi);
            }
            else {
                recipients = MMOHelper.getProximitySessionList(sender);
            }
            if (recipients == null) {
                throw new IllegalStateException("Public message sender is not spawned in the Room: " + sender + ", " + targetRoom);
            }
            recipients.add(sender.getSession());
        }
        else {
            recipients = targetRoom.getSessionList();
        }
        return recipients;
    }
    
    private Room checkMultiMMOJoin(final User user, final Room roomToJoin, final Room roomToLeave) {
        Room previousMMORoom = null;
        final Room anotherMMORoom = user.getCurrentMMORoom();
        if (anotherMMORoom != null && anotherMMORoom != roomToLeave) {
            previousMMORoom = anotherMMORoom;
        }
        return previousMMORoom;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import org.apache.commons.lang.RandomStringUtils;
import java.util.Map;
import com.smartfoxserver.v2.util.UsersUtil;
import com.smartfoxserver.v2.game.SFSGameInvitationCallback;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEvent;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEventParam;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import com.smartfoxserver.v2.exceptions.SFSCreateGameException;
import com.smartfoxserver.v2.exceptions.SFSQuickJoinGameException;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.entities.match.MatchingUtils;
import com.smartfoxserver.v2.entities.match.IMatcher;
import com.smartfoxserver.v2.entities.match.BoolMatch;
import com.smartfoxserver.v2.game.JoinRoomInvitationCallback;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.exceptions.SFSInvitationException;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.entities.invitation.InvitationResponse;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.invitation.SFSInvitation;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;
import com.smartfoxserver.v2.entities.invitation.Invitation;
import java.util.Collection;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.List;
import com.smartfoxserver.v2.game.SFSGame;
import com.smartfoxserver.v2.entities.variables.SFSRoomVariable;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import java.util.ArrayList;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.game.CreateSFSGameSettings;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.api.response.SFSGameResponseApi;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.api.response.ISFSGameResponseApi;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;

public class SFSGameApi implements ISFSGameApi
{
    private static final int GAME_PASSWORD_LEN = 16;
    protected SmartFoxServer sfs;
    protected ISFSApi sfsApi;
    protected final Logger log;
    protected final ISFSGameResponseApi responseApi;
    
    public SFSGameApi() {
        this(null);
    }
    
    public SFSGameApi(final SmartFoxServer sfs) {
        this.sfs = sfs;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.responseApi = new SFSGameResponseApi();
    }
    
    @Override
    public void setSFS(final SmartFoxServer sfs) {
        if (this.sfs != null) {
            throw new IllegalStateException();
        }
        this.sfs = sfs;
        this.sfsApi = sfs.getAPIManager().getSFSApi();
    }
    
    @Override
    public ISFSGameResponseApi getResponseAPI() {
        return this.responseApi;
    }
    
    @Override
    public Room createGame(final Zone zone, final CreateSFSGameSettings settings, final User owner) throws SFSCreateRoomException {
        return this.createGame(zone, settings, owner, true, true);
    }
    
    @Override
    public Room createGame(final Zone zone, final CreateSFSGameSettings settings, final User owner, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSCreateRoomException {
        Room roomToLeave = null;
        SFSGame theGame = null;
        this.validateSFSGameSettings(settings, owner);
        if (settings.isLeaveLastJoinedRoom()) {
            roomToLeave = ((owner != null) ? owner.getLastJoinedRoom() : null);
        }
        if (!settings.isGamePublic()) {
            settings.setPassword(this.generateGamePassword());
        }
        if (settings.isNotifyGameStartedViaRoomVariable()) {
            List<RoomVariable> variables = settings.getRoomVariables();
            if (variables == null) {
                variables = new ArrayList<RoomVariable>();
                settings.setRoomVariables(variables);
            }
            final RoomVariable varGameStarted = new SFSRoomVariable("$GS", false);
            varGameStarted.setGlobal(true);
            varGameStarted.setPrivate(true);
            varGameStarted.setOwner(null);
            variables.add(varGameStarted);
        }
        theGame = (SFSGame)this.sfsApi.createRoom(zone, settings, owner, true, roomToLeave, fireClientEvent, fireServerEvent);
        theGame.setPlayerMatchExpression(settings.getPlayerMatchExpression());
        theGame.setSpectatorMatchExpression(settings.getSpectatorMatchExpression());
        theGame.setLeaveLastRoomOnJoin(settings.isLeaveLastJoinedRoom());
        theGame.setMinPlayersToStartGame(settings.getMinPlayersToStartGame());
        theGame.setNotifyGameStarted(settings.isNotifyGameStartedViaRoomVariable());
        if (!theGame.isPublic()) {
            final List<User> invitedPlayers = settings.getInvitedPlayers();
            if (invitedPlayers != null) {
                this.populateInvitations(owner, invitedPlayers, settings.getMinPlayersToStartGame(), settings.getSearchableRooms(), settings.getPlayerMatchExpression());
                final ISFSObject inivitationParams = settings.getInvitationParams();
                this.inviteFriendsInGame(theGame, invitedPlayers, settings.isLeaveLastJoinedRoom(), settings.getInvitationExpiryTime(), inivitationParams);
                this.log.info(String.format("Game started: %s -- Invited people: %s", theGame, invitedPlayers));
            }
        }
        return theGame;
    }
    
    @Override
    public Room quickJoinGame(final User player, final MatchExpression expression, final Zone zone, final String groupId) throws SFSJoinRoomException {
        return this.quickJoinGame(player, expression, zone, groupId, null);
    }
    
    @Override
    public Room quickJoinGame(final User player, final MatchExpression expression, final Zone zone, final String groupId, final Room roomToLeave) throws SFSJoinRoomException {
        return this.quickJoinGame(player, expression, zone.getRoomListFromGroup(groupId), roomToLeave);
    }
    
    @Override
    public Room quickJoinGame(final User player, final MatchExpression expression, final Collection<Room> searchableRooms, final Room roomToLeave) throws SFSJoinRoomException {
        return this.quickJoinGame(player, expression, searchableRooms, roomToLeave, false);
    }
    
    @Override
    public void sendInvitation(final Invitation invitation, final InvitationCallback callBackHandler) {
        this.sfs.getInvitationManager().startInvitation(invitation, callBackHandler);
        this.responseApi.notifyInivitation(invitation);
    }
    
    @Override
    public void sendInvitation(final User inviter, final List<User> invitees, final int expirySeconds, final InvitationCallback callBackHandler, final ISFSObject params) {
        for (final User invitee : invitees) {
            if (invitee != null) {
                final Invitation invitation = new SFSInvitation(inviter, invitee, expirySeconds);
                invitation.setParams(params);
                this.sfs.getInvitationManager().startInvitation(invitation, callBackHandler);
                this.responseApi.notifyInivitation(invitation);
            }
        }
    }
    
    @Override
    public void replyToInvitation(final User invitedUser, final int invitationId, final InvitationResponse reply, final ISFSObject params, final boolean fireClientEvent) {
        try {
            this.sfs.getInvitationManager().onInvitationResult(invitationId, reply, params);
        }
        catch (SFSInvitationException e) {
            this.log.warn("Invitation Reply failure: " + e.getMessage());
            if (fireClientEvent) {
                this.sfsApi.getResponseAPI().notifyRequestError(e.getErrorData(), invitedUser, SystemRequest.InvitationReply);
            }
        }
    }
    
    @Override
    public void sendJoinRoomInvitation(final Room target, final User inviter, final List<User> invitees, final int expirySeconds) {
        this.sendJoinRoomInvitation(target, inviter, invitees, expirySeconds, false, false, null);
    }
    
    @Override
    public void sendJoinRoomInvitation(final Room target, final User inviter, final List<User> invitees, final int expirySeconds, final boolean asSpect, final boolean leaveLastJoinedRoom) {
        this.sendJoinRoomInvitation(target, inviter, invitees, expirySeconds, asSpect, leaveLastJoinedRoom, null);
    }
    
    @Override
    public void sendJoinRoomInvitation(final Room target, final User inviter, final List<User> invitees, final int expirySeconds, final boolean asSpect, final boolean leaveLastJoinedRoom, final ISFSObject params) {
        final boolean isServer = inviter == null;
        final boolean allowed = isServer || this.isJoinRoomInvitationSenderAllowed(inviter, target);
        if (!allowed) {
            throw new SFSRuntimeException("User: " + inviter.getName() + " is not allowed to join-invite people in " + target.toString());
        }
        this.sendInvitation(inviter, invitees, expirySeconds, new JoinRoomInvitationCallback(target), params);
    }
    
    private boolean isJoinRoomInvitationSenderAllowed(final User user, final Room target) {
        boolean allowed = false;
        if (target.isAllowOwnerInvitations()) {
            allowed = (target.getOwner() == user);
        }
        else if (target.isGame()) {
            allowed = target.getPlayersList().contains(user);
        }
        else {
            allowed = target.containsUser(user);
        }
        return allowed;
    }
    
    private Room quickJoinGame(final User player, final MatchExpression expression, final Collection<Room> searchableRooms, final Room roomToLeave, final boolean asSpectator) throws SFSJoinRoomException {
        if (searchableRooms == null || searchableRooms.size() < 1) {
            throw new IllegalArgumentException("No Room provided for searching.");
        }
        final MatchExpression basicFilter = new MatchExpression("${ISG}", BoolMatch.EQUALS, true).and("${ISP}", BoolMatch.EQUALS, false).and("${HFP}", BoolMatch.EQUALS, true);
        Collection<Room> possibleRooms = this.sfsApi.findRooms(searchableRooms, basicFilter, 0);
        possibleRooms = this.sfsApi.findRooms(possibleRooms, expression, 0);
        final StringBuilder debugSb = new StringBuilder("Rooms available for QuickJoin:\n");
        for (final Room item : possibleRooms) {
            debugSb.append(String.format("%s => %s, %s%n", item.getName(), item.getVariables(), ((SFSGame)item).getPlayerMatchExpression()));
        }
        if (this.log.isDebugEnabled()) {
            this.log.debug(debugSb.toString());
        }
        Room theRoom = null;
        for (final Room candidateRoom : possibleRooms) {
            if (!(candidateRoom instanceof SFSGame)) {
                theRoom = candidateRoom;
                break;
            }
            final MatchExpression roomCriteria = ((SFSGame)candidateRoom).getPlayerMatchExpression();
            if (MatchingUtils.getInstance().matchUser(player, roomCriteria)) {
                theRoom = candidateRoom;
                break;
            }
        }
        if (theRoom != null) {
            this.sfsApi.joinRoom(player, theRoom, null, asSpectator, roomToLeave);
            return theRoom;
        }
        final String message = String.format("No Game Room was found for %s", player);
        final SFSErrorData errData = new SFSErrorData(SFSErrorCode.JOIN_GAME_NOT_FOUND);
        throw new SFSQuickJoinGameException(message, errData);
    }
    
    private void validateSFSGameSettings(final CreateSFSGameSettings settings, final User owner) throws SFSCreateGameException {
        if (owner != null) {
            final String alreadyRunningProcessName = (String)owner.getSession().getSystemProperty("InvitationProcessRunning");
            if (alreadyRunningProcessName != null) {
                throw new SFSCreateGameException(String.format("%s is already running another invitation process for a game called: %s. A new one can be started once the previous is complete.", owner, alreadyRunningProcessName));
            }
        }
        if (settings.getMinPlayersToStartGame() < 1) {
            throw new SFSCreateGameException("minPlayersToStartGame cannot be < 1");
        }
        if (settings.getMinPlayersToStartGame() > settings.getMaxUsers()) {
            throw new SFSCreateGameException(String.format("Minimum amount of players (%s) can't be > maxUsers (%s).", settings.getMinPlayersToStartGame(), settings.getMaxUsers()));
        }
    }
    
    private void populateInvitations(final User inviter, final List<User> invitedPlayers, final int minPlayersToStart, final List<Room> searchableRooms, final MatchExpression exp) {
        if (invitedPlayers.size() < minPlayersToStart) {
            final int peopleToSearch = minPlayersToStart - invitedPlayers.size();
            final Set<User> setOfPlayers = new HashSet<User>(invitedPlayers);
            Collection<User> searchableUserList = null;
            if (searchableRooms.size() == 1) {
                searchableUserList = searchableRooms.get(0).getUserList();
            }
            else {
                searchableUserList = new HashSet<User>();
                for (final Room room : searchableRooms) {
                    searchableUserList.addAll(room.getUserList());
                }
            }
            final List<User> srcResult = this.sfsApi.findUsers(searchableUserList, exp, peopleToSearch);
            if (this.log.isDebugEnabled()) {
                if (srcResult.size() > 0) {
                    this.log.debug("Players matching the game were found and added to the invitation: " + srcResult);
                }
                else {
                    this.log.debug("No other Players matching the game were found.");
                }
            }
            setOfPlayers.addAll(srcResult);
            setOfPlayers.remove(inviter);
            invitedPlayers.clear();
            invitedPlayers.addAll(setOfPlayers);
        }
    }
    
    private void inviteFriendsInGame(final SFSGame theGame, final List<User> friends, final boolean leaveLastJoinedRoom, final int expiryTime, final ISFSObject params) {
        final User owner = theGame.getOwner();
        if (friends.size() == 0) {
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, theGame.getZone());
            evtParams.put(SFSEventParam.ROOM, theGame);
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.GAME_INVITATION_FAILURE, evtParams));
            return;
        }
        final InvitationCallback callback = new SFSGameInvitationCallback(theGame, friends.size(), leaveLastJoinedRoom);
        if (owner != null) {
            owner.getSession().setSystemProperty("InvitationProcessRunning", (Object)theGame.getName());
        }
        final User inviter = (owner == null) ? UsersUtil.getServerAdmin() : owner;
        for (final User friend : friends) {
            final Invitation invitation = new SFSInvitation(inviter, friend, expiryTime, params);
            this.sfs.getInvitationManager().startInvitation(invitation, callback);
            this.responseApi.notifyInivitation(invitation);
        }
    }
    
    private String generateGamePassword() {
        return String.valueOf(RandomStringUtils.randomAlphabetic(16)) + System.currentTimeMillis();
    }
}

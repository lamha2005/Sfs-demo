// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import java.util.Arrays;
import com.smartfoxserver.v2.buddylist.SFSBuddyVariable;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.variables.Variable;
import com.smartfoxserver.v2.entities.variables.Variables;
import java.util.ArrayList;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.List;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.buddylist.Buddy;
import com.smartfoxserver.v2.buddylist.BuddyProperties;
import java.util.Map;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEvent;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.buddylist.SFSBuddyEventParam;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEventParam;
import java.util.HashMap;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.buddylist.BuddyOnlineState;
import com.smartfoxserver.v2.buddylist.BuddyList;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.buddylist.BuddySerializerFactory;
import com.smartfoxserver.v2.api.response.SFSBuddyResponseApi;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;

public class SFSBuddyApi implements ISFSBuddyApi
{
    protected final SmartFoxServer sfs;
    protected final Logger log;
    protected final ISFSBuddyResponseApi responseAPI;
    protected final ISFSApi sfsApi;
    
    public SFSBuddyApi(final SmartFoxServer sfs) {
        this.sfs = sfs;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.responseAPI = new SFSBuddyResponseApi();
        this.sfsApi = sfs.getAPIManager().getSFSApi();
        BuddySerializerFactory.init();
    }
    
    @Override
    public ISFSBuddyResponseApi getResponseAPI() {
        return this.responseAPI;
    }
    
    @Override
    public BuddyList initBuddyList(final User user, final boolean fireServerEvent) throws IOException {
        final BuddyListManager manager = user.getZone().getBuddyListManager();
        this.checkBuddyManagerIsActive(manager, user);
        user.updateLastRequestTime();
        BuddyList buddyList = null;
        try {
            buddyList = manager.loadBuddyList(user.getName());
            user.getBuddyProperties().setInited();
            this.responseAPI.notifyBuddyListInited(buddyList);
            if (user.getBuddyProperties().isOnline()) {
                this.responseAPI.notifyBuddyOnlineStateChange(user, BuddyOnlineState.ONLINE, true);
            }
            try {
                this.initializeBuddyState(user);
            }
            catch (SFSBuddyListException e) {
                this.log.warn("Was not able to initalized the BUDDY_STATE variable: " + e);
            }
            if (fireServerEvent) {
                final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                evtParams.put(SFSEventParam.ZONE, user.getZone());
                evtParams.put(SFSEventParam.USER, user);
                evtParams.put(SFSBuddyEventParam.BUDDY_LIST, buddyList);
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.BUDDY_LIST_INIT, evtParams));
            }
        }
        catch (IOException ioErr) {
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.BUDDY_LIST_LOAD_FAILURE);
            errData.addParameter(ioErr.getMessage());
            final SFSBuddyListException err = new SFSBuddyListException("BuddyList load error", errData);
            this.sfsApi.getResponseAPI().notifyRequestError(err, user, SystemRequest.InitBuddyList);
            throw ioErr;
        }
        return buddyList;
    }
    
    @Override
    public void goOnline(final User user, final boolean online, final boolean fireServerEvent) {
        final BuddyListManager manager = user.getZone().getBuddyListManager();
        this.checkBuddyManagerIsActive(manager, user);
        final BuddyProperties props = user.getBuddyProperties();
        this.checkBuddyIsInited(props);
        if (props.isOnline() != online) {
            props.setOnline(online);
            props.setChangedSinceLastSave(true);
            user.updateLastRequestTime();
            if (this.log.isDebugEnabled()) {
                this.log.debug(String.format("User %s goes %s", user.getName(), online ? "ONLINE" : "OFFLINE"));
            }
            this.responseAPI.notifyBuddyOnlineStateChange(user, online ? BuddyOnlineState.ONLINE : BuddyOnlineState.OFFLINE);
            if (fireServerEvent) {
                final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                evtParams.put(SFSEventParam.ZONE, user.getZone());
                evtParams.put(SFSEventParam.USER, user);
                evtParams.put(SFSBuddyEventParam.BUDDY_IS_ONLINE, online);
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.BUDDY_ONLINE_STATE_UPDATE, evtParams));
            }
        }
        else {
            this.log.info(String.format("Buddy online state is already: %s, %s ", online, user));
        }
    }
    
    @Override
    public void addBuddy(final User owner, final String buddyName, final boolean isTemp, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSBuddyListException {
        final BuddyListManager manager = owner.getZone().getBuddyListManager();
        this.checkBuddyManagerIsActive(manager, owner);
        owner.updateLastRequestTime();
        try {
            final Buddy buddy = manager.addBuddy(owner.getName(), buddyName, isTemp);
            if (buddy != null) {
                owner.getBuddyProperties().setChangedSinceLastSave(true);
                if (fireClientEvent) {
                    this.responseAPI.notifyAddBuddy(buddy, owner);
                }
                if (fireServerEvent) {
                    final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                    evtParams.put(SFSEventParam.ZONE, owner.getZone());
                    evtParams.put(SFSEventParam.USER, owner);
                    evtParams.put(SFSBuddyEventParam.BUDDY, buddy);
                    this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.BUDDY_ADD, evtParams));
                }
            }
        }
        catch (SFSBuddyListException buddyErr) {
            if (fireClientEvent) {
                this.sfsApi.getResponseAPI().notifyRequestError(buddyErr, owner, SystemRequest.AddBuddy);
            }
            throw buddyErr;
        }
    }
    
    @Override
    public void addBuddy(final Zone zone, final String ownerName, final String buddyName, final boolean isTemp, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSBuddyListException {
        throw new UnsupportedOperationException("Not yet implemented!");
    }
    
    @Override
    public void removeBuddy(final User owner, final String buddyName, final boolean fireClientEvent, final boolean fireServerEvent) {
        final BuddyListManager manager = owner.getZone().getBuddyListManager();
        this.checkBuddyManagerIsActive(manager, owner);
        final BuddyProperties props = owner.getBuddyProperties();
        this.checkBuddyIsInited(props);
        final Buddy removedBuddy = manager.removeBuddy(owner.getName(), buddyName);
        owner.updateLastRequestTime();
        if (removedBuddy != null) {
            props.setChangedSinceLastSave(true);
            if (fireClientEvent) {
                this.responseAPI.notifyRemoveBuddy(removedBuddy.getName(), owner);
            }
            if (fireServerEvent) {
                final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                evtParams.put(SFSEventParam.ZONE, owner.getZone());
                evtParams.put(SFSEventParam.USER, owner);
                evtParams.put(SFSBuddyEventParam.BUDDY, removedBuddy);
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.BUDDY_REMOVE, evtParams));
            }
        }
        else {
            this.log.info(String.format("RemoveBuddy error: %s is not present in %s buddy list", buddyName, owner.getName()));
        }
    }
    
    @Override
    public void removeBuddy(final Zone zone, final String ownerName, final String buddyName, final boolean fireClientEvent, final boolean fireServerEvent) {
    }
    
    @Override
    public void blockBuddy(final User owner, final String buddyName, final boolean isBlocked, final boolean fireClientEvent, final boolean fireServerEvent) {
        final BuddyListManager buddyListManager = owner.getZone().getBuddyListManager();
        this.checkBuddyManagerIsActive(buddyListManager, owner);
        final BuddyProperties props = owner.getBuddyProperties();
        this.checkBuddyIsInited(props);
        final BuddyList bList = buddyListManager.getBuddyList(owner.getName());
        boolean error = false;
        owner.updateLastRequestTime();
        if (bList != null) {
            final Buddy buddy = bList.getBuddy(buddyName);
            if (buddy != null) {
                buddy.setBlocked(isBlocked);
                if (this.log.isDebugEnabled()) {
                    this.log.debug(String.format("Buddy %s was %s in %s buddylist", buddy.getName(), isBlocked ? "blocked" : "unblocked", owner.getName()));
                }
                owner.getBuddyProperties().setChangedSinceLastSave(true);
                if (fireClientEvent) {
                    this.responseAPI.notifyBuddyBlockStatus(buddy, owner);
                }
                if (fireServerEvent) {
                    final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
                    evtParams.put(SFSEventParam.ZONE, owner.getZone());
                    evtParams.put(SFSEventParam.USER, owner);
                    evtParams.put(SFSBuddyEventParam.BUDDY, buddy);
                    this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.BUDDY_BLOCK, evtParams));
                }
            }
            else {
                error = true;
            }
        }
        else {
            error = true;
        }
        if (error) {
            this.log.info(String.format("BlockBuddy failure. Buddy: %s is not present in %s BuddyList", buddyName, owner.getName()));
        }
    }
    
    @Override
    public void setBuddyVariables(final User owner, final List<BuddyVariable> buddyVariables, final boolean fireClientEvent, final boolean fireServerEvent) throws SFSBuddyListException {
        final BuddyListManager manager = owner.getZone().getBuddyListManager();
        this.checkBuddyManagerIsActive(manager, owner);
        final BuddyProperties props = owner.getBuddyProperties();
        this.checkBuddyIsInited(props);
        final int maxAllowedVariables = owner.getZone().getBuddyListManager().getMaxBuddyVariables();
        final List<BuddyVariable> listOfChanges = new ArrayList<BuddyVariable>();
        for (final BuddyVariable bVar : buddyVariables) {
            final BuddyVariable oldVar = props.getVariable(bVar.getName());
            if (oldVar == null) {
                if (props.getVariablesCount() < maxAllowedVariables) {
                    props.setVariable(bVar);
                    listOfChanges.add(bVar);
                }
                else {
                    this.log.warn(String.format("Max number of BuddyVariables (%) was reached for User: %s, Discarding variable: %s", maxAllowedVariables, owner.getName(), bVar));
                }
            }
            else {
                props.setVariable(bVar);
                listOfChanges.add(bVar);
            }
        }
        if (listOfChanges.size() > 0) {
            props.setChangedSinceLastSave(true);
        }
        owner.updateLastRequestTime();
        if (fireClientEvent) {
            this.responseAPI.notifyBuddyVariablesUpdate(owner, listOfChanges);
        }
        if (fireServerEvent) {
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, owner.getZone());
            evtParams.put(SFSEventParam.USER, owner);
            evtParams.put(SFSEventParam.VARIABLES, listOfChanges);
            evtParams.put(SFSEventParam.VARIABLES_MAP, Variables.toVariablesMap(listOfChanges));
            this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.BUDDY_VARIABLES_UPDATE, evtParams));
        }
    }
    
    @Override
    public void sendBuddyMessage(final User sender, final User recipient, final String message, final ISFSObject params) throws SFSBuddyListException {
        this.sfs.getAPIManager().getSFSApi().sendBuddyMessage(sender, recipient, message, params);
    }
    
    private void checkBuddyManagerIsActive(final BuddyListManager manager, final User sender) {
        if (!manager.isActive()) {
            throw new IllegalStateException(String.format("BuddyList operation failure. BuddyListManager is not active. Zone: %s, Sender: %s", sender.getZone(), sender));
        }
    }
    
    private void checkBuddyIsInited(final BuddyProperties props) {
        if (!props.isInited()) {
            throw new IllegalStateException("The BuddyList is not initialized. Please call initBuddyList() first or use the InitBuddyListRequest from client side.");
        }
    }
    
    protected void initializeBuddyState(final User user) throws SFSBuddyListException {
        final BuddyListManager manager = user.getZone().getBuddyListManager();
        if (manager.getBuddyStates() != null && manager.getBuddyStates().size() > 0) {
            final BuddyVariable buddyState = user.getBuddyProperties().getVariable("$__BV_STATE__");
            if (buddyState == null) {
                this.setBuddyVariables(user, Arrays.asList(new SFSBuddyVariable("$__BV_STATE__", manager.getBuddyStates().get(0))), true, false);
            }
        }
    }
}

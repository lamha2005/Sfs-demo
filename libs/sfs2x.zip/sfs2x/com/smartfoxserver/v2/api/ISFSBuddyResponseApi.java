// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import com.smartfoxserver.v2.grid.IGridBuddyEventDispatcher;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.List;
import com.smartfoxserver.v2.buddylist.BuddyOnlineState;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.buddylist.Buddy;
import com.smartfoxserver.v2.buddylist.BuddyList;

public interface ISFSBuddyResponseApi
{
    void notifyBuddyListInited(final BuddyList p0);
    
    void notifyAddBuddy(final Buddy p0, final User p1);
    
    void notifyRemoveBuddy(final String p0, final User p1);
    
    void notifyBuddyBlockStatus(final Buddy p0, final User p1);
    
    void notifyBuddyOnlineStateChange(final User p0, final BuddyOnlineState p1);
    
    void notifyBuddyOnlineStateChange(final User p0, final BuddyOnlineState p1, final boolean p2);
    
    void notifyBuddyVariablesUpdate(final User p0, final List<BuddyVariable> p1);
    
    IGridBuddyEventDispatcher getGridEventDispatcher();
}

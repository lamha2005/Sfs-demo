// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.Collection;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.bitswarm.sessions.ISession;

public final class LoginErrorHandler
{
    public void execute(final ISession sender, SFSLoginException err) {
        final ISFSObject resObj = SFSObject.newInstance();
        if (err.getErrorData() == null) {
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.GENERIC_ERROR);
            errData.addParameter("An unexpected error occurred, please check the server side logs");
            err = new SFSLoginException(err.getMessage(), errData);
        }
        this.updateFailedLogins(sender);
        final IResponse response = (IResponse)new Response();
        response.setId(SystemRequest.Login.getId());
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.setContent((Object)resObj);
        response.setRecipients(sender);
        resObj.putShort("ec", err.getErrorData().getCode().getId());
        resObj.putUtfStringArray("ep", err.getErrorData().getParams());
        response.write();
    }
    
    private void updateFailedLogins(final ISession session) {
        final AtomicInteger count = (AtomicInteger)session.getSystemProperty("FailedLoginCounts");
        if (count != null) {
            count.incrementAndGet();
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.api;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.List;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import java.io.IOException;
import com.smartfoxserver.v2.buddylist.BuddyList;
import com.smartfoxserver.v2.entities.User;

public interface ISFSBuddyApi
{
    ISFSBuddyResponseApi getResponseAPI();
    
    BuddyList initBuddyList(final User p0, final boolean p1) throws IOException;
    
    void goOnline(final User p0, final boolean p1, final boolean p2) throws SFSBuddyListException;
    
    void addBuddy(final Zone p0, final String p1, final String p2, final boolean p3, final boolean p4, final boolean p5) throws SFSBuddyListException;
    
    void addBuddy(final User p0, final String p1, final boolean p2, final boolean p3, final boolean p4) throws SFSBuddyListException;
    
    void setBuddyVariables(final User p0, final List<BuddyVariable> p1, final boolean p2, final boolean p3) throws SFSBuddyListException;
    
    void removeBuddy(final User p0, final String p1, final boolean p2, final boolean p3);
    
    void removeBuddy(final Zone p0, final String p1, final String p2, final boolean p3, final boolean p4);
    
    void blockBuddy(final User p0, final String p1, final boolean p2, final boolean p3, final boolean p4);
    
    void sendBuddyMessage(final User p0, final User p1, final String p2, final ISFSObject p3) throws SFSBuddyListException;
}

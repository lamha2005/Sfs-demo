// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.game;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import java.util.List;
import com.smartfoxserver.v2.api.CreateRoomSettings;

public class CreateSFSGameSettings extends CreateRoomSettings
{
    private boolean gamePublic;
    private int minPlayersToStartGame;
    private List<User> invitedPlayers;
    private List<Room> searchableRooms;
    private boolean leaveLastJoinedRoom;
    private MatchExpression playerMatchExpression;
    private MatchExpression spectatorMatchExpression;
    private int invitationExpiryTime;
    private boolean notifyGameStartedViaRoomVariable;
    private ISFSObject invitationParams;
    
    public static CreateSFSGameSettings newFromRoomSettings(final CreateRoomSettings rSettings) {
        final CreateSFSGameSettings gameSettings = new CreateSFSGameSettings();
        gameSettings.setAutoRemoveMode(rSettings.getAutoRemoveMode());
        gameSettings.setUseWordsFilter(rSettings.isUseWordsFilter());
        gameSettings.setCustomPlayerIdGeneratorClass(rSettings.getCustomPlayerIdGeneratorClass());
        gameSettings.setDynamic(rSettings.isDynamic());
        gameSettings.setExtension(rSettings.getExtension());
        gameSettings.setGroupId(rSettings.getGroupId());
        gameSettings.setHidden(rSettings.isHidden());
        gameSettings.setMaxSpectators(rSettings.getMaxSpectators());
        gameSettings.setMaxUsers(rSettings.getMaxUsers());
        gameSettings.setMaxVariablesAllowed(rSettings.getMaxVariablesAllowed());
        gameSettings.setName(rSettings.getName());
        gameSettings.setRoomSettings(rSettings.getRoomSettings());
        gameSettings.setRoomVariables(rSettings.getRoomVariables());
        return gameSettings;
    }
    
    public CreateSFSGameSettings() {
        this.leaveLastJoinedRoom = true;
        this.invitationExpiryTime = 10;
        this.notifyGameStartedViaRoomVariable = false;
        this.setGame(true);
    }
    
    public boolean isGamePublic() {
        return this.gamePublic;
    }
    
    public void setGamePublic(final boolean isGamePublic) {
        this.gamePublic = isGamePublic;
    }
    
    public int getMinPlayersToStartGame() {
        return this.minPlayersToStartGame;
    }
    
    public void setMinPlayersToStartGame(final int minPlayersToStartGame) {
        this.minPlayersToStartGame = minPlayersToStartGame;
    }
    
    public List<User> getInvitedPlayers() {
        return this.invitedPlayers;
    }
    
    public void setInvitedPlayers(final List<User> invitedPlayers) {
        this.invitedPlayers = invitedPlayers;
    }
    
    public List<Room> getSearchableRooms() {
        return this.searchableRooms;
    }
    
    public void setSearchableRooms(final List<Room> searchableRooms) {
        this.searchableRooms = searchableRooms;
    }
    
    public boolean isLeaveLastJoinedRoom() {
        return this.leaveLastJoinedRoom;
    }
    
    public void setLeaveLastJoinedRoom(final boolean leaveLastJoinedRoom) {
        this.leaveLastJoinedRoom = leaveLastJoinedRoom;
    }
    
    public MatchExpression getPlayerMatchExpression() {
        return this.playerMatchExpression;
    }
    
    public void setPlayerMatchExpression(final MatchExpression playerMatchExpression) {
        this.playerMatchExpression = playerMatchExpression;
    }
    
    public MatchExpression getSpectatorMatchExpression() {
        return this.spectatorMatchExpression;
    }
    
    public void setSpectatorMatchExpression(final MatchExpression spectatorMatchExpression) {
        this.spectatorMatchExpression = spectatorMatchExpression;
    }
    
    public int getInvitationExpiryTime() {
        return this.invitationExpiryTime;
    }
    
    public void setInvitationExpiryTime(final int invitationExpiryTime) {
        this.invitationExpiryTime = invitationExpiryTime;
    }
    
    public boolean isNotifyGameStartedViaRoomVariable() {
        return this.notifyGameStartedViaRoomVariable;
    }
    
    public void setNotifyGameStartedViaRoomVariable(final boolean notifyGameStartedWithRoomVariable) {
        this.notifyGameStartedViaRoomVariable = notifyGameStartedWithRoomVariable;
    }
    
    public ISFSObject getInvitationParams() {
        return this.invitationParams;
    }
    
    public void setInvitationParams(final ISFSObject invitationParams) {
        this.invitationParams = invitationParams;
    }
    
    @Override
    public String toString() {
        final String dump = String.valueOf(super.toString()) + " <<< SFSGame" + " Properties >>>" + "\n" + "=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--" + "\n" + "isGamePublic: " + this.isGamePublic() + "\n" + "minPlayersToStartGame: " + this.getMinPlayersToStartGame() + "\n" + "invitedPlayers: " + this.getInvitedPlayers() + "\n" + "playerMatchExp: " + this.getPlayerMatchExpression() + "\n" + "spectMatchExp: " + this.getSpectatorMatchExpression() + "\n" + "invExpiryTime: " + this.getInvitationExpiryTime() + "\n" + "notifyGameStarted: " + this.isNotifyGameStartedViaRoomVariable() + "\n" + "invitation params: " + this.getInvitationParams().getDump() + "\n" + "=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--\n";
        return dump;
    }
}

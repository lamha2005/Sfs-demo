// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.game;

import java.util.Map;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEvent;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEventParam;
import java.util.HashMap;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.invitation.Invitation;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.concurrent.atomic.AtomicInteger;

public class SFSGameInvitationCallback extends BaseGameInvitationCallback
{
    private final AtomicInteger responseCount;
    private final int invitedPlayersCount;
    private final SmartFoxServer sfs;
    
    public SFSGameInvitationCallback(final Room game, final int invitedPlayersCount, final boolean leaveLastJoinedRoom) {
        super(game, leaveLastJoinedRoom);
        this.sfs = SmartFoxServer.getInstance();
        this.invitedPlayersCount = invitedPlayersCount;
        this.responseCount = new AtomicInteger(0);
    }
    
    @Override
    public void onAccepted(final Invitation invObj, final ISFSObject params) {
        final User user = invObj.getInvitee();
        Room roomToLeave = null;
        Integer roomToLeavedIdFromClient = null;
        if (params != null) {
            roomToLeavedIdFromClient = params.getInt("$rl");
        }
        if (this.isLeaveLastJoindRoom()) {
            roomToLeave = user.getLastJoinedRoom();
        }
        else if (roomToLeavedIdFromClient != null) {
            roomToLeave = user.getZone().getRoomById(roomToLeavedIdFromClient);
        }
        try {
            this.sfsAPI.joinRoom(invObj.getInvitee(), this.getGame(), this.getGame().getPassword(), false, roomToLeave);
        }
        catch (SFSJoinRoomException joinErr) {
            this.log.warn(String.format("Invitee %s accepted invitation but failed joining %s, %s", invObj.getInvitee(), this.getGame(), joinErr));
            return;
        }
        finally {
            this.checkForInvitationCycleComplete();
        }
        this.checkForInvitationCycleComplete();
    }
    
    @Override
    public void onRefused(final Invitation invObj, final ISFSObject params) {
        this.log.info(String.format("Invitation refused by %s for game %s", invObj.getInvitee(), this.getGame()));
        this.checkForInvitationCycleComplete();
    }
    
    @Override
    public void onExpired(final Invitation invObj) {
        this.log.info(String.format("Invitation expired for %s, Game: %s", invObj.getInvitee(), this.getGame()));
        this.checkForInvitationCycleComplete();
    }
    
    private void checkForInvitationCycleComplete() {
        final int count = this.responseCount.incrementAndGet();
        final SFSGame game = (SFSGame)this.getGame();
        if (count == this.invitedPlayersCount) {
            final User owner = game.getOwner();
            if (owner != null) {
                owner.getSession().removeSystemProperty("InvitationProcessRunning");
            }
            final boolean goodToGo = game.isActive() && game.isGameStarted();
            final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
            evtParams.put(SFSEventParam.ZONE, game.getZone());
            evtParams.put(SFSEventParam.ROOM, game);
            if (goodToGo) {
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.GAME_INVITATION_SUCCESS, evtParams));
            }
            else {
                this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.GAME_INVITATION_FAILURE, evtParams));
            }
        }
    }
}

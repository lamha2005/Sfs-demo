// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.game;

import com.smartfoxserver.v2.entities.invitation.InvitationResponse;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.invitation.Invitation;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.api.response.ISFSGameResponseApi;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;

public class GenericInvitationCallback implements InvitationCallback
{
    protected final ISFSGameResponseApi responseApi;
    private int callCount;
    
    public GenericInvitationCallback() {
        this.callCount = 0;
        this.responseApi = SmartFoxServer.getInstance().getAPIManager().getGameApi().getResponseAPI();
    }
    
    @Override
    public void onAccepted(final Invitation invObj, final ISFSObject params) {
        this.responseApi.notifyInvitationResponse(invObj, InvitationResponse.ACCEPT, params);
    }
    
    @Override
    public void onExpired(final Invitation invObj) {
        this.responseApi.notifyInvitationResponse(invObj, InvitationResponse.EXPIRED, null);
    }
    
    @Override
    public void onRefused(final Invitation invObj, final ISFSObject params) {
        this.responseApi.notifyInvitationResponse(invObj, InvitationResponse.REFUSE, params);
    }
    
    private void debug(final Invitation invObj) {
        ++this.callCount;
        System.err.println("InvitationCallback: " + invObj.getId() + ", invocations: " + this.callCount);
        System.err.println("INVITATION OBJECT TYPE: " + invObj + ", INVITER: " + invObj.getInviter().getClass() + ", INVITEE: " + invObj.getInvitee().getClass());
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.game;

import com.smartfoxserver.v2.api.ISFSApi;
import com.smartfoxserver.v2.entities.Room;
import java.util.Arrays;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import com.smartfoxserver.v2.entities.variables.SFSRoomVariable;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.entities.SFSRoom;

public class SFSGame extends SFSRoom
{
    private MatchExpression playerMatchExpression;
    private MatchExpression spectatorMatchExpression;
    private int minPlayersToStartGame;
    private boolean leaveLastRoomOnJoin;
    private boolean notifyGameStarted;
    private boolean gameStateChanged;
    
    public SFSGame(final String name) {
        super(name);
        this.leaveLastRoomOnJoin = true;
        this.notifyGameStarted = false;
        this.gameStateChanged = false;
    }
    
    public MatchExpression getPlayerMatchExpression() {
        return this.playerMatchExpression;
    }
    
    public int getMinPlayersToStartGame() {
        return this.minPlayersToStartGame;
    }
    
    public void setPlayerMatchExpression(final MatchExpression exp) {
        if (this.playerMatchExpression != null) {
            throw new IllegalStateException("UserMatchExpression can't be modified at runtime");
        }
        this.playerMatchExpression = exp;
    }
    
    public MatchExpression getSpectatorMatchExpression() {
        return this.spectatorMatchExpression;
    }
    
    public void setSpectatorMatchExpression(final MatchExpression spectatorMatchExpression) {
        if (this.spectatorMatchExpression != null) {
            throw new IllegalStateException("UserMatchExpression can't be modified at runtime");
        }
        this.spectatorMatchExpression = spectatorMatchExpression;
    }
    
    public void setMinPlayersToStartGame(final int min) {
        this.minPlayersToStartGame = min;
    }
    
    public boolean isLeaveLastRoomOnJoin() {
        return this.leaveLastRoomOnJoin;
    }
    
    public void setLeaveLastRoomOnJoin(final boolean leaveLastRoomOnJoin) {
        this.leaveLastRoomOnJoin = leaveLastRoomOnJoin;
    }
    
    public boolean isNotifyGameStarted() {
        return this.notifyGameStarted;
    }
    
    public void setNotifyGameStarted(final boolean notifyGameStarted) {
        this.notifyGameStarted = notifyGameStarted;
    }
    
    public boolean isGameStarted() {
        return this.getSize().getUserCount() >= this.minPlayersToStartGame;
    }
    
    public boolean isGameStateChanged() {
        return this.gameStateChanged;
    }
    
    @Override
    public void addUser(final User user, final boolean asSpectator) throws SFSJoinRoomException {
        final boolean oldGameStarted = this.isGameStarted();
        super.addUser(user, asSpectator);
        final boolean newGameStarted = this.isGameStarted();
        this.notifyGameStartedUpdate(this.gameStateChanged = (newGameStarted ^ oldGameStarted), newGameStarted);
    }
    
    @Override
    public void removeUser(final User user) {
        final boolean oldGameStarted = this.isGameStarted();
        super.removeUser(user);
        final boolean newGameStarted = this.isGameStarted();
        this.notifyGameStartedUpdate(this.gameStateChanged = (newGameStarted ^ oldGameStarted), newGameStarted);
    }
    
    @Override
    public String toString() {
        return String.format("[ SFSGame: %s, Id: %s, Group: %s, public: %s, minPlayers: %s ]", this.getName(), this.getId(), this.getGroupId(), this.isPublic(), this.minPlayersToStartGame);
    }
    
    @Override
    public void switchPlayerToSpectator(final User user) throws SFSRoomException {
        final boolean oldGameStarted = this.isGameStarted();
        super.switchPlayerToSpectator(user);
        final boolean newGameStarted = this.isGameStarted();
        this.notifyGameStartedUpdate(this.gameStateChanged = (newGameStarted ^ oldGameStarted), newGameStarted);
    }
    
    @Override
    public void switchSpectatorToPlayer(final User user) throws SFSRoomException {
        final boolean oldGameStarted = this.isGameStarted();
        super.switchSpectatorToPlayer(user);
        final boolean newGameStarted = this.isGameStarted();
        this.notifyGameStartedUpdate(this.gameStateChanged = (newGameStarted ^ oldGameStarted), newGameStarted);
    }
    
    private void notifyGameStartedUpdate(final boolean gameStateChanged, final boolean gameStarted) {
        if (this.notifyGameStarted && gameStateChanged) {
            final ISFSApi api = SmartFoxServer.getInstance().getAPIManager().getSFSApi();
            final RoomVariable varGameStarted = new SFSRoomVariable("$GS", gameStarted);
            varGameStarted.setGlobal(true);
            varGameStarted.setPrivate(true);
            api.setRoomVariables(null, this, Arrays.asList(varGameStarted));
        }
    }
}

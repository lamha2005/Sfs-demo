// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.game;

import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.api.ISFSApi;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;

public abstract class BaseGameInvitationCallback implements InvitationCallback
{
    private Room game;
    private boolean leaveLastJoinedRoom;
    protected final Logger log;
    protected final ISFSApi sfsAPI;
    
    public BaseGameInvitationCallback(final Room game, final boolean leaveLastJoinedRoom) {
        this.game = game;
        this.leaveLastJoinedRoom = leaveLastJoinedRoom;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.sfsAPI = SmartFoxServer.getInstance().getAPIManager().getSFSApi();
    }
    
    protected Room getGame() {
        return this.game;
    }
    
    protected boolean isLeaveLastJoindRoom() {
        return this.leaveLastJoinedRoom;
    }
}

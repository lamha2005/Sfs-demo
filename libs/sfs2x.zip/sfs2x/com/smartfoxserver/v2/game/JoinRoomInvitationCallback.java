// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.game;

import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.invitation.Invitation;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.api.ISFSApi;
import com.smartfoxserver.v2.entities.Room;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;

public class JoinRoomInvitationCallback implements InvitationCallback
{
    private final Logger log;
    private final Room targetRoom;
    private final ISFSApi api;
    
    public JoinRoomInvitationCallback(final Room targetRoom) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.targetRoom = targetRoom;
        this.api = SmartFoxServer.getInstance().getAPIManager().getSFSApi();
    }
    
    @Override
    public void onAccepted(final Invitation invObj, final ISFSObject params) {
        try {
            this.api.joinRoom(invObj.getInvitee(), this.targetRoom);
        }
        catch (SFSJoinRoomException ex) {
            this.log.warn("Join Invitation accept failed: %s, %s ", (Object)ex, (Object)invObj);
        }
    }
    
    @Override
    public void onRefused(final Invitation invObj, final ISFSObject params) {
        this.log.debug("Join invitation refused by {}, in room: {}", (Object)invObj.getInvitee(), (Object)this.targetRoom);
    }
    
    @Override
    public void onExpired(final Invitation invObj) {
        this.log.debug("Join invitation expired for {}, in room: {}", (Object)invObj.getInvitee(), (Object)this.targetRoom);
    }
}

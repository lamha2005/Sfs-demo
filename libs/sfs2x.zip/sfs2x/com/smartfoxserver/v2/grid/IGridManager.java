// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.grid;

import com.smartfoxserver.grid.config.GridSettings;
import com.smartfoxserver.grid.config.NodeSettings;
import com.smartfoxserver.grid.SFSGridAppManager;
import com.smartfoxserver.grid.service.IPendingNotificationManager;
import javax.persistence.EntityManager;
import com.smartfoxserver.grid.service.IGridAppLoadBalancingManager;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.grid.api.ISFSGridApi;
import com.hazelcast.core.IExecutorService;
import com.smartfoxserver.grid.events.IGridEvent;
import com.hazelcast.query.Predicate;
import com.hazelcast.core.IMap;
import java.util.Collection;
import java.util.List;
import com.smartfoxserver.grid.model.IGridNode;
import com.hazelcast.core.Member;
import com.hazelcast.core.HazelcastInstance;

public interface IGridManager
{
    IGridUserManager getUserManager();
    
    HazelcastInstance getHC();
    
    Member getLocalMember();
    
    IGridNode getLocalNode();
    
    int getMinClienApiVersion();
    
    IGridNode getNodeById(final String p0);
    
    IGridNode getNodeByName(final String p0);
    
    List<IGridNode> getLobbyNodes();
    
    List<IGridNode> getAppNodes();
    
    List<IGridNode> getAppNodesByGroup(final String p0);
    
    Collection<Member> getLobbyMembers();
    
    Collection<Member> getAppMembers();
    
    Collection<String> getAppNodeGroups();
    
    boolean containsGroup(final String p0);
    
    void updateLoadBalanceParams(final IGridNode p0);
    
    IMap<String, Object> getDataStore();
    
    Collection<IGridNode> queryNodes(final Predicate<String, IGridNode> p0);
    
    void dispatchLobbyEvent(final IGridEvent p0);
    
    void dispatchLobbyEventBulk(final List<IGridEvent> p0);
    
    void dispatchLobbyEventBulk(final List<IGridEvent> p0, final Member p1);
    
    IExecutorService getExecutor();
    
    ISFSGridApi getApi();
    
    boolean isLobby();
    
    boolean isMaster();
    
    Zone getZone();
    
    IGridAppLoadBalancingManager getAppLoadManager();
    
    EntityManager getNewEntityManager();
    
    IPendingNotificationManager getPendingNotificationManager();
    
    SFSGridAppManager getAppManager();
    
    NodeSettings getLocalNodeSettings();
    
    GridSettings getGridSettings();
    
    void gracefulShutDown();
}

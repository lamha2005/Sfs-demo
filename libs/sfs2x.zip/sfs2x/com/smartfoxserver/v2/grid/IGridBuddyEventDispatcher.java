// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.grid;

import com.smartfoxserver.grid.events.IGridEvent;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.List;

public interface IGridBuddyEventDispatcher
{
    void dispatchBuddyOnline(final String p0, final List<String> p1, final ISFSObject p2);
    
    void dispatchBuddyVariables(final String p0, final List<String> p1, final ISFSObject p2);
    
    void dispatchBuddyMessage(final IGridEvent p0);
}

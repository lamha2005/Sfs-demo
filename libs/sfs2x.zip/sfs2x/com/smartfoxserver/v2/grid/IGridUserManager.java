// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.grid;

import java.util.Collection;
import com.hazelcast.query.Predicate;
import com.hazelcast.core.Member;
import com.smartfoxserver.grid.model.IGridUser;
import com.smartfoxserver.bitswarm.service.IService;

public interface IGridUserManager extends IService
{
    void addUser(final IGridUser p0);
    
    void removeUser(final String p0);
    
    void updateUser(final IGridUser p0);
    
    void lockUser(final String p0);
    
    boolean tryLockUser(final String p0);
    
    void unlockUser(final String p0);
    
    boolean isUserOnline(final String p0);
    
    Member getUserNode(final String p0);
    
    IGridUser getUser(final String p0);
    
    IGridUser getUser(final int p0);
    
    int getUserCount();
    
    int getUserCount(final Member p0);
    
    void onNodeRemoved(final Member p0);
    
    Collection<IGridUser> queryUsers(final Predicate<String, IGridUser> p0);
    
    Collection<IGridUser> resolveUsers(final Collection<Integer> p0);
}

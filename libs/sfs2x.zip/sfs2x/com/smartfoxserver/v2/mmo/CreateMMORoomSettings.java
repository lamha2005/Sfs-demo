// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.api.CreateRoomSettings;

public class CreateMMORoomSettings extends CreateRoomSettings
{
    private Vec3D defaultAOI;
    private MapLimits mapLimits;
    private int userMaxLimboSeconds;
    private int proximityListUpdateMillis;
    private boolean sendAOIEntryPoint;
    
    public CreateMMORoomSettings() {
        this.userMaxLimboSeconds = 0;
        this.proximityListUpdateMillis = 250;
        this.sendAOIEntryPoint = true;
    }
    
    public Vec3D getDefaultAOI() {
        return this.defaultAOI;
    }
    
    public void setDefaultAOI(final Vec3D defaultAOI) {
        this.defaultAOI = defaultAOI;
    }
    
    public MapLimits getMapLimits() {
        return this.mapLimits;
    }
    
    public void setMapLimits(final MapLimits mapLimits) {
        this.mapLimits = mapLimits;
    }
    
    public int getUserMaxLimboSeconds() {
        return this.userMaxLimboSeconds;
    }
    
    public void setUserMaxLimboSeconds(final int userMaxLimboSeconds) {
        this.userMaxLimboSeconds = userMaxLimboSeconds;
    }
    
    public int getProximityListUpdateMillis() {
        return this.proximityListUpdateMillis;
    }
    
    public void setProximityListUpdateMillis(final int updateMillis) {
        this.proximityListUpdateMillis = updateMillis;
    }
    
    public boolean isSendAOIEntryPoint() {
        return this.sendAOIEntryPoint;
    }
    
    public void setSendAOIEntryPoint(final boolean sendAOIEntryPoint) {
        this.sendAOIEntryPoint = sendAOIEntryPoint;
    }
    
    @Override
    public String toString() {
        final String dump = String.valueOf(super.toString()) + " <<< MMORoom Properties >>>" + "\n" + "=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--" + "\n" + "userMaxLimboSeconds: " + this.getUserMaxLimboSeconds() + "\n" + "proximityListUpdateMillis: " + this.getProximityListUpdateMillis() + "\n" + "sendAOIEntryPoint: " + this.isSendAOIEntryPoint() + "\n" + "default AOI: " + this.getDefaultAOI() + "\n" + "map limits: " + ((this.mapLimits != null) ? this.mapLimits : "(none)") + "\n" + "=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--\n";
        return dump;
    }
    
    public static final class MapLimits
    {
        private Vec3D lowerLimit;
        private Vec3D higherLimit;
        
        public MapLimits(final Vec3D low, final Vec3D high) {
            if (low != null && high != null) {
                this.lowerLimit = low;
                this.higherLimit = high;
                return;
            }
            throw new IllegalArgumentException("Map Limits arguments must be both non null!");
        }
        
        public Vec3D getLowerLimit() {
            return this.lowerLimit;
        }
        
        public Vec3D getHigherLimit() {
            return this.higherLimit;
        }
        
        @Override
        public String toString() {
            return String.format("%s -- %s", this.lowerLimit, this.higherLimit);
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.User;
import java.util.List;

public abstract class BaseMMOItem implements IMMOItem
{
    abstract P3D getLastPos();
    
    abstract void setLastPos(final P3D p0);
    
    abstract Vec3D getLastLocation();
    
    abstract void setLastLocation(final Vec3D p0);
    
    abstract List<User> getLastProxyList();
    
    abstract void setLastProxyList(final List<User> p0);
    
    public abstract MMORoom getRoom();
    
    abstract void setRoom(final MMORoom p0);
}

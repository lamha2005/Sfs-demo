// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.Room;
import java.util.Set;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.LinkedList;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.api.response.ISFSMMOResponseApi;
import java.util.concurrent.ScheduledFuture;
import com.smartfoxserver.v2.entities.User;
import java.util.List;
import org.slf4j.Logger;

public final class MMOUpdateManager implements IMMOUpdateManager
{
    private final Logger logger;
    private final MMORoom mmoRoom;
    private final List<User> usersToUpdate;
    private final List<BaseMMOItem> itemsToUpdate;
    private final ScheduledFuture<?> updateTask;
    private final ISFSMMOResponseApi responseAPI;
    private volatile int threshold;
    
    public MMOUpdateManager(final MMORoom room, final int thresholdMillis) {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.mmoRoom = room;
        this.threshold = thresholdMillis;
        this.usersToUpdate = new LinkedList<User>();
        this.itemsToUpdate = new LinkedList<BaseMMOItem>();
        this.responseAPI = SmartFoxServer.getInstance().getAPIManager().getMMOApi().getResponseAPI();
        this.updateTask = SmartFoxServer.getInstance().getTaskScheduler().scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                MMOUpdateManager.this.executeUpdate();
            }
        }, 0, thresholdMillis, TimeUnit.MILLISECONDS);
    }
    
    @Override
    public void addUserToUpdate(final User user) {
        synchronized (this.usersToUpdate) {
            if (!this.usersToUpdate.contains(user)) {
                this.usersToUpdate.add(user);
            }
        }
        // monitorexit(this.usersToUpdate)
    }
    
    @Override
    public void addBatchToUpdate(final List<User> users) {
        synchronized (this.usersToUpdate) {
            for (final User item : users) {
                if (!this.usersToUpdate.contains(item)) {
                    this.usersToUpdate.add(item);
                }
            }
        }
        // monitorexit(this.usersToUpdate)
    }
    
    @Override
    public void addItemToUpdate(final BaseMMOItem item) {
        synchronized (this.itemsToUpdate) {
            if (!this.itemsToUpdate.contains(item)) {
                this.itemsToUpdate.add(item);
            }
        }
        // monitorexit(this.itemsToUpdate)
    }
    
    @Override
    public int getUpdateThreshold() {
        return this.threshold;
    }
    
    @Override
    public void setUpdateThreshold(final int millis) {
        this.threshold = millis;
    }
    
    @Override
    public void destroy() {
        if (this.updateTask != null) {
            this.updateTask.cancel(true);
        }
    }
    
    private void executeUpdate() {
        try {
            if (this.usersToUpdate.size() == 0 && this.itemsToUpdate.size() == 0) {
                return;
            }
            final Set<User> allAffectedUsers = new HashSet<User>();
            List<User> usersToUpdateCopy = null;
            synchronized (this.usersToUpdate) {
                usersToUpdateCopy = new LinkedList<User>(this.usersToUpdate);
                this.usersToUpdate.clear();
            }
            // monitorexit(this.usersToUpdate)
            usersToUpdateCopy.addAll(this.findUsersAffectedByItemsUpdate());
            for (final User user : usersToUpdateCopy) {
                this.computeAndUpdateUsers(user, allAffectedUsers);
            }
            for (final User affectedUser : allAffectedUsers) {
                final boolean userWasNotAlreadyUpdated = !usersToUpdateCopy.contains(affectedUser);
                if (userWasNotAlreadyUpdated) {
                    this.computeAndUpdateUsers(affectedUser);
                }
            }
        }
        catch (Exception e) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
            emc.setDescription("Unexpected error in update task!");
            emc.addInfo("Room: " + this.mmoRoom.toString());
            this.logger.warn(emc.toString());
        }
    }
    
    private void computeAndUpdateUsers(final User user) {
        this.computeAndUpdateUsers(user, null);
    }
    
    private void computeAndUpdateUsers(final User user, final Set<User> allAffectedUsers) {
        if (user.getCurrentMMORoom() != this.mmoRoom) {
            return;
        }
        final List<User> newProxyList = this.mmoRoom.getProximityManager().getProximityList(user);
        final List<BaseMMOItem> newItemsList = this.mmoRoom.getItemsManager().getItemList(user);
        if (newProxyList == null || newItemsList == null) {
            return;
        }
        final List<User> plusUserList = new LinkedList<User>(newProxyList);
        final List<User> minusUserList = user.getLastProxyList();
        final List<BaseMMOItem> plusItemList = new LinkedList<BaseMMOItem>(newItemsList);
        final List<BaseMMOItem> minusItemList = user.getLastMMOItemsList();
        user.setLastProxyList(newProxyList);
        user.setLastMMOItemsList(newItemsList);
        final boolean previousUserListExists = minusUserList != null;
        final boolean previousItemListExists = minusItemList != null;
        if (allAffectedUsers != null) {
            allAffectedUsers.addAll(plusUserList);
            if (previousUserListExists) {
                allAffectedUsers.addAll(minusUserList);
            }
        }
        if (previousUserListExists) {
            final Iterator<User> it = minusUserList.iterator();
            while (it.hasNext()) {
                final User item = it.next();
                if (plusUserList.contains(item)) {
                    it.remove();
                    plusUserList.remove(item);
                }
            }
        }
        if (previousItemListExists) {
            final Iterator<BaseMMOItem> it2 = minusItemList.iterator();
            while (it2.hasNext()) {
                final BaseMMOItem item2 = it2.next();
                if (plusItemList.contains(item2)) {
                    it2.remove();
                    plusItemList.remove(item2);
                }
            }
        }
        boolean needsUpdate = plusUserList != null && plusUserList.size() > 0;
        needsUpdate |= (minusUserList != null && minusUserList.size() > 0);
        needsUpdate |= (plusItemList != null && plusItemList.size() > 0);
        needsUpdate |= (minusItemList != null && minusItemList.size() > 0);
        if (needsUpdate) {
            this.responseAPI.notifyProximityListUpdate(this.mmoRoom, new MMOUpdateDelta(user, plusUserList, minusUserList, plusItemList, minusItemList));
        }
    }
    
    private Set<User> findUsersAffectedByItemsUpdate() {
        final Set<User> affectedUsers = new HashSet<User>();
        List<BaseMMOItem> itemsToUpdateCopy = null;
        synchronized (this.itemsToUpdate) {
            itemsToUpdateCopy = new LinkedList<BaseMMOItem>(this.itemsToUpdate);
            this.itemsToUpdate.clear();
        }
        // monitorexit(this.itemsToUpdate)
        for (final BaseMMOItem item : itemsToUpdateCopy) {
            affectedUsers.addAll(this.findUsersAffectedByThisItem(item));
        }
        return affectedUsers;
    }
    
    private Collection<User> findUsersAffectedByThisItem(final BaseMMOItem item) {
        final Set<User> userList = new HashSet<User>();
        final List<User> oldUsers = item.getLastProxyList();
        if (oldUsers != null) {
            userList.addAll(oldUsers);
        }
        final List<User> newUsers = this.mmoRoom.getProximityManager().getProximityList(item.getLastLocation());
        userList.addAll(newUsers);
        return userList;
    }
}

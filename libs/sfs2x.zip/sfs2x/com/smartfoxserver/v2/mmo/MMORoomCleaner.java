// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.Room;
import java.util.Iterator;
import java.util.Collection;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.entities.User;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.v2.api.ISFSApi;

class MMORoomCleaner implements Runnable
{
    private final MMORoom targetRoom;
    private final ISFSApi sfsApi;
    private final Logger logger;
    private final long allowedTime;
    
    public MMORoomCleaner(final MMORoom targetRoom) {
        this.targetRoom = targetRoom;
        this.sfsApi = SmartFoxServer.getInstance().getAPIManager().getSFSApi();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.allowedTime = targetRoom.getUserLimboMaxSeconds() * 1000;
    }
    
    @Override
    public void run() {
        try {
            final Collection<User> allUsers = this.targetRoom.getUserManager().getDirectUserList();
            for (final User u : allUsers) {
                if (u.containsProperty("_uLoc")) {
                    continue;
                }
                final long joinTime = (long)u.getProperty("_uJoinTime");
                if (System.currentTimeMillis() <= joinTime + this.allowedTime) {
                    continue;
                }
                this.kickUserOut(u);
            }
        }
        catch (Exception e) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
            emc.setDescription("Limbo cleaner encountered an error!");
            emc.addInfo("Room: " + this.targetRoom.toString());
            this.logger.warn(emc.toString());
        }
    }
    
    private void kickUserOut(final User u) {
        if (this.logger.isDebugEnabled()) {
            this.logger.debug("User: " + u + " kicked out of " + this.targetRoom);
        }
        this.sfsApi.leaveRoom(u, this.targetRoom);
    }
}

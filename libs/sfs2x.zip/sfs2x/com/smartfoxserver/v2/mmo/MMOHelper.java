// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import java.util.Iterator;
import java.util.LinkedList;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.List;
import com.smartfoxserver.v2.entities.User;

public class MMOHelper
{
    public static final String USER_LOC = "_uLoc";
    public static final String USER_LAST_POS = "_uPos";
    public static final String USER_JOIN_TIME = "_uJoinTime";
    
    public static List<ISession> getProximitySessionList(final User target) {
        if (target.getLastProxyList() == null) {
            return null;
        }
        final List<ISession> sessions = new LinkedList<ISession>();
        for (final User item : target.getLastProxyList()) {
            sessions.add(item.getSession());
        }
        return sessions;
    }
    
    public static List<ISession> getProximitySessionList(final MMORoom theRoom, final User target, final Vec3D aoi) {
        if (target.getLastProxyList() == null) {
            return null;
        }
        final List<User> customProxyList = theRoom.getProximityManager().getProximityList(target, aoi);
        final List<ISession> sessions = new LinkedList<ISession>();
        for (final User item : customProxyList) {
            sessions.add(item.getSession());
        }
        return sessions;
    }
    
    public static Vec3D stringToVec3D(final String values, final boolean forceFloats) {
        Vec3D vec3d = null;
        if (!values.equals("")) {
            final String[] items = values.split("\\,");
            if (items.length != 3) {
                throw new IllegalArgumentException("Cannot convert to Vec3D: " + values);
            }
            final boolean isFloat = values.indexOf(46) > -1 || forceFloats;
            if (isFloat) {
                vec3d = new Vec3D(Float.parseFloat(items[0]), Float.parseFloat(items[1]), Float.parseFloat(items[2]));
            }
            else {
                vec3d = new Vec3D(Integer.parseInt(items[0]), Integer.parseInt(items[1]), Integer.parseInt(items[2]));
            }
        }
        return vec3d;
    }
    
    public static Vec3D getMMOItemLocation(final BaseMMOItem item) {
        return item.getLastLocation();
    }
    
    public static P3D getMMOItemPos(final BaseMMOItem item) {
        return item.getLastPos();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.variables.UserVariable;

public interface IMMOItemVariable extends UserVariable
{
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.List;

public interface IMMOItem
{
    int getId();
    
    IMMOItemVariable getVariable(final String p0);
    
    List<IMMOItemVariable> getVariables();
    
    void setVariable(final IMMOItemVariable p0);
    
    void setVariables(final List<IMMOItemVariable> p0);
    
    void removeVariable(final String p0);
    
    ISFSArray toSFSArray();
}

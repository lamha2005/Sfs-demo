// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.variables.VariableType;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.variables.SFSUserVariable;

public class MMOItemVariable extends SFSUserVariable implements IMMOItemVariable
{
    public MMOItemVariable(final String name, final Object value) {
        super(name, value, false, false);
    }
    
    public MMOItemVariable(final String name, final Object value, final boolean isHidden) {
        super(name, value, isHidden, false);
    }
    
    public static MMOItemVariable newInstance(final String name, final Object value) {
        return new MMOItemVariable(name, value);
    }
    
    public static MMOItemVariable newFromStringLiteral(final String name, final String type, final String literal) {
        return new MMOItemVariable(name, type, literal);
    }
    
    public static MMOItemVariable newFromSFSArray(final ISFSArray array) {
        return new MMOItemVariable(array.getUtfString(0), array.getElementAt(2));
    }
    
    protected MMOItemVariable(final String name) {
        super(name);
    }
    
    protected MMOItemVariable(final String name, final VariableType type, final String literal) {
        super(name, type, literal);
    }
    
    protected MMOItemVariable(final String name, final String type, final String literal) {
        this(name, VariableType.fromString(type), literal);
    }
}

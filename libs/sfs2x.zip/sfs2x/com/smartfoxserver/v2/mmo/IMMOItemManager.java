// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import java.util.List;
import com.smartfoxserver.v2.entities.User;

public interface IMMOItemManager
{
    void setItem(final BaseMMOItem p0, final Vec3D p1);
    
    void removeItem(final BaseMMOItem p0);
    
    List<BaseMMOItem> getItemList(final User p0);
    
    List<BaseMMOItem> getItemList(final User p0, final Vec3D p1);
    
    List<BaseMMOItem> getItemList(final Vec3D p0);
    
    List<BaseMMOItem> getItemList(final Vec3D p0, final Vec3D p1);
    
    int getSize();
}

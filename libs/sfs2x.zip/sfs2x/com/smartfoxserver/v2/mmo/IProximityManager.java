// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import java.util.List;
import com.smartfoxserver.v2.entities.User;

public interface IProximityManager
{
    void addUser(final User p0);
    
    void updateUser(final User p0);
    
    void removeUser(final User p0);
    
    List<User> getProximityList(final User p0);
    
    List<User> getProximityList(final User p0, final Vec3D p1);
    
    List<User> getProximityList(final Vec3D p0);
    
    List<User> getProximityList(final Vec3D p0, final Vec3D p1);
    
    int getSize();
    
    Vec3D getSectorSize();
    
    Vec3D getDefaultAOI();
}

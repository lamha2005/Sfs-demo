// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.User;
import java.util.List;

public class MMOUpdateDelta
{
    private final List<User> plusUserList;
    private final List<User> minusUserList;
    private final List<BaseMMOItem> plusItemList;
    private final List<BaseMMOItem> minusItemList;
    private final User recipient;
    
    public MMOUpdateDelta(final User recipient, final List<User> plusUserList, final List<User> minusUserList, final List<BaseMMOItem> plusItemList, final List<BaseMMOItem> minusItemList) {
        this.recipient = recipient;
        this.plusUserList = plusUserList;
        this.minusUserList = minusUserList;
        this.plusItemList = plusItemList;
        this.minusItemList = minusItemList;
    }
    
    public List<User> getPlusUserList() {
        return this.plusUserList;
    }
    
    public List<User> getMinusUserList() {
        return this.minusUserList;
    }
    
    public List<BaseMMOItem> getPlusItemList() {
        return this.plusItemList;
    }
    
    public List<BaseMMOItem> getMinusItemList() {
        return this.minusItemList;
    }
    
    public User getRecipient() {
        return this.recipient;
    }
    
    @Override
    public String toString() {
        return String.format("{\n  Update: %s\n  -U: %s\n  +U: %s -I: %s\n +I: %s\n}\n", this.recipient.getName(), this.minusUserList, this.plusUserList, this.minusItemList, this.plusItemList);
    }
}

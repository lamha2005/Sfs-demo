// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import java.util.Arrays;
import java.util.List;

public class Vec3D
{
    private final Number px;
    private final Number py;
    private final Number pz;
    private final boolean useFloat;
    
    public static Vec3D fromIntArray(final List<Integer> array) {
        if (array.size() != 3) {
            throw new IllegalArgumentException("Wrong array size. Vec3D requires an array with 3 parameters (x,y,z)");
        }
        return new Vec3D(array.get(0), array.get(1), array.get(2));
    }
    
    public static Vec3D fromFloatArray(final List<Float> array) {
        if (array.size() != 3) {
            throw new IllegalArgumentException("Wrong array size. Vec3D requires an array with 3 parameters (x,y,z)");
        }
        return new Vec3D(array.get(0), array.get(1), array.get(2));
    }
    
    public Vec3D(final int ix, final int iy, final int iz) {
        this.px = ix;
        this.py = iy;
        this.pz = iz;
        this.useFloat = false;
    }
    
    public Vec3D(final float fx, final float fy, final float fz) {
        this.px = fx;
        this.py = fy;
        this.pz = fz;
        this.useFloat = true;
    }
    
    public Vec3D(final int ix, final int iy) {
        this(ix, iy, 0);
    }
    
    public Vec3D(final float fx, final float fy) {
        this(fx, fy, 0.0f);
    }
    
    public boolean isFloat() {
        return this.useFloat;
    }
    
    public float floatX() {
        return this.px.floatValue();
    }
    
    public float floatY() {
        return this.py.floatValue();
    }
    
    public float floatZ() {
        return this.pz.floatValue();
    }
    
    public int intX() {
        return this.px.intValue();
    }
    
    public int intY() {
        return this.py.intValue();
    }
    
    public int intZ() {
        return this.pz.intValue();
    }
    
    @Override
    public String toString() {
        return String.format("(%s, %s, %s)", this.px, this.py, this.pz);
    }
    
    public List<Integer> toIntArray() {
        return Arrays.asList(this.intX(), this.intY(), this.intZ());
    }
    
    public List<Float> toFloatArray() {
        return Arrays.asList(this.floatX(), this.floatY(), this.floatZ());
    }
}

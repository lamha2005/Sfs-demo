// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import java.util.List;
import com.smartfoxserver.v2.entities.User;

public interface IMMOUpdateManager
{
    void addUserToUpdate(final User p0);
    
    void addBatchToUpdate(final List<User> p0);
    
    void addItemToUpdate(final BaseMMOItem p0);
    
    int getUpdateThreshold();
    
    void setUpdateThreshold(final int p0);
    
    void destroy();
}

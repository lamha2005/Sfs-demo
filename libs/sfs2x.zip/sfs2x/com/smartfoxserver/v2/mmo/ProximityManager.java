// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import java.util.Map;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.entities.User;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import org.slf4j.Logger;

public class ProximityManager implements IProximityManager
{
    private final int SECTOR_SIZE_MULTIPLIER = 1;
    private final Logger log;
    private final Vec3D aoi;
    private final Vec3D sectorSize;
    private final ConcurrentMap<P3D, ConcurrentLinkedQueue<User>> map;
    
    public ProximityManager(final Vec3D aoi) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.aoi = aoi;
        if (aoi.isFloat()) {
            this.sectorSize = new Vec3D(aoi.floatX() * 1.0f, aoi.floatY() * 1.0f, aoi.floatZ() * 1.0f);
        }
        else {
            this.sectorSize = new Vec3D(aoi.intX() * 1, aoi.intY() * 1, aoi.intZ() * 1);
        }
        this.map = new ConcurrentHashMap<P3D, ConcurrentLinkedQueue<User>>();
    }
    
    @Override
    public Vec3D getDefaultAOI() {
        return this.aoi;
    }
    
    @Override
    public void addUser(final User user) {
        final P3D pos = this.findSector(user);
        user.setProperty("_uPos", pos);
        this.moveUser(user, pos, null);
    }
    
    private void moveUser(final User user, final P3D newPos, final P3D oldPos) {
        ConcurrentLinkedQueue<User> uList = null;
        synchronized (this.map) {
            uList = this.map.get(newPos);
            if (uList == null) {
                uList = new ConcurrentLinkedQueue<User>();
                this.map.put(newPos, uList);
            }
        }
        // monitorexit(this.map)
        uList.add(user);
        if (oldPos != null) {
            uList = this.map.get(oldPos);
            if (uList != null) {
                uList.remove(user);
            }
        }
    }
    
    @Override
    public void updateUser(final User user) {
        final P3D newPos = this.findSector(user);
        final P3D oldPos = (P3D)user.getProperty("_uPos");
        user.setProperty("_uPos", newPos);
        if (!newPos.equals(oldPos)) {
            this.moveUser(user, newPos, oldPos);
        }
    }
    
    @Override
    public List<User> getProximityList(final User target, final Vec3D aoi) {
        final P3D targetPos = (P3D)target.getProperty("_uPos");
        final Vec3D targetLocation = (Vec3D)target.getProperty("_uLoc");
        if (targetLocation == null) {
            return null;
        }
        final List<P3D> queryBlocks = this.getQueryBlocks(targetPos);
        final List<User> proximityList = new LinkedList<User>();
        for (final P3D pos : queryBlocks) {
            final ConcurrentLinkedQueue<User> users = this.map.get(pos);
            if (users == null) {
                continue;
            }
            for (final User u : users) {
                if (u == target) {
                    continue;
                }
                if (!this.userFallsWithinAOI(u, targetLocation, aoi)) {
                    continue;
                }
                proximityList.add(u);
            }
        }
        return proximityList;
    }
    
    @Override
    public List<User> getProximityList(final User target) {
        return this.getProximityList(target, this.aoi);
    }
    
    @Override
    public List<User> getProximityList(final Vec3D pos) {
        return this.getProximityList(pos, this.aoi);
    }
    
    Collection<User> getProximitySector(final P3D pos) {
        return this.map.get(pos);
    }
    
    List<User> getProximityList(final P3D pos, final Vec3D targetLocation) {
        final List<P3D> queryBlocks = this.getQueryBlocks(pos);
        return this.findLocalUsersWithinAOI(queryBlocks, targetLocation, this.aoi);
    }
    
    @Override
    public List<User> getProximityList(final Vec3D targetLocation, final Vec3D aoi) {
        final List<P3D> queryBlocks = this.getQueryBlocks(this.findSector(targetLocation));
        return this.findLocalUsersWithinAOI(queryBlocks, targetLocation, aoi);
    }
    
    private boolean userFallsWithinAOI(final User userToCheck, final Vec3D targetLocation, final Vec3D aoi) {
        final Vec3D checkLocation = (Vec3D)userToCheck.getProperty("_uLoc");
        if (checkLocation == null) {
            if (this.log.isDebugEnabled()) {
                this.log.debug("User: " + userToCheck + " has no location in the map.");
            }
            return false;
        }
        boolean checkX;
        boolean checkY;
        boolean checkZ;
        if (targetLocation.isFloat()) {
            checkX = (Math.abs(targetLocation.floatX() - checkLocation.floatX()) < aoi.floatX());
            checkY = (Math.abs(targetLocation.floatY() - checkLocation.floatY()) < aoi.floatY());
            checkZ = (aoi.floatZ() == 0.0f || Math.abs(targetLocation.floatZ() - checkLocation.floatZ()) < aoi.floatZ());
        }
        else {
            checkX = (Math.abs(targetLocation.intX() - checkLocation.intX()) < aoi.intX());
            checkY = (Math.abs(targetLocation.intY() - checkLocation.intY()) < aoi.intY());
            checkZ = (aoi.intZ() == 0 || Math.abs(targetLocation.intZ() - checkLocation.intZ()) < aoi.intZ());
        }
        return checkX && checkY && checkZ;
    }
    
    private List<P3D> getQueryBlocks(final P3D center) {
        final List<P3D> queryBlocks = new LinkedList<P3D>();
        for (int z = -1; z <= 1; ++z) {
            for (int y = -1; y <= 1; ++y) {
                for (int x = -1; x <= 1; ++x) {
                    queryBlocks.add(new P3D(center.px + x, center.py + y, center.pz + z));
                }
            }
        }
        return queryBlocks;
    }
    
    @Override
    public Vec3D getSectorSize() {
        return this.sectorSize;
    }
    
    @Override
    public int getSize() {
        return this.map.size();
    }
    
    @Override
    public void removeUser(final User user) {
        P3D lastPos = (P3D)user.getProperty("_uPos");
        if (lastPos == null) {
            return;
        }
        ConcurrentLinkedQueue<User> q = this.map.get(lastPos);
        if (q != null && !q.contains(user)) {
            lastPos = this.findUserLocation(user);
            q = this.map.get(lastPos);
        }
        if (q != null) {
            q.remove(user);
            user.removeProperty("_uPos");
            return;
        }
        throw new IllegalStateException();
    }
    
    public P3D findUserLocation(final User user) {
        for (final Map.Entry<P3D, ConcurrentLinkedQueue<User>> entry : this.map.entrySet()) {
            if (entry.getValue().contains(user)) {
                return entry.getKey();
            }
        }
        return null;
    }
    
    public List<User> dumpAllUsers() {
        final List<User> allUsers = new LinkedList<User>();
        for (final ConcurrentLinkedQueue<User> q : this.map.values()) {
            allUsers.addAll(q);
        }
        return allUsers;
    }
    
    private P3D findSector(final User user) {
        final Vec3D pos = (Vec3D)user.getProperty("_uLoc");
        return this.findSector(pos);
    }
    
    private P3D findSector(final Vec3D pos) {
        if (pos == null) {
            throw new IllegalArgumentException("User does not have a position assigned!");
        }
        if (pos.isFloat() != this.sectorSize.isFloat()) {
            throw new IllegalArgumentException("User coordinates don't match numeric type of the Room's Area Of Interest (AOI)");
        }
        if (pos.isFloat()) {
            return this.findFloatSector(pos);
        }
        return this.findIntSector(pos);
    }
    
    private P3D findFloatSector(final Vec3D pos) {
        int xx = (int)(pos.floatX() / this.sectorSize.floatX());
        xx = ((pos.floatX() < 0.0f) ? (xx - 1) : xx);
        int yy = (int)(pos.floatY() / this.sectorSize.floatY());
        yy = ((pos.floatY() < 0.0f) ? (yy - 1) : yy);
        int zz = 0;
        if (this.sectorSize.floatZ() != 0.0f) {
            zz = (int)(pos.floatZ() / this.sectorSize.floatZ());
            zz = ((pos.floatZ() < 0.0f) ? (zz - 1) : zz);
        }
        return new P3D(xx, yy, zz);
    }
    
    private P3D findIntSector(final Vec3D pos) {
        int xx = pos.intX() / this.sectorSize.intX();
        xx = ((pos.intX() < 0) ? (xx - 1) : xx);
        int yy = pos.intY() / this.sectorSize.intY();
        yy = ((pos.intY() < 0) ? (yy - 1) : yy);
        int zz = 0;
        if (this.sectorSize.intZ() != 0) {
            zz = pos.intZ() / this.sectorSize.intZ();
            zz = ((pos.intZ() < 0) ? (zz - 1) : zz);
        }
        return new P3D(xx, yy, zz);
    }
    
    private List<User> findLocalUsersWithinAOI(final List<P3D> queryBlocks, final Vec3D targetLocation, final Vec3D aoi) {
        final List<User> userList = new LinkedList<User>();
        for (final P3D pos : queryBlocks) {
            final ConcurrentLinkedQueue<User> users = this.map.get(pos);
            if (users == null) {
                continue;
            }
            for (final User user : users) {
                if (this.userFallsWithinAOI(user, targetLocation, aoi)) {
                    userList.add(user);
                }
            }
        }
        return userList;
    }
    
    public void dumpState() {
        for (final P3D pos : this.map.keySet()) {
            System.out.println(pos + " --> " + this.map.get(pos));
        }
    }
}

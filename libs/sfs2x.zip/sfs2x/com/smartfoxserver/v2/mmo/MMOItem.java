// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.mmo;

import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.Iterator;
import java.util.Collection;
import java.util.LinkedList;
import java.util.HashMap;
import com.smartfoxserver.v2.entities.User;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class MMOItem extends BaseMMOItem
{
    private static final AtomicInteger AUTO_ID;
    private final Map<String, IMMOItemVariable> variables;
    private P3D lastPos;
    private Vec3D lastLoc;
    private volatile List<User> lastProxyList;
    private final int id;
    private MMORoom room;
    
    static {
        AUTO_ID = new AtomicInteger();
    }
    
    public MMOItem() {
        this.id = MMOItem.AUTO_ID.getAndIncrement();
        this.variables = new HashMap<String, IMMOItemVariable>();
    }
    
    public MMOItem(final List<IMMOItemVariable> variables) {
        this();
        this.setVariables(variables);
    }
    
    @Override
    public int getId() {
        return this.id;
    }
    
    @Override
    public IMMOItemVariable getVariable(final String name) {
        return this.variables.get(name);
    }
    
    @Override
    public List<IMMOItemVariable> getVariables() {
        List<IMMOItemVariable> vars = null;
        synchronized (this.variables) {
            vars = new LinkedList<IMMOItemVariable>(this.variables.values());
        }
        // monitorexit(this.variables)
        return vars;
    }
    
    @Override
    public void setVariable(final IMMOItemVariable var) {
        synchronized (this.variables) {
            this.variables.put(var.getName(), var);
        }
        // monitorexit(this.variables)
    }
    
    @Override
    public void setVariables(final List<IMMOItemVariable> varList) {
        synchronized (this.variables) {
            for (final IMMOItemVariable itemVar : varList) {
                this.variables.put(itemVar.getName(), itemVar);
            }
        }
        // monitorexit(this.variables)
    }
    
    @Override
    public void removeVariable(final String varName) {
        synchronized (this.variables) {
            this.variables.remove(varName);
        }
        // monitorexit(this.variables)
    }
    
    @Override
    public ISFSArray toSFSArray() {
        final ISFSArray arr = new SFSArray();
        arr.addInt(this.id);
        arr.addSFSArray(this.getVariablesData());
        return arr;
    }
    
    @Override
    public MMORoom getRoom() {
        return this.room;
    }
    
    @Override
    List<User> getLastProxyList() {
        return this.lastProxyList;
    }
    
    @Override
    void setLastProxyList(final List<User> proxyList) {
        this.lastProxyList = proxyList;
    }
    
    @Override
    P3D getLastPos() {
        return this.lastPos;
    }
    
    @Override
    void setLastPos(final P3D pos) {
        this.lastPos = pos;
    }
    
    @Override
    Vec3D getLastLocation() {
        return this.lastLoc;
    }
    
    @Override
    void setLastLocation(final Vec3D loc) {
        this.lastLoc = loc;
    }
    
    @Override
    void setRoom(final MMORoom room) {
        this.room = room;
    }
    
    @Override
    public String toString() {
        return String.format("[id: %s, %s, %s ]", this.id, this.lastPos, this.variables);
    }
    
    private ISFSArray getVariablesData() {
        final ISFSArray arr = new SFSArray();
        final List<IMMOItemVariable> vars = this.getVariables();
        for (final IMMOItemVariable var : vars) {
            arr.addSFSArray(var.toSFSArray());
        }
        return arr;
    }
}

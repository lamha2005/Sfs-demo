// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers;

import com.smartfoxserver.v2.controllers.filter.ISystemFilterChain;
import com.smartfoxserver.v2.exceptions.SFSFilterInterruptedException;
import com.smartfoxserver.v2.extensions.filter.FilterAction;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.security.SystemPermission;
import com.smartfoxserver.v2.exceptions.SFSFloodingException;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.bitswarm.io.IRequest;
import org.slf4j.LoggerFactory;
import java.util.Arrays;
import java.util.List;
import com.smartfoxserver.v2.api.ISFSApi;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;

public abstract class BaseControllerCommand implements IControllerCommand
{
    public static final String KEY_ERROR_CODE = "ec";
    public static final String KEY_ERROR_PARAMS = "ep";
    protected final Logger logger;
    protected final SmartFoxServer sfs;
    protected final ISFSApi api;
    private short id;
    private final SystemRequest requestType;
    private final List<SystemRequest> superUserRequest;
    
    public BaseControllerCommand(final SystemRequest request) {
        this.superUserRequest = Arrays.asList(SystemRequest.ModeratorMessage, SystemRequest.AdminMessage);
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = SmartFoxServer.getInstance();
        this.api = this.sfs.getAPIManager().getSFSApi();
        this.id = (short)request.getId();
        this.requestType = request;
    }
    
    @Override
    public Object preProcess(final IRequest request) throws Exception {
        return null;
    }
    
    public short getId() {
        return this.id;
    }
    
    public SystemRequest getRequestType() {
        return this.requestType;
    }
    
    protected User checkSuperUser(final IRequest request) {
        final SystemRequest requestType = SystemRequest.fromId(this.id);
        final User sender = this.api.getUserBySession(request.getSender());
        if (sender == null) {
            throw new SFSRuntimeException(String.format("System Request rejected: %s, Client is not logged in: ", request.getSender()));
        }
        if (!sender.isSuperUser()) {
            throw new SFSRuntimeException(String.format("System Request rejected: requester user must be SuperUser. Request: %s, User: %s", requestType, sender));
        }
        return sender;
    }
    
    protected User checkRequestPermissions(final IRequest request, final SystemRequest requestType) {
        final User sender = this.api.getUserBySession(request.getSender());
        if (sender == null) {
            throw new SFSRuntimeException(String.format("System Request rejected: %s, Client is not logged in.", request.getSender()));
        }
        if (sender.isBeingKicked()) {
            throw new SFSRuntimeException(String.format("System Request rejected: %s, Client is marked for kicking.", sender));
        }
        final Zone zone = sender.getZone();
        if (zone.isEncrypted() && sender.getSession().getType() != SessionType.WEBSOCKET) {
            final Boolean encryptionFlag = (Boolean)request.getAttribute("Encrypted");
            if (encryptionFlag == null || !encryptionFlag) {
                this.api.disconnectUser(sender);
                throw new SFSRuntimeException(String.format("System Request rejected: client is not using an encrypted connection. Request: %s, User: %s", requestType, sender));
            }
        }
        try {
            zone.getFloodFilter().filterRequest(requestType, sender);
        }
        catch (SFSFloodingException floodErr) {
            throw new SFSRuntimeException();
        }
        boolean isValid = false;
        if (this.superUserRequest.contains(requestType)) {
            isValid = zone.getPrivilegeManager().isFlagSet(sender, SystemPermission.SuperUser);
        }
        else {
            isValid = zone.getPrivilegeManager().isRequestAllowed(sender, requestType);
        }
        if (!isValid) {
            throw new SFSRuntimeException(String.format("System Request rejected: insufficient privileges. Request: %s, User: %s", requestType, sender));
        }
        return sender;
    }
    
    protected User checkRequestPermissions(final IRequest request) {
        return this.checkRequestPermissions(request, SystemRequest.fromId(this.id));
    }
    
    protected void applyZoneFilterChain(final User user, final IRequest request) {
        final Zone zone = user.getZone();
        if (!zone.isFilterChainInited()) {
            return;
        }
        final ISystemFilterChain chain = zone.getFilterChain(SystemRequest.fromId(request.getId()));
        if (chain != null) {
            final FilterAction action = chain.runRequest(user, (ISFSObject)request.getContent());
            if (action == FilterAction.HALT) {
                throw new SFSFilterInterruptedException();
            }
        }
    }
}

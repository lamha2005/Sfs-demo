// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.v290;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.exceptions.SFSFilterInterruptedException;
import com.smartfoxserver.bitswarm.exceptions.RequestQueueFullException;
import com.smartfoxserver.bitswarm.util.Logging;
import com.smartfoxserver.bitswarm.io.IRequest;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.controllers.SystemRequest;
import java.util.HashMap;
import java.util.concurrent.ThreadPoolExecutor;
import com.smartfoxserver.v2.controllers.IControllerCommand;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.Map;
import com.smartfoxserver.bitswarm.controllers.SimpleController;

public class SystemReqController extends SimpleController
{
    private static final Map<Object, String> commandMap;
    private static final String sysPackage = "com.smartfoxserver.v2.controllers.system.";
    private static final String gridOverridePackage;
    private static final String buddyPackage = "buddylist.";
    private static final String gamePackage = "game.";
    private int qSize;
    private final SmartFoxServer sfs;
    private final Logger logger;
    private Map<Object, IControllerCommand> commandCache;
    private boolean useCache;
    private final ThreadPoolExecutor systemThreadPool;
    
    static {
        commandMap = new HashMap<Object, String>();
        gridOverridePackage = (SmartFoxServer.grid() ? "com.smartfoxserver.grid.api.request." : "com.smartfoxserver.v2.controllers.system.");
        SystemReqController.commandMap.put(SystemRequest.Handshake.getId(), "com.smartfoxserver.v2.controllers.system.Handshake");
        SystemReqController.commandMap.put(SystemRequest.Login.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "Login");
        SystemReqController.commandMap.put(SystemRequest.Logout.getId(), "com.smartfoxserver.v2.controllers.system.Logout");
        SystemReqController.commandMap.put(SystemRequest.JoinRoom.getId(), "com.smartfoxserver.v2.controllers.system.JoinRoom");
        SystemReqController.commandMap.put(SystemRequest.AutoJoin.getId(), "com.smartfoxserver.v2.controllers.system.AutoJoin");
        SystemReqController.commandMap.put(SystemRequest.CreateRoom.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "CreateRoom");
        SystemReqController.commandMap.put(SystemRequest.GenericMessage.getId(), "com.smartfoxserver.v2.controllers.system.GenericMessage");
        SystemReqController.commandMap.put(SystemRequest.ChangeRoomName.getId(), "com.smartfoxserver.v2.controllers.system.ChangeRoomName");
        SystemReqController.commandMap.put(SystemRequest.ChangeRoomPassword.getId(), "com.smartfoxserver.v2.controllers.system.ChangeRoomPassword");
        SystemReqController.commandMap.put(SystemRequest.ChangeRoomCapacity.getId(), "com.smartfoxserver.v2.controllers.system.ChangeRoomCapacity");
        SystemReqController.commandMap.put(SystemRequest.ObjectMessage.getId(), "com.smartfoxserver.v2.controllers.system.SendObject");
        SystemReqController.commandMap.put(SystemRequest.SetRoomVariables.getId(), "com.smartfoxserver.v2.controllers.system.SetRoomVariables");
        SystemReqController.commandMap.put(SystemRequest.SetUserVariables.getId(), "com.smartfoxserver.v2.controllers.system.SetUserVariables");
        SystemReqController.commandMap.put(SystemRequest.CallExtension.getId(), "com.smartfoxserver.v2.controllers.system.CallExtension");
        SystemReqController.commandMap.put(SystemRequest.LeaveRoom.getId(), "com.smartfoxserver.v2.controllers.system.LeaveRoom");
        SystemReqController.commandMap.put(SystemRequest.SubscribeRoomGroup.getId(), "com.smartfoxserver.v2.controllers.system.SubscribeRoomGroup");
        SystemReqController.commandMap.put(SystemRequest.UnsubscribeRoomGroup.getId(), "com.smartfoxserver.v2.controllers.system.UnsubscribeRoomGroup");
        SystemReqController.commandMap.put(SystemRequest.PlayerToSpectator.getId(), "com.smartfoxserver.v2.controllers.system.PlayerToSpectator");
        SystemReqController.commandMap.put(SystemRequest.SpectatorToPlayer.getId(), "com.smartfoxserver.v2.controllers.system.SpectatorToPlayer");
        SystemReqController.commandMap.put(SystemRequest.KickUser.getId(), "com.smartfoxserver.v2.controllers.system.KickUser");
        SystemReqController.commandMap.put(SystemRequest.BanUser.getId(), "com.smartfoxserver.v2.controllers.system.BanUser");
        SystemReqController.commandMap.put(SystemRequest.ManualDisconnection.getId(), "com.smartfoxserver.v2.controllers.system.ManualDisconnection");
        SystemReqController.commandMap.put(SystemRequest.FindRooms.getId(), "com.smartfoxserver.v2.controllers.system.FindRooms");
        SystemReqController.commandMap.put(SystemRequest.FindUsers.getId(), "com.smartfoxserver.v2.controllers.system.FindUsers");
        SystemReqController.commandMap.put(SystemRequest.PingPong.getId(), "com.smartfoxserver.v2.controllers.system.PingPong");
        SystemReqController.commandMap.put(SystemRequest.SetUserPosition.getId(), "com.smartfoxserver.v2.controllers.system.SetUserPosition");
        SystemReqController.commandMap.put(SystemRequest.InitBuddyList.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "buddylist." + "InitBuddyList");
        SystemReqController.commandMap.put(SystemRequest.AddBuddy.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.AddBuddy");
        SystemReqController.commandMap.put(SystemRequest.BlockBuddy.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.BlockBuddy");
        SystemReqController.commandMap.put(SystemRequest.RemoveBuddy.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.RemoveBuddy");
        SystemReqController.commandMap.put(SystemRequest.SetBuddyVariables.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.SetBuddyVariables");
        SystemReqController.commandMap.put(SystemRequest.GoOnline.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.GoOnline");
        SystemReqController.commandMap.put(SystemRequest.CreateSFSGame.getId(), "com.smartfoxserver.v2.controllers.system.game.CreateSFSGame");
        SystemReqController.commandMap.put(SystemRequest.InviteUser.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "game." + "InviteUser");
        SystemReqController.commandMap.put(SystemRequest.InvitationReply.getId(), "com.smartfoxserver.v2.controllers.system.game.InvitationReply");
        SystemReqController.commandMap.put(SystemRequest.QuickJoinGame.getId(), "com.smartfoxserver.v2.controllers.system.game.QuickJoinGame");
        SystemReqController.commandMap.put(SystemRequest.JoinRoomInvite.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "game." + "JoinRoomInvite");
        SystemReqController.commandMap.put(SystemRequest.GetLobbyNode.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "GetLobbyNode");
        SystemReqController.commandMap.put(SystemRequest.KeepAlive.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "KeepAlive");
        SystemReqController.commandMap.put(SystemRequest.QuickJoin.getId(), String.valueOf(SystemReqController.gridOverridePackage) + "QuickJoin");
    }
    
    public SystemReqController() {
        this.useCache = true;
        this.sfs = SmartFoxServer.getInstance();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.systemThreadPool = (ThreadPoolExecutor)this.sfs.getSystemThreadPool();
    }
    
    public void init(final Object o) {
        super.init(o);
        this.commandCache = new ConcurrentHashMap<Object, IControllerCommand>();
    }
    
    public void enqueueRequest(final IRequest request) throws RequestQueueFullException {
        if (this.isActive) {
            try {
                this.processRequest(request);
            }
            catch (Throwable t) {
                Logging.logStackTrace(this.logger, t);
            }
        }
    }
    
    protected void processRequest(final IRequest request) throws Exception {
        if (this.logger.isDebugEnabled()) {
            this.logger.debug("{IN}: " + SystemRequest.fromId(request.getId()).toString());
        }
        IControllerCommand command = null;
        final Object reqId = request.getId();
        if (this.useCache) {
            command = this.commandCache.get(reqId);
            if (command == null) {
                command = this.getCommand(reqId);
                this.commandCache.put(reqId, command);
            }
        }
        else {
            command = this.getCommand(reqId);
        }
        if (command != null && command.validate(request)) {
            try {
                command.execute(request);
            }
            catch (SFSFilterInterruptedException err) {
                if (this.logger.isDebugEnabled()) {
                    final User user = this.sfs.getUserManager().getUserBySession(request.getSender());
                    final String sender = (user != null) ? user.toString() : request.getSender().toString();
                    this.logger.debug("FilterChain stopped request: " + SystemRequest.fromId(reqId) + ", Sender: " + sender);
                }
            }
            catch (SFSRuntimeException re) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(re);
                emc.setDescription("Runtime error while processing request");
                this.logger.warn(emc.toString());
            }
        }
    }
    
    private IControllerCommand getCommand(final Object reqId) {
        IControllerCommand command = null;
        final String className = SystemReqController.commandMap.get(reqId);
        if (className != null) {
            try {
                final Class<?> clazz = Class.forName(className);
                command = (IControllerCommand)clazz.newInstance();
            }
            catch (Exception err) {
                this.logger.error("Could not dynamically instantiate class: " + className + ", Error: " + err);
            }
        }
        else {
            this.logger.error("Cannot find a controller command for request ID: " + reqId);
        }
        return command;
    }
    
    public int getQueueSize() {
        return this.systemThreadPool.getQueue().size();
    }
    
    public int getMaxQueueSize() {
        return this.qSize;
    }
    
    public void setMaxQueueSize(final int size) {
        this.qSize = size;
    }
    
    public int getThreadPoolSize() {
        return this.systemThreadPool.getPoolSize();
    }
    
    public void setThreadPoolSize(final int size) {
    }
    
    public void handleMessage(final Object message) {
    }
}

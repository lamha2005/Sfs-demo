// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers;

import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.exceptions.SFSExtensionException;
import com.smartfoxserver.bitswarm.io.IRequest;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.entities.managers.IExtensionManager;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.controllers.AbstractController;

public class ExtensionController extends AbstractController
{
    public static final String KEY_EXT_CMD = "c";
    public static final String KEY_EXT_PARAMS = "p";
    public static final String KEY_ROOMID = "r";
    private final Logger logger;
    private final SmartFoxServer sfs;
    private IExtensionManager extensionManager;
    
    public ExtensionController() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = SmartFoxServer.getInstance();
    }
    
    public void init(final Object o) {
        super.init(o);
        this.extensionManager = this.sfs.getExtensionManager();
    }
    
    public void destroy(final Object o) {
        super.destroy(o);
        this.extensionManager = null;
    }
    
    public void processRequest(final IRequest request) throws Exception {
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(request.toString());
        }
        final long t1 = System.nanoTime();
        final User sender = this.sfs.getUserManager().getUserBySession(request.getSender());
        if (sender == null) {
            throw new SFSExtensionException("Extension Request refused. Sender is not a User: " + request.getSender());
        }
        final ISFSObject reqObj = (ISFSObject)request.getContent();
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(reqObj.getDump());
        }
        final String cmd = reqObj.getUtfString("c");
        if (cmd == null || cmd.length() == 0) {
            throw new SFSExtensionException("Extension Request refused. Missing CMD. " + sender);
        }
        int roomId = -1;
        if (reqObj.containsKey("r")) {
            roomId = reqObj.getInt("r");
        }
        ISFSObject params = reqObj.getSFSObject("p");
        if (request.isUdp()) {
            if (params == null) {
                params = new SFSObject();
            }
            params.putLong("$FS_REQUEST_UDP_TIMESTAMP", (long)request.getAttribute("$FS_REQUEST_UDP_TIMESTAMP"));
        }
        final Zone zone = sender.getZone();
        ISFSExtension extension = null;
        if (roomId > -1) {
            final Room room = zone.getRoomById(roomId);
            if (room != null) {
                if (!room.containsUser(sender)) {
                    throw new SFSExtensionException("User cannot invoke Room extension if he's not joined in that Room. " + sender + ", " + room);
                }
                extension = this.extensionManager.getRoomExtension(room);
            }
        }
        else {
            extension = this.extensionManager.getZoneExtension(zone);
        }
        if (extension == null) {
            throw new SFSExtensionException(String.format("No extensions can be invoked: %s, RoomId: %s", zone.toString(), (roomId == -1) ? "None" : roomId));
        }
        sender.updateLastRequestTime();
        try {
            extension.handleClientRequest(cmd, sender, params);
        }
        catch (Exception e) {
            final ExceptionMessageComposer composer = new ExceptionMessageComposer(e);
            composer.setDescription("Error while handling client request in extension: " + extension.toString());
            composer.addInfo("Extension Cmd: " + cmd);
            this.logger.error(composer.toString());
        }
        final long t2 = System.nanoTime();
        if (this.logger.isDebugEnabled()) {
            this.logger.debug("Extension call executed in: " + (t2 - t1) / 1000000.0);
        }
    }
}

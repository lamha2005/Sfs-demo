// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.exceptions.SFSFilterInterruptedException;
import com.smartfoxserver.bitswarm.io.IRequest;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import java.util.HashMap;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.Map;
import com.smartfoxserver.bitswarm.controllers.AbstractController;

public class SystemController extends AbstractController
{
    private static final Map<Object, String> commandMap;
    private static final String commandPackage = "com.smartfoxserver.v2.controllers.system.";
    private static final String buddyPackage = "buddylist.";
    private static final String gamePackage = "game.";
    private final SmartFoxServer sfs;
    private final Logger logger;
    private Map<Object, IControllerCommand> commandCache;
    private boolean useCache;
    
    static {
        (commandMap = new HashMap<Object, String>()).put(SystemRequest.Handshake.getId(), "com.smartfoxserver.v2.controllers.system.Handshake");
        SystemController.commandMap.put(SystemRequest.Login.getId(), "com.smartfoxserver.v2.controllers.system.Login");
        SystemController.commandMap.put(SystemRequest.Logout.getId(), "com.smartfoxserver.v2.controllers.system.Logout");
        SystemController.commandMap.put(SystemRequest.JoinRoom.getId(), "com.smartfoxserver.v2.controllers.system.JoinRoom");
        SystemController.commandMap.put(SystemRequest.AutoJoin.getId(), "com.smartfoxserver.v2.controllers.system.AutoJoin");
        SystemController.commandMap.put(SystemRequest.CreateRoom.getId(), "com.smartfoxserver.v2.controllers.system.CreateRoom");
        SystemController.commandMap.put(SystemRequest.GenericMessage.getId(), "com.smartfoxserver.v2.controllers.system.GenericMessage");
        SystemController.commandMap.put(SystemRequest.ChangeRoomName.getId(), "com.smartfoxserver.v2.controllers.system.ChangeRoomName");
        SystemController.commandMap.put(SystemRequest.ChangeRoomPassword.getId(), "com.smartfoxserver.v2.controllers.system.ChangeRoomPassword");
        SystemController.commandMap.put(SystemRequest.ChangeRoomCapacity.getId(), "com.smartfoxserver.v2.controllers.system.ChangeRoomCapacity");
        SystemController.commandMap.put(SystemRequest.ObjectMessage.getId(), "com.smartfoxserver.v2.controllers.system.SendObject");
        SystemController.commandMap.put(SystemRequest.SetRoomVariables.getId(), "com.smartfoxserver.v2.controllers.system.SetRoomVariables");
        SystemController.commandMap.put(SystemRequest.SetUserVariables.getId(), "com.smartfoxserver.v2.controllers.system.SetUserVariables");
        SystemController.commandMap.put(SystemRequest.CallExtension.getId(), "com.smartfoxserver.v2.controllers.system.CallExtension");
        SystemController.commandMap.put(SystemRequest.LeaveRoom.getId(), "com.smartfoxserver.v2.controllers.system.LeaveRoom");
        SystemController.commandMap.put(SystemRequest.SubscribeRoomGroup.getId(), "com.smartfoxserver.v2.controllers.system.SubscribeRoomGroup");
        SystemController.commandMap.put(SystemRequest.UnsubscribeRoomGroup.getId(), "com.smartfoxserver.v2.controllers.system.UnsubscribeRoomGroup");
        SystemController.commandMap.put(SystemRequest.PlayerToSpectator.getId(), "com.smartfoxserver.v2.controllers.system.PlayerToSpectator");
        SystemController.commandMap.put(SystemRequest.SpectatorToPlayer.getId(), "com.smartfoxserver.v2.controllers.system.SpectatorToPlayer");
        SystemController.commandMap.put(SystemRequest.KickUser.getId(), "com.smartfoxserver.v2.controllers.system.KickUser");
        SystemController.commandMap.put(SystemRequest.BanUser.getId(), "com.smartfoxserver.v2.controllers.system.BanUser");
        SystemController.commandMap.put(SystemRequest.ManualDisconnection.getId(), "com.smartfoxserver.v2.controllers.system.ManualDisconnection");
        SystemController.commandMap.put(SystemRequest.FindRooms.getId(), "com.smartfoxserver.v2.controllers.system.FindRooms");
        SystemController.commandMap.put(SystemRequest.FindUsers.getId(), "com.smartfoxserver.v2.controllers.system.FindUsers");
        SystemController.commandMap.put(SystemRequest.PingPong.getId(), "com.smartfoxserver.v2.controllers.system.PingPong");
        SystemController.commandMap.put(SystemRequest.SetUserPosition.getId(), "com.smartfoxserver.v2.controllers.system.SetUserPosition");
        SystemController.commandMap.put(SystemRequest.InitBuddyList.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.InitBuddyList");
        SystemController.commandMap.put(SystemRequest.AddBuddy.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.AddBuddy");
        SystemController.commandMap.put(SystemRequest.BlockBuddy.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.BlockBuddy");
        SystemController.commandMap.put(SystemRequest.RemoveBuddy.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.RemoveBuddy");
        SystemController.commandMap.put(SystemRequest.SetBuddyVariables.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.SetBuddyVariables");
        SystemController.commandMap.put(SystemRequest.GoOnline.getId(), "com.smartfoxserver.v2.controllers.system.buddylist.GoOnline");
        SystemController.commandMap.put(SystemRequest.CreateSFSGame.getId(), "com.smartfoxserver.v2.controllers.system.game.CreateSFSGame");
        SystemController.commandMap.put(SystemRequest.InviteUser.getId(), "com.smartfoxserver.v2.controllers.system.game.InviteUser");
        SystemController.commandMap.put(SystemRequest.InvitationReply.getId(), "com.smartfoxserver.v2.controllers.system.game.InvitationReply");
        SystemController.commandMap.put(SystemRequest.QuickJoinGame.getId(), "com.smartfoxserver.v2.controllers.system.game.QuickJoinGame");
    }
    
    public SystemController() {
        this.useCache = true;
        this.sfs = SmartFoxServer.getInstance();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    public void init(final Object o) {
        super.init(o);
        this.commandCache = new ConcurrentHashMap<Object, IControllerCommand>();
    }
    
    public void destroy(final Object o) {
        super.destroy(o);
    }
    
    public void processRequest(final IRequest request) throws Exception {
        if (this.logger.isDebugEnabled()) {
            this.logger.debug("{IN}: " + SystemRequest.fromId(request.getId()).toString());
        }
        IControllerCommand command = null;
        final Object reqId = request.getId();
        if (this.useCache) {
            command = this.commandCache.get(reqId);
            if (command == null) {
                command = this.getCommand(reqId);
            }
        }
        else {
            command = this.getCommand(reqId);
        }
        if (command != null && command.validate(request)) {
            try {
                command.execute(request);
            }
            catch (SFSFilterInterruptedException err) {
                if (this.logger.isDebugEnabled()) {
                    final User user = this.sfs.getUserManager().getUserBySession(request.getSender());
                    final String sender = (user != null) ? user.toString() : request.getSender().toString();
                    this.logger.debug("FilterChain stopped request: " + SystemRequest.fromId(reqId) + ", Sender: " + sender);
                }
            }
            catch (SFSRuntimeException re) {
                final String msg = re.getMessage();
                if (msg != null) {
                    this.logger.warn(msg);
                }
            }
        }
    }
    
    private IControllerCommand getCommand(final Object reqId) {
        IControllerCommand command = null;
        final String className = SystemController.commandMap.get(reqId);
        if (className != null) {
            try {
                final Class<?> clazz = Class.forName(className);
                command = (IControllerCommand)clazz.newInstance();
            }
            catch (Exception err) {
                this.logger.error("Could not dynamically instantiate class: " + className + ", Error: " + err);
            }
        }
        else {
            this.logger.error("Cannot find a controller command for request ID: " + reqId);
        }
        return command;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers;

import com.smartfoxserver.bitswarm.io.IResponse;
import java.lang.reflect.Method;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.managers.ILSManager;
import com.smartfoxserver.v2.scala.LSManagerProvider;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.bitswarm.controllers.AbstractController;

public class SmasherController extends AbstractController
{
    public static final short CMD_ZERO = 0;
    public static final short CMD_ONE = 1;
    public static final String KEY_EXT_CMD = "c";
    public static final String KEY_EXT_PARAMS = "p";
    public static final String KEY_ROOMID = "r";
    private final SmartFoxServer sfs;
    private ISession currentSmasherSession;
    
    public SmasherController() {
        this.sfs = SmartFoxServer.getInstance();
    }
    
    public void processRequest(final IRequest request) throws Exception {
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(request.toString());
        }
        final ISFSObject reqObj = (ISFSObject)request.getContent();
        final Object reqId = request.getId();
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(reqObj.getDump());
        }
        this.process(reqId, reqObj, request.getSender());
    }
    
    private void process(final Object reqId, final ISFSObject reqObj, final ISession sender) throws Exception {
        if (reqId == null) {
            throw new SFSRuntimeException("ReqId is null");
        }
        final short cmd = (short)reqId;
        if (cmd == 0) {
            this.cmdZero(reqObj, sender);
        }
        else {
            if (cmd != 1) {
                throw new SFSRuntimeException("Unknow request id: " + cmd);
            }
            this.cmdOne(reqObj, sender);
        }
    }
    
    private void cmdZero(final ISFSObject params, final ISession sender) {
        final String description = params.getUtfString("ds");
        final long startTime = params.getLong("st");
        final String logData = String.format("BS Test: %s, Start: %s", description, startTime);
        this.logger.info(logData);
        this.sfs.getAPIManager().getSFSApi().disconnect(sender);
    }
    
    private void cmdOne(final ISFSObject params, final ISession sender) throws Exception {
        if (this.checkSender(sender)) {
            this.currentSmasherSession = sender;
            final ILSManager ilsm = LSManagerProvider.instance();
            final Method m = ILSManager.class.getDeclaredMethod("execute", String.class, Object.class);
            final Object o = m.invoke(ilsm, "checkOpt", "BitSmasher");
            final Integer value = (o == null) ? 0 : Integer.parseInt((String)o);
            sender.setLastActivityTime(Long.MAX_VALUE);
            final ISFSObject prm = new SFSObject();
            prm.putShort("o0", (short)1);
            prm.putInt("o1", value);
            final ISFSObject sfso = new SFSObject();
            sfso.putSFSObject("p", prm);
            final IResponse resp = (IResponse)new Response();
            resp.setId((Object)(short)0);
            resp.setRecipients(sender);
            resp.setContent((Object)sfso);
            resp.setTargetController((Object)DefaultConstants.CORE_EXTENSIONS_CONTROLLER_ID);
            resp.write();
        }
        else {
            this.logger.warn("Another BitSmasher session is already running on: " + this.currentSmasherSession.getAddress() + " -- Unable to run more than one test at once!");
        }
    }
    
    private boolean checkSender(final ISession sender) {
        if (this.currentSmasherSession != null && this.currentSmasherSession == sender) {
            return true;
        }
        if (this.currentSmasherSession != null && this.currentSmasherSession.isConnected()) {
            return false;
        }
        this.currentSmasherSession = sender;
        return true;
    }
}

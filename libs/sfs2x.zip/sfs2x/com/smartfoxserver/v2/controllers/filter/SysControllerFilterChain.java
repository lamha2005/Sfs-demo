// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.filter;

import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.extensions.filter.FilterAction;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.util.Collection;

public class SysControllerFilterChain implements ISystemFilterChain
{
    private final Collection<SysControllerFilter> filters;
    private final Logger log;
    
    public SysControllerFilterChain() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.filters = new ConcurrentLinkedQueue<SysControllerFilter>();
    }
    
    @Override
    public final void addFilter(final String filterName, final SysControllerFilter filter) {
        filter.setName(filterName);
        this.filters.add(filter);
    }
    
    @Override
    public final void remove(final String filterName) {
        final Iterator<SysControllerFilter> it = this.filters.iterator();
        while (it.hasNext()) {
            final SysControllerFilter filter = it.next();
            if (filter.getName().equals(filterName)) {
                it.remove();
                break;
            }
        }
    }
    
    @Override
    public final void clearAll() {
        this.filters.clear();
    }
    
    @Override
    public final int size() {
        return this.filters.size();
    }
    
    @Override
    public FilterAction runRequest(final User sender, final ISFSObject params) {
        FilterAction filterAction = FilterAction.CONTINUE;
        for (final SysControllerFilter filter : this.filters) {
            try {
                filterAction = filter.handleClientRequest(sender, params);
                if (filterAction == FilterAction.HALT) {
                    break;
                }
                continue;
            }
            catch (Exception e) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
                emc.setDescription("Error while running SysController Filter: " + filter.getName());
                this.log.warn(emc.toString());
            }
        }
        return filterAction;
    }
}

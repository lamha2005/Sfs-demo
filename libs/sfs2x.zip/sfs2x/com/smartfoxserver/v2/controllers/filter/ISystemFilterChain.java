// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.filter;

import com.smartfoxserver.v2.extensions.filter.FilterAction;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;

public interface ISystemFilterChain
{
    void addFilter(final String p0, final SysControllerFilter p1);
    
    void remove(final String p0);
    
    FilterAction runRequest(final User p0, final ISFSObject p1);
    
    int size();
    
    void clearAll();
}

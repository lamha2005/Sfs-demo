// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.filter;

import com.smartfoxserver.v2.extensions.ExtensionLogLevel;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public abstract class SysControllerFilter implements ISystemFilter
{
    protected final Logger logger;
    private String name;
    
    public SysControllerFilter() {
        this.logger = LoggerFactory.getLogger("Extensions");
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        if (this.name == null) {
            this.name = name;
        }
    }
    
    protected void trace(final Object... args) {
        this.trace(ExtensionLogLevel.INFO, args);
    }
    
    protected void trace(final ExtensionLogLevel level, final Object... args) {
        final String traceMsg = this.getTraceMessage(args);
        if (level == ExtensionLogLevel.DEBUG) {
            this.logger.debug(traceMsg);
        }
        else if (level == ExtensionLogLevel.INFO) {
            this.logger.info(traceMsg);
        }
        else if (level == ExtensionLogLevel.WARN) {
            this.logger.warn(traceMsg);
        }
        else if (level == ExtensionLogLevel.ERROR) {
            this.logger.error(traceMsg);
        }
    }
    
    private String getTraceMessage(final Object[] args) {
        final StringBuilder traceMsg = new StringBuilder().append("{").append(this.name).append("}: ");
        for (final Object o : args) {
            traceMsg.append(o.toString()).append(" ");
        }
        return traceMsg.toString();
    }
}

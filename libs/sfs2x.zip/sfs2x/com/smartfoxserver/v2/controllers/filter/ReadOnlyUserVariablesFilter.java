// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.filter;

import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.extensions.filter.FilterAction;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CopyOnWriteArraySet;
import org.slf4j.LoggerFactory;
import java.util.List;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.Zone;
import java.util.Set;

public class ReadOnlyUserVariablesFilter extends SysControllerFilter
{
    private final Set<String> readOnlyVars;
    private final Zone zone;
    private final Logger log;
    
    public ReadOnlyUserVariablesFilter(final Zone zone) {
        this(zone, null);
    }
    
    public ReadOnlyUserVariablesFilter(final Zone zone, final List<String> varNames) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.zone = zone;
        this.readOnlyVars = ((varNames == null) ? new CopyOnWriteArraySet<String>() : new CopyOnWriteArraySet<String>(varNames));
    }
    
    public void addVariable(final String varName) {
        this.readOnlyVars.add(varName);
    }
    
    public void removeVariable(final String varName) {
        this.readOnlyVars.remove(varName);
    }
    
    public List<String> getFilteredVariables() {
        return new ArrayList<String>(this.readOnlyVars);
    }
    
    public void clearFilter() {
        this.readOnlyVars.clear();
    }
    
    @Override
    public FilterAction handleClientRequest(final User sender, final ISFSObject params) throws SFSException {
        if (sender.getZone() != this.zone) {
            return FilterAction.CONTINUE;
        }
        final ISFSArray vars = params.getSFSArray("vl");
        if (vars != null && vars.size() > 0) {
            ISFSArray filteredVars = null;
            if (vars.size() == 1) {
                filteredVars = this.filterSingleVariableUpdate(vars);
            }
            else {
                filteredVars = this.filterMultiVariableUpdate(vars);
            }
            if (filteredVars.size() < 1) {
                return FilterAction.HALT;
            }
            params.putSFSArray("vl", filteredVars);
        }
        return FilterAction.CONTINUE;
    }
    
    private ISFSArray filterSingleVariableUpdate(final ISFSArray vars) {
        final ISFSArray var = (ISFSArray)vars.getElementAt(0);
        return this.isReadOnly(var.getUtfString(0)) ? new SFSArray() : vars;
    }
    
    private ISFSArray filterMultiVariableUpdate(final ISFSArray vars) {
        final ISFSArray filteredVars = new SFSArray();
        for (int i = 0; i < vars.size(); ++i) {
            final ISFSArray var = (ISFSArray)vars.getElementAt(i);
            if (!this.isReadOnly(var.getUtfString(0))) {
                filteredVars.addSFSArray(var);
            }
        }
        return filteredVars;
    }
    
    private boolean isReadOnly(final String varName) {
        final boolean readOnly = this.readOnlyVars.contains(varName);
        if (this.log.isDebugEnabled() && readOnly) {
            this.log.debug("Filtering read-only variable: " + varName);
        }
        return readOnly;
    }
}

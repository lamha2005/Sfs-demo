// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.api.ISFSMMOApi;
import com.smartfoxserver.v2.entities.data.SFSDataWrapper;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.mmo.Vec3D;
import java.util.List;
import com.smartfoxserver.v2.entities.data.SFSDataType;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.mmo.MMORoom;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class SetUserPosition extends BaseControllerCommand
{
    public static final String KEY_VEC3D = "v";
    public static final String KEY_ROOM_ID = "r";
    public static final String KEY_PLUS_USER_LIST = "p";
    public static final String KEY_MINUS_USER_LIST = "m";
    public static final String KEY_PLUS_ITEM_LIST = "q";
    public static final String KEY_MINUS_ITEM_LIST = "n";
    
    public SetUserPosition() {
        super(SystemRequest.SetUserPosition);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("r")) {
            throw new SFSRequestValidationException("Missing target room id");
        }
        if (!sfso.containsKey("v")) {
            throw new SFSRequestValidationException("Missing position");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final Zone zone = user.getZone();
        final Room targetRoom = zone.getRoomById(sfso.getInt("r"));
        if (targetRoom == null) {
            throw new SFSRequestValidationException("Can't set user position. Room does not exist. ID: " + sfso.getInt("r"));
        }
        if (!(targetRoom instanceof MMORoom)) {
            throw new SFSRequestValidationException("Can't set user position. Room is not of MMO type: " + targetRoom);
        }
        final SFSDataWrapper wrapper = sfso.get("v");
        final ISFSMMOApi mmoApi = SmartFoxServer.getInstance().getAPIManager().getMMOApi();
        Vec3D pos = null;
        boolean isFloat = false;
        if (wrapper.getTypeId() == SFSDataType.SFS_ARRAY) {
            isFloat = ((MMORoom)targetRoom).getDefaultAOI().isFloat();
        }
        else {
            isFloat = (wrapper.getTypeId() == SFSDataType.FLOAT_ARRAY);
        }
        if (!isFloat) {
            final List<Integer> iVals = (List<Integer>)(List)sfso.getIntArray("v");
            if (iVals.size() != 3) {
                throw new SFSRequestValidationException("Can't set user position. Expected 3 integers, found " + iVals.size());
            }
            pos = new Vec3D(iVals.get(0), iVals.get(1), iVals.get(2));
        }
        else {
            final List<Float> fVals = (List<Float>)(List)sfso.getFloatArray("v");
            if (fVals.size() != 3) {
                throw new SFSRequestValidationException("Can't set user position. Expected 3 integers, found " + fVals.size());
            }
            pos = new Vec3D(fVals.get(0), fVals.get(1), fVals.get(2));
        }
        mmoApi.setUserPosition(user, pos, targetRoom);
    }
}

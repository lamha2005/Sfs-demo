// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import java.util.Iterator;
import com.smartfoxserver.v2.entities.Room;
import java.util.ArrayList;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.Collection;
import com.smartfoxserver.v2.controllers.SuperUserSendMode;
import com.smartfoxserver.grid.SFSGrid;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.data.SFSDataWrapper;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.mmo.Vec3D;
import java.util.List;
import com.smartfoxserver.v2.entities.data.SFSDataType;
import com.smartfoxserver.v2.api.GenericMessageType;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class GenericMessage extends BaseControllerCommand
{
    public static final String KEY_ROOM_ID = "r";
    public static final String KEY_USER_ID = "u";
    public static final String KEY_MESSAGE = "m";
    public static final String KEY_MESSAGE_TYPE = "t";
    public static final String KEY_RECIPIENT = "rc";
    public static final String KEY_RECIPIENT_MODE = "rm";
    public static final String KEY_SENDER_DATA = "sd";
    public static final String KEY_XTRA_PARAMS = "p";
    public static final String KEY_AOI = "aoi";
    
    public GenericMessage() {
        super(SystemRequest.GenericMessage);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final Byte messageType = sfso.getByte("t");
        if (messageType == null) {
            throw new SFSRequestValidationException("Missing message type");
        }
        final GenericMessageType type = GenericMessageType.fromId(messageType);
        if (type == null) {
            throw new SFSRequestValidationException("Unrecognized message type");
        }
        switch (type) {
            case PUBLIC_MSG: {
                this.validatePublicMessage(request);
                break;
            }
            case PRIVATE_MSG: {
                this.validatePrivateMessage(request);
                break;
            }
            case OBJECT_MSG: {
                this.validateObjectMessage(request);
                break;
            }
            case BUDDY_MSG: {
                this.validateBuddyMessage(request);
                break;
            }
            default: {
                this.validateSuperUserMessage(request);
                break;
            }
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final Byte messageType = sfso.getByte("t");
        final GenericMessageType type = GenericMessageType.fromId(messageType);
        switch (type) {
            case PUBLIC_MSG: {
                this.executePublicMessage(request);
                break;
            }
            case PRIVATE_MSG: {
                this.executePrivateMessage(request);
                break;
            }
            case OBJECT_MSG: {
                this.executeObjectMessage(request);
                break;
            }
            case BUDDY_MSG: {
                this.executeBuddyMessage(request);
                break;
            }
            default: {
                this.executeSuperUserMessage(request, type);
                break;
            }
        }
    }
    
    private void validatePublicMessage(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("r")) {
            throw new SFSRequestValidationException("Missing Target Room id");
        }
        if (!sfso.containsKey("m")) {
            throw new SFSRequestValidationException("Missing message data");
        }
    }
    
    private void validatePrivateMessage(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("rc")) {
            throw new SFSRequestValidationException("Missing recipient id");
        }
        if (!sfso.containsKey("m")) {
            throw new SFSRequestValidationException("Missing message data");
        }
    }
    
    private void validateBuddyMessage(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("rc")) {
            throw new SFSRequestValidationException("Missing target buddy");
        }
        if (!sfso.containsKey("m")) {
            throw new SFSRequestValidationException("Missing message data");
        }
    }
    
    private void validateSuperUserMessage(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("rm")) {
            throw new SFSRequestValidationException("Missing recipient mode");
        }
        if (!sfso.containsKey("m")) {
            throw new SFSRequestValidationException("Missing message data");
        }
    }
    
    private void validateObjectMessage(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("r")) {
            throw new SFSRequestValidationException("Missing Target Room id");
        }
        if (!sfso.containsKey("p")) {
            throw new SFSRequestValidationException("Missing object message");
        }
    }
    
    private void executePublicMessage(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User user = this.checkRequestPermissions(request, SystemRequest.PublicMessage);
        request.setId(SystemRequest.PublicMessage.getId());
        this.applyZoneFilterChain(user, request);
        final Zone zone = user.getZone();
        user.updateLastRequestTime();
        final boolean containsAOI = sfso.containsKey("aoi");
        if (containsAOI) {
            final SFSDataWrapper item = sfso.get("aoi");
            final boolean isFloat = item.getTypeId() == SFSDataType.FLOAT_ARRAY;
            Vec3D aoi = null;
            if (isFloat) {
                aoi = Vec3D.fromFloatArray((List)sfso.getFloatArray("aoi"));
            }
            else {
                aoi = Vec3D.fromIntArray((List)sfso.getIntArray("aoi"));
            }
            this.sfs.getAPIManager().getMMOApi().sendPublicMessage(zone.getRoomById(sfso.getInt("r")), zone.getUserBySession(request.getSender()), sfso.getUtfString("m"), sfso.getSFSObject("p"), aoi);
        }
        else {
            this.api.sendPublicMessage(zone.getRoomById(sfso.getInt("r")), zone.getUserBySession(request.getSender()), sfso.getUtfString("m"), sfso.getSFSObject("p"));
        }
    }
    
    private void executePrivateMessage(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User sender = this.checkRequestPermissions(request, SystemRequest.PrivateMessage);
        request.setId(SystemRequest.PrivateMessage.getId());
        this.applyZoneFilterChain(sender, request);
        final User recipient = this.api.getUserById(sfso.getInt("rc"));
        if (recipient == null) {
            throw new IllegalArgumentException("Private Message recipient is not available. Recipient ID: " + sfso.getInt("rc"));
        }
        sender.updateLastRequestTime();
        this.api.sendPrivateMessage(sender, recipient, sfso.getUtfString("m"), sfso.getSFSObject("p"));
    }
    
    private void executeBuddyMessage(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User sender = this.checkRequestPermissions(request, SystemRequest.BuddyMessage);
        request.setId(SystemRequest.BuddyMessage.getId());
        this.applyZoneFilterChain(sender, request);
        final int recipientID = sfso.getInt("rc");
        final User recipient = this.api.getUserById(recipientID);
        sender.updateLastRequestTime();
        if (SmartFoxServer.grid()) {
            SFSGrid.manager().getApi().sendBuddyMessage(sender, recipientID, sfso.getUtfString("m"), sfso.getSFSObject("p"));
        }
        else {
            this.api.sendBuddyMessage(sender, recipient, sfso.getUtfString("m"), sfso.getSFSObject("p"));
        }
    }
    
    private void executeSuperUserMessage(final IRequest request, final GenericMessageType type) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User sender = this.checkRequestPermissions(request, SystemRequest.ModeratorMessage);
        request.setId(SystemRequest.ModeratorMessage.getId());
        this.applyZoneFilterChain(sender, request);
        final SuperUserSendMode sendMode = SuperUserSendMode.fromId(sfso.getInt("rm"));
        if (sendMode == null) {
            throw new IllegalArgumentException("SendMode not recognized: " + sfso.getInt("rm"));
        }
        final Collection<ISession> recipients = this.getMessageRecipients(sendMode, sender, sfso);
        if (type == GenericMessageType.MODERATOR_MSG) {
            this.api.sendModeratorMessage(sender, sfso.getUtfString("m"), sfso.getSFSObject("p"), recipients);
        }
        else {
            this.api.sendAdminMessage(sender, sfso.getUtfString("m"), sfso.getSFSObject("p"), recipients);
        }
    }
    
    private void executeObjectMessage(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User user = this.checkRequestPermissions(request, SystemRequest.ObjectMessage);
        request.setId(SystemRequest.ObjectMessage.getId());
        this.applyZoneFilterChain(user, request);
        final Zone zone = user.getZone();
        final Room targetRoom = zone.getRoomById(sfso.getInt("r"));
        if (targetRoom == null) {
            throw new IllegalArgumentException("Room with Id: " + sfso.getInt("r") + ", is not found.");
        }
        user.updateLastRequestTime();
        final Collection<Integer> recipientIds = sfso.getIntArray("rc");
        List<User> recipients = null;
        if (recipientIds != null) {
            if (recipientIds.size() > targetRoom.getCapacity()) {
                throw new IllegalArgumentException(String.format("Number of Object Message recipients (%s) is bigger than Room capacity (%s)", recipientIds.size(), targetRoom.getCapacity()));
            }
            recipients = new ArrayList<User>();
            for (final Integer userId : recipientIds) {
                if (userId != null) {
                    final User targetUser = zone.getUserById(userId);
                    if (targetUser == null) {
                        continue;
                    }
                    recipients.add(targetUser);
                }
            }
        }
        else {
            recipients = targetRoom.getUserList();
            recipients.remove(user);
        }
        this.api.sendObjectMessage(targetRoom, user, sfso.getSFSObject("p"), recipients);
    }
    
    private Collection<ISession> getMessageRecipients(final SuperUserSendMode mode, final User sender, final ISFSObject params) {
        Collection<ISession> recipients = null;
        switch (mode) {
            case TO_USER: {
                recipients = new ArrayList<ISession>();
                final User user = this.api.getUserById(params.getInt("rc"));
                if (user != null) {
                    recipients.add(user.getSession());
                    break;
                }
                break;
            }
            case TO_ROOM: {
                final Room room = sender.getZone().getRoomById(params.getInt("rc"));
                if (room != null) {
                    recipients = room.getSessionList();
                    break;
                }
                recipients = new ArrayList<ISession>();
                break;
            }
            case TO_GROUP: {
                final String groupId = params.getUtfString("rc");
                final Zone zone = sender.getZone();
                if (zone.containsGroup(groupId)) {
                    recipients = zone.getSessionsInGroup(groupId);
                    break;
                }
                recipients = new ArrayList<ISession>();
                break;
            }
            default: {
                recipients = sender.getZone().getSessionList();
                break;
            }
        }
        return recipients;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class Logout extends BaseControllerCommand
{
    public static final String KEY_ZONE_NAME = "zn";
    
    public Logout() {
        super(SystemRequest.Logout);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User sender = this.api.getUserBySession(request.getSender());
        if (sender == null) {
            throw new IllegalArgumentException("Logout failure. Session is not logged in: " + request.getSender());
        }
        this.api.logout(sender);
    }
}

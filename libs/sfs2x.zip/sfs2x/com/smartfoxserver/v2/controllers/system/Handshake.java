// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.v2.entities.User;
import java.util.List;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.bitswarm.io.Response;
import com.smartfoxserver.v2.util.CryptoUtils;
import java.util.Collection;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import java.util.Arrays;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class Handshake extends BaseControllerCommand
{
    public static final String KEY_BIN_FLAG = "bin";
    public static final String KEY_API = "api";
    public static final String KEY_TOKEN = "tk";
    public static final String KEY_COMPRESSION_THRESHOLD = "ct";
    public static final String KEY_RECONNECTION_TOKEN = "rt";
    public static final String KEY_CLIENT_TYPE = "cl";
    public static final String KEY_MAX_MESSAGE_SIZE = "ms";
    
    public Handshake() {
        super(SystemRequest.Handshake);
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        ISession sender = request.getSender();
        final ISFSObject reqObj = (ISFSObject)request.getContent();
        final String apiVersionStr = reqObj.getUtfString("api");
        final String reconnectionToken = reqObj.getUtfString("rt");
        final ISFSObject resObj = SFSObject.newInstance();
        if (!this.isApiVersionOk(apiVersionStr)) {
            final List<String> errorParams = Arrays.asList(apiVersionStr, this.formatVersionNumber(this.sfs.getMinClientApiVersion()));
            resObj.putShort("ec", SFSErrorCode.HANDSHAKE_API_OBSOLETE.getId());
            resObj.putUtfStringArray("ep", errorParams);
        }
        else {
            String sessionToken = null;
            if (reconnectionToken != null) {
                final ISession resumedSession = this.sfs.getSessionManager().reconnectSession(sender, reconnectionToken);
                if (resumedSession == null) {
                    return;
                }
                sender = resumedSession;
                sessionToken = sender.getHashId();
                final User user = this.sfs.getUserManager().getUserBySession(sender);
                if (user == null) {
                    this.logger.warn("User not found at reconnection time. " + sender);
                }
                else {
                    user.updateLastRequestTime();
                    this.logger.info("Reconnected USER: " + user + ", logged: " + sender.isLoggedIn());
                }
            }
            else {
                sessionToken = CryptoUtils.getUniqueSessionToken(sender);
            }
            sender.setSystemProperty("ClientType", (Object)(reqObj.containsKey("cl") ? reqObj.getUtfString("cl") : "Unknown"));
            sender.setHashId(sessionToken);
            resObj.putUtfString("tk", sessionToken);
            resObj.putInt("ct", this.sfs.getConfigurator().getServerSettings().protocolCompressionThreshold);
            resObj.putInt("ms", this.sfs.getConfigurator().getCoreSettings().maxIncomingRequestSize);
        }
        final IResponse response = (IResponse)new Response();
        response.setId((Object)this.getId());
        response.setRecipients(sender);
        response.setContent((Object)resObj);
        response.setTargetController((Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID);
        response.write();
    }
    
    private String formatVersionNumber(final int ver) {
        final String unformatted = String.valueOf(ver);
        final int additionalZeros = 3 - unformatted.length();
        final StringBuffer sb = new StringBuffer();
        if (additionalZeros > 0) {
            for (int j = 0; j < additionalZeros; ++j) {
                sb.append('0');
            }
        }
        sb.append(unformatted);
        int bottomPos = sb.length() - 1;
        sb.insert(bottomPos, '.');
        --bottomPos;
        sb.insert(bottomPos, '.');
        return sb.toString();
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject reqObj = (ISFSObject)request.getContent();
        final ISession sender = request.getSender();
        if (!reqObj.containsKey("api")) {
            throw new SFSRequestValidationException("Missing 'api' flag in Handshake Request. Sender: " + sender);
        }
        final String clientType = reqObj.getUtfString("cl");
        if (clientType != null && clientType.length() > 512) {
            throw new SFSRequestValidationException("Illegal ClientType field length (> 512 chars). Sender: " + sender);
        }
        return true;
    }
    
    private boolean isApiVersionOk(String apiVersionStr) {
        boolean ok = false;
        apiVersionStr = apiVersionStr.replace(".", "");
        int apiVersionNumber = -1;
        try {
            apiVersionNumber = Integer.parseInt(apiVersionStr);
        }
        catch (NumberFormatException ex) {}
        if (apiVersionNumber >= this.sfs.getMinClientApiVersion()) {
            ok = true;
        }
        return ok;
    }
}

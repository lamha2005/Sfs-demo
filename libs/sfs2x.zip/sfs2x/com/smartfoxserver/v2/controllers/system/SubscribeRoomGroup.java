// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class SubscribeRoomGroup extends BaseControllerCommand
{
    public static final String KEY_GROUP_ID = "g";
    public static final String KEY_ROOM_LIST = "rl";
    
    public SubscribeRoomGroup() {
        super(SystemRequest.SubscribeRoomGroup);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("g")) {
            throw new SFSRequestValidationException("Missing GroupId");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final Zone zone = user.getZone();
        final String groupId = sfso.getUtfString("g");
        if (!zone.containsPublicGroup(groupId)) {
            final SFSErrorData errData = new SFSErrorData(SFSErrorCode.SUBSCRIBE_GROUP_NOT_FOUND);
            errData.addParameter(groupId);
            this.api.getResponseAPI().notifyRequestError(errData, user, SystemRequest.SubscribeRoomGroup);
            throw new SFSException(String.format("Invalid client group subscription: %s, User: %s", groupId, user.getName()), errData);
        }
        this.api.subscribeRoomGroup(user, groupId);
    }
}

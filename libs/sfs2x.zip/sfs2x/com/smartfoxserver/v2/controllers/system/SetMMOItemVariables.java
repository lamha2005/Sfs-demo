// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

public class SetMMOItemVariables
{
    public static final String KEY_ROOM_ID = "r";
    public static final String KEY_ITEM_ID = "i";
    public static final String KEY_VAR_LIST = "v";
}

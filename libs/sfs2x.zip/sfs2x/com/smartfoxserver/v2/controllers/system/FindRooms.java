// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Room;
import java.util.Collection;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.util.UsersUtil;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class FindRooms extends BaseControllerCommand
{
    public static final String KEY_EXPRESSION = "e";
    public static final String KEY_GROUP = "g";
    public static final String KEY_LIMIT = "l";
    public static final String KEY_FILTERED_ROOMS = "fr";
    
    public FindRooms() {
        super(SystemRequest.FindRooms);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("e")) {
            throw new SFSRequestValidationException("No Expression was specified");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        final Zone zone = user.getZone();
        if (!UsersUtil.isAllowedToPerformNewSearch(user)) {
            throw new IllegalStateException("Denied: too little time since the last Find request, " + user);
        }
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final ISFSArray expressionData = sfso.getSFSArray("e");
        final String groupId = sfso.getUtfString("g");
        final int limit = sfso.containsKey("l") ? ((short)sfso.getShort("l")) : 0;
        if (expressionData == null) {
            throw new IllegalArgumentException("Invalid expression. Null data");
        }
        final MatchExpression expression = MatchExpression.fromSFSArray(expressionData);
        Collection<Room> roomList = null;
        if (groupId == null || groupId.length() == 0) {
            roomList = zone.getRoomList();
        }
        else {
            roomList = zone.getRoomListFromGroup(groupId);
        }
        final Collection<Room> filteredRooms = this.api.findRooms(roomList, expression, limit);
        this.api.getResponseAPI().notifyFilteredRoomList(user.getSession(), filteredRooms);
    }
}

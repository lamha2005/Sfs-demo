// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.game;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.invitation.InvitationResponse;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class InvitationReply extends BaseControllerCommand
{
    public static final String KEY_INVITATION_ID = "i";
    public static final String KEY_INVITATION_REPLY = "r";
    public static final String KEY_INVITATION_PARAMS = "p";
    
    public InvitationReply() {
        super(SystemRequest.InvitationReply);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (sfso.isNull("i")) {
            throw new SFSRequestValidationException("missing Invitation id");
        }
        if (sfso.isNull("r")) {
            throw new SFSRequestValidationException("missing Invitation reply (accept/refuse)");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        this.sfs.getAPIManager().getGameApi().replyToInvitation(user, sfso.getInt("i"), InvitationResponse.fromId(sfso.getByte("r")), sfso.getSFSObject("p"), true);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class ChangeRoomPassword extends BaseControllerCommand
{
    public static final String KEY_ROOM = "r";
    public static final String KEY_PASS = "p";
    
    public ChangeRoomPassword() {
        super(SystemRequest.ChangeRoomPassword);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("r")) {
            throw new SFSRequestValidationException("No Room was specified");
        }
        if (!sfso.containsKey("p")) {
            throw new SFSRequestValidationException("No new Password was specified.");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User user = this.checkRequestPermissions(request);
        final Zone zone = user.getZone();
        final Room targetRoom = zone.getRoomById(sfso.getInt("r"));
        if (targetRoom == null) {
            throw new SFSRoomException("Target Room does not exist. Id: " + sfso.getInt("r"));
        }
        this.api.changeRoomPassword(user, targetRoom, sfso.getUtfString("p"));
    }
}

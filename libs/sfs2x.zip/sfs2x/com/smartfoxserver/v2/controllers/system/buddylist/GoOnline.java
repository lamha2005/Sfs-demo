// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.buddylist;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class GoOnline extends BaseControllerCommand
{
    public static final String KEY_ONLINE = "o";
    public static final String KEY_BUDDY_NAME = "bn";
    public static final String KEY_BUDDY_ID = "bi";
    
    public GoOnline() {
        super(SystemRequest.GoOnline);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("o")) {
            throw new SFSRequestValidationException("Missing online status");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User sender = this.checkRequestPermissions(request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        this.sfs.getAPIManager().getBuddyApi().goOnline(sender, sfso.getBool("o"), true);
    }
}

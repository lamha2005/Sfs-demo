// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class UnsubscribeRoomGroup extends BaseControllerCommand
{
    public static final String KEY_GROUP_ID = "g";
    
    public UnsubscribeRoomGroup() {
        super(SystemRequest.UnsubscribeRoomGroup);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("g")) {
            throw new SFSRequestValidationException("Missing GroupId");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final String groupId = sfso.getUtfString("g");
        this.api.unsubscribeRoomGroup(user, groupId);
    }
}

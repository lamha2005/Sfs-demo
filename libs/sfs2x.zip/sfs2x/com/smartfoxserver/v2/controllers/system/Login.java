// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.util.Country;
import com.smartfoxserver.v2.util.GeoLocationUtil;
import java.util.Map;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSSystemEvent;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.SFSEventSysParam;
import com.smartfoxserver.v2.core.ISFSEventParam;
import java.util.HashMap;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class Login extends BaseControllerCommand
{
    public static final String KEY_USERNAME = "un";
    public static final String KEY_PASSWORD = "pw";
    public static final String KEY_ZONENAME = "zn";
    public static final String KEY_PARAMS = "p";
    public static final String KEY_PRIVILEGE_ID = "pi";
    public static final String KEY_ID = "id";
    public static final String KEY_ROOMLIST = "rl";
    public static final String KEY_RECONNECTION_SECONDS = "rs";
    
    public Login() {
        super(SystemRequest.Login);
        SmartFoxServer.getInstance();
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        boolean res = true;
        final ISFSObject sfso = (ISFSObject)request.getContent();
        this.validateFormalParameters(sfso);
        final Zone zone = this.sfs.getZoneManager().getZoneByName(sfso.getUtfString("zn"));
        final ISession sender = request.getSender();
        this.validateLoginErrors(request.getSender(), zone);
        this.validateEncryptionStatus(sender, request, zone);
        if (zone != null && zone.isGeoLocationEnabled()) {
            this.resolveIpAddress(sender);
        }
        res = this.customLogin(sfso, request, zone);
        return res;
    }
    
    protected void validateFormalParameters(final ISFSObject sfso) throws SFSRequestValidationException {
        if (!sfso.containsKey("un") || !sfso.containsKey("pw") || !sfso.containsKey("zn")) {
            throw new SFSRequestValidationException("Bad Login Request. Essential parameters are missing. Client API is probably fake.");
        }
    }
    
    protected void validateLoginErrors(final ISession session, final Zone zone) throws SFSRequestValidationException {
        if (zone != null) {
            AtomicInteger count = (AtomicInteger)session.getSystemProperty("FailedLoginCounts");
            if (count == null) {
                count = new AtomicInteger();
                session.setSystemProperty("FailedLoginCounts", (Object)count);
            }
            if (count.get() >= zone.getMaxFailedLogins()) {
                this.api.disconnect(session);
                throw new SFSRequestValidationException("Too many failed login attempts");
            }
        }
    }
    
    protected void validateEncryptionStatus(final ISession sender, final IRequest request, final Zone zone) {
        final boolean sessionCheck = sender.getType() != SessionType.WEBSOCKET;
        if (zone != null && zone.isEncrypted() && sessionCheck) {
            final Boolean encryptionFlag = (Boolean)request.getAttribute("Encrypted");
            if (encryptionFlag == null || !encryptionFlag) {
                this.api.disconnect(request.getSender());
                throw new SFSRuntimeException(String.format("Login rejected. Client is not using an encrypted connection: %s", sender));
            }
        }
        if (zone != null && !zone.isEncrypted() && sessionCheck) {
            final Boolean encryptionFlag = (Boolean)request.getAttribute("Encrypted");
            if (encryptionFlag != null && encryptionFlag) {
                this.api.disconnect(request.getSender());
                throw new SFSRuntimeException(String.format("Login rejected. The requested Zone does not support encryption: %s, %s", zone.getName(), sender));
            }
        }
    }
    
    protected boolean customLogin(final ISFSObject sfso, final IRequest request, final Zone zone) throws SFSRequestValidationException {
        boolean res = true;
        if (zone != null && zone.isCustomLogin()) {
            if (zone.getExtension() == null) {
                throw new SFSRequestValidationException("Custom login is ON but no Extension is active for this zone: " + zone.getName());
            }
            final Map<ISFSEventParam, Object> sysParams = new HashMap<ISFSEventParam, Object>();
            sysParams.put(SFSEventSysParam.NEXT_COMMAND, Login.class);
            sysParams.put(SFSEventSysParam.REQUEST_OBJ, request);
            final Map<ISFSEventParam, Object> userParams = new HashMap<ISFSEventParam, Object>();
            userParams.put(SFSEventParam.ZONE, zone);
            userParams.put(SFSEventParam.SESSION, request.getSender());
            userParams.put(SFSEventParam.LOGIN_NAME, sfso.getUtfString("un"));
            userParams.put(SFSEventParam.LOGIN_PASSWORD, sfso.getUtfString("pw"));
            userParams.put(SFSEventParam.LOGIN_IN_DATA, sfso.getSFSObject("p"));
            final ISFSObject paramsOut = SFSObject.newInstance();
            request.setAttribute("$FS_REQUEST_LOGIN_DATA_OUT", (Object)paramsOut);
            userParams.put(SFSEventParam.LOGIN_OUT_DATA, paramsOut);
            this.sfs.getEventManager().dispatchEvent(new SFSSystemEvent(SFSEventType.USER_LOGIN, userParams, sysParams));
            res = false;
        }
        return res;
    }
    
    protected void resolveIpAddress(final ISession session) {
        final Country country = GeoLocationUtil.resolve(session.getAddress());
        if (country != null) {
            session.setSystemProperty("GeoLocation", (Object)country);
        }
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final ISFSObject reqObj = (ISFSObject)request.getContent();
        final String zoneName = reqObj.getUtfString("zn");
        String userName = reqObj.getUtfString("un");
        final String password = reqObj.getUtfString("pw");
        final ISFSObject params = (ISFSObject)request.getAttribute("$FS_REQUEST_LOGIN_DATA_OUT");
        request.getSender().setSystemProperty("FailedLoginCounts", (Object)new AtomicInteger());
        if (params != null) {
            final String newUserName = params.getUtfString("$FS_NEW_LOGIN_NAME");
            if (newUserName != null) {
                userName = newUserName;
            }
        }
        this.api.login(request.getSender(), userName, password, zoneName, params, true);
    }
}

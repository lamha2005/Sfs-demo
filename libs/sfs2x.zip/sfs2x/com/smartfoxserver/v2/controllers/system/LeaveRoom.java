// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class LeaveRoom extends BaseControllerCommand
{
    public static final String KEY_ROOM_ID = "r";
    
    public LeaveRoom() {
        super(SystemRequest.LeaveRoom);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final Zone zone = user.getZone();
        final ISFSObject reqObj = (ISFSObject)request.getContent();
        int roomId = -1;
        if (reqObj.containsKey("r")) {
            roomId = reqObj.getInt("r");
        }
        final Room theRoom = (roomId >= 0) ? zone.getRoomById(roomId) : null;
        this.api.leaveRoom(user, theRoom, true, true);
    }
}

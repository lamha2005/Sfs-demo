// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import java.util.List;
import com.smartfoxserver.v2.entities.variables.SFSRoomVariable;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import java.util.ArrayList;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class SetRoomVariables extends BaseControllerCommand
{
    public static final String KEY_VAR_LIST = "vl";
    public static final String KEY_VAR_ROOM = "r";
    
    public SetRoomVariables() {
        super(SystemRequest.SetRoomVariables);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("r")) {
            throw new SFSRequestValidationException("Missing target room id");
        }
        if (!sfso.containsKey("vl")) {
            throw new SFSRequestValidationException("Missing variables list");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final List<RoomVariable> roomVars = new ArrayList<RoomVariable>();
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final Zone zone = user.getZone();
        final Room targetRoom = zone.getRoomById(sfso.getInt("r"));
        if (targetRoom == null) {
            throw new SFSRequestValidationException("Can't set RoomVariables. Room does not exist. ID: " + sfso.getInt("r"));
        }
        if (!targetRoom.containsUser(user)) {
            throw new SFSRequestValidationException("Can't set RoomVariables. User " + user + " is not joined in " + targetRoom);
        }
        final ISFSArray varListData = sfso.getSFSArray("vl");
        for (int j = 0; j < varListData.size(); ++j) {
            final RoomVariable rv = SFSRoomVariable.newFromSFSArray(varListData.getSFSArray(j));
            rv.setOwner(user);
            final RoomVariable targetVar = targetRoom.getVariable(rv.getName());
            if (targetVar == null || !targetVar.isHidden()) {
                roomVars.add(rv);
            }
        }
        this.api.setRoomVariables(user, targetRoom, roomVars);
    }
}

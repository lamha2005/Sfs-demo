// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.game;

import java.util.Iterator;
import com.smartfoxserver.v2.entities.Zone;
import java.util.List;
import java.util.Collection;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;
import com.smartfoxserver.v2.game.GenericInvitationCallback;
import com.smartfoxserver.v2.entities.User;
import java.util.LinkedList;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class InviteUser extends BaseControllerCommand
{
    public static final String KEY_USER = "u";
    public static final String KEY_USER_ID = "ui";
    public static final String KEY_INVITATION_ID = "ii";
    public static final String KEY_TIME = "t";
    public static final String KEY_PARAMS = "p";
    public static final String KEY_INVITED_USERS = "iu";
    public static final String KEY_REPLY_ID = "ri";
    
    public InviteUser() {
        super(SystemRequest.InviteUser);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (sfso.isNull("iu")) {
            throw new SFSRequestValidationException("missing list of invited users");
        }
        if (sfso.isNull("t")) {
            throw new SFSRequestValidationException("missing SecondsForAnswer parameter");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final Collection<Integer> invitedUserIds = sfso.getIntArray("iu");
        if (invitedUserIds.size() < 1) {
            throw new IllegalArgumentException("Invited Users Array expected to contain at least 1 element!, Sender: " + user);
        }
        final List<User> invitedPeople = new LinkedList<User>();
        final Zone zone = user.getZone();
        for (final Integer userId : invitedUserIds) {
            final User invited = zone.getUserById(userId);
            if (invited != null) {
                invitedPeople.add(invited);
            }
        }
        this.sfs.getAPIManager().getGameApi().sendInvitation(user, invitedPeople, sfso.getShort("t"), new GenericInvitationCallback(), sfso.getSFSObject("p"));
    }
}

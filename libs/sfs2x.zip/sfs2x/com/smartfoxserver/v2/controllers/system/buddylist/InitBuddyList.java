// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.buddylist;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class InitBuddyList extends BaseControllerCommand
{
    public static final String KEY_BUDDY_LIST = "bl";
    public static final String KEY_BUDDY_STATES = "bs";
    public static final String KEY_MY_VARS = "mv";
    
    public InitBuddyList() {
        super(SystemRequest.InitBuddyList);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User sender = this.checkRequestPermissions(request);
        this.sfs.getAPIManager().getBuddyApi().initBuddyList(sender, true);
    }
}

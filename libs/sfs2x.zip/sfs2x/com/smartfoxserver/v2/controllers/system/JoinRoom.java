// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class JoinRoom extends BaseControllerCommand
{
    public static final String KEY_ROOM = "r";
    public static final String KEY_USER_LIST = "ul";
    public static final String KEY_ROOM_NAME = "n";
    public static final String KEY_ROOM_ID = "i";
    public static final String KEY_PASS = "p";
    public static final String KEY_ROOM_TO_LEAVE = "rl";
    public static final String KEY_AS_SPECTATOR = "sp";
    
    public JoinRoom() {
        super(SystemRequest.JoinRoom);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("n") && !sfso.containsKey("i")) {
            throw new SFSRequestValidationException("No Room id/name was specified");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final Zone zone = user.getZone();
        final ISFSObject sfso = (ISFSObject)request.getContent();
        Room roomToJoin = null;
        if (sfso.containsKey("i")) {
            roomToJoin = zone.getRoomById(sfso.getInt("i"));
            if (roomToJoin == null) {
                this.logger.warn("Client requested non-existent Room with ID: " + sfso.getInt("i"));
            }
        }
        else {
            roomToJoin = zone.getRoomByName(sfso.getUtfString("n"));
            if (roomToJoin == null) {
                this.logger.warn("Client requested non-existent Room with name: " + sfso.getUtfString("n"));
            }
        }
        final Room roomToLeave = sfso.containsKey("rl") ? zone.getRoomById(sfso.getInt("rl")) : user.getLastJoinedRoom();
        final String password = sfso.getUtfString("p");
        final boolean asSpectator = sfso.containsKey("sp") && sfso.getBool("sp");
        user.updateLastRequestTime();
        this.api.joinRoom(user, roomToJoin, password, asSpectator, roomToLeave);
    }
}

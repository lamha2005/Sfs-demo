// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.buddylist;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class RemoveBuddy extends BaseControllerCommand
{
    public static final String KEY_BUDDY_NAME = "bn";
    
    public RemoveBuddy() {
        super(SystemRequest.RemoveBuddy);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("bn")) {
            throw new SFSRequestValidationException("Missing buddy name");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User sender = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(sender, request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        this.sfs.getAPIManager().getBuddyApi().removeBuddy(sender, sfso.getUtfString("bn"), true, true);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.game;

import java.util.Iterator;
import com.smartfoxserver.v2.entities.Zone;
import java.util.ArrayList;
import java.util.Collection;
import com.smartfoxserver.v2.entities.Room;
import java.util.List;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.game.CreateSFSGameSettings;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.system.CreateRoom;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class CreateSFSGame extends BaseControllerCommand
{
    public static final String KEY_IS_PUBLIC = "gip";
    public static final String KEY_MIN_PLAYERS = "gmp";
    public static final String KEY_INVITED_PLAYERS = "ginp";
    public static final String KEY_SEARCHABLE_ROOMS = "gsr";
    public static final String KEY_PLAYER_MATCH_EXP = "gpme";
    public static final String KEY_SPECTATOR_MATCH_EXP = "gsme";
    public static final String KEY_INVITATION_EXPIRY = "gie";
    public static final String KEY_LEAVE_ROOM = "glr";
    public static final String KEY_NOTIFY_GAME_STARTED = "gns";
    public static final String KEY_INVITATION_PARAMS = "ip";
    private static final int MAX_CLIENT_INVITATIONS = 16;
    private static final int MIN_EXPIRY_TIME_SECONDS = 5;
    private static final int MAX_EXPIRY_TIME_SECONDS = 300;
    private CreateRoom createRoomRequest;
    
    public CreateSFSGame() {
        super(SystemRequest.CreateSFSGame);
        this.createRoomRequest = new CreateRoom();
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        this.createRoomRequest.validate(request);
        if (sfso.isNull("gip")) {
            throw new SFSRequestValidationException("isPublic flag is missing");
        }
        if (sfso.isNull("gmp")) {
            throw new SFSRequestValidationException("minPlayersToStartGame value is missing");
        }
        if (sfso.isNull("glr")) {
            throw new SFSRequestValidationException("leaveLastJoinedRoom flag is missing");
        }
        if (sfso.isNull("gns")) {
            throw new SFSRequestValidationException("notifyGameStarted flag is missing");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final CreateSFSGameSettings gameSettings = CreateSFSGameSettings.newFromRoomSettings((CreateRoomSettings)this.createRoomRequest.preProcess(request));
        final User user = this.api.getUserBySession(request.getSender());
        final ISFSObject sfso = (ISFSObject)request.getContent();
        gameSettings.setGamePublic(sfso.getBool("gip"));
        gameSettings.setMinPlayersToStartGame(sfso.getShort("gmp"));
        gameSettings.setLeaveLastJoinedRoom(sfso.getBool("glr"));
        gameSettings.setNotifyGameStartedViaRoomVariable(sfso.getBool("gns"));
        gameSettings.setInvitationExpiryTime(sfso.getShort("gie"));
        gameSettings.setInvitationParams(sfso.getSFSObject("ip"));
        if (sfso.containsKey("gpme")) {
            gameSettings.setPlayerMatchExpression(MatchExpression.fromSFSArray(sfso.getSFSArray("gpme")));
        }
        if (sfso.containsKey("gsme")) {
            gameSettings.setSpectatorMatchExpression(MatchExpression.fromSFSArray(sfso.getSFSArray("gsme")));
        }
        if (gameSettings.getInvitationExpiryTime() < 5 || gameSettings.getInvitationExpiryTime() > 300) {
            throw new IllegalArgumentException(String.format("CreateGame Error: %s. Invalid invitationExpiryTime: %s. Valid range is %s - %s seconds.", gameSettings.getName(), gameSettings.getInvitationExpiryTime(), 5, 300));
        }
        List<User> invitedPlayers = null;
        List<Room> searchableRooms = null;
        if (!gameSettings.isGamePublic()) {
            invitedPlayers = this.getListOfInvitedPlayers(user, sfso.getIntArray("ginp"));
            if (invitedPlayers.size() > 16) {
                throw new IllegalArgumentException(String.format("CreateGame Error: %s. Too many invited players: %s. Max allowed from client request: %s", gameSettings.getName(), invitedPlayers.size(), 16));
            }
            searchableRooms = this.getListOfSearchableRooms(user, sfso.getUtfStringArray("gsr"));
            gameSettings.setInvitedPlayers(invitedPlayers);
            gameSettings.setSearchableRooms(searchableRooms);
        }
        this.sfs.getAPIManager().getGameApi().createGame(user.getZone(), gameSettings, user);
    }
    
    private List<User> getListOfInvitedPlayers(final User inviter, final Collection<Integer> userIds) {
        final List<User> invitedPlayers = new ArrayList<User>();
        final List<User> refusedPlayers = new ArrayList<User>();
        final Zone zone = inviter.getZone();
        if (userIds != null) {
            for (final Integer ii : userIds) {
                final User usr = this.api.getUserById(ii);
                if (usr != null) {
                    if (usr.getZone() != zone) {
                        refusedPlayers.add(usr);
                    }
                    else {
                        if (invitedPlayers.size() > 16) {
                            refusedPlayers.add(usr);
                            break;
                        }
                        invitedPlayers.add(usr);
                    }
                }
            }
        }
        if (refusedPlayers.size() > 0) {
            this.logger.warn(String.format("Player invitations were refused: %s, invited players must be in the same Zone ( %s ) of the inviter ( %s ) and the number of invited player cannot exceed: %s", refusedPlayers.toString(), zone.getName(), inviter.getName(), 16));
        }
        return invitedPlayers;
    }
    
    private List<Room> getListOfSearchableRooms(final User inviter, final Collection<String> groupIds) {
        final List<Room> searchableRooms = new ArrayList<Room>();
        final Zone zone = inviter.getZone();
        if (groupIds == null) {
            return searchableRooms;
        }
        for (final String groupId : groupIds) {
            if (zone.containsPublicGroup(groupId)) {
                searchableRooms.addAll(zone.getRoomListFromGroup(groupId));
            }
        }
        return searchableRooms;
    }
}

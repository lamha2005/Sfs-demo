// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class PingPong extends BaseControllerCommand
{
    private static final String KEY_LAST_PING_TIME = "key_lastPingTime";
    private static final int MIN_PING_TIME = 900;
    
    public PingPong() {
        super(SystemRequest.PingPong);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        boolean isOk = true;
        final ISession sender = request.getSender();
        final Long lastPing = (Long)sender.getProperty("key_lastPingTime");
        final long now = System.currentTimeMillis();
        if (lastPing != null && now - lastPing < 900L) {
            isOk = false;
        }
        return isOk;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        request.getSender().setProperty("key_lastPingTime", (Object)System.currentTimeMillis());
        this.api.getResponseAPI().sendPingPongResponse(request.getSender());
    }
}

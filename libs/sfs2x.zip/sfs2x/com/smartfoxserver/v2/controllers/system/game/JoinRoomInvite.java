// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.game;

import java.util.Iterator;
import com.smartfoxserver.v2.buddylist.BuddyList;
import java.util.List;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import java.util.Collection;
import com.smartfoxserver.v2.entities.User;
import java.util.ArrayList;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class JoinRoomInvite extends BaseControllerCommand
{
    public static final String KEY_ROOM_ID = "r";
    public static final String KEY_EXPIRY_SECONDS = "es";
    public static final String KEY_INVITED_NAMES = "in";
    public static final String KEY_AS_SPECT = "as";
    public static final String KEY_OPTIONAL_PARAMS = "op";
    protected static final int DEFAULT_EXPIRY_SEC = 25;
    protected static final boolean DEFAULT_AS_SPECT = false;
    
    public JoinRoomInvite() {
        super(SystemRequest.JoinRoomInvite);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("r")) {
            throw new SFSRequestValidationException("missing target Room");
        }
        if (!sfso.containsKey("in")) {
            throw new SFSRequestValidationException("missing list of invited users/players");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final int roomId = sfso.getInt("r");
        final int expirySeconds = sfso.containsKey("es") ? sfso.getInt("es") : 25;
        final boolean asSpect = sfso.containsKey("as") && sfso.getBool("as");
        final Collection<String> invitedNames = sfso.getUtfStringArray("in");
        final ISFSObject optionalParams = sfso.getSFSObject("op");
        final Zone zone = user.getZone();
        final Room targetRoom = zone.getRoomById(roomId);
        if (targetRoom == null) {
            throw new SFSRuntimeException("Invalid targetRoom: " + roomId + " from: " + user.toString());
        }
        if (invitedNames.size() < 1) {
            throw new SFSRuntimeException("List of invited people is empty. From: " + user.toString());
        }
        if (invitedNames.size() > zone.getMaxInvitationsPerRequest()) {
            throw new SFSRuntimeException("Cannot invite more than " + zone.getMaxInvitationsPerRequest() + " user(s) at once in room: " + targetRoom.getName() + ", " + user.toString());
        }
        final boolean isBuddiesOnly = zone.isAllowInvitationsOnlyForBuddies();
        final List<User> invitedUsers = new ArrayList<User>();
        final BuddyList buddyList = zone.getBuddyListManager().getBuddyList(user.getName());
        for (final String uName : invitedNames) {
            final User invitedUser = zone.getUserByName(uName);
            if (invitedUser == null) {
                continue;
            }
            final boolean isInvited = !isBuddiesOnly || (buddyList != null && buddyList.containsBuddy(uName));
            if (!isInvited) {
                continue;
            }
            invitedUsers.add(invitedUser);
        }
        if (invitedUsers.size() < 1) {
            throw new SFSRuntimeException("JoinRoomInvite dropped, no available invitees. Requested by: " + user.getName());
        }
        this.sfs.getAPIManager().getGameApi().sendJoinRoomInvitation(targetRoom, user, invitedUsers, expirySeconds, asSpect, false, optionalParams);
    }
}

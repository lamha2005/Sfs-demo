// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.controllers.SystemRequest;
import org.slf4j.Logger;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class ChangeRoomCapacity extends BaseControllerCommand
{
    public static final String KEY_ROOM = "r";
    public static final String KEY_MAX_USERS = "u";
    public static final String KEY_MAX_SPECT = "s";
    private static final int MAX_USERS_LIMIT = 200;
    private static final int MAX_SPECT_LIMIT = 32;
    private final Logger logger;
    
    public ChangeRoomCapacity() {
        super(SystemRequest.ChangeRoomCapacity);
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("r")) {
            throw new SFSRequestValidationException("No Room was specified");
        }
        if (!sfso.containsKey("u")) {
            throw new SFSRequestValidationException("No new Room MaxUsers was specified.");
        }
        if (!sfso.containsKey("s")) {
            throw new SFSRequestValidationException("No new Room MaxSpect was specified.");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User user = this.checkRequestPermissions(request);
        final Zone zone = user.getZone();
        final Room targetRoom = zone.getRoomById(sfso.getInt("r"));
        if (targetRoom == null) {
            throw new SFSRoomException("Target Room does not exist. Id: " + sfso.getInt("r"));
        }
        int maxUsers = sfso.getInt("u");
        int maxSpect = sfso.getInt("s");
        if (!user.isSuperUser()) {
            if (maxUsers > 200) {
                this.logger.info(String.format("MaxUsers parameter exceeds the limit allowed for a client: %s / %s. Restrictions were applied.", maxUsers, 200));
                maxUsers = 200;
            }
            if (maxSpect > 32) {
                this.logger.info(String.format("MaxSpect parameter exceeds the limit allowed for a client: %s / %s. Restrictions were applied.", maxSpect, 32));
                maxSpect = 32;
            }
        }
        this.api.changeRoomCapacity(user, targetRoom, maxUsers, maxSpect);
    }
}

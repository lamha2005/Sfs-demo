// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.managers.BanMode;
import com.smartfoxserver.v2.exceptions.SFSAdminException;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class BanUser extends BaseControllerCommand
{
    public static final String KEY_USER_ID = "u";
    public static final String KEY_MESSAGE = "m";
    public static final String KEY_DELAY = "d";
    public static final String KEY_BAN_MODE = "b";
    public static final String KEY_BAN_DURATION_HOURS = "dh";
    
    public BanUser() {
        super(SystemRequest.BanUser);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("u")) {
            throw new SFSRequestValidationException("Missing user Id");
        }
        if (!sfso.containsKey("b")) {
            throw new SFSRequestValidationException("Missing BanMode parameter");
        }
        if (!sfso.containsKey("d")) {
            throw new SFSRequestValidationException("Missing delay parameter");
        }
        if (sfso.getInt("d") > 10) {
            throw new SFSRequestValidationException("Delay param out of range (0...10 seconds)");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User sender = this.checkSuperUser(request);
        this.applyZoneFilterChain(sender, request);
        final Zone zone = sender.getZone();
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final Integer id = sfso.getInt("u");
        final User userToBan = zone.getUserById(id);
        if (userToBan == null) {
            throw new SFSAdminException(String.format("BanRequest failed. No user exist with Id: %s, requested by ", id, sender));
        }
        final int banDuration = sfso.containsKey("dh") ? (sfso.getInt("dh") * 60) : 1440;
        this.api.banUser(userToBan, sender, sfso.getUtfString("m"), BanMode.fromId(sfso.getInt("b")), banDuration, sfso.getInt("d"));
    }
}

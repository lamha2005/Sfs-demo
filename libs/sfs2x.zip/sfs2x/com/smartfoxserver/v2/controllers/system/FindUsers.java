// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Room;
import java.util.Collection;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import java.util.ArrayList;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.util.UsersUtil;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class FindUsers extends BaseControllerCommand
{
    public static final String KEY_EXPRESSION = "e";
    public static final String KEY_GROUP = "g";
    public static final String KEY_ROOM = "r";
    public static final String KEY_LIMIT = "l";
    public static final String KEY_FILTERED_USERS = "fu";
    
    public FindUsers() {
        super(SystemRequest.FindUsers);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("e")) {
            throw new SFSRequestValidationException("No Expression was specified");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        final Zone zone = user.getZone();
        if (!UsersUtil.isAllowedToPerformNewSearch(user)) {
            throw new IllegalStateException("Denied: too little time since the last Find request, " + user);
        }
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final ISFSArray expressionData = sfso.getSFSArray("e");
        Collection<User> searchableUsers = null;
        String failureMessage = null;
        if (sfso.containsKey("r")) {
            final int roomId = sfso.getInt("r");
            final Room room = zone.getRoomById(roomId);
            if (room != null) {
                searchableUsers = room.getUserList();
            }
            else {
                failureMessage = "Room not found, id: " + roomId;
            }
        }
        else if (sfso.containsKey("g")) {
            final String groupId = sfso.getUtfString("g");
            if (zone.containsPublicGroup(groupId)) {
                searchableUsers = zone.getUsersInGroup(sfso.getUtfString("g"));
            }
            else {
                failureMessage = "Group does not exist or is not public: " + groupId;
            }
        }
        else {
            searchableUsers = zone.getUserList();
        }
        final MatchExpression expression = MatchExpression.fromSFSArray(expressionData);
        Collection<User> filteredUsers = null;
        final int limit = sfso.containsKey("l") ? ((short)sfso.getShort("l")) : 0;
        if (failureMessage != null) {
            this.logger.warn("FindUsers failed: " + failureMessage);
            filteredUsers = new ArrayList<User>();
        }
        else {
            filteredUsers = this.api.findUsers(searchableUsers, expression, limit);
        }
        this.api.getResponseAPI().notifyFilteredUserList(user.getSession(), filteredUsers);
    }
}

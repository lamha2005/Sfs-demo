// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.buddylist;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.User;
import java.util.List;
import com.smartfoxserver.v2.buddylist.SFSBuddyVariable;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.ArrayList;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class SetBuddyVariables extends BaseControllerCommand
{
    public static final String KEY_BUDDY_VARS = "bv";
    public static final String KEY_BUDDY_NAME = "bn";
    
    public SetBuddyVariables() {
        super(SystemRequest.SetBuddyVariables);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("bv")) {
            throw new SFSRequestValidationException("Missing variables list");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final List<BuddyVariable> buddyVars = new ArrayList<BuddyVariable>();
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final ISFSArray varListData = sfso.getSFSArray("bv");
        for (int j = 0; j < varListData.size(); ++j) {
            final BuddyVariable bVar = SFSBuddyVariable.newFromSFSArray(varListData.getSFSArray(j));
            if (bVar.getName().equals("$__BV_ONLINE__")) {
                this.logger.warn(String.format("Client can't set the reserver BV_ONLINE BuddyVariable. Update discarded. %s", user));
            }
            else {
                buddyVars.add(bVar);
            }
        }
        this.sfs.getAPIManager().getBuddyApi().setBuddyVariables(user, buddyVars, true, true);
    }
}

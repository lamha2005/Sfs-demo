// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system.game;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import com.smartfoxserver.v2.entities.Room;
import java.util.Collection;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSQuickJoinGameException;
import com.smartfoxserver.v2.entities.match.MatchExpression;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class QuickJoinGame extends BaseControllerCommand
{
    private static final int MAX_ROOMS = 32;
    public static final String KEY_ROOM_LIST = "rl";
    public static final String KEY_GROUP_LIST = "gl";
    public static final String KEY_ROOM_TO_LEAVE = "tl";
    public static final String KEY_MATCH_EXPRESSION = "me";
    
    public QuickJoinGame() {
        super(SystemRequest.QuickJoinGame);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (!sfso.containsKey("rl") && !sfso.containsKey("gl")) {
            throw new SFSRequestValidationException("No Room/Group specified where to search for Games");
        }
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final Zone zone = user.getZone();
        final ISFSObject sfso = (ISFSObject)request.getContent();
        MatchExpression matchExpression = null;
        final ISFSArray matchExprData = sfso.getSFSArray("me");
        if (matchExprData != null) {
            matchExpression = MatchExpression.fromSFSArray(matchExprData);
        }
        final Collection<Room> searchableRooms = this.autoDetectSearchableRooms(zone, sfso);
        Room roomToLeave = null;
        if (sfso.containsKey("tl")) {
            roomToLeave = zone.getRoomById(sfso.getInt("tl"));
        }
        try {
            this.sfs.getAPIManager().getGameApi().quickJoinGame(user, matchExpression, searchableRooms, roomToLeave);
        }
        catch (SFSQuickJoinGameException quickJoinError) {
            this.api.getResponseAPI().notifyRequestError(quickJoinError.getErrorData(), user, SystemRequest.QuickJoinGame);
        }
    }
    
    private Collection<Room> autoDetectSearchableRooms(final Zone zone, final ISFSObject sfso) {
        final List<Room> searchableRooms = new ArrayList<Room>();
        if (sfso.containsKey("gl")) {
            final Collection<String> groupIds = sfso.getUtfStringArray("gl");
            for (final String groupId : groupIds) {
                if (zone.containsPublicGroup(groupId)) {
                    searchableRooms.addAll(zone.getRoomListFromGroup(groupId));
                }
            }
        }
        else if (sfso.containsKey("rl")) {
            int count = 0;
            final Collection<Integer> roomIds = sfso.getIntArray("rl");
            for (final Integer id : roomIds) {
                final Room room = zone.getRoomById(id);
                if (room != null) {
                    searchableRooms.add(room);
                }
                if (count++ > 32) {
                    break;
                }
            }
        }
        return searchableRooms;
    }
}

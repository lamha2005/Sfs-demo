// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.data.SFSDataWrapper;
import com.smartfoxserver.v2.entities.data.SFSDataType;
import com.smartfoxserver.v2.entities.data.SFSObjectLite;
import com.smartfoxserver.v2.entities.variables.SFSRoomVariable;
import java.util.ArrayList;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.exceptions.SFSRoomException;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.mmo.Vec3D;
import com.smartfoxserver.v2.entities.SFSRoomRemoveMode;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.mmo.CreateMMORoomSettings;
import java.util.Set;
import java.util.Collections;
import java.util.EnumSet;
import com.smartfoxserver.v2.entities.SFSRoomSettings;
import java.util.List;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class CreateRoom extends BaseControllerCommand
{
    public static final String KEY_ROOM = "r";
    public static final String KEY_NAME = "n";
    public static final String KEY_GROUP_ID = "g";
    public static final String KEY_PASSWORD = "p";
    public static final String KEY_ISGAME = "ig";
    public static final String KEY_MAXUSERS = "mu";
    public static final String KEY_MAXSPECTATORS = "ms";
    public static final String KEY_MAXVARS = "mv";
    public static final String KEY_ROOMVARS = "rv";
    public static final String KEY_PERMISSIONS = "pm";
    public static final String KEY_EVENTS = "ev";
    public static final String KEY_EXTID = "xn";
    public static final String KEY_EXTCLASS = "xc";
    public static final String KEY_EXTPROP = "xp";
    public static final String KEY_AUTO_JOIN = "aj";
    public static final String KEY_ROOM_TO_LEAVE = "rl";
    public static final String KEY_ALLOW_JOIN_INVITATION_BY_OWNER = "aji";
    public static final String KEY_MMO_DEFAULT_AOI = "maoi";
    public static final String KEY_MMO_MAP_LOW_LIMIT = "mllm";
    public static final String KEY_MMO_MAP_HIGH_LIMIT = "mlhm";
    public static final String KEY_MMO_USER_MAX_LIMBO_SECONDS = "muls";
    public static final String KEY_MMO_PROXIMITY_UPDATE_MILLIS = "mpum";
    public static final String KEY_MMO_SEND_ENTRY_POINT = "msep";
    
    public CreateRoom() {
        super(SystemRequest.CreateRoom);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        final ISFSObject sfso = (ISFSObject)request.getContent();
        if (sfso.isNull("n")) {
            throw new SFSRequestValidationException("Room name is missing");
        }
        if (sfso.isNull("mu")) {
            throw new SFSRequestValidationException("MaxUsers param is missing");
        }
        if (sfso.isNull("aj")) {
            throw new SFSRequestValidationException("AutoJoin param is missing");
        }
        this.validateGroupId(request.getSender(), sfso.getUtfString("g"));
        return true;
    }
    
    @Override
    public Object preProcess(final IRequest request) throws Exception {
        final User user = this.checkRequestPermissions(request);
        this.applyZoneFilterChain(user, request);
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final boolean isMMO = sfso.containsKey("maoi");
        final String name = sfso.getUtfString("n");
        final String groupId = sfso.getUtfString("g");
        final String pass = sfso.getUtfString("p");
        final boolean isGame = !sfso.isNull("ig") && sfso.getBool("ig");
        final int maxUsers = sfso.getShort("mu");
        final int maxSpect = sfso.isNull("ms") ? 0 : ((short)sfso.getShort("ms"));
        int maxVars = sfso.isNull("mv") ? 0 : ((short)sfso.getShort("mv"));
        final boolean allowOwnerOnlyInvitation = !sfso.containsKey("aji") || sfso.getBool("aji");
        Set<SFSRoomSettings> roomFlags = null;
        final List<Boolean> permissions = (List<Boolean>)(List)sfso.getBoolArray("pm");
        final List<Boolean> events = (List<Boolean>)(List)sfso.getBoolArray("ev");
        if (permissions != null && permissions.size() == 4) {
            roomFlags = Collections.synchronizedSet(EnumSet.noneOf(SFSRoomSettings.class));
            if (permissions.get(0)) {
                roomFlags.add(SFSRoomSettings.ROOM_NAME_CHANGE);
            }
            if (permissions.get(1)) {
                roomFlags.add(SFSRoomSettings.PASSWORD_STATE_CHANGE);
            }
            if (permissions.get(2)) {
                roomFlags.add(SFSRoomSettings.PUBLIC_MESSAGES);
            }
            if (permissions.get(3)) {
                roomFlags.add(SFSRoomSettings.CAPACITY_CHANGE);
            }
        }
        else {
            roomFlags = Collections.synchronizedSet(EnumSet.of(SFSRoomSettings.PUBLIC_MESSAGES));
        }
        if (events != null && events.size() == 4) {
            if (events.get(0)) {
                roomFlags.add(SFSRoomSettings.USER_ENTER_EVENT);
            }
            if (events.get(1)) {
                roomFlags.add(SFSRoomSettings.USER_EXIT_EVENT);
            }
            if (events.get(2)) {
                roomFlags.add(SFSRoomSettings.USER_COUNT_CHANGE_EVENT);
            }
            if (events.get(3)) {
                roomFlags.add(SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT);
            }
        }
        else {
            roomFlags.add(SFSRoomSettings.USER_ENTER_EVENT);
            roomFlags.add(SFSRoomSettings.USER_EXIT_EVENT);
            roomFlags.add(SFSRoomSettings.USER_VARIABLES_UPDATE_EVENT);
            roomFlags.add(SFSRoomSettings.USER_COUNT_CHANGE_EVENT);
        }
        final CreateRoomSettings params = isMMO ? new CreateMMORoomSettings() : new CreateRoomSettings();
        params.setName(name);
        params.setGroupId(groupId);
        params.setPassword(pass);
        params.setGame(isGame);
        params.setMaxUsers(maxUsers);
        params.setMaxSpectators(maxSpect);
        params.setMaxVariablesAllowed(maxVars);
        params.setRoomSettings(roomFlags);
        params.setDynamic(true);
        params.setAutoRemoveMode(SFSRoomRemoveMode.DEFAULT);
        params.setAllowOwnerOnlyInvitation(allowOwnerOnlyInvitation);
        final ISFSArray varArray = sfso.getSFSArray("rv");
        if (varArray != null) {
            final List<RoomVariable> roomVariables = this.processRoomVariables(request.getSender(), varArray);
            if (maxVars > roomVariables.size()) {
                maxVars = roomVariables.size();
            }
            params.setRoomVariables(roomVariables);
        }
        if (!sfso.isNull("xn") && !sfso.isNull("xc")) {
            final CreateRoomSettings.RoomExtensionSettings extension = new CreateRoomSettings.RoomExtensionSettings(sfso.getUtfString("xn"), sfso.getUtfString("xc"));
            if (sfso.containsKey("xp")) {
                extension.setPropertiesFile(sfso.getUtfString("xp"));
            }
            params.setExtension(extension);
        }
        if (isMMO) {
            final boolean isFloat = this.isVec3DFloat(sfso);
            Vec3D defaultAOI;
            Vec3D mapLowerLimit;
            Vec3D mapHigherLimit;
            if (isFloat) {
                defaultAOI = Vec3D.fromFloatArray((List)sfso.getFloatArray("maoi"));
                mapLowerLimit = (sfso.containsKey("mllm") ? Vec3D.fromFloatArray((List)sfso.getFloatArray("mllm")) : null);
                mapHigherLimit = (sfso.containsKey("mlhm") ? Vec3D.fromFloatArray((List)sfso.getFloatArray("mlhm")) : null);
            }
            else {
                defaultAOI = Vec3D.fromIntArray((List)sfso.getIntArray("maoi"));
                mapLowerLimit = (sfso.containsKey("mllm") ? Vec3D.fromIntArray((List)sfso.getIntArray("mllm")) : null);
                mapHigherLimit = (sfso.containsKey("mlhm") ? Vec3D.fromIntArray((List)sfso.getIntArray("mlhm")) : null);
            }
            final int userMaxLimboSeconds = sfso.getShort("muls");
            final int proximityListUpdateMillis = sfso.getShort("mpum");
            final boolean sendAOIEntryPoint = sfso.getBool("msep");
            final CreateMMORoomSettings mmoParams = (CreateMMORoomSettings)params;
            mmoParams.setDefaultAOI(defaultAOI);
            if (mapLowerLimit != null && mapHigherLimit != null) {
                mmoParams.setMapLimits(new CreateMMORoomSettings.MapLimits(mapLowerLimit, mapHigherLimit));
            }
            mmoParams.setUserMaxLimboSeconds(userMaxLimboSeconds);
            mmoParams.setProximityListUpdateMillis(proximityListUpdateMillis);
            mmoParams.setSendAOIEntryPoint(sendAOIEntryPoint);
        }
        user.updateLastRequestTime();
        return params;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User user = this.api.getUserBySession(request.getSender());
        if (user.getCreatedRooms().size() >= user.getZone().getMaxRoomsCreatedPerUserLimit()) {
            throw new SFSRoomException("Can't create Room. User limit was reached: " + user.getCreatedRooms().size() + ", " + user);
        }
        final ISFSObject sfso = (ISFSObject)request.getContent();
        final CreateRoomSettings params = (CreateRoomSettings)this.preProcess(request);
        Room roomToLeave = null;
        if (sfso.containsKey("rl")) {
            roomToLeave = user.getZone().getRoomById(sfso.getInt("rl"));
        }
        final Room newRoom = this.api.createRoom(user.getZone(), params, user, sfso.getBool("aj"), roomToLeave);
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(newRoom.getDump());
        }
    }
    
    private void validateGroupId(final ISession session, final String groupId) throws SFSRequestValidationException {
        final User sender = this.sfs.getUserManager().getUserBySession(session);
        if (sender == null) {
            throw new SFSRequestValidationException("User not found! Session: " + session);
        }
        if (!sender.getZone().containsPublicGroup(groupId)) {
            throw new SFSRequestValidationException("Requested groupId is not available: " + groupId);
        }
    }
    
    private List<RoomVariable> processRoomVariables(final ISession session, final ISFSArray varArray) {
        final User sender = this.sfs.getUserManager().getUserBySession(session);
        if (sender == null) {
            throw new SFSRuntimeException("Room Creation failed. The requester session is not a User. Session: " + session);
        }
        final int maxRoomVars = sender.getZone().getMaxRoomVariablesAllowed();
        final List<RoomVariable> roomVars = new ArrayList<RoomVariable>();
        for (int loopEnd = (varArray.size() < maxRoomVars) ? varArray.size() : maxRoomVars, j = 0; j < loopEnd; ++j) {
            roomVars.add(SFSRoomVariable.newFromSFSArray(varArray.getSFSArray(j)));
        }
        return roomVars;
    }
    
    private boolean isVec3DFloat(final ISFSObject sfso) {
        if (sfso instanceof SFSObjectLite) {
            final ISFSArray data = sfso.getSFSArray("maoi");
            return data.get(0).getTypeId() == SFSDataType.DOUBLE || data.get(1).getTypeId() == SFSDataType.DOUBLE || data.get(2).getTypeId() == SFSDataType.DOUBLE;
        }
        final SFSDataWrapper wrap = sfso.get("maoi");
        return wrap.getTypeId() == SFSDataType.FLOAT_ARRAY;
    }
}

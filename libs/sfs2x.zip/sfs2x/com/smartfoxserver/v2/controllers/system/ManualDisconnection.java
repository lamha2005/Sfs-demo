// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers.system;

import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.controllers.BaseControllerCommand;

public class ManualDisconnection extends BaseControllerCommand
{
    public ManualDisconnection() {
        super(SystemRequest.ManualDisconnection);
    }
    
    @Override
    public boolean validate(final IRequest request) throws SFSRequestValidationException {
        return true;
    }
    
    @Override
    public void execute(final IRequest request) throws Exception {
        final User sender = this.api.getUserBySession(request.getSender());
        if (sender != null) {
            final Zone zone = sender.getZone();
            if (zone != null && zone.getUserReconnectionSeconds() > 0) {
                sender.setReconnectionSeconds(0);
            }
        }
    }
}

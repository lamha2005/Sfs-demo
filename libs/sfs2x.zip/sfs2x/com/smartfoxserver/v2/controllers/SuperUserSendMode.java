// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers;

public enum SuperUserSendMode
{
    TO_USER("TO_USER", 0, 0), 
    TO_ROOM("TO_ROOM", 1, 1), 
    TO_GROUP("TO_GROUP", 2, 2), 
    TO_ZONE("TO_ZONE", 3, 3);
    
    private int modeId;
    
    private SuperUserSendMode(final String s, final int n, final int id) {
        this.modeId = id;
    }
    
    public int getId() {
        return this.modeId;
    }
    
    public static SuperUserSendMode fromId(final int id) {
        SuperUserSendMode mode = null;
        SuperUserSendMode[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final SuperUserSendMode item = values[i];
            if (item.getId() == id) {
                mode = item;
                break;
            }
        }
        return mode;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers;

import com.smartfoxserver.v2.exceptions.SFSRequestValidationException;
import com.smartfoxserver.bitswarm.io.IRequest;

public interface IControllerCommand
{
    boolean validate(final IRequest p0) throws SFSRequestValidationException;
    
    Object preProcess(final IRequest p0) throws Exception;
    
    void execute(final IRequest p0) throws Exception;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.controllers;

public enum SystemRequest
{
    Handshake("Handshake", 0, (Object)(short)0), 
    Login("Login", 1, (Object)(short)1), 
    Logout("Logout", 2, (Object)(short)2), 
    GetRoomList("GetRoomList", 3, (Object)(short)3), 
    JoinRoom("JoinRoom", 4, (Object)(short)4), 
    AutoJoin("AutoJoin", 5, (Object)(short)5), 
    CreateRoom("CreateRoom", 6, (Object)(short)6), 
    GenericMessage("GenericMessage", 7, (Object)(short)7), 
    ChangeRoomName("ChangeRoomName", 8, (Object)(short)8), 
    ChangeRoomPassword("ChangeRoomPassword", 9, (Object)(short)9), 
    ObjectMessage("ObjectMessage", 10, (Object)(short)10), 
    SetRoomVariables("SetRoomVariables", 11, (Object)(short)11), 
    SetUserVariables("SetUserVariables", 12, (Object)(short)12), 
    CallExtension("CallExtension", 13, (Object)(short)13), 
    LeaveRoom("LeaveRoom", 14, (Object)(short)14), 
    SubscribeRoomGroup("SubscribeRoomGroup", 15, (Object)(short)15), 
    UnsubscribeRoomGroup("UnsubscribeRoomGroup", 16, (Object)(short)16), 
    SpectatorToPlayer("SpectatorToPlayer", 17, (Object)(short)17), 
    PlayerToSpectator("PlayerToSpectator", 18, (Object)(short)18), 
    ChangeRoomCapacity("ChangeRoomCapacity", 19, (Object)(short)19), 
    PublicMessage("PublicMessage", 20, (Object)(short)20), 
    PrivateMessage("PrivateMessage", 21, (Object)(short)21), 
    ModeratorMessage("ModeratorMessage", 22, (Object)(short)22), 
    AdminMessage("AdminMessage", 23, (Object)(short)23), 
    KickUser("KickUser", 24, (Object)(short)24), 
    BanUser("BanUser", 25, (Object)(short)25), 
    ManualDisconnection("ManualDisconnection", 26, (Object)(short)26), 
    FindRooms("FindRooms", 27, (Object)(short)27), 
    FindUsers("FindUsers", 28, (Object)(short)28), 
    PingPong("PingPong", 29, (Object)(short)29), 
    SetUserPosition("SetUserPosition", 30, (Object)(short)30), 
    InitBuddyList("InitBuddyList", 31, (Object)(short)200), 
    AddBuddy("AddBuddy", 32, (Object)(short)201), 
    BlockBuddy("BlockBuddy", 33, (Object)(short)202), 
    RemoveBuddy("RemoveBuddy", 34, (Object)(short)203), 
    SetBuddyVariables("SetBuddyVariables", 35, (Object)(short)204), 
    GoOnline("GoOnline", 36, (Object)(short)205), 
    BuddyMessage("BuddyMessage", 37, (Object)(short)206), 
    InviteUser("InviteUser", 38, (Object)(short)300), 
    InvitationReply("InvitationReply", 39, (Object)(short)301), 
    CreateSFSGame("CreateSFSGame", 40, (Object)(short)302), 
    QuickJoinGame("QuickJoinGame", 41, (Object)(short)303), 
    JoinRoomInvite("JoinRoomInvite", 42, (Object)(short)304), 
    GetLobbyNode("GetLobbyNode", 43, (Object)(short)400), 
    KeepAlive("KeepAlive", 44, (Object)(short)401), 
    QuickJoin("QuickJoin", 45, (Object)(short)402), 
    OnEnterRoom("OnEnterRoom", 46, (Object)(short)1000), 
    OnRoomCountChange("OnRoomCountChange", 47, (Object)(short)1001), 
    OnUserLost("OnUserLost", 48, (Object)(short)1002), 
    OnRoomLost("OnRoomLost", 49, (Object)(short)1003), 
    OnUserExitRoom("OnUserExitRoom", 50, (Object)(short)1004), 
    OnClientDisconnection("OnClientDisconnection", 51, (Object)(short)1005), 
    OnReconnectionFailure("OnReconnectionFailure", 52, (Object)(short)1006), 
    OnMMOItemVariablesUpdate("OnMMOItemVariablesUpdate", 53, (Object)(short)1007), 
    OnJoinAppNode("OnJoinAppNode", 54, (Object)(short)1400);
    
    private Object id;
    
    public static SystemRequest fromId(final Object id) {
        SystemRequest req = null;
        SystemRequest[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final SystemRequest item = values[i];
            if (item.getId().equals(id)) {
                req = item;
                break;
            }
        }
        return req;
    }
    
    private SystemRequest(final String s, final int n, final Object id) {
        this.id = id;
    }
    
    public Object getId() {
        return this.id;
    }
}

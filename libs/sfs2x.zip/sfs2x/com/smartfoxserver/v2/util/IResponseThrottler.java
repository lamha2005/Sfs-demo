// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

public interface IResponseThrottler
{
    void enqueueResponse(final Object p0);
    
    void setInterval(final int p0);
    
    int getInterval();
    
    String getName();
}

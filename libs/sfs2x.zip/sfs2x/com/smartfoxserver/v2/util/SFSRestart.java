// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.util.List;
import java.util.ArrayList;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class SFSRestart extends Thread
{
    private static final String LINUX_LAUNCHER = "./sfs2x.sh";
    private static final String OSX_LAUNCHER = "./sfs2x.sh";
    private static final String WIN_LAUNCHER = "sfs2x.bat";
    private final Logger log;
    private boolean isWindows;
    private boolean isOSX;
    private boolean isLinux;
    
    public SFSRestart() {
        this.isLinux = false;
        this.setName(":::SFSRestarter:::");
        this.log = LoggerFactory.getLogger((Class)SFSRestart.class);
        final String osName = System.getProperty("os.name");
        if (osName.toLowerCase().indexOf("linux") != -1) {
            this.isLinux = true;
        }
        else if (osName.toLowerCase().indexOf("mac os x") != -1) {
            this.isOSX = true;
        }
        else {
            if (osName.toLowerCase().indexOf("windows") == -1) {
                throw new IllegalStateException("Restart failure: operating system not supported: " + osName);
            }
            this.isWindows = true;
        }
    }
    
    @Override
    public void run() {
        try {
            String restartCmd = null;
            if (this.isWindows) {
                restartCmd = "sfs2x.bat";
            }
            else if (this.isLinux) {
                restartCmd = "./sfs2x.sh";
            }
            else if (this.isOSX) {
                restartCmd = "./sfs2x.sh";
            }
            final String[] cmds = restartCmd.split("\\,");
            final List<String> command = new ArrayList<String>();
            String[] array;
            for (int length = (array = cmds).length, i = 0; i < length; ++i) {
                final String cmd = array[i];
                command.add(cmd);
            }
            final ProcessBuilder builder = new ProcessBuilder(command);
            final Process proc = builder.start();
            this.log.info("Process restarted: " + proc);
            Thread.sleep(500L);
            System.exit(-2);
        }
        catch (Exception e) {
            this.log.error("Restart exception: " + e);
        }
    }
}

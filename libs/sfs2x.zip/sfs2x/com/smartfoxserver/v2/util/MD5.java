// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.security.NoSuchAlgorithmException;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.security.MessageDigest;

public final class MD5
{
    private static MD5 _instance;
    private MessageDigest messageDigest;
    private final Logger log;
    
    static {
        MD5._instance = new MD5();
    }
    
    private MD5() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        try {
            this.messageDigest = MessageDigest.getInstance("MD5");
        }
        catch (NoSuchAlgorithmException e) {
            this.log.error("Could not instantiate the MD5 Message Digest!");
        }
    }
    
    public static MD5 getInstance() {
        return MD5._instance;
    }
    
    public synchronized String getHash(final String s) {
        final byte[] data = s.getBytes();
        this.messageDigest.update(data);
        return this.toHexString(this.messageDigest.digest());
    }
    
    private String toHexString(final byte[] byteData) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; ++i) {
            String hex = Integer.toHexString(byteData[i] & 0xFF);
            if (hex.length() == 1) {
                hex = "0" + hex;
            }
            sb.append(hex);
        }
        return sb.toString();
    }
}

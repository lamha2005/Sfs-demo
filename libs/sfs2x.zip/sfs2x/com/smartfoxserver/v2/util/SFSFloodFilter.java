// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.util.HashMap;
import com.smartfoxserver.v2.exceptions.SFSFloodingException;
import com.smartfoxserver.v2.util.filters.RequestMonitor;
import com.smartfoxserver.v2.entities.User;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.entities.managers.BanMode;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;
import com.smartfoxserver.v2.controllers.SystemRequest;
import java.util.Map;
import com.smartfoxserver.v2.core.BaseCoreService;

public class SFSFloodFilter extends BaseCoreService implements IFloodFilter
{
    private final Map<SystemRequest, Integer> requestTable;
    private final IBannedUserManager banUserManager;
    private final Logger log;
    private volatile int banDurationMinutes;
    private volatile int maxFloodingAttempts;
    private volatile int secondsBeforeBan;
    private volatile boolean logFloodingAttempts;
    private BanMode banMode;
    private String banMessage;
    
    public SFSFloodFilter(final IBannedUserManager manager) {
        this.banDurationMinutes = 60;
        this.maxFloodingAttempts = 5;
        this.secondsBeforeBan = 5;
        this.logFloodingAttempts = false;
        this.banMode = BanMode.BY_NAME;
        this.banMessage = "You are being banned, too many flooding attempts.";
        super.setName(this.getClass().getName());
        this.log = LoggerFactory.getLogger(this.getClass().getName());
        this.banUserManager = manager;
        (this.requestTable = new ConcurrentHashMap<SystemRequest, Integer>()).put(SystemRequest.PublicMessage, 50);
    }
    
    @Override
    public void init(final Object o) {
        this.name = BaseCoreService.getId();
    }
    
    @Override
    public void filterRequest(final SystemRequest reqType, final User user) throws SFSFloodingException {
        if (!this.active) {
            return;
        }
        RequestMonitor monitor = (RequestMonitor)user.getSession().getSystemProperty("FloodFilterRequestTable");
        if (monitor == null) {
            monitor = new RequestMonitor();
            user.getSession().setSystemProperty("FloodFilterRequestTable", (Object)monitor);
        }
        final Integer maxReqsPerSecond = this.requestTable.get(reqType);
        if (maxReqsPerSecond == null) {
            return;
        }
        final int userReqsPerSecond = monitor.updateRequest(reqType);
        if (userReqsPerSecond >= maxReqsPerSecond) {
            final boolean isFirstOccurrence = maxReqsPerSecond - userReqsPerSecond == -1;
            if (isFirstOccurrence) {
                final int currentFloodWarns = user.getFloodWarnings() + 1;
                user.setFloodWarnings(currentFloodWarns);
                if (this.logFloodingAttempts) {
                    this.log.warn(String.format("Flooding: %s , Request: %s, User warns: %s", user, reqType, currentFloodWarns));
                }
                if (currentFloodWarns >= this.maxFloodingAttempts) {
                    this.banUserManager.banUser(user, UsersUtil.getServerModerator(), this.banDurationMinutes, this.banMode, "flooding", this.banMessage, this.secondsBeforeBan);
                }
            }
            throw new SFSFloodingException();
        }
    }
    
    @Override
    public void setActive(final boolean flag) {
        this.active = flag;
    }
    
    @Override
    public void addRequestFilter(final SystemRequest request, final int reqPerSecond) {
        this.requestTable.put(request, reqPerSecond);
    }
    
    @Override
    public Map<SystemRequest, Integer> getRequestTable() {
        return new HashMap<SystemRequest, Integer>(this.requestTable);
    }
    
    @Override
    public void clearAllFilters() {
        this.requestTable.clear();
    }
    
    @Override
    public boolean isRequestFiltered(final SystemRequest request) {
        return this.requestTable.containsKey(request);
    }
    
    @Override
    public int getBanDurationMinutes() {
        return this.banDurationMinutes;
    }
    
    @Override
    public void setBanDurationMinutes(final int banDurationMinutes) {
        this.banDurationMinutes = banDurationMinutes;
    }
    
    @Override
    public int getMaxFloodingAttempts() {
        return this.maxFloodingAttempts;
    }
    
    @Override
    public void setMaxFloodingAttempts(final int maxFloodingAttempts) {
        this.maxFloodingAttempts = maxFloodingAttempts;
    }
    
    @Override
    public int getSecondsBeforeBan() {
        return this.secondsBeforeBan;
    }
    
    @Override
    public void setSecondsBeforeBan(final int secondsBeforeBan) {
        this.secondsBeforeBan = secondsBeforeBan;
    }
    
    @Override
    public boolean isLogFloodingAttempts() {
        return this.logFloodingAttempts;
    }
    
    @Override
    public void setLogFloodingAttempts(final boolean logFloodingAttempts) {
        this.logFloodingAttempts = logFloodingAttempts;
    }
    
    @Override
    public BanMode getBanMode() {
        return this.banMode;
    }
    
    @Override
    public void setBanMode(final BanMode banMode) {
        this.banMode = banMode;
    }
    
    @Override
    public String getBanMessage() {
        return this.banMessage;
    }
    
    @Override
    public void setBanMessage(final String banMessage) {
        this.banMessage = banMessage;
    }
}

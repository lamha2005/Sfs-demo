// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

public class UploadedFile
{
    private String originalName;
    private String tempFilePath;
    
    public UploadedFile(final String originalName, final String tempFilePath) {
        this.originalName = originalName;
        this.tempFilePath = tempFilePath;
    }
    
    public String getOriginalName() {
        return this.originalName;
    }
    
    public String getTempFilePath() {
        return this.tempFilePath;
    }
}

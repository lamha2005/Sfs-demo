// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.util.Iterator;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.io.IResponse;
import java.util.Map;

public final class UserCountChangeResponseThrottler implements IResponseThrottler
{
    private static final int MIN_INTERVAL_MILLIS = 250;
    private Runnable taskHandler;
    private final Map<Integer, IResponse> responsesByRoomId;
    private volatile int interval;
    private final Logger log;
    private final String zoneName;
    private final SmartFoxServer sfs;
    
    public UserCountChangeResponseThrottler(final int delay, final String zoneName) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.responsesByRoomId = new ConcurrentHashMap<Integer, IResponse>();
        this.zoneName = zoneName;
        this.sfs = SmartFoxServer.getInstance();
        this.setInterval(delay);
    }
    
    @Override
    public String getName() {
        return this.zoneName;
    }
    
    @Override
    public int getInterval() {
        return this.interval;
    }
    
    @Override
    public void setInterval(final int delay) {
        this.interval = ((delay >= 250) ? delay : 0);
        if (this.taskHandler != null) {
            ((UCountTaskHandler)this.taskHandler).stop();
        }
        if (this.interval > 0) {
            this.taskHandler = new UCountTaskHandler();
            this.sfs.getTaskScheduler().scheduleAtFixedRate(this.taskHandler, 0, this.interval, TimeUnit.MILLISECONDS);
        }
    }
    
    @Override
    public void enqueueResponse(final Object o) {
        final IResponse response = (IResponse)o;
        if (this.interval == 0) {
            response.write();
        }
        else {
            final ISFSObject sfso = (ISFSObject)response.getContent();
            final Integer roomId = sfso.getInt("r");
            if (roomId == null) {
                throw new SFSRuntimeException("Unexpected malformed UCount response, missing room id:\n " + sfso.getDump());
            }
            this.responsesByRoomId.put(roomId, response);
        }
    }
    
    final class UCountTaskHandler implements Runnable
    {
        private volatile boolean stopMe;
        
        UCountTaskHandler() {
            this.stopMe = false;
        }
        
        @Override
        public void run() {
            if (this.stopMe) {
                throw new RuntimeException("Stopping");
            }
            try {
                final Iterator<IResponse> iter = UserCountChangeResponseThrottler.this.responsesByRoomId.values().iterator();
                while (iter.hasNext()) {
                    final IResponse response = iter.next();
                    if (UserCountChangeResponseThrottler.this.log.isDebugEnabled()) {
                        UserCountChangeResponseThrottler.this.log.debug("---> Throttler running: " + response);
                    }
                    response.write();
                    iter.remove();
                }
            }
            catch (Exception err) {
                UserCountChangeResponseThrottler.this.log.warn("Unexpected Error: " + err);
            }
        }
        
        public void stop() {
            this.stopMe = true;
        }
    }
}

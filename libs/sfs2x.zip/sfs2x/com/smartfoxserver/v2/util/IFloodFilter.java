// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import com.smartfoxserver.v2.entities.managers.BanMode;
import java.util.Map;
import com.smartfoxserver.v2.exceptions.SFSFloodingException;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.core.ICoreService;

public interface IFloodFilter extends ICoreService
{
    void setActive(final boolean p0);
    
    void filterRequest(final SystemRequest p0, final User p1) throws SFSFloodingException;
    
    void addRequestFilter(final SystemRequest p0, final int p1);
    
    boolean isRequestFiltered(final SystemRequest p0);
    
    void clearAllFilters();
    
    Map<SystemRequest, Integer> getRequestTable();
    
    int getBanDurationMinutes();
    
    void setBanDurationMinutes(final int p0);
    
    int getMaxFloodingAttempts();
    
    void setMaxFloodingAttempts(final int p0);
    
    int getSecondsBeforeBan();
    
    void setSecondsBeforeBan(final int p0);
    
    boolean isLogFloodingAttempts();
    
    void setLogFloodingAttempts(final boolean p0);
    
    BanMode getBanMode();
    
    void setBanMode(final BanMode p0);
    
    String getBanMessage();
    
    void setBanMessage(final String p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.security.GeneralSecurityException;
import java.security.spec.InvalidKeySpecException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import java.util.Arrays;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.util.Random;

public class PasswordUtil
{
    private static final Random RANDOM;
    private static final int KEY_LENGTH = 256;
    private static int ITERATIONS;
    
    static {
        RANDOM = new SecureRandom();
        PasswordUtil.ITERATIONS = 500;
    }
    
    public static byte[] getNextSalt() {
        final byte[] salt = new byte[16];
        PasswordUtil.RANDOM.nextBytes(salt);
        return salt;
    }
    
    public static byte[] hash(final char[] password, final byte[] salt) {
        final PBEKeySpec spec = new PBEKeySpec(password, salt, PasswordUtil.ITERATIONS, 256);
        Arrays.fill(password, '\0');
        try {
            final SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            return skf.generateSecret(spec).getEncoded();
        }
        catch (NoSuchAlgorithmException ex) {}
        catch (InvalidKeySpecException e) {
            throw new AssertionError("Error while hashing a password: " + e.getMessage(), e);
        }
        finally {
            spec.clearPassword();
        }
    }
    
    public static boolean isExpectedPassword(final char[] password, final byte[] salt, final byte[] expectedHash) {
        final byte[] pwdHash = hash(password, salt);
        Arrays.fill(password, '\0');
        if (pwdHash.length != expectedHash.length) {
            return false;
        }
        for (int i = 0; i < pwdHash.length; ++i) {
            if (pwdHash[i] != expectedHash[i]) {
                return false;
            }
        }
        return true;
    }
    
    public static String generateRandomPassword(final int length) {
        final StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; ++i) {
            final int c = PasswordUtil.RANDOM.nextInt(62);
            if (c <= 9) {
                sb.append(String.valueOf(c));
            }
            else if (c < 36) {
                sb.append((char)(97 + c - 10));
            }
            else {
                sb.append((char)(65 + c - 36));
            }
        }
        return sb.toString();
    }
    
    public static void setPBKDF2Iterations(final int iter) {
        PasswordUtil.ITERATIONS = iter;
    }
}

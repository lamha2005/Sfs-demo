// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.util.regex.Matcher;
import java.util.Iterator;
import java.util.List;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.config.GlobalSettings;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.util.filters.FilteredMessage;
import com.smartfoxserver.v2.util.filters.SFSWordFilterLogic;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.util.filters.IWordFilterLogic;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;
import com.smartfoxserver.v2.util.filters.WordsFilterMode;
import com.smartfoxserver.v2.entities.managers.BanMode;
import java.util.regex.Pattern;
import java.util.concurrent.ConcurrentMap;
import org.slf4j.Logger;
import com.smartfoxserver.v2.core.BaseCoreService;

public class SFSWordFilter extends BaseCoreService implements IWordFilter
{
    private static final String PUNCTUATION = ",.;:-_ ";
    private final Logger logger;
    private final ConcurrentMap<String, Pattern> dictionary;
    private volatile int banDurationMinutes;
    private volatile int kicksBeforeBan;
    private volatile int kicksBeforeBanMinutes;
    private volatile int warningsBeforeKick;
    private volatile int maxBadWordsPerMessage;
    private volatile int secondsBeforeBanOrKick;
    private volatile boolean useWarnings;
    private BanMode banMode;
    private String wordsFile;
    private String warningMessage;
    private String kickMessage;
    private String banMessage;
    private String maskCharacter;
    private WordsFilterMode filterMode;
    IBannedUserManager bannedUserManger;
    IWordFilterLogic filterLogic;
    IWordFilterLoader wordFilterLoader;
    
    public SFSWordFilter(final IBannedUserManager manager) {
        this.banDurationMinutes = 60;
        this.kicksBeforeBan = 3;
        this.kicksBeforeBanMinutes = 60;
        this.warningsBeforeKick = 3;
        this.maxBadWordsPerMessage = -1;
        this.secondsBeforeBanOrKick = 6;
        this.useWarnings = false;
        this.banMode = BanMode.BY_NAME;
        this.warningMessage = "Please be polite and avoid swear words. If this continues you will be kicked and ultimately banned.";
        this.kickMessage = "You are being kicked, too many swear words.";
        this.banMessage = "You are being banned, too many swear words.";
        this.maskCharacter = "*";
        this.filterMode = WordsFilterMode.BLACK_LIST;
        this.setName("SFSWordsFilter");
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.dictionary = new ConcurrentHashMap<String, Pattern>();
        this.bannedUserManger = manager;
        this.wordFilterLoader = SmartFoxServer.getInstance().getServiceProvider().getWordFilterLoader();
        this.filterLogic = new SFSWordFilterLogic(this.bannedUserManger, this);
    }
    
    public SFSWordFilter(final IBannedUserManager manager, final String wordsFile) {
        this(manager);
        this.wordsFile = wordsFile;
    }
    
    @Override
    public void init(final Object o) {
        this.name = BaseCoreService.getId();
        this.loadExpressionList(true);
    }
    
    @Override
    public void setActive(final boolean flag) {
        this.active = flag;
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
    }
    
    @Override
    public FilteredMessage apply(final String message) {
        FilteredMessage filtered;
        if (this.filterMode == WordsFilterMode.BLACK_LIST) {
            filtered = this.applyBlackListFilter(message);
        }
        else {
            filtered = this.applyWhiteListFilter(message);
        }
        return filtered;
    }
    
    @Override
    public FilteredMessage apply(final String message, final User user) {
        final FilteredMessage filtered = this.apply(message);
        if (this.filterMode == WordsFilterMode.BLACK_LIST && filtered.getOccurrences() > 0) {
            if (this.maxBadWordsPerMessage > 0 && filtered.getOccurrences() > this.maxBadWordsPerMessage) {
                this.filterLogic.kickUser(user);
            }
            else {
                this.filterLogic.warnUser(user);
            }
        }
        return filtered;
    }
    
    @Override
    public void addExpression(final String word) {
        this.dictionary.putIfAbsent(word, Pattern.compile(word));
    }
    
    @Override
    public void clearExpressions() {
        this.dictionary.clear();
    }
    
    @Override
    public int getBanDurationMinutes() {
        return this.banDurationMinutes;
    }
    
    @Override
    public BanMode getBanMode() {
        return this.banMode;
    }
    
    @Override
    public WordsFilterMode getFilterMode() {
        return this.filterMode;
    }
    
    @Override
    public int getWarningsBeforeKick() {
        return this.warningsBeforeKick;
    }
    
    @Override
    public String getWordsFile() {
        return this.wordsFile;
    }
    
    @Override
    public void setWordsFile(final String wordsFile) {
        this.wordsFile = wordsFile;
    }
    
    @Override
    public Set<String> getExpressionsList() {
        return new HashSet<String>((Collection<? extends String>)this.dictionary.keySet());
    }
    
    @Override
    public int getKicksBeforeBan() {
        return this.kicksBeforeBan;
    }
    
    @Override
    public void removeExpression(final String word) {
        this.dictionary.remove(word);
    }
    
    @Override
    public void setBanDurationMinutes(final int minutes) {
        this.banDurationMinutes = minutes;
    }
    
    @Override
    public void setBanMode(final BanMode banMode) {
        this.banMode = banMode;
    }
    
    @Override
    public void setFilterMode(final WordsFilterMode filterMode) {
        this.filterMode = filterMode;
    }
    
    @Override
    public void setKicksBeforeBan(final int kicks) {
        this.kicksBeforeBan = kicks;
    }
    
    @Override
    public void setWarningsBeforeKick(final int warnings) {
        this.warningsBeforeKick = warnings;
    }
    
    @Override
    public IBannedUserManager getBannedUserManager() {
        return this.bannedUserManger;
    }
    
    @Override
    public void setBannedUserManager(final IBannedUserManager manager) {
        this.bannedUserManger = manager;
    }
    
    @Override
    public String getMaskCharacter() {
        return this.maskCharacter;
    }
    
    @Override
    public void setMaskCharacter(final String mask) {
        this.maskCharacter = mask;
    }
    
    @Override
    public int getMaxBadWordsPerMessage() {
        return this.maxBadWordsPerMessage;
    }
    
    @Override
    public void setMaxBadWordsPerMessage(final int max) {
        this.maxBadWordsPerMessage = max;
    }
    
    @Override
    public int getKicksBeforeBanMinutes() {
        return this.kicksBeforeBanMinutes;
    }
    
    @Override
    public void setKicksBeforeBanMinutes(final int kicksBeforeBanMinutes) {
        this.kicksBeforeBanMinutes = kicksBeforeBanMinutes;
    }
    
    @Override
    public String getKickMessage() {
        return this.kickMessage;
    }
    
    @Override
    public void setKickMessage(final String kickMessage) {
        this.kickMessage = kickMessage;
    }
    
    @Override
    public String getBanMessage() {
        return this.banMessage;
    }
    
    @Override
    public void setBanMessage(final String banMessage) {
        this.banMessage = banMessage;
    }
    
    @Override
    public IBannedUserManager getBannedUserManger() {
        return this.bannedUserManger;
    }
    
    @Override
    public void setBannedUserManger(final IBannedUserManager bannedUserManger) {
        this.bannedUserManger = bannedUserManger;
    }
    
    @Override
    public int getSecondsBeforeBanOrKick() {
        return this.secondsBeforeBanOrKick;
    }
    
    @Override
    public void setSecondsBeforeBanOrKick(final int secondsBeforeBanOrKick) {
        this.secondsBeforeBanOrKick = secondsBeforeBanOrKick;
    }
    
    @Override
    public String getWarningMessage() {
        return this.warningMessage;
    }
    
    @Override
    public void setWarningMessage(final String message) {
        this.warningMessage = message;
    }
    
    @Override
    public boolean isUseWarnings() {
        return this.useWarnings;
    }
    
    @Override
    public void setUseWarnings(final boolean value) {
        this.useWarnings = value;
    }
    
    @Override
    public void loadExpressionList() {
        this.loadExpressionList(false);
    }
    
    private void loadExpressionList(final boolean isInit) {
        this.clearExpressions();
        try {
            final List<String> data = this.wordFilterLoader.load(this.wordsFile, isInit);
            for (final String expression : data) {
                this.addExpression(expression);
            }
        }
        catch (IOException e) {
            final ExceptionMessageComposer message = new ExceptionMessageComposer(e, GlobalSettings.FRIENDLY_LOGGING);
            message.setDescription("the specified words file was not found: " + this.wordsFile);
            message.setPossibleCauses("please double check that the file is really in the location specified in the configuration");
            this.logger.warn(message.toString());
        }
    }
    
    private FilteredMessage applyBlackListFilter(final String message) {
        final FilteredMessage filteredMessage = new FilteredMessage();
        final StringBuilder buffer = new StringBuilder(message);
        int occurrences = 0;
        for (final Pattern expression : this.dictionary.values()) {
            final Matcher patternMatcher = expression.matcher(buffer);
            while (patternMatcher.find()) {
                this.maskBadWord(buffer, patternMatcher.start(), patternMatcher.end());
                ++occurrences;
            }
        }
        filteredMessage.setMessage(buffer.toString());
        filteredMessage.setOccurrences(occurrences);
        return filteredMessage;
    }
    
    private void maskBadWord(final StringBuilder str, final int startPos, final int endPos) {
        str.replace(startPos, endPos, this.getStringMask(endPos - startPos));
    }
    
    private FilteredMessage applyWhiteListFilter(final String message) {
        final FilteredMessage filteredMessage = new FilteredMessage();
        final FilteredMessage blackListed = this.applyBlackListFilter(message);
        final StringBuilder negativeVersion = new StringBuilder();
        boolean prevCharWasBad = false;
        int occurences = 0;
        int pos = 0;
        char[] charArray;
        for (int length = (charArray = blackListed.getMessage().toCharArray()).length, i = 0; i < length; ++i) {
            final char ch = charArray[i];
            if (ch == this.maskCharacter.charAt(0)) {
                negativeVersion.append(message.charAt(pos));
                prevCharWasBad = false;
            }
            else if (",.;:-_ ".indexOf(ch) > -1) {
                negativeVersion.append(ch);
                prevCharWasBad = false;
            }
            else {
                negativeVersion.append(this.maskCharacter);
                if (!prevCharWasBad) {
                    ++occurences;
                    prevCharWasBad = true;
                }
            }
            ++pos;
        }
        filteredMessage.setMessage(negativeVersion.toString());
        filteredMessage.setOccurrences(occurences);
        return filteredMessage;
    }
    
    private String getStringMask(final int len) {
        final StringBuilder buf = new StringBuilder();
        for (int j = 0; j < len; ++j) {
            buf.append(this.maskCharacter);
        }
        return buf.toString();
    }
}

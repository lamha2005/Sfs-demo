// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.util.filters.FilteredMessage;
import com.smartfoxserver.v2.util.filters.WordsFilterMode;
import com.smartfoxserver.v2.entities.managers.BanMode;
import java.util.Set;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;
import com.smartfoxserver.v2.core.ICoreService;

public interface IWordFilter extends ICoreService
{
    IBannedUserManager getBannedUserManager();
    
    void setBannedUserManager(final IBannedUserManager p0);
    
    Set<String> getExpressionsList();
    
    void addExpression(final String p0);
    
    void removeExpression(final String p0);
    
    void clearExpressions();
    
    void loadExpressionList();
    
    String getMaskCharacter();
    
    void setMaskCharacter(final String p0);
    
    int getWarningsBeforeKick();
    
    void setWarningsBeforeKick(final int p0);
    
    String getWarningMessage();
    
    void setWarningMessage(final String p0);
    
    int getKicksBeforeBan();
    
    void setKicksBeforeBan(final int p0);
    
    int getKicksBeforeBanMinutes();
    
    void setKicksBeforeBanMinutes(final int p0);
    
    int getBanDurationMinutes();
    
    void setBanDurationMinutes(final int p0);
    
    BanMode getBanMode();
    
    void setBanMode(final BanMode p0);
    
    int getMaxBadWordsPerMessage();
    
    void setMaxBadWordsPerMessage(final int p0);
    
    String getWordsFile();
    
    void setWordsFile(final String p0);
    
    WordsFilterMode getFilterMode();
    
    void setFilterMode(final WordsFilterMode p0);
    
    String getKickMessage();
    
    void setKickMessage(final String p0);
    
    String getBanMessage();
    
    void setBanMessage(final String p0);
    
    int getSecondsBeforeBanOrKick();
    
    void setSecondsBeforeBanOrKick(final int p0);
    
    IBannedUserManager getBannedUserManger();
    
    void setBannedUserManger(final IBannedUserManager p0);
    
    boolean isUseWarnings();
    
    void setUseWarnings(final boolean p0);
    
    FilteredMessage apply(final String p0);
    
    FilteredMessage apply(final String p0, final User p1);
    
    void setActive(final boolean p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.text.Format;
import java.text.DecimalFormat;

public class ServerUptime
{
    private static final int ONE_DAY = 86400000;
    private static final int ONE_HOUR = 3600000;
    private static final int ONE_MINUTE = 60000;
    private static final int ONE_SECOND = 1000;
    private int days;
    private int hours;
    private int minutes;
    private int seconds;
    
    public ServerUptime(long unixTime) {
        this.days = (int)Math.floor(unixTime / 86400000L);
        unixTime -= 86400000L * this.days;
        this.hours = (int)Math.floor(unixTime / 3600000L);
        unixTime -= 3600000 * this.hours;
        this.minutes = (int)Math.floor(unixTime / 60000L);
        unixTime -= 60000 * this.minutes;
        this.seconds = (int)Math.floor(unixTime / 1000L);
    }
    
    public int getDays() {
        return this.days;
    }
    
    public int getHours() {
        return this.hours;
    }
    
    public int getMinutes() {
        return this.minutes;
    }
    
    public int getSeconds() {
        return this.seconds;
    }
    
    @Override
    public String toString() {
        final Format fmt = new DecimalFormat("##00");
        return String.format("%s days, %s:%s:%s", this.days, fmt.format(this.hours), fmt.format(this.minutes), fmt.format(this.seconds));
    }
}

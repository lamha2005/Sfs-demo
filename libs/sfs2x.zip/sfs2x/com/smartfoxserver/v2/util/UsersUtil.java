// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.entities.SFSUser;
import com.smartfoxserver.bitswarm.sessions.SessionType;
import com.smartfoxserver.bitswarm.sessions.Session;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;

public class UsersUtil
{
    private static User fakeAdminUser;
    private static User fakeModUser;
    private static volatile boolean isInited;
    
    static {
        UsersUtil.isInited = false;
    }
    
    public static boolean usersSeeEachOthers(final User sender, final User recipient) {
        boolean seeEachOthers = false;
        for (final Room room : recipient.getJoinedRooms()) {
            if (room.containsUser(sender)) {
                seeEachOthers = true;
                break;
            }
        }
        return seeEachOthers;
    }
    
    public static User getServerAdmin() {
        if (!UsersUtil.isInited) {
            initialize();
        }
        return UsersUtil.fakeAdminUser;
    }
    
    public static User getServerModerator() {
        if (!UsersUtil.isInited) {
            initialize();
        }
        return UsersUtil.fakeModUser;
    }
    
    public static boolean isAllowedToPerformNewSearch(final User user) {
        boolean ok = false;
        final Long lastSearchTime = (Long)user.getSession().getSystemProperty("LastSearchTime");
        if (lastSearchTime == null) {
            ok = true;
        }
        else if (System.currentTimeMillis() - lastSearchTime > 1000L) {
            ok = true;
        }
        if (ok) {
            user.getSession().setSystemProperty("LastSearchTime", (Object)System.currentTimeMillis());
        }
        return ok;
    }
    
    private static synchronized void initialize() {
        final ISession modSession = (ISession)new Session();
        modSession.setType(SessionType.VOID);
        UsersUtil.fakeModUser = new SFSUser("{Server.Mod}", modSession);
        final ISession dmnSession = (ISession)new Session();
        dmnSession.setType(SessionType.VOID);
        UsersUtil.fakeAdminUser = new SFSUser("{Server.Admin}", dmnSession);
        UsersUtil.isInited = true;
    }
}

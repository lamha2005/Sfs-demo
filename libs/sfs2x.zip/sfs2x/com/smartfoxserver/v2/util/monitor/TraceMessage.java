// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.monitor;

import com.smartfoxserver.v2.extensions.ExtensionLogLevel;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;

public class TraceMessage
{
    private Zone zone;
    private Room room;
    private ExtensionLogLevel level;
    private String message;
    private long timestamp;
    
    public TraceMessage(final Zone zone, final Room room, final ExtensionLogLevel level, final String message) {
        this.zone = zone;
        this.room = room;
        this.level = level;
        this.message = message;
        this.timestamp = System.currentTimeMillis();
    }
    
    public Zone getZone() {
        return this.zone;
    }
    
    public Room getRoom() {
        return this.room;
    }
    
    public ExtensionLogLevel getLevel() {
        return this.level;
    }
    
    public String getMessage() {
        return this.message;
    }
    
    public long getTimestamp() {
        return this.timestamp;
    }
    
    @Override
    public String toString() {
        return String.format("[ %s | Z: %s | R: %s | %s | %s ]", this.timestamp, this.zone, this.room, this.level, this.message);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.monitor;

import com.smartfoxserver.bitswarm.service.IService;

public interface ITraceMonitor extends IService
{
    void handleTraceMessage(final TraceMessage p0);
}

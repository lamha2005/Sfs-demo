// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.monitor;

import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.smartfoxserver.v2.entities.User;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import com.smartfoxserver.v2.api.ISFSApi;
import com.smartfoxserver.v2.SmartFoxServer;

public class GhostUserHunter implements IGhostUserHunter
{
    private static final String EOL;
    private final SmartFoxServer sfs;
    private final ISFSApi api;
    private ISessionManager sm;
    private final Logger log;
    private static final int TRIGGER_INTERVAL_SEC = 900;
    private static final int TOT_CYCLES = 90;
    private int cycleCounter;
    
    static {
        EOL = System.getProperty("line.separator");
    }
    
    public GhostUserHunter() {
        this.cycleCounter = 0;
        this.sfs = SmartFoxServer.getInstance();
        this.api = this.sfs.getAPIManager().getSFSApi();
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void hunt() {
        if (this.sm == null) {
            this.sm = this.sfs.getSessionManager();
        }
        if (++this.cycleCounter < 90) {
            return;
        }
        this.cycleCounter = 0;
        final List<User> ghosts = this.searchGhosts();
        if (ghosts.size() > 0) {
            this.log.info(this.buildReport(ghosts));
        }
        for (final User ghost : ghosts) {
            this.api.disconnectUser(ghost);
        }
    }
    
    private List<User> searchGhosts() {
        final List<User> allUsers = this.sfs.getUserManager().getAllUsers();
        final List<User> ghosts = new ArrayList<User>();
        for (final User u : allUsers) {
            if (u.isNpc()) {
                continue;
            }
            final ISession sess = u.getSession();
            if (this.sm.containsSession(sess) && !sess.isIdle() && !sess.isMarkedForEviction()) {
                continue;
            }
            ghosts.add(u);
        }
        return ghosts;
    }
    
    private String buildReport(final List<User> ghosts) {
        final StringBuilder sb = new StringBuilder("GHOST REPORT");
        sb.append(GhostUserHunter.EOL).append("Total ghosts: ").append(ghosts.size()).append(GhostUserHunter.EOL);
        for (final User ghost : ghosts) {
            final ISession ss = ghost.getSession();
            if (ss == null) {
                sb.append(ghost.getId()).append(", ").append(ghost.getName()).append(" -> Null session").append(", SessionById: ").append(this.sm.getSessionById(ghost.getId()));
            }
            else {
                sb.append(ghost.getId()).append(", ").append(ghost.getName()).append(", Connected: ").append(ss.isConnected()).append(", Idle: ").append(ss.isIdle()).append(", Marked: ").append(ss.isMarkedForEviction()).append(", Frozen: ").append(ss.isFrozen()).append(", SessionById: ").append(this.sm.getSessionById(ghost.getId()));
            }
        }
        return sb.toString();
    }
}

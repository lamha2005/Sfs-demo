// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.monitor;

public class TraceMessageMonitor implements ITraceMonitor
{
    private final TraceMessageThrottler throttler;
    private final int throttlingSpeed = 1000;
    
    public TraceMessageMonitor() {
        this.throttler = new TraceMessageThrottler(1000);
    }
    
    @Override
    public void handleTraceMessage(final TraceMessage tmsg) {
        this.throttler.enqueueResponse(tmsg);
    }
    
    public void destroy(final Object o) {
    }
    
    public String getName() {
        return "ExtensionTraceMonitorService";
    }
    
    public void handleMessage(final Object message) {
    }
    
    public void init(final Object o) {
    }
    
    public void setName(final String name) {
    }
}

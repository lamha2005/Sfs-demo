// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.monitor;

import java.util.Map;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEvent;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.core.SFSEventSysParam;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEventParam;
import java.util.HashMap;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import org.slf4j.LoggerFactory;
import java.util.List;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.v2.util.IResponseThrottler;

final class TraceMessageThrottler implements IResponseThrottler
{
    private final int MIN_THROTTLING_SPEED = 250;
    private final Logger log;
    private final SmartFoxServer sfs;
    private int interval;
    private List<TraceMessage> messages;
    private Runnable taskRunner;
    
    public TraceMessageThrottler(final int interval) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = SmartFoxServer.getInstance();
        this.messages = new ArrayList<TraceMessage>();
        this.setInterval(interval);
    }
    
    @Override
    public void enqueueResponse(final Object o) {
        final TraceMessage tms = (TraceMessage)o;
        synchronized (this.messages) {
            this.messages.add(tms);
        }
        // monitorexit(this.messages)
    }
    
    @Override
    public int getInterval() {
        return this.interval;
    }
    
    @Override
    public String getName() {
        return "TraceMessageThrottler";
    }
    
    @Override
    public void setInterval(final int interval) {
        if (interval < 250) {
            this.interval = 250;
        }
        this.interval = interval;
        if (this.taskRunner != null) {
            ((TraceEventTaskRunner)this.taskRunner).stop();
        }
        this.taskRunner = new TraceEventTaskRunner();
        this.sfs.getTaskScheduler().scheduleAtFixedRate(this.taskRunner, 0, this.interval, TimeUnit.MILLISECONDS);
    }
    
    final class TraceEventTaskRunner implements Runnable
    {
        private volatile boolean stopMe;
        
        TraceEventTaskRunner() {
            this.stopMe = false;
        }
        
        @Override
        public void run() {
            if (this.stopMe) {
                throw new RuntimeException("Stopping Task");
            }
            if (TraceMessageThrottler.this.messages.size() == 0) {
                return;
            }
            try {
                final List<TraceMessage> eventData;
                synchronized (TraceMessageThrottler.this.messages) {
                    eventData = new ArrayList<TraceMessage>(TraceMessageThrottler.this.messages);
                    TraceMessageThrottler.this.messages.clear();
                }
                // monitorexit(TraceMessageThrottler.access$0(this.this$0))
                final Zone targetZone = TraceMessageThrottler.this.sfs.getZoneManager().getZoneByName("--=={{{ AdminZone }}}==--");
                if (targetZone != null) {
                    final Map<ISFSEventParam, Object> params = new HashMap<ISFSEventParam, Object>();
                    params.put(SFSEventParam.ZONE, targetZone);
                    params.put(SFSEventSysParam.TRACE_MESSAGE_LIST, eventData);
                    TraceMessageThrottler.this.sfs.getEventManager().dispatchEvent(new SFSEvent(SFSEventType.__TRACE_MESSAGE, params));
                }
            }
            catch (Exception err) {
                TraceMessageThrottler.this.log.warn("Unexpected Error: " + err);
            }
        }
        
        public void stop() {
            this.stopMe = true;
        }
    }
}

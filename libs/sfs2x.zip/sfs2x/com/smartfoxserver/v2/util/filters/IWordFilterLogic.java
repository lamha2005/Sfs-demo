// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.filters;

import com.smartfoxserver.v2.util.IWordFilter;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;
import com.smartfoxserver.v2.entities.User;

public interface IWordFilterLogic
{
    void warnUser(final User p0);
    
    void kickUser(final User p0);
    
    IBannedUserManager getBannedUserManger();
    
    IWordFilter getWordFilter();
    
    void setBannedUserManager(final IBannedUserManager p0);
    
    void setWordFilter(final IWordFilter p0);
}

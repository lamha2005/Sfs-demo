// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.filters;

public class FilteredMessage
{
    private String message;
    private int occurrences;
    
    public String getMessage() {
        return this.message;
    }
    
    public void setMessage(final String message) {
        this.message = message;
    }
    
    public int getOccurrences() {
        return this.occurrences;
    }
    
    public void setOccurrences(final int substitutions) {
        this.occurrences = substitutions;
    }
}

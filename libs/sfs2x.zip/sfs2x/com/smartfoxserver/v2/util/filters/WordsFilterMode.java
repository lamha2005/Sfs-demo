// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.filters;

public enum WordsFilterMode
{
    WHITE_LIST("WHITE_LIST", 0), 
    BLACK_LIST("BLACK_LIST", 1);
    
    private WordsFilterMode(final String s, final int n) {
    }
    
    public static WordsFilterMode fromString(final String id) {
        WordsFilterMode mode = WordsFilterMode.BLACK_LIST;
        if (id.equalsIgnoreCase("whitelist")) {
            mode = WordsFilterMode.WHITE_LIST;
        }
        return mode;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.filters;

import com.smartfoxserver.v2.util.UsersUtil;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.util.IWordFilter;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;

public class SFSWordFilterLogic implements IWordFilterLogic
{
    private static final String BANNING_REASON = "Swearing";
    private final IBannedUserManager bannedUserManger;
    private final IWordFilter wordFilter;
    
    public SFSWordFilterLogic(final IBannedUserManager manager, final IWordFilter filter) {
        this.bannedUserManger = manager;
        this.wordFilter = filter;
    }
    
    @Override
    public IBannedUserManager getBannedUserManger() {
        return this.bannedUserManger;
    }
    
    @Override
    public IWordFilter getWordFilter() {
        return this.wordFilter;
    }
    
    @Override
    public void setBannedUserManager(final IBannedUserManager manager) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void setWordFilter(final IWordFilter filter) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void kickUser(final User user) {
        int kickCount = this.bannedUserManger.getKickCount(user.getName(), user.getZone().getName(), this.wordFilter.getBanDurationMinutes() * 60);
        if (++kickCount > this.wordFilter.getKicksBeforeBan()) {
            this.bannedUserManger.banUser(user, UsersUtil.getServerModerator(), this.wordFilter.getBanDurationMinutes(), this.wordFilter.getBanMode(), "Swearing", this.wordFilter.getBanMessage(), this.wordFilter.getSecondsBeforeBanOrKick());
        }
        else {
            this.bannedUserManger.kickUser(user, UsersUtil.getServerModerator(), this.wordFilter.getKickMessage(), this.wordFilter.getSecondsBeforeBanOrKick());
        }
    }
    
    @Override
    public void warnUser(final User user) {
        int warnings = user.getBadWordsWarnings() + 1;
        if (warnings > this.wordFilter.getWarningsBeforeKick()) {
            warnings = 0;
            this.kickUser(user);
        }
        else if (this.wordFilter.isUseWarnings()) {
            this.bannedUserManger.sendWarningMessage(user, null, this.wordFilter.getWarningMessage());
        }
        user.setBadWordsWarnings(warnings);
    }
}

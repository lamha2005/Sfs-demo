// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.filters;

import java.util.concurrent.ConcurrentHashMap;
import com.smartfoxserver.v2.controllers.SystemRequest;
import java.util.Map;

public class RequestMonitor
{
    private final Map<SystemRequest, RequestRateMeter> rateMeters;
    
    public RequestMonitor() {
        this.rateMeters = new ConcurrentHashMap<SystemRequest, RequestRateMeter>();
    }
    
    public int updateRequest(final SystemRequest request) {
        final RequestRateMeter meter = this.rateMeters.get(request);
        if (meter != null) {
            return meter.updateAndCheck();
        }
        this.rateMeters.put(request, new RequestRateMeter());
        return 1;
    }
    
    private static final class RequestRateMeter
    {
        private static final int DEFAULT_SECONDS = 1;
        private int rateMonitorMillis;
        private long lastUpdate;
        private int reqCounter;
        
        public RequestRateMeter() {
            this(1);
        }
        
        public RequestRateMeter(final int secondsMonitored) {
            this.rateMonitorMillis = secondsMonitored * 1000;
            this.lastUpdate = System.currentTimeMillis();
            this.reqCounter = 0;
        }
        
        public synchronized int updateAndCheck() {
            final long now = System.currentTimeMillis();
            if (now - this.lastUpdate > this.rateMonitorMillis) {
                this.reqCounter = 0;
            }
            ++this.reqCounter;
            this.lastUpdate = now;
            return this.reqCounter;
        }
    }
}

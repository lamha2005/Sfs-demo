// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.util.Arrays;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.Room;

public class DefaultPlayerIdGenerator implements IPlayerIdGenerator
{
    private Room parentRoom;
    private volatile Boolean[] playerSlots;
    private final Logger logger;
    
    public DefaultPlayerIdGenerator() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void init() {
        Arrays.fill(this.playerSlots = new Boolean[this.parentRoom.getMaxUsers() + 1], Boolean.FALSE);
    }
    
    @Override
    public int getPlayerSlot() {
        int playerId = 0;
        synchronized (this.playerSlots) {
            for (int ii = 1; ii < this.playerSlots.length; ++ii) {
                if (!this.playerSlots[ii]) {
                    playerId = ii;
                    this.playerSlots[ii] = Boolean.TRUE;
                    break;
                }
            }
        }
        // monitorexit(this.playerSlots)
        if (playerId < 1) {
            this.logger.warn("No player slot found in " + this.parentRoom);
        }
        return playerId;
    }
    
    @Override
    public void freePlayerSlot(final int playerId) {
        if (playerId == -1) {
            return;
        }
        if (playerId >= this.playerSlots.length) {
            return;
        }
        synchronized (this.playerSlots) {
            this.playerSlots[playerId] = Boolean.FALSE;
        }
        // monitorexit(this.playerSlots)
    }
    
    @Override
    public void onRoomResize() {
        final Boolean[] newPlayerSlots = new Boolean[this.parentRoom.getMaxUsers() + 1];
        synchronized (this.playerSlots) {
            for (int i = 1; i < newPlayerSlots.length; ++i) {
                if (i < this.playerSlots.length) {
                    newPlayerSlots[i] = this.playerSlots[i];
                }
                else {
                    newPlayerSlots[i] = Boolean.FALSE;
                }
            }
        }
        // monitorexit(this.playerSlots)
        this.playerSlots = newPlayerSlots;
    }
    
    @Override
    public Room getParentRoom() {
        return this.parentRoom;
    }
    
    @Override
    public void setParentRoom(final Room room) {
        this.parentRoom = room;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.security.NoSuchAlgorithmException;
import org.slf4j.LoggerFactory;
import com.thoughtworks.xstream.core.util.Base64Encoder;
import org.slf4j.Logger;
import java.security.MessageDigest;

public final class SHA1
{
    private static SHA1 _instance;
    private MessageDigest messageDigest;
    private final Logger log;
    private final Base64Encoder b64;
    
    static {
        SHA1._instance = new SHA1();
    }
    
    private SHA1() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.b64 = new Base64Encoder();
        try {
            this.messageDigest = MessageDigest.getInstance("SHA-1");
        }
        catch (NoSuchAlgorithmException e) {
            this.log.error("Could not instantiate the SHA-1 Message Digest!");
        }
    }
    
    public static SHA1 getInstance() {
        return SHA1._instance;
    }
    
    public synchronized String getHash(final String s) {
        final byte[] data = s.getBytes();
        this.messageDigest.update(data);
        return this.toHexString(this.messageDigest.digest());
    }
    
    public synchronized String getBase64Hash(final String s) {
        final byte[] data = s.getBytes();
        this.messageDigest.update(data);
        return this.b64.encode(this.messageDigest.digest());
    }
    
    private String toHexString(final byte[] byteData) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; ++i) {
            String hex = Integer.toHexString(byteData[i] & 0xFF);
            if (hex.length() == 1) {
                hex = "0" + hex;
            }
            sb.append(hex);
        }
        return sb.toString();
    }
}

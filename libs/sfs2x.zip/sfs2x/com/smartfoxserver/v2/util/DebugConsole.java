// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import org.python.core.PyObject;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.v2.SmartFoxServer;
import org.python.core.PySystemState;
import org.python.util.PythonInterpreter;

public class DebugConsole
{
    private PythonInterpreter runtime;
    
    public DebugConsole() {
        PySystemState.initialize();
        this.runtime = new PythonInterpreter();
    }
    
    public void init() {
        this.runtime.exec("import sys");
        this.runtime.exec("sys.path.append(r'lib/jconsole/')");
        this.runtime.exec("from console import main");
        final PyObject main = this.runtime.get("main");
        this.runtime.set("sfs", (Object)SmartFoxServer.getInstance());
        this.runtime.set("eng", (Object)BitSwarmEngine.getInstance());
        this.runtime.set("api", (Object)SmartFoxServer.getInstance().getAPIManager().getSFSApi());
        this.runtime.set("um", (Object)SmartFoxServer.getInstance().getUserManager());
        this.runtime.set("zm", (Object)SmartFoxServer.getInstance().getZoneManager());
        this.runtime.set("xm", (Object)SmartFoxServer.getInstance().getExtensionManager());
        this.runtime.set("bum", (Object)SmartFoxServer.getInstance().getBannedUserManager());
        this.runtime.set("sm", (Object)SmartFoxServer.getInstance().getSessionManager());
        this.runtime.set("sm", (Object)SmartFoxServer.getInstance().getSessionManager());
        main.__call__(this.runtime.getLocals());
        this.runtime.exec("print('sfs\t\tSmartFoxServer instance');print('api\t\tSmartFoxServer API');print('sm\t\tSessionManager');print('um\t\tUserManager');print('zm\t\tZoneManager');print('xm\t\tExtensionManager');print('bum\t\tBannedUserManager');print('um\t\tUserManager');print('zm\t\tZoneManager');print('xm\t\tExtensionManager');print('eng\t\tBitSwarmEngine');");
        this.runtime.exec("print ''");
    }
}

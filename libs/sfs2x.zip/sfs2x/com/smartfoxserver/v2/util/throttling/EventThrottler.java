// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.throttling;

import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.LinkedList;
import org.slf4j.LoggerFactory;
import java.util.concurrent.ScheduledFuture;
import java.util.List;
import org.slf4j.Logger;

public class EventThrottler<T> implements IMessageThrottler<T>
{
    protected final Logger log;
    protected int interval;
    protected int messageLimit;
    protected IThrottlerTask<T> taskRunner;
    protected List<T> items;
    private Runnable internalRunner;
    private ScheduledFuture<?> taskId;
    
    public EventThrottler(final IThrottlerTask<T> taskRunner) {
        this(taskRunner, -1);
    }
    
    public EventThrottler(final IThrottlerTask<T> taskRunner, final int millis) {
        this(taskRunner, millis, Integer.MAX_VALUE);
    }
    
    public EventThrottler(final IThrottlerTask<T> taskRunner, final int millis, final int messageLimit) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.interval = 1000;
        this.messageLimit = Integer.MAX_VALUE;
        this.internalRunner = new InternalRunner((InternalRunner)null);
        this.taskRunner = taskRunner;
        this.items = new LinkedList<T>();
        this.messageLimit = messageLimit;
        this.setInterval(millis);
    }
    
    @Override
    public void add(final T item) {
        synchronized (this.items) {
            this.items.add(item);
            if (this.items.size() >= this.messageLimit) {
                this.internalRunner.run();
            }
        }
        // monitorexit(this.items)
    }
    
    @Override
    public int getInterval() {
        return this.interval;
    }
    
    @Override
    public void setInterval(final int millis) {
        if (millis >= 0) {
            this.interval = millis;
        }
        if (this.taskId != null) {
            this.taskId.cancel(true);
        }
        this.taskId = SmartFoxServer.getInstance().getTaskScheduler().scheduleAtFixedRate(this.internalRunner, 0, this.interval, TimeUnit.MILLISECONDS);
    }
    
    @Override
    public int getMessageLimit() {
        return this.messageLimit;
    }
    
    @Override
    public void setMessageLimit(final int limit) {
        this.messageLimit = limit;
    }
    
    private final class InternalRunner implements Runnable
    {
        @Override
        public void run() {
            try {
                List<T> itemsCopy = null;
                synchronized (EventThrottler.this.items) {
                    if (EventThrottler.this.items.size() > 0) {
                        itemsCopy = new LinkedList<T>((Collection<? extends T>)EventThrottler.this.items);
                        EventThrottler.this.items.clear();
                    }
                }
                // monitorexit(this.this$0.items)
                EventThrottler.this.taskRunner.execute(itemsCopy);
            }
            catch (Exception err) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(err);
                emc.setDescription("Error while running Throttler Task");
                EventThrottler.this.log.warn(emc.toString());
            }
        }
    }
}

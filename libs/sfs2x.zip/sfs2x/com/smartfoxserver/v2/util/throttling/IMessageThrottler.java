// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.throttling;

public interface IMessageThrottler<T>
{
    void add(final T p0);
    
    int getInterval();
    
    void setInterval(final int p0);
    
    int getMessageLimit();
    
    void setMessageLimit(final int p0);
}

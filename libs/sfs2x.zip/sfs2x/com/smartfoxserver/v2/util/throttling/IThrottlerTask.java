// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.throttling;

import java.util.List;

public interface IThrottlerTask<T>
{
    void execute(final List<T> p0) throws Exception;
}

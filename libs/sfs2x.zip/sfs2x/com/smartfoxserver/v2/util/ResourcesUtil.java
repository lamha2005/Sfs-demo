// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import com.smartfoxserver.v2.core.ObjectFactory;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ResourcesUtil
{
    private static final Loader objectLoader;
    
    static {
        objectLoader = new Loader(null);
    }
    
    public static Object loadClass(final String className) throws Exception {
        return ResourcesUtil.objectLoader.load(className);
    }
    
    public static String readTextData(final String resourceName) throws IOException {
        return new String(readBinaryData(resourceName));
    }
    
    public static byte[] readBinaryData(final String resourceName) throws IOException {
        byte[] byteData = null;
        final InputStream is = ResourcesUtil.class.getClassLoader().getResourceAsStream(resourceName);
        if (is == null) {
            throw new FileNotFoundException("Resource '" + resourceName + "' was not found");
        }
        BufferedInputStream bis = null;
        ByteArrayOutputStream baos = null;
        try {
            baos = new ByteArrayOutputStream();
            bis = new BufferedInputStream(is);
            int read;
            while ((read = bis.read()) != -1) {
                baos.write(read);
            }
        }
        finally {
            try {
                if (bis != null) {
                    bis.close();
                }
                if (baos != null) {
                    baos.close();
                }
            }
            catch (Exception ex) {}
            byteData = baos.toByteArray();
        }
        try {
            if (bis != null) {
                bis.close();
            }
            if (baos != null) {
                baos.close();
            }
        }
        catch (Exception ex2) {}
        byteData = baos.toByteArray();
        return byteData;
    }
    
    private static final class Loader extends ObjectFactory
    {
        public Object load(final String className) throws Exception {
            return this.load(className);
        }
    }
}

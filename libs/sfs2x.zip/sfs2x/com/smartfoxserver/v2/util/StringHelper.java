// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.File;

public class StringHelper
{
    private static final String ASCII_FOLDER = "config/ascii/";
    private static final String ASCII_EXT = ".txt";
    
    public static void fillRight(final StringBuilder sb, final char c, final int max) {
        sb.append(fillString(c, max));
    }
    
    public static void fillLeft(final StringBuilder sb, final char c, final int max) {
        sb.insert(0, fillString(c, max));
    }
    
    private static String fillString(final char c, final int len) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; ++i) {
            sb.append(c);
        }
        return sb.toString();
    }
    
    public static String getAsciiMessage(final String messageName) {
        final String filePath = "config/ascii/" + messageName + ".txt";
        String asciiMessage = null;
        try {
            asciiMessage = FileUtils.readFileToString(new File(filePath));
        }
        catch (IOException ex) {}
        return asciiMessage;
    }
}

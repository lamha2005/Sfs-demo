// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class DefaultWordFilterLoader implements IWordFilterLoader
{
    private Logger log;
    
    public DefaultWordFilterLoader() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public List<String> load(final Object... params) throws IOException {
        if (params.length != 2) {
            throw new IllegalStateException("Wrong number of parameters. Expected (String, Boolean)");
        }
        final String filePath = (String)params[0];
        final boolean init = (boolean)params[1];
        List<String> data = null;
        if (filePath != null) {
            data = (List<String>)FileUtils.readLines(new File(filePath));
            if (!init) {
                this.log.info("WordsFilter expression file reloaded: " + filePath);
            }
        }
        else if (!init) {
            this.log.warn("Reloading WordsFilter expression failed: no file specified, is the filter turned on? ");
        }
        return data;
    }
}

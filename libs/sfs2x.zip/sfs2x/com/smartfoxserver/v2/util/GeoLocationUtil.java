// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import com.smartfoxserver.v2.admin.utils.IpGeoLocator;

public class GeoLocationUtil
{
    private static final IpGeoLocator geo;
    
    static {
        (geo = new IpGeoLocator()).init("data/", false);
    }
    
    public static Country resolve(final String ipAddress) {
        Country country = null;
        final com.maxmind.geoip2.record.Country res = GeoLocationUtil.geo.locateIP(ipAddress);
        if (res != null) {
            country = new Country(res);
        }
        return country;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

public class JSONUtil
{
    public static String stripComments(final String jsonData) {
        final StringBuilder sb = new StringBuilder();
        final String[] lines = jsonData.split("\\r?\\n");
        String[] array;
        for (int length = (array = lines).length, i = 0; i < length; ++i) {
            final String line = array[i];
            if (!line.trim().startsWith("//")) {
                sb.append(line).append("\n");
            }
        }
        return sb.toString();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.File;

public final class FlashMasterSocketPolicyLoader
{
    public String loadPolicy(final String fileName) throws IOException {
        return FileUtils.readFileToString(new File(fileName));
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.io.IOException;
import java.util.List;

public interface IWordFilterLoader
{
    List<String> load(final Object... p0) throws IOException;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.bitswarm.service.IService;

public class TaskScheduler implements IService
{
    private static AtomicInteger schedulerId;
    private final ScheduledThreadPoolExecutor taskScheduler;
    private final String serviceName;
    private final Logger logger;
    
    static {
        TaskScheduler.schedulerId = new AtomicInteger(0);
    }
    
    public TaskScheduler(final int threadPoolSize) {
        this.serviceName = "TaskScheduler-" + TaskScheduler.schedulerId.getAndIncrement();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.taskScheduler = new ScheduledThreadPoolExecutor(threadPoolSize);
    }
    
    public void init(final Object o) {
        this.logger.info(String.valueOf(this.serviceName) + " started.");
    }
    
    public void destroy(final Object o) {
        final List<Runnable> awaitingExecution = this.taskScheduler.shutdownNow();
        this.logger.info(String.valueOf(this.serviceName) + " stopping. Tasks awaiting execution: " + awaitingExecution.size());
    }
    
    public String getName() {
        return this.serviceName;
    }
    
    public void handleMessage(final Object arg0) {
    }
    
    public void setName(final String arg0) {
    }
    
    public ScheduledFuture<?> schedule(final Runnable task, final int delay, final TimeUnit unit) {
        this.logger.debug("Task scheduled: " + task + ", " + delay + " " + unit);
        return this.taskScheduler.schedule(task, delay, unit);
    }
    
    public ScheduledFuture<?> scheduleAtFixedRate(final Runnable task, final int initialDelay, final int period, final TimeUnit unit) {
        return this.taskScheduler.scheduleAtFixedRate(task, initialDelay, period, unit);
    }
    
    public void resizeThreadPool(final int threadPoolSize) {
        this.taskScheduler.setCorePoolSize(threadPoolSize);
    }
    
    public int getThreadPoolSize() {
        return this.taskScheduler.getCorePoolSize();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

public enum ClientDisconnectionReason implements IDisconnectionReason
{
    IDLE("IDLE", 0, 0), 
    KICK("KICK", 1, 1), 
    BAN("BAN", 2, 2), 
    UNKNOWN("UNKNOWN", 3, 3);
    
    private final int value;
    
    private ClientDisconnectionReason(final String s, final int n, final int id) {
        this.value = id;
    }
    
    @Override
    public int getValue() {
        return this.value;
    }
    
    @Override
    public byte getByteValue() {
        return (byte)this.value;
    }
}

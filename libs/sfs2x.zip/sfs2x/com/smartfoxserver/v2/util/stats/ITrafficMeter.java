// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

import java.util.List;

public interface ITrafficMeter
{
    int getMonitoredHours();
    
    int getSamplingRateMinutes();
    
    int getTrafficAverage();
    
    int getTrafficAverage(final int p0);
    
    int getMaxTraffic();
    
    int getMinTraffic();
    
    List<Integer> getDataPoints();
    
    List<Integer> getDataPoints(final int p0);
    
    long getLastUpdateMillis();
    
    void onTick();
}

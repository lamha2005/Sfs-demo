// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

import com.smartfoxserver.bitswarm.sessions.bluebox.BlueBoxStats;
import com.smartfoxserver.bitswarm.websocket.WebSocketStats;
import com.smartfoxserver.bitswarm.sessions.bluebox.BlueBoxService;
import com.smartfoxserver.bitswarm.websocket.WebSocketService;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;

public class SFSTrafficStats implements ITrafficStats
{
    private final BitSwarmEngine bse;
    private final WebSocketService webSocketService;
    private final BlueBoxService blueBoxService;
    private final WebSocketStats wsStats;
    private final BlueBoxStats bbStats;
    
    public SFSTrafficStats() {
        this.bse = BitSwarmEngine.getInstance();
        this.webSocketService = (WebSocketService)BitSwarmEngine.getInstance().getServiceByName("webSocketEngine");
        this.blueBoxService = (BlueBoxService)BitSwarmEngine.getInstance().getServiceByName("blueBoxEngine");
        this.wsStats = this.webSocketService.getWebSocketStats();
        this.bbStats = this.blueBoxService.getBbStats();
    }
    
    @Override
    public long getReadBytes() {
        final long value = this.bse.getSocketReader().getReadBytes() + this.bse.getDatagramReader().getReadBytes() + this.bbStats.getReadBytes() + this.wsStats.getReadBytes();
        return value;
    }
    
    @Override
    public long getReadPackets() {
        final long value = this.bse.getSocketReader().getReadPackets() + this.bse.getDatagramReader().getReadPackets() + this.wsStats.getReadPackets();
        return value;
    }
    
    @Override
    public long getWrittenBytes() {
        final long value = this.bse.getSocketWriter().getWrittenBytes() + this.bbStats.getWrittenBytes() + this.wsStats.getWrittenBytes();
        return value;
    }
    
    @Override
    public long getWrittenPackets() {
        final long value = this.bse.getSocketWriter().getWrittenPackets() + this.bbStats.getWrittenPackets() + this.wsStats.getWrittenPackets();
        return value;
    }
}

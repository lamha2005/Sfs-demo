// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.managers.IStatsManager;
import java.util.List;
import java.util.LinkedList;

public class NetworkTrafficMeter implements INetworkTrafficMeter
{
    public static final int DEFAULT_MONITORED_HOURS = 24;
    public static final int DEFAULT_SAMPLING_RATE_MINUTES = 1;
    private int monitoredHours;
    private int samplingRateMinutes;
    private int samplesPerHour;
    private volatile long maxTrafficValueEverSeen;
    private volatile long minTrafficValueEverSeen;
    private volatile long lastUpdateTime;
    private LinkedList<List<Long>> trafficDataByHour;
    private TrafficType trafficType;
    private final IStatsManager statsManager;
    
    public NetworkTrafficMeter(final TrafficType type) {
        this(type, 24, 1);
    }
    
    public NetworkTrafficMeter(final TrafficType type, final int monitoredHours, final int samplingRateMinutes) {
        this.maxTrafficValueEverSeen = 0L;
        this.minTrafficValueEverSeen = Long.MAX_VALUE;
        this.statsManager = SmartFoxServer.getInstance().getStatsManager();
        this.monitoredHours = monitoredHours;
        this.samplingRateMinutes = samplingRateMinutes;
        this.trafficType = type;
        (this.trafficDataByHour = new LinkedList<List<Long>>()).add(new ArrayList<Long>());
        this.lastUpdateTime = System.currentTimeMillis();
        this.samplesPerHour = 60 / this.samplingRateMinutes;
    }
    
    @Override
    public long getLastUpdateMillis() {
        return this.lastUpdateTime;
    }
    
    @Override
    public List<Long> getDataPoints() {
        return this.getDataPoints(0);
    }
    
    @Override
    public long getMaxTraffic() {
        return this.maxTrafficValueEverSeen;
    }
    
    @Override
    public long getMinTraffic() {
        return this.minTrafficValueEverSeen;
    }
    
    @Override
    public List<Long> getDataPoints(final int howManyPoints) {
        final List<Long> flatData = this.getFlatData();
        if (howManyPoints < 1) {
            return flatData;
        }
        if (howManyPoints > flatData.size()) {
            return flatData;
        }
        final int steps = flatData.size() / howManyPoints;
        final List<Long> selectedDataPoints = new ArrayList<Long>();
        for (int i = 0; i < flatData.size(); i += steps) {
            selectedDataPoints.add(flatData.get(i));
        }
        return selectedDataPoints;
    }
    
    @Override
    public int getMonitoredHours() {
        return this.monitoredHours;
    }
    
    @Override
    public int getSamplingRateMinutes() {
        return this.samplingRateMinutes;
    }
    
    @Override
    public long getTrafficAverage() {
        final List<Long> values = new ArrayList<Long>();
        synchronized (this.trafficDataByHour) {
            for (final List<Long> samples : this.trafficDataByHour) {
                try {
                    values.add(this.getAverage(samples));
                }
                // monitorexit(list)
                finally {}
            }
        }
        // monitorexit(this.trafficDataByHour)
        return this.getAverage(values);
    }
    
    @Override
    public void onTick() {
        final int currHour = this.trafficDataByHour.size();
        final List<Long> samples = this.trafficDataByHour.get(currHour - 1);
        long trafficValue;
        if (this.trafficType == TrafficType.INCOMING) {
            trafficValue = this.statsManager.getTrafficStats().getReadBytes() / 1024L;
        }
        else {
            trafficValue = this.statsManager.getTrafficStats().getWrittenBytes() / 1024L;
        }
        if (trafficValue > this.maxTrafficValueEverSeen) {
            this.maxTrafficValueEverSeen = trafficValue;
        }
        if (trafficValue < this.minTrafficValueEverSeen) {
            this.minTrafficValueEverSeen = trafficValue;
        }
        synchronized (samples) {
            samples.add(trafficValue);
        }
        if (samples.size() == this.samplesPerHour) {
            synchronized (this.trafficDataByHour) {
                if (this.trafficDataByHour.size() == this.monitoredHours) {
                    this.trafficDataByHour.removeFirst();
                }
                this.trafficDataByHour.add(new ArrayList<Long>());
            }
            // monitorexit(this.trafficDataByHour)
        }
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        synchronized (this.trafficDataByHour) {
            int hour = 1;
            for (final List<Long> samples : this.trafficDataByHour) {
                sb.append(hour++).append(" => ").append(samples.toString()).append("\n");
            }
        }
        // monitorexit(this.trafficDataByHour)
        return sb.toString();
    }
    
    private long getAverage(final List<Long> data) {
        if (data.size() == 0) {
            return 0L;
        }
        long tot = 0L;
        for (final Long value : data) {
            tot += value;
        }
        return (int)tot / data.size();
    }
    
    private List<Long> getFlatData() {
        final List<Long> flatData = new ArrayList<Long>();
        synchronized (this.trafficDataByHour) {
            for (final List<Long> samples : this.trafficDataByHour) {
                try {
                    flatData.addAll(samples);
                }
                // monitorexit(list)
                finally {}
            }
        }
        // monitorexit(this.trafficDataByHour)
        return flatData;
    }
}

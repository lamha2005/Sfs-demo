// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedList;
import com.smartfoxserver.v2.entities.Zone;

public class ZoneTrafficMeter implements ITrafficMeter
{
    private static final int DEFAULT_MONITORED_HOURS = 24;
    private static final int DEFAULT_SAMPLING_RATE_MINUTES = 5;
    private int monitoredHours;
    private int samplingRateMinutes;
    private int samplesPerHour;
    private int maxTrafficValueEverSeen;
    private int minTrafficValueEverSeen;
    private volatile long lastUpdateTime;
    private final Zone zone;
    LinkedList<List<Integer>> trafficDataByHour;
    
    public ZoneTrafficMeter(final Zone zone) {
        this(zone, 24, 5);
    }
    
    public ZoneTrafficMeter(final Zone zone, final int monitoredHours, final int samplingRateMinutes) {
        this.maxTrafficValueEverSeen = 0;
        this.minTrafficValueEverSeen = Integer.MAX_VALUE;
        this.zone = zone;
        this.monitoredHours = monitoredHours;
        this.samplingRateMinutes = samplingRateMinutes;
        (this.trafficDataByHour = new LinkedList<List<Integer>>()).add(new ArrayList<Integer>());
        this.lastUpdateTime = System.currentTimeMillis();
        this.samplesPerHour = 60 / this.samplingRateMinutes;
    }
    
    @Override
    public long getLastUpdateMillis() {
        return this.lastUpdateTime;
    }
    
    @Override
    public List<Integer> getDataPoints() {
        return this.getDataPoints(0);
    }
    
    @Override
    public List<Integer> getDataPoints(final int howManyPoints) {
        final List<Integer> flatData = this.getFlatData();
        if (howManyPoints < 1) {
            return flatData;
        }
        if (howManyPoints > flatData.size()) {
            return flatData;
        }
        final int steps = flatData.size() / howManyPoints;
        final List<Integer> selectedDataPoints = new ArrayList<Integer>();
        for (int i = 0; i < flatData.size(); i += steps) {
            selectedDataPoints.add(flatData.get(i));
        }
        return selectedDataPoints;
    }
    
    @Override
    public int getMaxTraffic() {
        return this.maxTrafficValueEverSeen;
    }
    
    @Override
    public int getMinTraffic() {
        return this.minTrafficValueEverSeen;
    }
    
    @Override
    public int getMonitoredHours() {
        return this.monitoredHours;
    }
    
    @Override
    public int getSamplingRateMinutes() {
        return this.samplingRateMinutes;
    }
    
    @Override
    public int getTrafficAverage() {
        final List<Integer> values = new ArrayList<Integer>();
        synchronized (this.trafficDataByHour) {
            for (final List<Integer> samples : this.trafficDataByHour) {
                try {
                    values.add(this.getAverage(samples));
                }
                // monitorexit(list)
                finally {}
            }
        }
        // monitorexit(this.trafficDataByHour)
        return this.getAverage(values);
    }
    
    @Override
    public int getTrafficAverage(final int previousHours) {
        throw new UnsupportedOperationException("Not implemented yet");
    }
    
    @Override
    public void onTick() {
        final int currHour = this.trafficDataByHour.size();
        final List<Integer> samples = this.trafficDataByHour.get(currHour - 1);
        final int userCountNow = this.zone.getUserCount();
        if (userCountNow > this.maxTrafficValueEverSeen) {
            this.maxTrafficValueEverSeen = userCountNow;
        }
        if (userCountNow < this.minTrafficValueEverSeen) {
            this.minTrafficValueEverSeen = userCountNow;
        }
        synchronized (samples) {
            samples.add(userCountNow);
        }
        if (samples.size() == this.samplesPerHour) {
            synchronized (this.trafficDataByHour) {
                if (this.trafficDataByHour.size() == this.monitoredHours) {
                    this.trafficDataByHour.removeFirst();
                }
                this.trafficDataByHour.add(new ArrayList<Integer>());
            }
            // monitorexit(this.trafficDataByHour)
        }
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        synchronized (this.trafficDataByHour) {
            int hour = 1;
            for (final List<Integer> samples : this.trafficDataByHour) {
                sb.append(hour++).append(" => ").append(samples.toString()).append("\n");
            }
        }
        // monitorexit(this.trafficDataByHour)
        return sb.toString();
    }
    
    private int getAverage(final List<Integer> data) {
        if (data.size() == 0) {
            return 0;
        }
        long tot = 0L;
        for (final Integer value : data) {
            tot += value;
        }
        return (int)tot / data.size();
    }
    
    private List<Integer> getFlatData() {
        final List<Integer> flatData = new ArrayList<Integer>();
        synchronized (this.trafficDataByHour) {
            for (final List<Integer> samples : this.trafficDataByHour) {
                try {
                    flatData.addAll(samples);
                }
                // monitorexit(list)
                finally {}
            }
        }
        // monitorexit(this.trafficDataByHour)
        return flatData;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.GregorianCalendar;
import com.smartfoxserver.v2.entities.Zone;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import java.util.Map;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;

public class CCULoggerTask implements Runnable
{
    private static final int TIME_TO_LOG = 55;
    private final SmartFoxServer sfs;
    private final Logger log;
    private final Map<String, StatsData> stats;
    private final StatsData serverStats;
    private int lastLoggedHour;
    
    public CCULoggerTask() {
        this.lastLoggedHour = -1;
        this.sfs = SmartFoxServer.getInstance();
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.stats = new ConcurrentHashMap<String, StatsData>();
        this.serverStats = new StatsData(null);
    }
    
    @Override
    public void run() {
        final List<Zone> zList = this.sfs.getZoneManager().getZoneList();
        for (final Zone zone : zList) {
            StatsData zoneStatsData = this.stats.get(zone.getName());
            if (zoneStatsData == null) {
                zoneStatsData = new StatsData(null);
                this.stats.put(zone.getName(), zoneStatsData);
            }
            final int ccu = zone.getUserCount();
            final StatsData statsData = zoneStatsData;
            statsData.hourAvg += ccu;
            zoneStatsData.peakCCU = ((zoneStatsData.peakCCU < ccu) ? ccu : zoneStatsData.peakCCU);
        }
        final int globalCCU = this.sfs.getUserManager().getUserCount();
        final StatsData serverStats = this.serverStats;
        serverStats.hourAvg += globalCCU;
        this.serverStats.peakCCU = ((this.serverStats.peakCCU < globalCCU) ? globalCCU : this.serverStats.peakCCU);
        final Calendar cal = new GregorianCalendar();
        final int min = cal.get(12);
        if (min >= 55) {
            final int currHour = cal.get(10);
            if (this.lastLoggedHour != currHour) {
                this.lastLoggedHour = currHour;
                this.logStats();
                this.stats.clear();
                this.serverStats.hourAvg = 0;
                this.serverStats.peakCCU = 0;
            }
        }
    }
    
    private void logStats() {
        for (final Map.Entry<String, StatsData> item : this.stats.entrySet()) {
            this.log.info(String.format("CCU stats: { Zone: %s }, CCU: %s/%s", item.getKey(), item.getValue().hourAvg / 60, item.getValue().peakCCU));
        }
        this.log.info(String.format("CCU stats: CCU: %s/%s", this.serverStats.hourAvg / 60, this.serverStats.peakCCU));
    }
    
    private static final class StatsData
    {
        int hourAvg;
        int peakCCU;
    }
}

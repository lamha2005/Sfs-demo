// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.SFSObject;
import java.util.Locale;
import org.joda.time.LocalDateTime;
import com.smartfoxserver.v2.util.extprocess.LogAnalysisProcessManagerThread;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.config.ServerSettings;
import org.slf4j.Logger;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.util.extprocess.IProcessManager;

public class LogAnalyzerTask implements Runnable, IProcessManager
{
    private volatile boolean isRunning;
    private final SmartFoxServer sfs;
    private final Logger logger;
    private boolean forceFirstRun;
    private ServerSettings.AnalyticsSettings settings;
    
    public LogAnalyzerTask(final boolean forceFirstRun) {
        this.sfs = SmartFoxServer.getInstance();
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.forceFirstRun = forceFirstRun;
        this.settings = this.sfs.getConfigurator().getServerSettings().analytics;
    }
    
    @Override
    public void run() {
        if (this.doRun()) {
            this.isRunning = true;
            try {
                final boolean rebuildDB = this.settings.rebuildDB;
                final boolean skipGeoLocation = this.settings.skipGeolocation;
                final String sourcePath = this.settings.sourceFolder;
                final String locale = this.settings.locale;
                new LogAnalysisProcessManagerThread(this, rebuildDB, skipGeoLocation, sourcePath, locale);
                if (rebuildDB) {
                    this.resetRebuildDBFlag();
                }
            }
            catch (Exception e) {
                this.isRunning = false;
                this.logger.warn(e.getMessage());
            }
        }
    }
    
    private Boolean doRun() {
        if (this.isRunning) {
            return false;
        }
        if (this.forceFirstRun) {
            this.forceFirstRun = false;
            return true;
        }
        final LocalDateTime now = new LocalDateTime();
        if (!this.settings.runOnDay.equals("[everyday]")) {
            final LocalDateTime.Property pDoW = now.dayOfWeek();
            final String todayName = pDoW.getAsText(Locale.ENGLISH);
            if (!todayName.equals(this.settings.runOnDay)) {
                return false;
            }
        }
        if (now.getHourOfDay() != this.settings.runAtHour) {
            return false;
        }
        return true;
    }
    
    private void resetRebuildDBFlag() {
        this.settings.rebuildDB = false;
        try {
            final Zone adminZone = this.sfs.getZoneManager().getZoneByName("--=={{{ AdminZone }}}==--");
            adminZone.getExtension().handleClientRequest("serverConfig.saveXML", null, new SFSObject());
        }
        catch (SFSException e) {
            this.logger.error("Unable to save the XML configuration due to the following exception: " + e.getMessage());
        }
    }
    
    @Override
    public boolean getIsRunning() {
        return this.isRunning;
    }
    
    @Override
    public void onProcessStarted() {
    }
    
    @Override
    public void onProcessCompleted() {
        this.isRunning = false;
    }
    
    @Override
    public void onProcessFailed(final String errorMsg) {
        this.isRunning = false;
    }
}

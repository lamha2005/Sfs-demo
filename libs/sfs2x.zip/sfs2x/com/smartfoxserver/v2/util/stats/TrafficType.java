// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

public enum TrafficType
{
    INCOMING("INCOMING", 0), 
    OUTGOING("OUTGOING", 1);
    
    private TrafficType(final String s, final int n) {
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

public interface ITrafficStats
{
    long getReadBytes();
    
    long getWrittenBytes();
    
    long getReadPackets();
    
    long getWrittenPackets();
}

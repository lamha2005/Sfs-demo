// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.stats;

import java.util.List;

public interface INetworkTrafficMeter
{
    int getMonitoredHours();
    
    int getSamplingRateMinutes();
    
    long getTrafficAverage();
    
    long getMaxTraffic();
    
    long getMinTraffic();
    
    List<Long> getDataPoints();
    
    List<Long> getDataPoints(final int p0);
    
    long getLastUpdateMillis();
    
    void onTick();
}

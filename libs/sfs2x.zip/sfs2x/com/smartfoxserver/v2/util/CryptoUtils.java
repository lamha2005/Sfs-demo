// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import java.util.Random;
import com.smartfoxserver.bitswarm.sessions.ISession;

public class CryptoUtils
{
    private static final String DELIMITER = "__";
    
    public static String getClientPassword(final ISession session, final String clearPass) {
        return MD5.getInstance().getHash(String.valueOf(session.getHashId()) + clearPass);
    }
    
    public static String getMD5Hash(final String str) {
        return MD5.getInstance().getHash(str);
    }
    
    public static String getUniqueSessionToken(final ISession session) {
        final Random rnd = new Random();
        final String key = String.valueOf(session.getFullIpAddress()) + "__" + String.valueOf(rnd.nextInt());
        return MD5.getInstance().getHash(key);
    }
    
    public static String getHexFileName(final String name) {
        final StringBuilder sb = new StringBuilder();
        final char[] c = name.toCharArray();
        for (int i = 0; i < c.length; ++i) {
            sb.append(Integer.toHexString(c[i]));
        }
        return sb.toString();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import com.smartfoxserver.v2.entities.Room;

public interface IPlayerIdGenerator
{
    void init();
    
    int getPlayerSlot();
    
    void freePlayerSlot(final int p0);
    
    void onRoomResize();
    
    void setParentRoom(final Room p0);
    
    Room getParentRoom();
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

import com.smartfoxserver.v2.SmartFoxServer;

public class PreShutDownCleanerTask
{
    public PreShutDownCleanerTask(final SmartFoxServer sfs) {
        final Runnable shutDownHelper = sfs.getServiceProvider().getShutDownHelper();
        if (shutDownHelper != null) {
            shutDownHelper.run();
        }
    }
}

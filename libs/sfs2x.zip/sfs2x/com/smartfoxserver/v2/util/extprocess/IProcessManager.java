// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.extprocess;

public interface IProcessManager
{
    boolean getIsRunning();
    
    void onProcessStarted();
    
    void onProcessCompleted();
    
    void onProcessFailed(final String p0);
}

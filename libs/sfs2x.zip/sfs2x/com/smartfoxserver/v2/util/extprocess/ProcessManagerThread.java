// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.extprocess;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class ProcessManagerThread extends Thread
{
    private volatile boolean isRunning;
    protected Logger logger;
    
    public ProcessManagerThread(final String name) {
        super(name);
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    protected void setIsRunning(final boolean value) {
        this.isRunning = value;
    }
    
    public boolean getIsRunning() {
        return this.isRunning;
    }
    
    protected String getCommandString() {
        String command = null;
        if (this.isMac()) {
            command = "java";
        }
        else if (this.isLinux()) {
            command = "../jre/bin/java";
        }
        else if (this.isWindows()) {
            command = "..\\jre\\bin\\java.exe";
        }
        return command;
    }
    
    private boolean isWindows() {
        return this.getOSName().indexOf("win") >= 0;
    }
    
    private boolean isMac() {
        return this.getOSName().indexOf("mac") >= 0;
    }
    
    private boolean isLinux() {
        return this.getOSName().indexOf("linux") >= 0;
    }
    
    private String getOSName() {
        return System.getProperty("os.name").toLowerCase();
    }
}

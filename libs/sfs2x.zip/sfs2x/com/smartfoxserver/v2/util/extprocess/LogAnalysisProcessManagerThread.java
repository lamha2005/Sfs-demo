// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util.extprocess;

import java.util.List;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.util.Properties;

public class LogAnalysisProcessManagerThread extends ProcessManagerThread
{
    private IProcessManager pm;
    private String sourcePath;
    private boolean rebuildDB;
    private boolean skipGeoLocation;
    private String locale;
    
    public LogAnalysisProcessManagerThread(final IProcessManager pm, final boolean rebuildDB) {
        super("LogAnalysisThread");
        this.initialize(pm, rebuildDB, false, null, null);
    }
    
    public LogAnalysisProcessManagerThread(final IProcessManager pm, final boolean rebuildDB, final String locale) {
        super("LogAnalysisThread");
        this.initialize(pm, rebuildDB, false, null, locale);
    }
    
    public LogAnalysisProcessManagerThread(final IProcessManager pm, final boolean rebuildDB, final boolean skipGeoLocation, final String sourcePath, final String locale) {
        super("LogAnalysisThread");
        this.initialize(pm, rebuildDB, skipGeoLocation, sourcePath, locale);
    }
    
    private void initialize(final IProcessManager pm, final boolean rebuildDB, final boolean skipGeoLocation, final String sourcePath, final String locale) {
        this.pm = pm;
        this.rebuildDB = rebuildDB;
        this.skipGeoLocation = skipGeoLocation;
        this.sourcePath = ((sourcePath != null) ? sourcePath : "");
        this.locale = ((locale != null) ? locale.toLowerCase() : "");
        final Properties log4jConfig = new Properties();
        try {
            final FileInputStream log4jConfigFile = new FileInputStream("config/log4j.properties");
            log4jConfig.load(log4jConfigFile);
        }
        catch (IOException e) {
            throw new RuntimeException("Unable to locate SmartFoxServer log due to the following error: '" + e.getMessage() + "'");
        }
        if (this.sourcePath.equals("")) {
            this.sourcePath = log4jConfig.getProperty("log4j.appender.fileAppender.File");
        }
        if (this.sourcePath == null) {
            throw new RuntimeException("Unable to access runtime log because the following parameter is missing in the log4j configuration (config/log4j.properties): 'log4j.appender.fileAppender.File'");
        }
        final String convPattern = log4jConfig.getProperty("log4j.appender.fileAppender.layout.ConversionPattern");
        final boolean isConvPatternValid = convPattern != null && convPattern.equals("%d{dd MMM yyyy | HH:mm:ss,SSS} | %-5p | %t | %c{3} | %3x | %m%n");
        if (!isConvPatternValid) {
            throw new RuntimeException("Unable to parse runtime log due to altered log structure in the 'config/log4j.properties' file; if you need to modify the log structure, please add a new appender to the log4j configuration instead of changing the default one.\nInvolved log4j parameter:\nlog4j.appender.fileAppender.layout.ConversionPattern\nExpected value:\n%d{dd MMM yyyy | HH:mm:ss,SSS} | %-5p | %t | %c{3} | %3x | %m%n");
        }
        this.logger.info("Starting external log analysis process");
        pm.onProcessStarted();
        this.start();
    }
    
    @Override
    public void run() {
        String error = null;
        final String command = this.getCommandString();
        if (command != null) {
            final List<String> arguments = new ArrayList<String>();
            arguments.add(command);
            arguments.add("-classpath");
            arguments.add("lib/*" + File.pathSeparator);
            arguments.add("com.smartfoxserver.v2.admin.LogAnalyzer");
            arguments.add(String.valueOf(this.rebuildDB));
            arguments.add(String.valueOf(this.skipGeoLocation));
            arguments.add(this.sourcePath);
            if (!this.locale.equals("")) {
                arguments.add(this.locale);
            }
            final ProcessBuilder pb = new ProcessBuilder(arguments);
            pb.redirectErrorStream(true);
            try {
                final Process p = pb.start();
                final InputStream inStream = p.getInputStream();
                BufferedReader reader = null;
                String line = null;
                String output = "";
                reader = new BufferedReader(new InputStreamReader(inStream));
                while ((line = reader.readLine()) != null) {
                    if (!output.equals("")) {
                        output = String.valueOf(output) + "\n";
                    }
                    output = String.valueOf(output) + line;
                }
                reader.close();
                this.logger.info("Log analysis process output:\n" + output);
                final int exitCode = p.waitFor();
                if (exitCode != 0) {
                    if (exitCode == 10) {
                        error = "Unable to execute log analysis process because the source or target folders couldn't be found";
                    }
                    else if (exitCode == 20) {
                        error = "Unable to complete log analysis process because the database is locked by another process";
                    }
                    else if (exitCode == 30) {
                        error = "Unable to complete log analysis process because an exception was thrown when accessing the database";
                    }
                    else if (exitCode == 100) {
                        error = "Unable to complete log analysis process due to an unhandled exception";
                    }
                }
            }
            catch (IOException e) {
                error = "Unable to complete log analysis process due to the following error.\n" + e.getMessage();
            }
            catch (InterruptedException e2) {
                error = "Unable to complete log analysis process due to the following error.\n" + e2.getMessage();
            }
        }
        else {
            error = "Unable to execute log analysis process because the Operating System is not supported";
        }
        if (error == null) {
            this.logger.info("Log analysis process completed successfully");
            this.pm.onProcessCompleted();
        }
        else {
            this.logger.warn("Log analysis process failed. " + error);
            this.pm.onProcessFailed(error);
        }
    }
}

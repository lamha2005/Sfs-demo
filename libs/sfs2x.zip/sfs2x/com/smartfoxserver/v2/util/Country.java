// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.util;

public class Country
{
    private com.maxmind.geoip2.record.Country ctry;
    
    public Country(final com.maxmind.geoip2.record.Country ctry) {
        this.ctry = ctry;
    }
    
    public String getName() {
        return this.ctry.getName();
    }
    
    public String getIsoCode() {
        return this.ctry.getIsoCode();
    }
}

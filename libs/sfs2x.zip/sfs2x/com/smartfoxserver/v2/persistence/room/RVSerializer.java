// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

import com.smartfoxserver.v2.entities.variables.SFSRoomVariable;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.variables.RoomVariable;

final class RVSerializer
{
    static final ISFSArray serialize(final RoomVariable rv) {
        final ISFSArray sfsa = rv.toSFSArray();
        sfsa.addBool(rv.isHidden());
        sfsa.addBool(rv.isGlobal());
        return sfsa;
    }
    
    static final RoomVariable deserialize(final ISFSArray sfsa) {
        final RoomVariable rv = SFSRoomVariable.newFromSFSArray(sfsa);
        rv.setHidden(sfsa.getBool(5));
        rv.setGlobal(sfsa.getBool(6));
        return rv;
    }
}

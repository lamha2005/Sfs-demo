// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

import java.util.List;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.entities.Room;

public interface IRoomStorage
{
    void saveRoom(final Room p0) throws SFSStorageException;
    
    void saveAllRooms() throws SFSStorageException;
    
    void saveAllRooms(final String p0) throws SFSStorageException;
    
    CreateRoomSettings loadRoom(final String p0) throws SFSStorageException;
    
    List<CreateRoomSettings> loadAllRooms() throws SFSStorageException;
    
    List<CreateRoomSettings> loadAllRooms(final String p0) throws SFSStorageException;
    
    void removeRoom(final String p0) throws SFSStorageException;
    
    void removeAllRooms() throws SFSStorageException;
    
    void removeAllRooms(final String p0) throws SFSStorageException;
    
    void destroy();
}

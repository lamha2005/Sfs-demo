// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

public class FileRoomStorageConfig extends BaseStorageConfig
{
    public String baseDataFolder;
    
    public FileRoomStorageConfig() {
        this.baseDataFolder = "./data/roomData/";
    }
}

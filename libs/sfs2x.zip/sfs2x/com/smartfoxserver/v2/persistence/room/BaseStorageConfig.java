// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

public class BaseStorageConfig
{
    public boolean storeInactiveRooms;
    public boolean storeRoomVariables;
    public boolean skipStaticRooms;
    
    public BaseStorageConfig() {
        this.storeInactiveRooms = false;
        this.storeRoomVariables = true;
        this.skipStaticRooms = true;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

public class SFSStorageException extends Exception
{
    private static final long serialVersionUID = -2940249829611328439L;
    
    public SFSStorageException() {
    }
    
    public SFSStorageException(final String str) {
        super(str);
    }
    
    public SFSStorageException(final Exception e) {
        super(e);
    }
}

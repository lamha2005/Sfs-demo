// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

import com.smartfoxserver.v2.entities.Zone;

public class RoomStorageFactory
{
    public static IRoomStorage getStorage(final Zone zone, final RoomStorageMode mode, final BaseStorageConfig config) {
        switch (mode) {
            case DB_STORAGE: {
                return initDBRoomStorage(zone, config);
            }
            case FILE_STORAGE: {
                return initFileRoomStorage(zone, config);
            }
            default: {
                throw new IllegalArgumentException("Unknow Room Storage Mode: " + mode);
            }
        }
    }
    
    private static DBRoomStorage initDBRoomStorage(final Zone zone, final Object config) {
        if (!(config instanceof DBRoomStorageConfig)) {
            throw new IllegalArgumentException("Expecting a DBRoomStorageConfig object, instead got: " + config.getClass());
        }
        return new DBRoomStorage((DBRoomStorageConfig)config, zone);
    }
    
    private static FileRoomStorage initFileRoomStorage(final Zone zone, final Object config) {
        if (!(config instanceof FileRoomStorageConfig)) {
            throw new IllegalArgumentException("Expecting a FileRoomStorageConfig object, instead got: " + config.getClass());
        }
        return new FileRoomStorage((FileRoomStorageConfig)config, zone);
    }
}

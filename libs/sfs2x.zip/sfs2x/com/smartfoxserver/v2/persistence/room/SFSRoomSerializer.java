// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

import com.smartfoxserver.v2.util.IPlayerIdGenerator;
import java.util.HashSet;
import java.util.Set;
import com.smartfoxserver.v2.entities.SFSRoomSettings;
import com.smartfoxserver.v2.entities.data.SFSDataWrapper;
import java.util.LinkedList;
import com.smartfoxserver.v2.mmo.Vec3D;
import java.util.List;
import com.smartfoxserver.v2.entities.data.SFSDataType;
import com.smartfoxserver.v2.entities.SFSRoomRemoveMode;
import com.smartfoxserver.v2.mmo.CreateMMORoomSettings;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.variables.RoomVariable;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.mmo.MMORoom;
import java.util.Collection;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.Room;

public class SFSRoomSerializer
{
    private static final String NAME = "name";
    private static final String GROUP_ID = "groupId";
    private static final String PASSWORD = "password";
    private static final String MAX_USERS = "maxUsers";
    private static final String MAX_SPECTATORS = "maxSpectators";
    private static final String MAX_VARIABLES_ALLOWED = "maxVariablesAllowed";
    private static final String IS_ACTIVE = "isActive";
    private static final String IS_DYNAMIC = "isDynamic";
    private static final String IS_GAME = "isGame";
    private static final String IS_HIDDEN = "isHidden";
    private static final String AUTO_REMOVE_MODE = "autoRemoveMode";
    private static final String ROOM_SETTINGS = "roomSettings";
    private static final String USE_WORDS_FILTER = "useWordsFilter";
    private static final String ROOM_VARIABLES = "roomVariables";
    private static final String CUSTOM_PLAYER_ID_GENERATOR_CLASS = "customPlayerIdGeneratorClass";
    private static final String EXT_ID = "ext_id";
    private static final String EXT_CLASS_NAME = "ext_className";
    private static final String EXT_PROPERTIES = "ext_Properties";
    private static final String MMO_DEFAULT_AOI = "defaultAOI";
    private static final String MMO_MAP_LOW_LIMIT = "mapLowLimit";
    private static final String MMO_MAP_HIGH_LIMIT = "mapHighLimit";
    private static final String MMO_USER_MAX_LIMBO_SECONDS = "userMaxLimboSeconds";
    private static final String MMO_PROXIMITY_LIST_UPDATE_MILLIS = "proximityListUpdateMillis";
    private static final String MMO_SEND_AOI_ENTRY_POINT = "sendAOIEntryPoint";
    
    public ISFSObject serialize(final Room theRoom, final boolean storeRoomVars) {
        final ISFSObject sfso = new SFSObject();
        sfso.putUtfString("name", theRoom.getName());
        sfso.putUtfString("groupId", theRoom.getGroupId());
        if (theRoom.getPassword() != null) {
            sfso.putUtfString("password", theRoom.getPassword());
        }
        sfso.putInt("maxUsers", theRoom.getMaxUsers());
        sfso.putInt("maxSpectators", theRoom.getMaxSpectators());
        sfso.putInt("maxVariablesAllowed", theRoom.getMaxRoomVariablesAllowed());
        sfso.putBool("isActive", theRoom.isActive());
        sfso.putBool("isDynamic", theRoom.isDynamic());
        sfso.putBool("isGame", theRoom.isGame());
        sfso.putBool("isHidden", theRoom.isHidden());
        sfso.putUtfString("autoRemoveMode", theRoom.getAutoRemoveMode().toString());
        sfso.putUtfStringArray("roomSettings", this.serializeFlagSettings(theRoom));
        sfso.putBool("useWordsFilter", theRoom.isUseWordsFilter());
        sfso.putUtfString("customPlayerIdGeneratorClass", theRoom.getPlayerIdGeneratorClassName());
        if (theRoom.getExtension() != null) {
            sfso.putUtfString("ext_id", theRoom.getExtension().getName());
            sfso.putUtfString("ext_className", theRoom.getExtension().getExtensionFileName());
            sfso.putUtfString("ext_Properties", theRoom.getExtension().getPropertiesFileName());
        }
        if (theRoom instanceof MMORoom) {
            final MMORoom mmoRoom = (MMORoom)theRoom;
            final boolean isFloat = mmoRoom.getDefaultAOI().isFloat();
            if (isFloat) {
                sfso.putFloatArray("defaultAOI", mmoRoom.getDefaultAOI().toFloatArray());
                if (mmoRoom.getMapLowerLimit() != null) {
                    sfso.putFloatArray("mapLowLimit", mmoRoom.getMapLowerLimit().toFloatArray());
                    sfso.putFloatArray("mapHighLimit", mmoRoom.getMapHigherLimit().toFloatArray());
                }
            }
            else {
                sfso.putIntArray("defaultAOI", mmoRoom.getDefaultAOI().toIntArray());
                if (mmoRoom.getMapLowerLimit() != null) {
                    sfso.putIntArray("mapLowLimit", mmoRoom.getMapLowerLimit().toIntArray());
                    sfso.putIntArray("mapHighLimit", mmoRoom.getMapHigherLimit().toIntArray());
                }
            }
            sfso.putInt("proximityListUpdateMillis", mmoRoom.getProximityListUpdateMillis());
            sfso.putInt("userMaxLimboSeconds", mmoRoom.getUserLimboMaxSeconds());
            sfso.putBool("sendAOIEntryPoint", mmoRoom.isSendAOIEntryPoint());
        }
        if (storeRoomVars) {
            final ISFSArray rVars = new SFSArray();
            for (final RoomVariable rv : theRoom.getVariables()) {
                if (rv.getOwner() == null) {
                    rVars.addSFSArray(RVSerializer.serialize(rv));
                }
            }
            sfso.putSFSArray("roomVariables", rVars);
        }
        return sfso;
    }
    
    public CreateRoomSettings deserialize(final ISFSObject sfso) {
        final boolean isMMORoom = sfso.containsKey("defaultAOI");
        final CreateRoomSettings crs = isMMORoom ? new CreateMMORoomSettings() : new CreateRoomSettings();
        crs.setName(sfso.getUtfString("name"));
        crs.setGroupId(sfso.getUtfString("groupId"));
        if (sfso.containsKey("password")) {
            crs.setPassword(sfso.getUtfString("password"));
        }
        crs.setMaxUsers(sfso.getInt("maxUsers"));
        crs.setMaxSpectators(sfso.getInt("maxSpectators"));
        crs.setMaxVariablesAllowed(sfso.getInt("maxVariablesAllowed"));
        crs.setDynamic(sfso.getBool("isDynamic"));
        crs.setGame(sfso.getBool("isGame"));
        crs.setHidden(sfso.getBool("isHidden"));
        crs.setAutoRemoveMode(SFSRoomRemoveMode.fromString(sfso.getUtfString("autoRemoveMode")));
        crs.setRoomSettings(this.deserializeFlagSettings(sfso));
        crs.setUseWordsFilter(sfso.getBool("useWordsFilter"));
        crs.setCustomPlayerIdGeneratorClass(this.deserializePlayerIdGenerator(sfso));
        if (sfso.containsKey("ext_id")) {
            final CreateRoomSettings.RoomExtensionSettings res = new CreateRoomSettings.RoomExtensionSettings(sfso.getUtfString("ext_id"), sfso.getUtfString("ext_className"));
            res.setPropertiesFile(sfso.getUtfString("ext_Properties"));
            crs.setExtension(res);
        }
        if (isMMORoom) {
            final CreateMMORoomSettings mmoCrs = (CreateMMORoomSettings)crs;
            final SFSDataWrapper wrapper = sfso.get("defaultAOI");
            final boolean isFloat = wrapper.getTypeId() == SFSDataType.FLOAT_ARRAY;
            Vec3D defaultAOI = null;
            CreateMMORoomSettings.MapLimits mapLimits = null;
            if (isFloat) {
                defaultAOI = Vec3D.fromFloatArray((List)sfso.getFloatArray("defaultAOI"));
                if (sfso.containsKey("mapLowLimit")) {
                    final Vec3D lowLimit = Vec3D.fromFloatArray((List)sfso.getFloatArray("mapLowLimit"));
                    final Vec3D highLimit = Vec3D.fromFloatArray((List)sfso.getFloatArray("mapHighLimit"));
                    mapLimits = new CreateMMORoomSettings.MapLimits(lowLimit, highLimit);
                }
            }
            else {
                defaultAOI = Vec3D.fromIntArray((List)sfso.getIntArray("defaultAOI"));
                if (sfso.containsKey("mapLowLimit")) {
                    final Vec3D lowLimit = Vec3D.fromIntArray((List)sfso.getIntArray("mapLowLimit"));
                    final Vec3D highLimit = Vec3D.fromIntArray((List)sfso.getIntArray("mapHighLimit"));
                    mapLimits = new CreateMMORoomSettings.MapLimits(lowLimit, highLimit);
                }
            }
            mmoCrs.setDefaultAOI(defaultAOI);
            if (mapLimits != null) {
                mmoCrs.setMapLimits(mapLimits);
            }
            mmoCrs.setProximityListUpdateMillis(sfso.getInt("proximityListUpdateMillis"));
            mmoCrs.setUserMaxLimboSeconds(sfso.getInt("userMaxLimboSeconds"));
            mmoCrs.setSendAOIEntryPoint(sfso.getBool("sendAOIEntryPoint"));
        }
        final ISFSArray savedVars = sfso.getSFSArray("roomVariables");
        final List<RoomVariable> roomVariables = new LinkedList<RoomVariable>();
        if (savedVars != null) {
            for (int i = 0; i < savedVars.size(); ++i) {
                roomVariables.add(RVSerializer.deserialize(savedVars.getSFSArray(i)));
            }
        }
        crs.setRoomVariables(roomVariables);
        return crs;
    }
    
    private List<String> serializeFlagSettings(final Room theRoom) {
        final List<String> flags = new LinkedList<String>();
        SFSRoomSettings[] values;
        for (int length = (values = SFSRoomSettings.values()).length, i = 0; i < length; ++i) {
            final SFSRoomSettings item = values[i];
            if (theRoom.isFlagSet(item)) {
                flags.add(item.toString());
            }
        }
        return flags;
    }
    
    private Set<SFSRoomSettings> deserializeFlagSettings(final ISFSObject sfso) {
        final Set<SFSRoomSettings> flags = new HashSet<SFSRoomSettings>();
        final List<String> items = (List<String>)(List)sfso.getUtfStringArray("roomSettings");
        for (final String item : items) {
            flags.add(SFSRoomSettings.valueOf(item));
        }
        return flags;
    }
    
    private Class<? extends IPlayerIdGenerator> deserializePlayerIdGenerator(final ISFSObject sfso) {
        Class<? extends IPlayerIdGenerator> clazz = null;
        try {
            clazz = (Class<? extends IPlayerIdGenerator>)Class.forName(sfso.getUtfString("customPlayerIdGeneratorClass"));
        }
        catch (ClassNotFoundException ex) {}
        return clazz;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

import com.smartfoxserver.v2.db.IDBManager;

public class DBRoomStorageConfig extends BaseStorageConfig
{
    public IDBManager dbManager;
    public String tableName;
    public String testTableExistenceSQL;
    public String createTableSQL;
    public boolean debugSQL;
    public boolean useTextSerialization;
    
    public DBRoomStorageConfig() {
        this.dbManager = null;
        this.tableName = "sfs_room_storage";
        this.testTableExistenceSQL = "SELECT 1 FROM %s";
        this.createTableSQL = "CREATE TABLE %s (`name` varchar(200) NOT NULL,`groupId` varchar(200) NOT NULL,`roomdata` %s NOT NULL,PRIMARY KEY (`name`),KEY `groupId` (`groupId`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
        this.debugSQL = false;
        this.useTextSerialization = false;
    }
}

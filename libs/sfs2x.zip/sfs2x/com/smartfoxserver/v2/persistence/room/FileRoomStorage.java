// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

import com.smartfoxserver.v2.entities.Room;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import org.apache.commons.io.FileUtils;
import com.smartfoxserver.v2.util.CryptoUtils;
import java.io.File;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.Zone;

public class FileRoomStorage implements IRoomStorage
{
    protected final String FILE_EXT = ".room";
    protected final Zone zone;
    protected final SFSRoomSerializer serializer;
    protected final Logger log;
    protected final FileRoomStorageConfig cfg;
    protected String zoneFolderName;
    private final String zoneName;
    
    public FileRoomStorage(final FileRoomStorageConfig config, final Zone zone) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.serializer = new SFSRoomSerializer();
        this.zone = zone;
        this.zoneName = zone.getName();
        this.cfg = config;
        this.initDataFolder();
        if (this.log.isDebugEnabled()) {
            this.log.debug("FileRoomStorage active, " + zone);
        }
    }
    
    private void initDataFolder() {
        final File targetFolder = new File(this.cfg.baseDataFolder);
        if (!this.cfg.baseDataFolder.endsWith("/")) {
            final FileRoomStorageConfig cfg = this.cfg;
            cfg.baseDataFolder = String.valueOf(cfg.baseDataFolder) + "/";
        }
        this.zoneFolderName = String.valueOf(this.cfg.baseDataFolder) + CryptoUtils.getHexFileName(this.zoneName) + "/";
        if (!targetFolder.isDirectory()) {
            try {
                FileUtils.forceMkdir(new File(this.zoneFolderName));
            }
            catch (IOException e) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
                emc.setDescription("Failed to created the Room Storage data directory: " + this.cfg.baseDataFolder);
                emc.addInfo("The RoomStorage service will not be able to load/save data. Please check your configuration as soon as possible.");
                this.log.error(emc.toString());
            }
        }
    }
    
    @Override
    public CreateRoomSettings loadRoom(final String name) throws SFSStorageException {
        String roomFile = null;
        final String encodedRoomName = CryptoUtils.getHexFileName(name);
        for (final String fname : this.getFileList()) {
            if (fname.endsWith(encodedRoomName)) {
                roomFile = fname;
                break;
            }
        }
        if (roomFile == null) {
            throw new SFSStorageException("Cannot find stored Room file for Room named: " + name + ", Zone: " + this.zoneName);
        }
        try {
            final byte[] rawData = FileUtils.readFileToByteArray(new File(String.valueOf(this.zoneFolderName) + roomFile));
            if (this.log.isDebugEnabled()) {
                this.log.debug("Reading room file: " + this.zoneFolderName + roomFile + ", Zone: " + this.zoneName);
            }
            return this.serializer.deserialize(SFSObject.newFromBinaryData(rawData));
        }
        catch (IOException e) {
            throw new SFSStorageException(e);
        }
    }
    
    @Override
    public List<CreateRoomSettings> loadAllRooms() throws SFSStorageException {
        return this.loadAllRooms(null);
    }
    
    @Override
    public List<CreateRoomSettings> loadAllRooms(final String groupId) throws SFSStorageException {
        final List<CreateRoomSettings> allRooms = new LinkedList<CreateRoomSettings>();
        int failureCount = 0;
        for (final String fname : this.getFileList(groupId)) {
            try {
                final byte[] rawData = FileUtils.readFileToByteArray(new File(String.valueOf(this.zoneFolderName) + fname));
                if (this.log.isDebugEnabled()) {
                    this.log.debug("Reading room file: " + this.zoneFolderName + fname + ", Zone: " + this.zoneName);
                }
                allRooms.add(this.serializer.deserialize(SFSObject.newFromBinaryData(rawData)));
            }
            catch (IOException err) {
                this.log.warn(err.toString());
                ++failureCount;
            }
        }
        if (failureCount > 0) {
            this.log.warn("There have been errors while loading Rooms, " + failureCount + " Room(s) where not loaded. See previous errors in the logs.");
        }
        return allRooms;
    }
    
    @Override
    public void saveRoom(final Room theRoom) throws SFSStorageException {
        if (this.cfg.skipStaticRooms && !theRoom.isDynamic()) {
            return;
        }
        if (!this.cfg.storeInactiveRooms && !theRoom.isActive()) {
            return;
        }
        final ISFSObject serialized = this.serializer.serialize(theRoom, this.cfg.storeRoomVariables);
        final byte[] rawData = serialized.toBinary();
        final String localFileName = this.getRoomFileName(theRoom);
        final File roomFile = new File(String.valueOf(this.zoneFolderName) + localFileName);
        try {
            FileUtils.writeByteArrayToFile(roomFile, rawData);
            if (this.log.isDebugEnabled()) {
                this.log.debug("Writing room file: " + this.zoneFolderName + localFileName + ", Zone: " + this.zoneName);
            }
        }
        catch (IOException e) {
            throw new SFSStorageException("I/O Error storing: " + roomFile + ", " + e.toString());
        }
    }
    
    @Override
    public void saveAllRooms() throws SFSStorageException {
        this.saveAllRooms(null);
    }
    
    @Override
    public void saveAllRooms(final String groupId) throws SFSStorageException {
        int failureCount = 0;
        for (final Room theRoom : this.zone.getRoomList()) {
            final boolean saveThisRoom = groupId == null || groupId.equals(theRoom.getGroupId());
            try {
                if (!saveThisRoom) {
                    continue;
                }
                this.saveRoom(theRoom);
            }
            catch (SFSStorageException err) {
                this.log.warn(err.toString());
                ++failureCount;
            }
        }
        if (failureCount > 0) {
            this.log.warn("There have been errors while storing Rooms, " + failureCount + " Room(s) where not saved. See previous errors in the logs.");
        }
    }
    
    @Override
    public void removeAllRooms() throws SFSStorageException {
        this.removeAllRooms(null);
    }
    
    @Override
    public void removeAllRooms(final String groupId) throws SFSStorageException {
        final List<String> failedFiles = new LinkedList<String>();
        for (final String fname : this.getFileList(groupId)) {
            final boolean ok = FileUtils.deleteQuietly(new File(String.valueOf(this.zoneFolderName) + fname));
            if (!ok) {
                failedFiles.add(fname);
            }
            else {
                if (!this.log.isDebugEnabled()) {
                    continue;
                }
                this.log.debug("Removed room file: " + this.zoneFolderName + fname + ", Zone: " + this.zoneName);
            }
        }
        if (failedFiles.size() > 0) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(new SFSStorageException("Error deleting Room Files"));
            emc.addInfo("Some files could not be deleted: " + failedFiles.toString());
            emc.addInfo("Zone: " + this.zoneName + ", directory: " + this.zoneFolderName);
            if (groupId != null) {
                emc.addInfo("GroupId: " + groupId);
            }
            this.log.warn(emc.toString());
        }
    }
    
    @Override
    public void removeRoom(final String name) throws SFSStorageException {
        String roomFile = null;
        final String encodedRoomName = CryptoUtils.getHexFileName(name);
        for (final String fname : this.getFileList()) {
            if (fname.endsWith(encodedRoomName)) {
                roomFile = fname;
                break;
            }
        }
        if (roomFile != null) {
            final File ff = new File(String.valueOf(this.zoneFolderName) + roomFile);
            if (ff.isFile()) {
                final boolean wasDeleted = FileUtils.deleteQuietly(ff);
                if (wasDeleted && this.log.isDebugEnabled()) {
                    this.log.debug("Deleted Room File:" + name + ", " + ff);
                }
                else {
                    this.log.warn("Unable to remove Room File:" + name + ", " + ff);
                }
            }
        }
    }
    
    @Override
    public void destroy() {
    }
    
    private String getRoomFileName(final Room theRoom) {
        return String.valueOf(CryptoUtils.getHexFileName(new StringBuilder(String.valueOf(theRoom.getGroupId())).append(theRoom.getName()).toString())) + ".room";
    }
    
    private List<String> getFileList() {
        return this.getFileList(null);
    }
    
    private List<String> getFileList(final String groupId) {
        final List<String> fileList = new LinkedList<String>();
        final String encodedGroupId = (groupId != null) ? CryptoUtils.getHexFileName(groupId) : null;
        final File storageDir = new File(this.zoneFolderName);
        final File[] allFiles = storageDir.listFiles();
        File[] array;
        for (int length = (array = allFiles).length, i = 0; i < length; ++i) {
            final File ff = array[i];
            if (ff.isFile()) {
                final String fn = ff.getName();
                if (fn.endsWith(".room")) {
                    if (encodedGroupId == null) {
                        fileList.add(fn);
                    }
                    else if (fn.startsWith(encodedGroupId)) {
                        fileList.add(fn);
                    }
                }
            }
        }
        return fileList;
    }
}

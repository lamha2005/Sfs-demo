// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

public enum RoomStorageMode
{
    FILE_STORAGE("FILE_STORAGE", 0), 
    DB_STORAGE("DB_STORAGE", 1);
    
    private RoomStorageMode(final String s, final int n) {
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.persistence.room;

import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.LinkedList;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import java.util.List;
import java.util.Arrays;
import java.sql.SQLException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.db.IDBManager;

public class DBRoomStorage implements IRoomStorage
{
    protected static final String FLD_NAME = "name";
    protected static final String FLD_GROUP_ID = "groupId";
    protected static final String FLD_ROOM_DATA = "roomdata";
    private final IDBManager dbManager;
    protected final DBRoomStorageConfig cfg;
    protected final Zone zone;
    protected final SFSRoomSerializer serializer;
    protected final Logger log;
    
    public DBRoomStorage(final DBRoomStorageConfig cfg, final Zone zone) {
        this.cfg = cfg;
        this.zone = zone;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.dbManager = ((cfg.dbManager != null) ? cfg.dbManager : zone.getDBManager());
        if (this.dbManager == null || !this.dbManager.isActive()) {
            throw new IllegalArgumentException("An active DatabaseManager object is required!");
        }
        this.serializer = new SFSRoomSerializer();
        this.initTable();
    }
    
    private void initTable() {
        try {
            this.checkOrCreateTable();
        }
        catch (SQLException e) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
            emc.setDescription("Failed to created the Room Storage table: " + this.cfg.tableName);
            emc.addInfo("The RoomStorage service will not be able to load/save data. Please check your configuration as soon as possible.");
            this.log.error(emc.toString());
        }
    }
    
    @Override
    public void destroy() {
        if (this.dbManager != this.zone.getDBManager()) {
            this.dbManager.destroy((Object)null);
        }
    }
    
    @Override
    public void removeRoom(final String name) throws SFSStorageException {
        final String sql = String.format("DELETE FROM %s WHERE %s=?", this.cfg.tableName, "name");
        final Object[] params = { name };
        if (this.cfg.debugSQL) {
            this.log.info(String.valueOf(sql) + ", " + Arrays.asList(params));
        }
        try {
            this.dbManager.executeUpdate(sql, params);
        }
        catch (SQLException sqle) {
            throw new SFSStorageException(sqle);
        }
    }
    
    @Override
    public void removeAllRooms() throws SFSStorageException {
        this.removeAllRooms(null);
    }
    
    @Override
    public void removeAllRooms(final String groupId) throws SFSStorageException {
        String sql;
        Object[] params;
        if (groupId != null) {
            sql = String.format("DELETE FROM %s WHERE %s=? ", this.cfg.tableName, "groupId");
            params = new Object[] { groupId };
        }
        else {
            sql = String.format("DELETE FROM %s", this.cfg.tableName);
            params = new Object[0];
        }
        if (this.cfg.debugSQL) {
            this.log.info(String.valueOf(sql) + ", " + Arrays.asList(params));
        }
        try {
            this.dbManager.executeUpdate(sql, params);
        }
        catch (SQLException sqle) {
            throw new SFSStorageException(sqle);
        }
    }
    
    @Override
    public List<CreateRoomSettings> loadAllRooms() throws SFSStorageException {
        return this.loadAllRooms(null);
    }
    
    @Override
    public List<CreateRoomSettings> loadAllRooms(final String groupId) throws SFSStorageException {
        final List<CreateRoomSettings> allRooms = new LinkedList<CreateRoomSettings>();
        String sql = String.format("SELECT %s FROM %s", "roomdata", this.cfg.tableName);
        Object[] params = null;
        ISFSArray res = null;
        if (groupId != null) {
            sql = String.valueOf(sql) + String.format(" WHERE %s=?", "groupId");
            params = new Object[] { groupId };
        }
        else {
            params = new Object[0];
        }
        if (this.cfg.debugSQL) {
            this.log.info(String.valueOf(sql) + ", " + Arrays.asList(params));
        }
        try {
            res = this.dbManager.executeQuery(sql, params);
        }
        catch (SQLException sqle) {
            throw new SFSStorageException(sqle);
        }
        if (res.size() > 0) {
            for (int i = 0; i < res.size(); ++i) {
                try {
                    allRooms.add(this.extractData(res.getSFSObject(i)));
                }
                catch (Exception e) {
                    this.log.warn("Unexpected serialization error while loading Rooms: " + e.toString());
                }
            }
        }
        return allRooms;
    }
    
    @Override
    public CreateRoomSettings loadRoom(final String name) throws SFSStorageException {
        CreateRoomSettings crs = null;
        ISFSArray res = null;
        try {
            final String sql = String.format("SELECT %s FROM %s WHERE %s=?", "roomdata", this.cfg.tableName, "name");
            final Object[] params = { name };
            if (this.cfg.debugSQL) {
                this.log.info(String.valueOf(sql) + ", " + Arrays.asList(params));
            }
            res = this.dbManager.executeQuery(sql, params);
        }
        catch (SQLException sqle) {
            throw new SFSStorageException(sqle);
        }
        if (res.size() > 0) {
            crs = this.extractData(res.getSFSObject(0));
        }
        return crs;
    }
    
    @Override
    public void saveAllRooms() throws SFSStorageException {
        this.saveAllRooms(null);
    }
    
    @Override
    public void saveAllRooms(final String groupId) throws SFSStorageException {
        int failureCount = 0;
        for (final Room theRoom : this.zone.getRoomList()) {
            final boolean saveThisRoom = groupId == null || groupId.equals(theRoom.getGroupId());
            try {
                if (!saveThisRoom) {
                    continue;
                }
                this.saveRoom(theRoom);
            }
            catch (SFSStorageException err) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(err);
                this.log.warn(emc.toString());
                ++failureCount;
            }
        }
        if (failureCount > 0) {
            this.log.warn("There have been errors while storing Rooms, " + failureCount + " Room(s) where not saved. See previous errors in the logs.");
        }
    }
    
    @Override
    public void saveRoom(final Room theRoom) throws SFSStorageException {
        if (this.cfg.skipStaticRooms && !theRoom.isDynamic()) {
            return;
        }
        if (!this.cfg.storeInactiveRooms && !theRoom.isActive()) {
            return;
        }
        try {
            final ISFSObject serialized = this.serializer.serialize(theRoom, this.cfg.storeRoomVariables);
            final Object roomData = this.cfg.useTextSerialization ? serialized.toJson() : serialized.toBinary();
            String sql = String.format("SELECT %s FROM %s WHERE %s=?", "name", this.cfg.tableName, "name");
            final ISFSArray res = this.dbManager.executeQuery(sql, new Object[] { theRoom.getName() });
            Object[] params;
            if (res.size() > 0) {
                sql = String.format("UPDATE %s SET %s=?, %s=? WHERE %s=?", this.cfg.tableName, "groupId", "roomdata", "name");
                params = new Object[] { theRoom.getGroupId(), roomData, theRoom.getName() };
            }
            else {
                sql = String.format("INSERT INTO %s (%s,%s,%s) VALUES (?,?,?)", this.cfg.tableName, "name", "groupId", "roomdata");
                params = new Object[] { theRoom.getName(), theRoom.getGroupId(), roomData };
            }
            if (this.cfg.debugSQL) {
                this.log.info(String.valueOf(sql) + ", " + Arrays.asList(params));
            }
            this.dbManager.executeUpdate(sql, params);
        }
        catch (SQLException sqle) {
            throw new SFSStorageException(sqle);
        }
    }
    
    private CreateRoomSettings extractData(final ISFSObject sfso) {
        if (this.cfg.useTextSerialization) {
            return this.serializer.deserialize(SFSObject.newFromJsonData(sfso.getUtfString("roomdata")));
        }
        final byte[] rawData = sfso.getByteArray("roomdata");
        return this.serializer.deserialize(SFSObject.newFromBinaryData(rawData));
    }
    
    private boolean checkStorageTableExistence() {
        boolean exists = false;
        try {
            final String sql = String.format(this.cfg.testTableExistenceSQL, this.cfg.tableName);
            if (this.cfg.debugSQL) {
                this.log.info(sql);
            }
            this.dbManager.executeQuery(sql, new Object[0]);
            exists = true;
        }
        catch (SQLException ex) {}
        return exists;
    }
    
    private void checkOrCreateTable() throws SQLException {
        if (!this.checkStorageTableExistence()) {
            final String serializationFiledType = this.cfg.useTextSerialization ? "text" : "blob";
            final String sql = String.format(this.cfg.createTableSQL, this.cfg.tableName, serializationFiledType);
            if (this.cfg.debugSQL) {
                this.log.info(sql);
            }
            this.dbManager.executeUpdate(sql, new Object[0]);
        }
    }
}

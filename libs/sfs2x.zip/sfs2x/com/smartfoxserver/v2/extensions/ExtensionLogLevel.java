// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

public enum ExtensionLogLevel
{
    DEBUG("DEBUG", 0), 
    INFO("INFO", 1), 
    WARN("WARN", 2), 
    ERROR("ERROR", 3);
    
    private ExtensionLogLevel(final String s, final int n) {
    }
}

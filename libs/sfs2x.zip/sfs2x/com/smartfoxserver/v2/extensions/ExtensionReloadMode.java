// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

public enum ExtensionReloadMode
{
    AUTO("AUTO", 0), 
    MANUAL("MANUAL", 1), 
    NONE("NONE", 2);
    
    private ExtensionReloadMode(final String s, final int n) {
    }
}

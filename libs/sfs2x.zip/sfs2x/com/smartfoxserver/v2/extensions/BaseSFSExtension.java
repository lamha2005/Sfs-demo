// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import com.smartfoxserver.v2.util.monitor.TraceMessage;
import com.smartfoxserver.v2.entities.User;
import java.util.List;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.core.SFSEventType;
import java.io.InputStream;
import java.io.FileInputStream;
import com.smartfoxserver.v2.core.ISFSEvent;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.api.ISFSApi;
import java.util.Random;
import org.slf4j.Logger;
import java.util.Properties;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.core.ISFSEventListener;

public abstract class BaseSFSExtension implements ISFSExtension, ISFSEventListener
{
    private String name;
    private String fileName;
    private String configFileName;
    private ExtensionLevel level;
    private ExtensionType type;
    private Room parentRoom;
    private Zone parentZone;
    private volatile boolean active;
    private final SmartFoxServer sfs;
    private Properties configProperties;
    private ExtensionReloadMode reloadMode;
    private String currentPath;
    protected volatile int lagSimulationMillis;
    protected volatile int lagOscillation;
    private final Logger logger;
    private Random rnd;
    protected final ISFSApi sfsApi;
    
    public BaseSFSExtension() {
        this.parentRoom = null;
        this.parentZone = null;
        this.lagSimulationMillis = 0;
        this.lagOscillation = 0;
        this.logger = LoggerFactory.getLogger("Extensions");
        this.active = true;
        this.sfs = SmartFoxServer.getInstance();
        this.sfsApi = this.sfs.getAPIManager().getSFSApi();
    }
    
    public String getCurrentFolder() {
        return this.currentPath;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setName(final String name) {
        if (this.name != null) {
            throw new SFSRuntimeException("Cannot redefine name of extension: " + this.toString());
        }
        this.name = name;
        this.currentPath = "extensions/" + name + "/";
    }
    
    @Override
    public String getExtensionFileName() {
        return this.fileName;
    }
    
    @Override
    public Properties getConfigProperties() {
        return this.configProperties;
    }
    
    @Override
    public String getPropertiesFileName() {
        return this.configFileName;
    }
    
    @Override
    public void setPropertiesFileName(final String fileName) throws IOException {
        if (this.configFileName != null) {
            throw new SFSRuntimeException("Cannot redefine properties file name of an extension: " + this.toString());
        }
        boolean isDefault = false;
        if (fileName == null || fileName.length() == 0 || fileName.equals("config.properties")) {
            isDefault = true;
            this.configFileName = "config.properties";
        }
        else {
            this.configFileName = fileName;
        }
        final String fileToLoad = "extensions/" + this.name + "/" + this.configFileName;
        if (isDefault) {
            this.loadDefaultConfigFile(fileToLoad);
        }
        else {
            this.loadCustomConfigFile(fileToLoad);
        }
    }
    
    public ISFSApi getApi() {
        return this.sfsApi;
    }
    
    @Override
    public void handleServerEvent(final ISFSEvent event) throws Exception {
    }
    
    @Override
    public Object handleInternalMessage(final String cmdName, final Object params) {
        return null;
    }
    
    private void loadDefaultConfigFile(final String fileName) {
        this.configProperties = new Properties();
        try {
            this.configProperties.load(new FileInputStream(fileName));
        }
        catch (IOException ex) {}
    }
    
    private void loadCustomConfigFile(final String fileName) throws IOException {
        (this.configProperties = new Properties()).load(new FileInputStream(fileName));
    }
    
    @Override
    public void setExtensionFileName(final String fileName) {
        if (this.fileName != null) {
            throw new SFSRuntimeException("Cannot redefine file name of an extension: " + this.toString());
        }
        this.fileName = fileName;
    }
    
    @Override
    public Room getParentRoom() {
        return this.parentRoom;
    }
    
    @Override
    public void setParentRoom(final Room room) {
        if (this.parentRoom != null) {
            throw new SFSRuntimeException("Cannot redefine parent room of extension: " + this.toString());
        }
        this.parentRoom = room;
    }
    
    @Override
    public Zone getParentZone() {
        return this.parentZone;
    }
    
    @Override
    public void setParentZone(final Zone zone) {
        if (this.parentZone != null) {
            throw new SFSRuntimeException("Cannot redefine parent zone of extension: " + this.toString());
        }
        this.parentZone = zone;
    }
    
    @Override
    public void addEventListener(final SFSEventType eventType, final ISFSEventListener listener) {
        if (this.level == ExtensionLevel.ZONE) {
            this.sfs.getExtensionManager().addZoneEventListener(eventType, listener, this.parentZone);
        }
        else if (this.level == ExtensionLevel.ROOM) {
            this.sfs.getExtensionManager().addRoomEventListener(eventType, listener, this.parentRoom);
        }
    }
    
    @Override
    public void removeEventListener(final SFSEventType eventType, final ISFSEventListener listener) {
        if (this.level == ExtensionLevel.ZONE) {
            this.sfs.getExtensionManager().removeZoneEventListener(eventType, listener, this.parentZone);
        }
        else if (this.level == ExtensionLevel.ROOM) {
            this.sfs.getExtensionManager().removeRoomEventListener(eventType, listener, this.parentRoom);
        }
    }
    
    @Override
    public boolean isActive() {
        return this.active;
    }
    
    @Override
    public void setActive(final boolean flag) {
        this.active = flag;
    }
    
    @Override
    public ExtensionLevel getLevel() {
        return this.level;
    }
    
    @Override
    public void setLevel(final ExtensionLevel level) {
        if (this.level != null) {
            throw new SFSRuntimeException("Cannot change level for extension: " + this.toString());
        }
        this.level = level;
    }
    
    @Override
    public ExtensionType getType() {
        return this.type;
    }
    
    @Override
    public void setType(final ExtensionType type) {
        if (this.type != null) {
            throw new SFSRuntimeException("Cannot change type for extension: " + this.toString());
        }
        this.type = type;
    }
    
    @Override
    public ExtensionReloadMode getReloadMode() {
        return this.reloadMode;
    }
    
    @Override
    public void setReloadMode(final ExtensionReloadMode mode) {
        if (this.reloadMode != null) {
            throw new SFSRuntimeException("Cannot change reloadMode for extension: " + this.toString());
        }
        this.reloadMode = mode;
    }
    
    @Override
    public void send(final String cmdName, final ISFSObject params, final List<User> recipients) {
        this.send(cmdName, params, recipients, false);
    }
    
    @Override
    public void send(final String cmdName, final ISFSObject params, final User recipient) {
        this.send(cmdName, params, recipient, false);
    }
    
    @Override
    public void send(final String cmdName, final ISFSObject params, final List<User> recipients, final boolean useUDP) {
        if (useUDP) {
            params.removeElement("$FS_REQUEST_UDP_TIMESTAMP");
        }
        this.checkLagSimulation();
        final Room room = (this.level == ExtensionLevel.ROOM) ? this.parentRoom : null;
        this.sfsApi.sendExtensionResponse(cmdName, params, recipients, room, useUDP);
    }
    
    @Override
    public void send(final String cmdName, final ISFSObject params, final User recipient, final boolean useUDP) {
        if (useUDP) {
            params.removeElement("$FS_REQUEST_UDP_TIMESTAMP");
        }
        this.checkLagSimulation();
        final Room room = (this.level == ExtensionLevel.ROOM) ? this.parentRoom : null;
        this.sfsApi.sendExtensionResponse(cmdName, params, recipient, room, useUDP);
    }
    
    @Override
    public String toString() {
        return String.format("{ Ext: %s, Type: %s, Lev: %s, %s, %s }", this.name, this.type, this.level, this.parentZone, (this.parentRoom == null) ? "{}" : this.parentRoom);
    }
    
    public Logger getLogger() {
        return this.logger;
    }
    
    public void trace(final Object... args) {
        this.trace(ExtensionLogLevel.INFO, args);
    }
    
    public void trace(final ExtensionLogLevel level, final Object... args) {
        final String traceMsg = this.getTraceMessage(args);
        if (level == ExtensionLogLevel.DEBUG) {
            this.logger.debug(traceMsg);
        }
        else if (level == ExtensionLogLevel.INFO) {
            this.logger.info(traceMsg);
        }
        else if (level == ExtensionLogLevel.WARN) {
            this.logger.warn(traceMsg);
        }
        else if (level == ExtensionLogLevel.ERROR) {
            this.logger.error(traceMsg);
        }
        this.sfs.getTraceMonitor().handleTraceMessage(new TraceMessage(this.parentZone, this.parentRoom, level, traceMsg));
    }
    
    private String getTraceMessage(final Object[] args) {
        final StringBuilder traceMsg = new StringBuilder().append("{").append(this.name).append("}: ");
        for (final Object o : args) {
            traceMsg.append(o.toString()).append(" ");
        }
        return traceMsg.toString();
    }
    
    protected void removeEventsForListener(final ISFSEventListener listener) {
        if (this.level == ExtensionLevel.ZONE) {
            this.sfs.getExtensionManager().removeListenerFromZone(listener, this.parentZone);
        }
        else if (this.level == ExtensionLevel.ROOM) {
            this.sfs.getExtensionManager().removeListenerFromRoom(listener, this.parentRoom);
        }
    }
    
    private void checkLagSimulation() {
        if (this.lagSimulationMillis > 0) {
            try {
                long lagValue = this.lagSimulationMillis;
                if (this.lagOscillation > 0) {
                    if (this.rnd == null) {
                        this.rnd = new Random();
                    }
                    final int sign = (this.rnd.nextInt(100) > 49) ? 1 : -1;
                    lagValue += sign * this.rnd.nextInt(this.lagOscillation);
                }
                if (this.logger.isDebugEnabled()) {
                    this.logger.debug("Lag simulation, sleeping for: " + lagValue + "ms.");
                }
                Thread.sleep(lagValue);
            }
            catch (InterruptedException e) {
                this.logger.warn("Interruption during lag simulation: " + e);
            }
        }
    }
}

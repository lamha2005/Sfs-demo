// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import java.util.List;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.core.ISFSEventListener;
import com.smartfoxserver.v2.core.SFSEventType;
import java.util.Properties;
import java.io.IOException;

public interface ISFSExtension
{
    void init();
    
    void destroy();
    
    String getName();
    
    void setName(final String p0);
    
    String getExtensionFileName();
    
    void setExtensionFileName(final String p0);
    
    String getPropertiesFileName();
    
    void setPropertiesFileName(final String p0) throws IOException;
    
    Properties getConfigProperties();
    
    boolean isActive();
    
    void setActive(final boolean p0);
    
    void addEventListener(final SFSEventType p0, final ISFSEventListener p1);
    
    void removeEventListener(final SFSEventType p0, final ISFSEventListener p1);
    
    void setLevel(final ExtensionLevel p0);
    
    ExtensionLevel getLevel();
    
    ExtensionType getType();
    
    void setType(final ExtensionType p0);
    
    Zone getParentZone();
    
    void setParentZone(final Zone p0);
    
    Room getParentRoom();
    
    void setParentRoom(final Room p0);
    
    ExtensionReloadMode getReloadMode();
    
    void setReloadMode(final ExtensionReloadMode p0);
    
    void handleClientRequest(final String p0, final User p1, final ISFSObject p2) throws SFSException;
    
    Object handleInternalMessage(final String p0, final Object p1);
    
    void send(final String p0, final ISFSObject p1, final User p2, final boolean p3);
    
    void send(final String p0, final ISFSObject p1, final User p2);
    
    void send(final String p0, final ISFSObject p1, final List<User> p2, final boolean p3);
    
    void send(final String p0, final ISFSObject p1, final List<User> p2);
}

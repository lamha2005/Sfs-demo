// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions.filter;

public enum FilterAction
{
    CONTINUE("CONTINUE", 0), 
    HALT("HALT", 1);
    
    private FilterAction(final String s, final int n) {
    }
}

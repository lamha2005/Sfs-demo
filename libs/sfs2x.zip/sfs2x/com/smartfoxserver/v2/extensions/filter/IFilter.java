// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions.filter;

import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.extensions.SFSExtension;

public interface IFilter
{
    void init(final SFSExtension p0);
    
    void destroy();
    
    FilterAction handleClientRequest(final String p0, final User p1, final ISFSObject p2) throws SFSException;
    
    FilterAction handleServerEvent(final ISFSEvent p0) throws SFSException;
}

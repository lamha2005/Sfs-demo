// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions.filter;

import com.smartfoxserver.v2.extensions.ExtensionLogLevel;
import com.smartfoxserver.v2.extensions.SFSExtension;

public abstract class SFSExtensionFilter implements IFilter
{
    private String name;
    protected SFSExtension parentExtension;
    
    @Override
    public void init(final SFSExtension ext) {
        this.parentExtension = ext;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    protected void trace(final Object... args) {
        this.parentExtension.trace(args);
    }
    
    protected void trace(final ExtensionLogLevel level, final Object... args) {
        this.parentExtension.trace(level, args);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions.filter;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.core.ISFSEvent;
import java.util.Iterator;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.smartfoxserver.v2.extensions.SFSExtension;
import java.util.Collection;

public class SFSExtensionFilterChain implements IFilterChain
{
    private final Collection<SFSExtensionFilter> filters;
    private final SFSExtension parentExtension;
    private final Logger log;
    
    public SFSExtensionFilterChain(final SFSExtension parentExtension) {
        this.parentExtension = parentExtension;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.filters = new ConcurrentLinkedQueue<SFSExtensionFilter>();
    }
    
    @Override
    public void addFilter(final String filterName, final SFSExtensionFilter filter) {
        if (this.filters.contains(filter)) {
            throw new SFSRuntimeException("A filter with the same name already exists: " + filterName + ", Ext: " + this.parentExtension);
        }
        filter.setName(filterName);
        filter.init(this.parentExtension);
        this.filters.add(filter);
    }
    
    @Override
    public void remove(final String filterName) {
        final Iterator<SFSExtensionFilter> it = this.filters.iterator();
        while (it.hasNext()) {
            final SFSExtensionFilter filter = it.next();
            if (filter.getName().equals(filterName)) {
                it.remove();
                break;
            }
        }
    }
    
    @Override
    public FilterAction runEventInChain(final ISFSEvent event) throws SFSException {
        FilterAction filterAction = FilterAction.CONTINUE;
        for (final SFSExtensionFilter filter : this.filters) {
            try {
                filterAction = filter.handleServerEvent(event);
                if (filterAction == FilterAction.HALT) {
                    break;
                }
                continue;
            }
            catch (SFSException sfsEx) {
                throw sfsEx;
            }
            catch (Exception e) {
                this.log.warn(String.format("Exception in FilterChain execution:%s --- Filter: %s, Event: %s, Ext: %s", e.toString(), filter.getName(), event, this.parentExtension));
            }
        }
        return filterAction;
    }
    
    @Override
    public FilterAction runRequestInChain(final String requestId, final User sender, final ISFSObject params) {
        FilterAction filterAction = FilterAction.CONTINUE;
        for (final SFSExtensionFilter filter : this.filters) {
            try {
                filterAction = filter.handleClientRequest(requestId, sender, params);
                if (filterAction == FilterAction.HALT) {
                    break;
                }
                continue;
            }
            catch (Exception e) {
                this.log.warn(String.format("Exception in FilterChain execution:%s --- Filter: %s, Req: %s, Ext: %s", e.toString(), filter.getName(), requestId, this.parentExtension));
            }
        }
        return filterAction;
    }
    
    @Override
    public int size() {
        return this.filters.size();
    }
    
    @Override
    public void destroy() {
        for (final SFSExtensionFilter filter : this.filters) {
            filter.destroy();
        }
        this.filters.clear();
    }
}

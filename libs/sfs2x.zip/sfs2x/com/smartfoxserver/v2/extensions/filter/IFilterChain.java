// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions.filter;

import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;

public interface IFilterChain
{
    void addFilter(final String p0, final SFSExtensionFilter p1);
    
    void remove(final String p0);
    
    FilterAction runRequestInChain(final String p0, final User p1, final ISFSObject p2);
    
    FilterAction runEventInChain(final ISFSEvent p0) throws SFSException;
    
    int size();
    
    void destroy();
}

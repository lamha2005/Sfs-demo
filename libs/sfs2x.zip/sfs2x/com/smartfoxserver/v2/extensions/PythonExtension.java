// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import java.io.IOException;
import org.apache.commons.io.FileUtils;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.exceptions.SFSException;
import org.python.core.PyJavaInstance;
import org.python.core.PyString;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import java.util.Properties;
import java.io.File;
import org.slf4j.LoggerFactory;
import org.python.core.PyObject;
import org.python.util.PythonInterpreter;
import org.slf4j.Logger;

public final class PythonExtension extends BaseSFSExtension
{
    public static final String py_path = "./extensions/";
    private final Logger log;
    private PythonInterpreter interp;
    private PyObject fnInit;
    private PyObject fnDestroy;
    private PyObject fnHandleClientRequest;
    private PyObject fnHandleMessage;
    
    public PythonExtension() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        final File f = new File("./extensions/");
        final Properties props = new Properties();
        props.setProperty("python.path", f.getAbsolutePath());
        PythonInterpreter.initialize(System.getProperties(), props, new String[0]);
        this.interp = new PythonInterpreter();
    }
    
    @Override
    public void init() {
        try {
            this.loadPyScript();
            this.fnInit.__call__();
        }
        catch (Exception e) {
            this.log.warn("Failed initializing Python Extension: " + this.getName() + " -> " + e);
        }
    }
    
    @Override
    public void destroy() {
        try {
            this.fnDestroy.__call__();
        }
        catch (Exception e) {
            this.log.warn("Failed destroying Python Extension: " + this.getName() + " -> " + e);
        }
    }
    
    @Override
    public void handleClientRequest(final String cmdName, final User sender, final ISFSObject params) throws SFSException {
        try {
            final PyObject[] args = { new PyString(cmdName), new PyJavaInstance((Object)sender), new PyJavaInstance((Object)params) };
            this.fnHandleClientRequest.__call__(args);
        }
        catch (Exception e) {
            this.log.warn("handleClientRequest error in Python Extension: " + this.getName() + " -> " + e);
        }
    }
    
    @Override
    public Object handleInternalMessage(final String cmdName, final Object params) {
        try {
            final PyObject[] args = { new PyString(cmdName), new PyJavaInstance(params) };
            this.fnHandleMessage.__call__(args);
        }
        catch (Exception e) {
            this.log.warn("handleInternalMessage error in Python Extension: " + this.getName() + " -> " + e);
        }
        return null;
    }
    
    private void loadPyScript() throws Exception {
        final String sourceFilePath = "extensions/" + this.getName() + "/" + this.getExtensionFileName();
        final String pyScript = this.loadSourceCode(sourceFilePath);
        this.interp.exec(pyScript);
        this.interp.set("_sfsApi", (PyObject)new PyJavaInstance((Object)this.sfsApi));
        this.interp.set("_base", (PyObject)new PyJavaInstance((Object)this));
        this.interp.set("_sfs", (Object)SmartFoxServer.getInstance());
        this.interp.set("_sfsGameApi", (Object)SmartFoxServer.getInstance().getAPIManager().getGameApi());
        final String fnTraceCode = "def trace(*args):\n\tfrom java.lang import Object\n\tfrom jarray import array\n\t_base.trace(array(args, Object))\n";
        this.interp.exec(fnTraceCode);
        this.fnInit = this.interp.get("init");
        this.fnDestroy = this.interp.get("destroy");
        this.fnHandleClientRequest = this.interp.get("handleClientRequest");
        this.fnHandleMessage = this.interp.get("handleInternalMessage");
    }
    
    private String loadSourceCode(final String sourceFilePath) throws IOException {
        return FileUtils.readFileToString(new File(sourceFilePath));
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

public enum ExtensionType
{
    JAVA("JAVA", 0), 
    JAVASCRIPT("JAVASCRIPT", 1), 
    PYTHON("PYTHON", 2);
    
    private ExtensionType(final String s, final int n) {
    }
}

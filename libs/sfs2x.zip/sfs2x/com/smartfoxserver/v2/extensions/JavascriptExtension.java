// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.File;
import org.mozilla.javascript.Script;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import org.mozilla.javascript.ScriptableObject;
import java.io.Reader;
import java.io.StringReader;
import org.mozilla.javascript.Context;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;

public final class JavascriptExtension extends BaseSFSExtension
{
    private boolean isInited;
    private Scriptable scope;
    private String scriptSourceCode;
    private Function fnInit;
    private Function fnDestroy;
    private Function fnHandleClientRequest;
    
    public JavascriptExtension() {
        this.isInited = false;
    }
    
    @Override
    public void init() {
        this.loadScript();
        this.invokeFunction(this.fnInit, new Object[] { this.sfsApi, this });
    }
    
    @Override
    public void destroy() {
        this.invokeFunction(this.fnDestroy, new Object[0]);
    }
    
    @Override
    public void handleClientRequest(final String cmdName, final User sender, final ISFSObject params) {
        this.invokeFunction(this.fnHandleClientRequest, new Object[] { cmdName, sender, params });
    }
    
    @Override
    public void handleServerEvent(final ISFSEvent event) throws Exception {
    }
    
    public void fireLoginException(final String message, final SFSErrorData data) throws SFSLoginException {
        throw new SFSLoginException(message, data);
    }
    
    private void loadScript() {
        try {
            final Context cx = Context.enter();
            final String sourceFilePath = "extensions/" + this.getName() + "/" + this.getExtensionFileName();
            this.scriptSourceCode = this.loadSourceCode(sourceFilePath);
            final Script compiledScript = cx.compileReader((Reader)new StringReader(this.scriptSourceCode), sourceFilePath, 1, (Object)null);
            this.scope = cx.initStandardObjects((ScriptableObject)null);
            cx.setOptimizationLevel(9);
            compiledScript.exec(cx, this.scope);
            this.fnInit = (Function)this.scope.get("init", this.scope);
            this.fnDestroy = (Function)this.scope.get("destroy", this.scope);
            this.fnHandleClientRequest = (Function)this.scope.get("handleClientRequest", this.scope);
            this.isInited = true;
        }
        catch (Exception err) {
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(err);
            msg.setDescription("Error while initializing Javascript extension");
            this.trace(msg.toString(), ExtensionLogLevel.WARN);
            return;
        }
        finally {
            Context.exit();
        }
        Context.exit();
    }
    
    private String loadSourceCode(final String sourceFilePath) throws IOException {
        return FileUtils.readFileToString(new File(sourceFilePath));
    }
    
    private void invokeFunction(final Function fn, final Object[] params) {
        if (!this.isInited) {
            throw new SFSRuntimeException("Cannot call extension: " + this.getName() + " - Extension was not inited correctly, please check the logs.");
        }
        try {
            final Context cx = Context.enter();
            fn.call(cx, this.scope, this.scope, params);
            Context.exit();
        }
        catch (Exception err) {
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(err);
            this.trace(msg.toString(), ExtensionLogLevel.WARN);
        }
    }
}

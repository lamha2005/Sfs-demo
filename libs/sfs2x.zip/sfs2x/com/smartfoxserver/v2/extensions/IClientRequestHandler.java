// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;

public interface IClientRequestHandler
{
    void handleClientRequest(final User p0, final ISFSObject p1);
    
    void setParentExtension(final SFSExtension p0);
    
    SFSExtension getParentExtension();
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

public enum ExtensionLevel
{
    ZONE("ZONE", 0), 
    ROOM("ROOM", 1), 
    GLOBAL("GLOBAL", 2);
    
    private ExtensionLevel(final String s, final int n) {
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.core.ISFSEvent;

public interface IServerEventHandler
{
    void handleServerEvent(final ISFSEvent p0) throws SFSException;
    
    void setParentExtension(final SFSExtension p0);
    
    SFSExtension getParentExtension();
}

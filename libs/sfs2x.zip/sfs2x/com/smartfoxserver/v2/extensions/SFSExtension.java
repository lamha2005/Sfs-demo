// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import com.smartfoxserver.v2.extensions.filter.SFSExtensionFilter;
import com.smartfoxserver.v2.core.ISFSEvent;
import java.lang.annotation.Annotation;
import com.smartfoxserver.v2.annotations.MultiHandler;
import com.smartfoxserver.v2.extensions.filter.FilterAction;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.core.ISFSEventListener;
import com.smartfoxserver.v2.extensions.filter.SFSExtensionFilterChain;
import com.smartfoxserver.v2.extensions.filter.IFilterChain;

public abstract class SFSExtension extends BaseSFSExtension
{
    public static final String MULTIHANDLER_REQUEST_ID = "__[[REQUEST_ID]]__";
    private final IHandlerFactory handlerFactory;
    private final IFilterChain filterChain;
    
    public SFSExtension() {
        this.handlerFactory = new SFSHandlerFactory(this);
        this.filterChain = new SFSExtensionFilterChain(this);
    }
    
    @Override
    public void destroy() {
        this.handlerFactory.clearAll();
        this.filterChain.destroy();
        this.removeEventsForListener(this);
    }
    
    protected void addRequestHandler(final String requestId, final Class<?> theClass) {
        if (!IClientRequestHandler.class.isAssignableFrom(theClass)) {
            throw new SFSRuntimeException(String.format("Provided Request Handler does not implement IClientRequestHandler: %s, Cmd: %s", theClass, requestId));
        }
        this.handlerFactory.addHandler(requestId, theClass);
    }
    
    protected void addRequestHandler(final String requestId, final IClientRequestHandler requestHandler) {
        this.handlerFactory.addHandler(requestId, requestHandler);
    }
    
    protected void addEventHandler(final SFSEventType eventType, final Class<?> theClass) {
        if (!IServerEventHandler.class.isAssignableFrom(theClass)) {
            throw new SFSRuntimeException(String.format("Provided Event Handler does not implement IServerEventHandler: %s, Cmd: %s", theClass, eventType.toString()));
        }
        this.addEventListener(eventType, this);
        this.handlerFactory.addHandler(eventType.toString(), theClass);
    }
    
    protected void addEventHandler(final SFSEventType eventType, final IServerEventHandler handler) {
        this.addEventListener(eventType, this);
        this.handlerFactory.addHandler(eventType.toString(), handler);
    }
    
    protected void removeRequestHandler(final String requestId) {
        this.handlerFactory.removeHandler(requestId);
    }
    
    protected void removeEventHandler(final SFSEventType eventType) {
        this.removeEventListener(eventType, this);
        this.handlerFactory.removeHandler(eventType.toString());
    }
    
    protected void clearAllHandlers() {
        this.handlerFactory.clearAll();
    }
    
    @Override
    public void handleClientRequest(final String requestId, final User sender, final ISFSObject params) {
        if (this.filterChain.size() > 0 && this.filterChain.runRequestInChain(requestId, sender, params) == FilterAction.HALT) {
            return;
        }
        try {
            final IClientRequestHandler handler = (IClientRequestHandler)this.handlerFactory.findHandler(requestId);
            if (handler == null) {
                throw new SFSRuntimeException("Request handler not found: '" + requestId + "'. Make sure the handler is registered in your extension using addRequestHandler()");
            }
            if (handler.getClass().isAnnotationPresent(MultiHandler.class)) {
                final String[] requestNameTokens = requestId.split("\\.");
                params.putUtfString("__[[REQUEST_ID]]__", requestNameTokens[requestNameTokens.length - 1]);
            }
            handler.handleClientRequest(sender, params);
        }
        catch (InstantiationException err) {
            this.trace(ExtensionLogLevel.WARN, "Cannot instantiate handler class: " + err);
        }
        catch (IllegalAccessException err2) {
            this.trace(ExtensionLogLevel.WARN, "Illegal access for handler class: " + err2);
        }
    }
    
    @Override
    public void handleServerEvent(final ISFSEvent event) throws Exception {
        final String handlerId = event.getType().toString();
        if (this.filterChain.size() > 0 && this.filterChain.runEventInChain(event) == FilterAction.HALT) {
            return;
        }
        try {
            final IServerEventHandler handler = (IServerEventHandler)this.handlerFactory.findHandler(handlerId);
            if (handler == null) {
                if (this.getLevel() == ExtensionLevel.ROOM && this.getParentZone().getRoomById(this.getParentRoom().getId()) == null) {
                    return;
                }
                throw new SFSRuntimeException("Event handler not found: '" + handlerId + "'. Make sure the handler is registered in your extension using addEventHandler()");
            }
            else {
                Thread.currentThread().setContextClassLoader(handler.getClass().getClassLoader());
                handler.handleServerEvent(event);
            }
        }
        catch (InstantiationException err) {
            this.trace(ExtensionLogLevel.WARN, "Cannot instantiate handler class: " + err);
        }
        catch (IllegalAccessException err2) {
            this.trace(ExtensionLogLevel.WARN, "Illegal access for handler class: " + err2);
        }
    }
    
    public final void addFilter(final String filterName, final SFSExtensionFilter filter) {
        this.filterChain.addFilter(filterName, filter);
    }
    
    public void removeFilter(final String filterName) {
        this.filterChain.remove(filterName);
    }
    
    public void clearFilters() {
        this.filterChain.destroy();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import java.lang.annotation.Annotation;
import com.smartfoxserver.v2.annotations.MultiHandler;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import com.smartfoxserver.v2.annotations.Instantiation;

@Instantiation(Instantiation.InstantiationMode.NEW_INSTANCE)
public class SFSHandlerFactory implements IHandlerFactory
{
    private static final String DOT_SEPARATOR = ".";
    private final Map<String, Class<?>> handlers;
    private final Map<String, Object> cachedHandlers;
    private final SFSExtension parentExtension;
    
    public SFSHandlerFactory(final SFSExtension parentExtension) {
        this.handlers = new ConcurrentHashMap<String, Class<?>>();
        this.cachedHandlers = new ConcurrentHashMap<String, Object>();
        this.parentExtension = parentExtension;
    }
    
    @Override
    public void addHandler(final String handlerKey, final Class<?> handlerClass) {
        this.handlers.put(handlerKey, handlerClass);
    }
    
    @Override
    public void addHandler(final String handlerKey, final Object requestHandler) {
        this.setHandlerParentExtension(requestHandler);
        this.cachedHandlers.put(handlerKey, requestHandler);
    }
    
    @Override
    public synchronized void clearAll() {
        this.handlers.clear();
        this.cachedHandlers.clear();
    }
    
    @Override
    public synchronized void removeHandler(final String handlerKey) {
        this.handlers.remove(handlerKey);
        if (this.cachedHandlers.containsKey(handlerKey)) {
            this.cachedHandlers.remove(handlerKey);
        }
    }
    
    @Override
    public Object findHandler(String key) throws InstantiationException, IllegalAccessException {
        Object handler = this.getHandlerInstance(key);
        if (handler == null) {
            final int lastDotPos = key.lastIndexOf(".");
            if (lastDotPos > 0) {
                key = key.substring(0, lastDotPos);
            }
            handler = this.getHandlerInstance(key);
            if (handler != null && !handler.getClass().isAnnotationPresent(MultiHandler.class)) {
                handler = null;
            }
        }
        return handler;
    }
    
    private Object getHandlerInstance(final String key) throws InstantiationException, IllegalAccessException {
        Object handler = this.cachedHandlers.get(key);
        if (handler != null) {
            return handler;
        }
        final Class<?> handlerClass = this.handlers.get(key);
        if (handlerClass == null) {
            return null;
        }
        handler = handlerClass.newInstance();
        this.setHandlerParentExtension(handler);
        if (handlerClass.isAnnotationPresent(Instantiation.class)) {
            final Instantiation instAnnotation = handlerClass.getAnnotation(Instantiation.class);
            if (instAnnotation.value() == Instantiation.InstantiationMode.SINGLE_INSTANCE) {
                this.cachedHandlers.put(key, handler);
            }
        }
        return handler;
    }
    
    private void setHandlerParentExtension(final Object handler) {
        if (handler instanceof IClientRequestHandler) {
            ((IClientRequestHandler)handler).setParentExtension(this.parentExtension);
        }
        else if (handler instanceof IServerEventHandler) {
            ((IServerEventHandler)handler).setParentExtension(this.parentExtension);
        }
    }
}

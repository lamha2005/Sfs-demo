// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.extensions;

import org.slf4j.Logger;
import java.util.List;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.api.ISFSApi;

public abstract class BaseClientRequestHandler implements IClientRequestHandler
{
    private SFSExtension parentExtension;
    
    @Override
    public SFSExtension getParentExtension() {
        return this.parentExtension;
    }
    
    @Override
    public void setParentExtension(final SFSExtension ext) {
        this.parentExtension = ext;
    }
    
    protected ISFSApi getApi() {
        return this.parentExtension.sfsApi;
    }
    
    protected void send(final String cmdName, final ISFSObject params, final User recipient) {
        this.parentExtension.send(cmdName, params, recipient);
    }
    
    protected void send(final String cmdName, final ISFSObject params, final List<User> recipients) {
        this.parentExtension.send(cmdName, params, recipients);
    }
    
    protected void send(final String cmdName, final ISFSObject params, final User recipient, final boolean useUDP) {
        this.parentExtension.send(cmdName, params, recipient, useUDP);
    }
    
    protected void send(final String cmdName, final ISFSObject params, final List<User> recipients, final boolean useUDP) {
        this.parentExtension.send(cmdName, params, recipients, useUDP);
    }
    
    protected void trace(final Object... args) {
        this.parentExtension.trace(args);
    }
    
    protected void trace(final ExtensionLogLevel level, final Object... args) {
        this.parentExtension.trace(level, args);
    }
    
    protected Logger getLogger() {
        return this.parentExtension.getLogger();
    }
}

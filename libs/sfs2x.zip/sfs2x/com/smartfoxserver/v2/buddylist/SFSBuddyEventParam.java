// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.core.ISFSEventParam;

public enum SFSBuddyEventParam implements ISFSEventParam
{
    BUDDY("BUDDY", 0), 
    BUDDY_LIST("BUDDY_LIST", 1), 
    BUDDY_BLOCK_STAUTS("BUDDY_BLOCK_STAUTS", 2), 
    BUDDY_STATE("BUDDY_STATE", 3), 
    BUDDY_IS_ONLINE("BUDDY_IS_ONLINE", 4);
    
    private SFSBuddyEventParam(final String s, final int n) {
    }
}

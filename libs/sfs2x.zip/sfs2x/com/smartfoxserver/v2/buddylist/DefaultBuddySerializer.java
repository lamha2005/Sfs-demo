// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;

public class DefaultBuddySerializer implements IBuddySerializer
{
    @Override
    public ISFSArray serialize(final Buddy buddy) {
        final ISFSArray buddyData = new SFSArray();
        final User relatedUser = this.getRelatedUser(buddy);
        buddyData.addInt((relatedUser != null) ? relatedUser.getId() : -1);
        buddyData.addUtfString(buddy.getName());
        buddyData.addBool(buddy.isBlocked());
        buddyData.addSFSArray(buddy.getBuddyVariablesData());
        if (buddy.isTemp()) {
            buddyData.addBool(true);
        }
        return buddyData;
    }
    
    private User getRelatedUser(final Buddy buddy) {
        final Zone zone = buddy.getParentBuddyList().getBuddyListManager().getZone();
        return zone.getUserByName(buddy.getName());
    }
}

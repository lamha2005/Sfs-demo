// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist.storage;

import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.List;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.SFSBuddyListNotFoundException;
import com.smartfoxserver.v2.buddylist.BuddyList;

public interface BuddyStorage
{
    void init();
    
    void destroy();
    
    BuddyList loadList(final String p0) throws SFSBuddyListNotFoundException, IOException;
    
    void saveList(final BuddyList p0) throws IOException;
    
    List<BuddyVariable> getOfflineVariables(final String p0) throws IOException;
    
    BuddyListManager getBuddyListManager();
    
    void setBuddyListManager(final BuddyListManager p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist.storage;

import com.smartfoxserver.v2.buddylist.SFSBuddyVariable;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.buddylist.Buddy;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.buddylist.SFSBuddy;
import com.smartfoxserver.v2.buddylist.SFSBuddyList;
import com.smartfoxserver.v2.entities.data.SFSObject;
import org.apache.commons.io.FileUtils;
import com.smartfoxserver.v2.exceptions.SFSBuddyListNotFoundException;
import java.io.File;
import com.smartfoxserver.v2.util.CryptoUtils;
import com.smartfoxserver.v2.buddylist.BuddyList;
import java.io.IOException;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import org.slf4j.Logger;

public class FSBuddyStorage implements BuddyStorage
{
    private static final String BL_ROOT_FOLDER = "buddylists/";
    private static final String KEY_LIST_OWNER = "lo";
    private static final String KEY_MY_VARIABLES = "mv";
    private static final String KEY_BUDDY_LIST = "bl";
    private static final String KEY_BUDDY_NAME = "bn";
    private static final String KEY_BUDDY_BLOCK = "bb";
    private final Logger log;
    private BuddyListManager buddyListManager;
    private String blistFolderName;
    private boolean inited;
    
    public FSBuddyStorage() {
        this.inited = false;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void init() {
        try {
            this.checkFolderStructure();
            this.inited = true;
        }
        catch (IOException ioErr) {
            this.log.warn("Was not able to initialize BuddyStorage: " + ioErr);
        }
    }
    
    @Override
    public void destroy() {
    }
    
    @Override
    public BuddyList loadList(final String ownerName) throws SFSBuddyListNotFoundException, IOException {
        this.checkInited();
        final String targetFileName = String.valueOf(this.blistFolderName) + "/" + CryptoUtils.getHexFileName(ownerName);
        final File targetFile = new File(targetFileName);
        if (!targetFile.isFile()) {
            throw new SFSBuddyListNotFoundException("BuddyList not found for: " + ownerName);
        }
        final ISFSObject serializedBuddyList = SFSObject.newFromBinaryData(FileUtils.readFileToByteArray(targetFile));
        final BuddyList buddyList = new SFSBuddyList(serializedBuddyList.getUtfString("lo"), this.buddyListManager);
        final ISFSArray buddyArray = serializedBuddyList.getSFSArray("bl");
        for (int i = 0; i < buddyArray.size(); ++i) {
            final ISFSObject buddyItem = buddyArray.getSFSObject(i);
            final Buddy buddy = new SFSBuddy(buddyItem.getUtfString("bn"));
            buddy.setParentBuddyList(buddyList);
            buddy.setBlocked(buddyItem.getBool("bb"));
            try {
                buddyList.addBuddy(buddy);
            }
            catch (SFSBuddyListException ex) {}
        }
        return buddyList;
    }
    
    @Override
    public void saveList(final BuddyList buddyList) throws IOException {
        this.checkInited();
        final ISFSObject serializedBuddyList = SFSObject.newInstance();
        final ISFSArray buddyArray = SFSArray.newInstance();
        final ISFSArray buddyVarsArray = SFSArray.newInstance();
        for (final Buddy buddy : buddyList.getBuddies()) {
            if (buddy.isTemp()) {
                continue;
            }
            final ISFSObject buddyObj = SFSObject.newInstance();
            buddyObj.putUtfString("bn", buddy.getName());
            buddyObj.putBool("bb", buddy.isBlocked());
            buddyArray.addSFSObject(buddyObj);
        }
        if (this.buddyListManager.allowOfflineBuddyVariables()) {
            final List<BuddyVariable> myBuddyVars = buddyList.getOwner().getBuddyProperties().getVariables();
            if (myBuddyVars != null) {
                for (final BuddyVariable bv : myBuddyVars) {
                    if (bv.isOffline()) {
                        buddyVarsArray.addSFSArray(bv.toSFSArray());
                    }
                }
            }
        }
        serializedBuddyList.putUtfString("lo", buddyList.getOwnerName());
        serializedBuddyList.putSFSArray("bl", buddyArray);
        serializedBuddyList.putSFSArray("mv", buddyVarsArray);
        final String fileName = CryptoUtils.getHexFileName(buddyList.getOwnerName());
        final byte[] data = serializedBuddyList.toBinary();
        FileUtils.writeByteArrayToFile(new File(String.valueOf(this.blistFolderName) + "/" + fileName), data);
        if (this.log.isDebugEnabled()) {
            this.log.debug("BuddyList saved: " + buddyList.getOwnerName() + ", " + data.length + " bytes written.");
        }
    }
    
    @Override
    public List<BuddyVariable> getOfflineVariables(final String buddyName) throws IOException {
        this.checkInited();
        List<BuddyVariable> offlineBuddyVars = null;
        if (this.buddyListManager.allowOfflineBuddyVariables()) {
            final String targetFileName = String.valueOf(this.blistFolderName) + "/" + CryptoUtils.getHexFileName(buddyName);
            final File targetFile = new File(targetFileName);
            if (targetFile.isFile()) {
                final ISFSObject serializedBuddyList = SFSObject.newFromBinaryData(FileUtils.readFileToByteArray(targetFile));
                offlineBuddyVars = this.rebuildBuddyVariables(serializedBuddyList);
            }
        }
        return offlineBuddyVars;
    }
    
    @Override
    public BuddyListManager getBuddyListManager() {
        return this.buddyListManager;
    }
    
    @Override
    public void setBuddyListManager(final BuddyListManager buddyListManager) {
        if (this.buddyListManager != null) {
            throw new IllegalStateException("Can't re-assign buddyListManager.");
        }
        this.buddyListManager = buddyListManager;
    }
    
    private void checkFolderStructure() throws IOException {
        this.blistFolderName = "data/buddylists/" + this.buddyListManager.getZone().getName();
        final File targetFolder = new File(this.blistFolderName);
        if (!targetFolder.isDirectory()) {
            FileUtils.forceMkdir(targetFolder);
        }
    }
    
    private void checkInited() {
        if (!this.inited) {
            throw new IllegalStateException("BuddyStorage class cannot operate correctly because initialization failed: " + this.buddyListManager.getZone());
        }
    }
    
    private List<BuddyVariable> rebuildBuddyVariables(final ISFSObject serializedBuddyList) {
        final List<BuddyVariable> buddyVariables = new ArrayList<BuddyVariable>();
        final ISFSArray varItems = serializedBuddyList.getSFSArray("mv");
        for (int i = 0; i < varItems.size(); ++i) {
            buddyVariables.add(SFSBuddyVariable.newFromSFSArray(varItems.getSFSArray(i)));
        }
        return buddyVariables;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

public enum BuddyOnlineState
{
    ONLINE("ONLINE", 0), 
    OFFLINE("OFFLINE", 1), 
    LEFT_THE_SERVER("LEFT_THE_SERVER", 2);
    
    private BuddyOnlineState(final String s, final int n) {
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.exceptions.IErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.entities.User;
import java.util.Map;
import org.slf4j.Logger;

public class SFSBuddyList implements BuddyList
{
    private final Logger log;
    private final String ownerName;
    private BuddyListManager buddyListManager;
    private final Map<String, Buddy> buddies;
    private final User owner;
    
    public SFSBuddyList(final String ownerName) {
        this(ownerName, null);
    }
    
    public SFSBuddyList(final String ownerName, final BuddyListManager buddyListManager) {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.ownerName = ownerName;
        this.buddyListManager = buddyListManager;
        this.buddies = new ConcurrentHashMap<String, Buddy>();
        this.owner = buddyListManager.getZone().getUserByName(ownerName);
    }
    
    @Override
    public Buddy addBuddy(Buddy buddy) throws SFSBuddyListException {
        if (this.ownerName.equals(buddy.getName())) {
            throw new IllegalStateException(String.format("Cannot add yourself the BuddyList. %s, %s", this.owner, buddy));
        }
        if (!buddy.isTemp()) {
            if (this.isFull()) {
                final SFSErrorData errData = new SFSErrorData(SFSErrorCode.BUDDY_LIST_FULL);
                errData.addParameter(String.valueOf(this.buddyListManager.getBuddyListMaxSize()));
                throw new SFSBuddyListException("BuddyList is full. Current limit is set to: " + this.buddyListManager.getBuddyListMaxSize(), errData);
            }
            final Buddy previousBuddyItem = this.buddies.get(buddy.getName());
            if (previousBuddyItem != null) {
                if (!previousBuddyItem.isTemp()) {
                    throw new IllegalStateException("Buddy is already in the buddylist: " + buddy);
                }
                buddy = previousBuddyItem;
                buddy.setIsTemp(false);
            }
        }
        this.buddies.put(buddy.getName(), buddy);
        if (this.log.isDebugEnabled()) {
            this.log.debug(String.format("Buddy: %s added to User: %s buddy-list.", buddy.getName(), this.owner.getName()));
        }
        return buddy;
    }
    
    @Override
    public Buddy removeBuddy(final String buddyName) {
        Buddy removedBuddy = null;
        final Iterator<Buddy> iter = this.buddies.values().iterator();
        while (iter.hasNext()) {
            final Buddy item = iter.next();
            if (item.getName().equals(buddyName)) {
                iter.remove();
                removedBuddy = item;
                break;
            }
        }
        if (this.log.isDebugEnabled()) {
            this.log.debug(String.format("Removed buddy %s from %s buddylist", buddyName, this.owner));
        }
        return removedBuddy;
    }
    
    @Override
    public boolean containsBuddy(final String buddyName) {
        return this.buddies.containsKey(buddyName);
    }
    
    @Override
    public boolean isBuddyBlocked(final String buddyName) {
        boolean res = false;
        final Buddy buddy = this.buddies.get(buddyName);
        if (buddy != null) {
            res = buddy.isBlocked();
        }
        return res;
    }
    
    @Override
    public int getSize() {
        int count = 0;
        for (final Buddy item : this.buddies.values()) {
            if (item.isTemp()) {
                ++count;
            }
        }
        return this.getRuntimeSize() - count;
    }
    
    @Override
    public int getRuntimeSize() {
        return this.buddies.size();
    }
    
    @Override
    public boolean isEmpty() {
        return this.getSize() == 0;
    }
    
    @Override
    public boolean isFull() {
        return this.getSize() >= this.buddyListManager.getBuddyListMaxSize();
    }
    
    @Override
    public void clearAll() {
        this.buddies.clear();
    }
    
    @Override
    public Buddy getBuddy(final String buddyName) {
        return this.buddies.get(buddyName);
    }
    
    @Override
    public List<Buddy> getBuddies() {
        return new ArrayList<Buddy>(this.buddies.values());
    }
    
    @Override
    public BuddyListManager getBuddyListManager() {
        return this.buddyListManager;
    }
    
    @Override
    public void setBuddyListManager(final BuddyListManager buddyListManager) {
        if (this.buddyListManager != null) {
            throw new IllegalStateException("Cannot redefine BuddyManager in a BuddyList at runtime");
        }
        this.buddyListManager = buddyListManager;
    }
    
    @Override
    public String getOwnerName() {
        return this.ownerName;
    }
    
    @Override
    public User getOwner() {
        return this.owner;
    }
    
    @Override
    public ISFSArray toSFSArray() {
        final ISFSArray buddyListData = new SFSArray();
        for (final Buddy buddy : this.buddies.values()) {
            buddyListData.addSFSArray(buddy.toSFSArray());
        }
        return buddyListData;
    }
    
    @Override
    public String toString() {
        return String.format("[Owner: %s, Size: %s List: %s ]", this.ownerName, this.buddies.size(), this.buddies.toString());
    }
}

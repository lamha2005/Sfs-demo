// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.LinkedList;
import com.smartfoxserver.v2.entities.User;
import java.util.Iterator;
import java.util.List;

public class BuddyUtils
{
    private static final String KEY_OWNER_NAME = "on";
    private static final String KEY_BLIST = "bl";
    private static final String KEY_BUDDY_NAME = "bn";
    private static final String KEY_BUDDY_BLOCKED = "bb";
    private static final String KEY_BUDDY_STATE = "bs";
    private static final String KEY_BUDDY_TEMP = "bt";
    private static final String KEY_BUDDY_VARS = "bvs";
    
    public static BuddyVariable findVariable(final List<BuddyVariable> vars, final String varName) {
        for (final BuddyVariable bv : vars) {
            if (bv.getName().equals(varName)) {
                return bv;
            }
        }
        return null;
    }
    
    public static List<String> filterNonMutualRecipients(final User sender, final List<String> recipientNames) {
        final BuddyListManager bManager = sender.getZone().getBuddyListManager();
        final String senderName = sender.getName();
        final List<String> filteredNames = new LinkedList<String>();
        for (final String targetName : recipientNames) {
            final BuddyList bList = bManager.getBuddyList(targetName);
            if (bList != null && bList.containsBuddy(senderName)) {
                filteredNames.add(targetName);
            }
        }
        return filteredNames;
    }
    
    public static ISFSObject toSFSObject(final BuddyList buddyList, final boolean excludeTemporaryBuddies) {
        final ISFSObject sfso = SFSObject.newInstance();
        final ISFSArray sfsa = SFSArray.newInstance();
        sfso.putUtfString("on", buddyList.getOwnerName());
        sfso.putSFSArray("bl", sfsa);
        for (final Buddy buddy : buddyList.getBuddies()) {
            if (excludeTemporaryBuddies && buddy.isTemp()) {
                continue;
            }
            sfsa.addSFSObject(encodeBuddy(buddy));
        }
        return sfso;
    }
    
    public static ISFSObject encodeBuddy(final Buddy buddy) {
        final ISFSObject buddyObj = SFSObject.newInstance();
        buddyObj.putUtfString("bn", buddy.getName());
        buddyObj.putBool("bb", buddy.isBlocked());
        buddyObj.putBool("bt", buddy.isTemp());
        buddyObj.putUtfString("bs", buddy.getState());
        if (buddy.hasVariables()) {
            buddyObj.putSFSArray("bvs", encodeBuddyVariables(buddy.getVariables()));
        }
        return buddyObj;
    }
    
    public static ISFSArray encodeBuddyVariables(final List<BuddyVariable> buddyVariables) {
        final ISFSArray arr = SFSArray.newInstance();
        for (final BuddyVariable bVar : buddyVariables) {
            arr.addSFSArray(bVar.toSFSArray());
        }
        return arr;
    }
    
    public static BuddyList fromSFSObject(final ISFSObject sfso) throws SFSBuddyListException {
        final BuddyList buddyList = new SFSBuddyList(sfso.getUtfString("on"));
        final ISFSArray bListData = sfso.getSFSArray("bl");
        for (int i = 0; i < bListData.size(); ++i) {
            buddyList.addBuddy(decodeBuddy(bListData.getSFSObject(i)));
        }
        return buddyList;
    }
    
    private static Buddy decodeBuddy(final ISFSObject buddyObj) {
        final Buddy buddy = new SFSBuddy(buddyObj.getUtfString("bn"), buddyObj.getBool("bt"));
        buddy.setBlocked(buddyObj.getBool("bb"));
        return buddy;
    }
}

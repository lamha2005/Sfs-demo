// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.List;

public interface Buddy
{
    String getName();
    
    String getState();
    
    String getNickName();
    
    boolean isBlocked();
    
    void setBlocked(final boolean p0);
    
    boolean isTemp();
    
    void setIsTemp(final boolean p0);
    
    boolean isOnline();
    
    BuddyList getParentBuddyList();
    
    void setParentBuddyList(final BuddyList p0);
    
    boolean hasVariables();
    
    BuddyVariable getVariable(final String p0);
    
    List<BuddyVariable> getVariables();
    
    void setVariable(final BuddyVariable p0);
    
    void setVariables(final List<BuddyVariable> p0);
    
    ISFSArray toSFSArray();
    
    ISFSArray getBuddyVariablesData();
}

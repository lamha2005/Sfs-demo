// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.entities.data.ISFSArray;

public interface IBuddySerializer
{
    ISFSArray serialize(final Buddy p0);
}

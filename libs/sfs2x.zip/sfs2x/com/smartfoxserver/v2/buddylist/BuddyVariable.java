// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.entities.variables.Variable;

public interface BuddyVariable extends Variable
{
    boolean isOffline();
}

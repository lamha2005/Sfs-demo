// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import java.util.List;
import com.smartfoxserver.v2.entities.User;

public interface BuddyList
{
    String getOwnerName();
    
    User getOwner();
    
    BuddyListManager getBuddyListManager();
    
    void setBuddyListManager(final BuddyListManager p0);
    
    Buddy getBuddy(final String p0);
    
    List<Buddy> getBuddies();
    
    Buddy addBuddy(final Buddy p0) throws SFSBuddyListException;
    
    Buddy removeBuddy(final String p0);
    
    boolean containsBuddy(final String p0);
    
    int getSize();
    
    int getRuntimeSize();
    
    boolean isFull();
    
    boolean isEmpty();
    
    boolean isBuddyBlocked(final String p0);
    
    void clearAll();
    
    ISFSArray toSFSArray();
}

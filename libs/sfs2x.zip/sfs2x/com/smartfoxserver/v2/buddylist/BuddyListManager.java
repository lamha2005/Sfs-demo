// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.List;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.buddylist.storage.BuddyStorage;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.bitswarm.service.IService;

public interface BuddyListManager extends IService
{
    Zone getZone();
    
    int getBuddyListMaxSize();
    
    void setBuddyListMaxSize(final int p0);
    
    int getOfflineBuddyVariablesCacheSize();
    
    void setOfflineBuddyVariablesCacheSize(final int p0);
    
    int getMaxBuddyVariables();
    
    void setMaxBuddyVariables(final int p0);
    
    boolean isActive();
    
    void setActive(final boolean p0);
    
    boolean allowOfflineBuddyVariables();
    
    void setAllowOfflineBuddyVariables(final boolean p0);
    
    BuddyStorage getStorageHandler();
    
    void setStorageHandler(final BuddyStorage p0);
    
    Buddy addBuddy(final String p0, final String p1, final boolean p2) throws SFSBuddyListException;
    
    Buddy removeBuddy(final String p0, final String p1);
    
    BuddyList getBuddyList(final String p0);
    
    void removeBuddyList(final String p0);
    
    BuddyList loadBuddyList(final String p0) throws IOException;
    
    void saveBuddyList(final String p0) throws IOException;
    
    void saveAll();
    
    List<BuddyVariable> getOfflineBuddyVariables(final String p0);
    
    List<BuddyVariable> getOfflineBuddyVariables(final String p0, final boolean p1);
    
    BuddyVariable getOfflineBuddyVariable(final String p0, final String p1);
    
    List<ISession> getClientsWatchingBuddy(final String p0);
    
    List<ISession> getClientsWatchingBuddy(final String p0, final boolean p1);
    
    List<String> getBuddyStates();
    
    void setBuddyStates(final List<String> p0);
    
    boolean getUseTempBuddies();
    
    void setUseTempBuddies(final boolean p0);
    
    boolean getApplyBadWordsFilter();
    
    void setApplyBadWordsFilter(final boolean p0);
    
    List<String> getRecipientNamesForUpdate(final String p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import java.util.Iterator;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.List;
import com.smartfoxserver.v2.entities.User;

public class SFSBuddy implements Buddy
{
    private final String name;
    private volatile boolean blocked;
    private volatile boolean temp;
    private BuddyList buddyList;
    
    public SFSBuddy(final String name) {
        this(name, false);
    }
    
    public SFSBuddy(final String name, final boolean isTemp) {
        this.name = name;
        this.blocked = false;
        this.temp = isTemp;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public BuddyList getParentBuddyList() {
        return this.buddyList;
    }
    
    @Override
    public void setParentBuddyList(final BuddyList parentList) {
        if (this.buddyList != null) {
            throw new IllegalStateException("Parent BuddyList cannot be changed at runtime.");
        }
        this.buddyList = parentList;
    }
    
    @Override
    public String getState() {
        final BuddyVariable bv = this.getVariable("$__BV_STATE__");
        return (bv == null) ? null : bv.getStringValue();
    }
    
    @Override
    public String getNickName() {
        final BuddyVariable bv = this.getVariable("$__BV_NICKNAME__");
        return (bv == null) ? null : bv.getStringValue();
    }
    
    @Override
    public boolean hasVariables() {
        int varCount = 0;
        final User user = this.getRelatedUser();
        if (user != null) {
            varCount = user.getBuddyProperties().getVariablesCount();
        }
        return varCount > 0;
    }
    
    @Override
    public BuddyVariable getVariable(final String varName) {
        final User user = this.getRelatedUser();
        BuddyVariable var = null;
        if (user != null) {
            var = user.getBuddyProperties().getVariable(varName);
        }
        else {
            var = this.getParentBuddyList().getBuddyListManager().getOfflineBuddyVariable(this.name, varName);
        }
        return var;
    }
    
    @Override
    public List<BuddyVariable> getVariables() {
        final User user = this.getRelatedUser();
        List<BuddyVariable> variables = null;
        if (user != null) {
            variables = user.getBuddyProperties().getVariables();
        }
        else {
            variables = this.getParentBuddyList().getBuddyListManager().getOfflineBuddyVariables(this.name);
        }
        return variables;
    }
    
    @Override
    public boolean isBlocked() {
        return this.blocked;
    }
    
    @Override
    public boolean isOnline() {
        boolean isOnline = true;
        final User user = this.getRelatedUser();
        if (user != null) {
            isOnline = user.getBuddyProperties().isOnline();
        }
        return isOnline;
    }
    
    @Override
    public boolean isTemp() {
        return this.temp;
    }
    
    @Override
    public void setIsTemp(final boolean value) {
        this.temp = value;
    }
    
    @Override
    public void setBlocked(final boolean value) {
        this.blocked = value;
    }
    
    @Override
    public void setVariable(final BuddyVariable buddyVariable) {
        final User user = this.getRelatedUser();
        if (user != null) {
            user.getBuddyProperties().setVariable(buddyVariable);
        }
    }
    
    @Override
    public void setVariables(final List<BuddyVariable> buddyVariables) {
        final User user = this.getRelatedUser();
        if (user != null) {
            user.getBuddyProperties().setVariables(buddyVariables);
        }
    }
    
    @Override
    public ISFSArray toSFSArray() {
        return BuddySerializerFactory.getSerializer().serialize(this);
    }
    
    @Override
    public ISFSArray getBuddyVariablesData() {
        final ISFSArray variablesData = SFSArray.newInstance();
        final List<BuddyVariable> vars = this.getVariables();
        if (vars != null) {
            for (final BuddyVariable var : vars) {
                variablesData.addSFSArray(var.toSFSArray());
            }
        }
        return variablesData;
    }
    
    @Override
    public String toString() {
        return String.format("{ Buddy: %s, Blk: %s, Tmp: %s }", this.name, this.blocked, this.temp);
    }
    
    private User getRelatedUser() {
        return this.buddyList.getBuddyListManager().getZone().getUserByName(this.name);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist.cache;

import java.util.concurrent.ConcurrentHashMap;
import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.List;
import java.util.concurrent.ConcurrentMap;

public class SimpleVariableCache implements BuddyVariablesCache
{
    private final ConcurrentMap<String, List<BuddyVariable>> cache;
    private volatile int size;
    
    public SimpleVariableCache(int size) {
        if (size < 0) {
            size = 100;
        }
        this.cache = new ConcurrentHashMap<String, List<BuddyVariable>>();
        this.size = size;
    }
    
    @Override
    public void addVariables(final String ownerName, final List<BuddyVariable> variables) {
        if (this.cache.size() >= this.size) {
            this.createRoom();
        }
        this.cache.put(ownerName, variables);
    }
    
    private void createRoom() {
        final Object[] keys = this.cache.keySet().toArray();
        this.cache.remove(keys[keys.length - 1]);
    }
    
    @Override
    public int getSize() {
        return this.size;
    }
    
    @Override
    public List<BuddyVariable> getVariables(final String ownerName) {
        return this.cache.get(ownerName);
    }
    
    @Override
    public void removeVariables(final String ownerName) {
        this.cache.remove(ownerName);
    }
    
    @Override
    public void setSize(final int size) {
        if (size < this.size) {
            throw new IllegalArgumentException("BuddyVariablesCache implementation does not support cache shrinking");
        }
        this.size = size;
    }
}

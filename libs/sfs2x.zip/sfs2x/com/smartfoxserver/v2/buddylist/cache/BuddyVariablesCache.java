// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist.cache;

import com.smartfoxserver.v2.buddylist.BuddyVariable;
import java.util.List;

public interface BuddyVariablesCache
{
    int getSize();
    
    void setSize(final int p0);
    
    void addVariables(final String p0, final List<BuddyVariable> p1);
    
    List<BuddyVariable> getVariables(final String p0);
    
    void removeVariables(final String p0);
}

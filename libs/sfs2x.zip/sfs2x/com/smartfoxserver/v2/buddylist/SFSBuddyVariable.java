// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.variables.VariableType;

public class SFSBuddyVariable implements BuddyVariable
{
    private static final String OFFLINE_PREFIX = "$";
    protected String name;
    protected Object value;
    protected VariableType type;
    
    public static SFSBuddyVariable newFromSFSArray(final ISFSArray array) {
        return new SFSBuddyVariable(array.getUtfString(0), array.getElementAt(2));
    }
    
    public SFSBuddyVariable(final String name, final Object value) {
        this.name = name;
        this.setValue(value);
    }
    
    protected SFSBuddyVariable() {
    }
    
    protected void setValueFromStringLiteral(final VariableType type, final String literal) {
        if (type == VariableType.NULL) {
            this.setNull();
        }
        else if (type == VariableType.BOOL) {
            this.setValue(Boolean.valueOf(Boolean.parseBoolean(literal)));
        }
        else if (type == VariableType.INT) {
            this.setValue(Integer.valueOf(Integer.parseInt(literal)));
        }
        else if (type == VariableType.DOUBLE) {
            this.setValue(Double.valueOf(Double.parseDouble(literal)));
        }
        else if (type == VariableType.STRING) {
            this.setValue(literal);
        }
        else if (type == VariableType.ARRAY) {
            this.setValue(SFSArray.newFromJsonData(literal));
        }
        else if (type == VariableType.OBJECT) {
            this.setValue(SFSObject.newFromJsonData(literal));
        }
    }
    
    @Override
    public boolean isOffline() {
        return this.name.startsWith("$");
    }
    
    @Override
    public VariableType getType() {
        return this.type;
    }
    
    @Override
    public Boolean getBoolValue() {
        return (Boolean)this.value;
    }
    
    @Override
    public Double getDoubleValue() {
        return (Double)this.value;
    }
    
    @Override
    public Integer getIntValue() {
        return (Integer)this.value;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public ISFSArray getSFSArrayValue() {
        return (ISFSArray)this.value;
    }
    
    @Override
    public ISFSObject getSFSObjectValue() {
        return (ISFSObject)this.value;
    }
    
    @Override
    public String getStringValue() {
        return (String)this.value;
    }
    
    @Override
    public Object getValue() {
        return this.value;
    }
    
    @Override
    public boolean isNull() {
        return this.type == VariableType.NULL;
    }
    
    protected void setNull() {
        this.value = null;
        this.type = VariableType.NULL;
    }
    
    protected void setValue(final Boolean val) {
        this.type = VariableType.BOOL;
        this.value = val;
    }
    
    protected void setValue(final Double val) {
        this.type = VariableType.DOUBLE;
        this.value = val;
    }
    
    protected void setValue(final Integer val) {
        this.type = VariableType.INT;
        this.value = val;
    }
    
    protected void setValue(final ISFSArray val) {
        this.type = VariableType.ARRAY;
        this.value = val;
    }
    
    protected void setValue(final ISFSObject val) {
        this.type = VariableType.OBJECT;
        this.value = val;
    }
    
    protected void setValue(final Object val) {
        if (val == null) {
            this.type = VariableType.NULL;
        }
        else if (val instanceof Boolean) {
            this.setValue((Boolean)val);
        }
        else if (val instanceof Byte) {
            this.setValue(Integer.valueOf((int)val));
        }
        else if (val instanceof Short) {
            this.setValue(Integer.valueOf((int)val));
        }
        else if (val instanceof Integer) {
            this.setValue((Integer)val);
        }
        else if (val instanceof Long) {
            this.setValue(Double.valueOf((double)val));
        }
        else if (val instanceof Float) {
            this.setValue(Double.valueOf((double)val));
        }
        else if (val instanceof Double) {
            this.setValue((Double)val);
        }
        else if (val instanceof String) {
            this.setValue((String)val);
        }
        else if (val instanceof ISFSArray) {
            this.setValue((ISFSArray)val);
        }
        else if (val instanceof ISFSObject) {
            this.setValue((ISFSObject)val);
        }
    }
    
    @Override
    public ISFSArray toSFSArray() {
        final ISFSArray sfsa = SFSArray.newInstance();
        sfsa.addUtfString(this.name);
        sfsa.addByte((byte)this.type.getId());
        this.populateArrayWithValue(sfsa);
        return sfsa;
    }
    
    protected void populateArrayWithValue(final ISFSArray sfsa) {
        switch (this.type) {
            case NULL: {
                sfsa.addNull();
                break;
            }
            case BOOL: {
                sfsa.addBool(this.getBoolValue());
                break;
            }
            case INT: {
                sfsa.addInt(this.getIntValue());
                break;
            }
            case DOUBLE: {
                sfsa.addDouble(this.getDoubleValue());
                break;
            }
            case STRING: {
                sfsa.addUtfString(this.getStringValue());
                break;
            }
            case OBJECT: {
                sfsa.addSFSObject(this.getSFSObjectValue());
                break;
            }
            case ARRAY: {
                sfsa.addSFSArray(this.getSFSArrayValue());
                break;
            }
        }
    }
    
    protected void setValue(final String val) {
        this.type = VariableType.STRING;
        this.value = val;
    }
    
    public Object clone() {
        try {
            return super.clone();
        }
        catch (CloneNotSupportedException e) {
            throw new SFSRuntimeException("Clone Error! " + e.getMessage() + ", " + this.toString());
        }
    }
    
    @Override
    public String toString() {
        return String.format("{ N: %s, T: %s, V: %s }", this.name, this.type, this.value);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

public class ReservedBuddyVariables
{
    public static final String BV_ONLINE = "$__BV_ONLINE__";
    public static final String BV_STATE = "$__BV_STATE__";
    public static final String BV_NICKNAME = "$__BV_NICKNAME__";
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import java.util.List;

public interface BuddyProperties
{
    void init(final Object p0);
    
    boolean isOnline();
    
    void setOnline(final boolean p0);
    
    String getState();
    
    void setState(final String p0);
    
    String getNickName();
    
    void setNickName(final String p0);
    
    BuddyVariable getVariable(final String p0);
    
    List<BuddyVariable> getVariables();
    
    void setVariable(final BuddyVariable p0);
    
    List<BuddyVariable> getPersistentVariables();
    
    void setVariables(final List<BuddyVariable> p0);
    
    void removeVariable(final String p0);
    
    boolean containsVariable(final String p0);
    
    int getVariablesCount();
    
    boolean isChangedSinceLastSave();
    
    void setChangedSinceLastSave(final boolean p0);
    
    boolean isInited();
    
    void setInited();
}

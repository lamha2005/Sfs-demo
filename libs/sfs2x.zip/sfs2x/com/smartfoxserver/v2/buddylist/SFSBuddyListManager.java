// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.core.ISFSEventParam;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEvent;
import java.util.LinkedList;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.entities.User;
import java.util.Iterator;
import java.util.ArrayList;
import java.io.IOException;
import com.smartfoxserver.v2.exceptions.SFSBuddyListNotFoundException;
import com.smartfoxserver.v2.exceptions.SFSBuddyListException;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.buddylist.cache.SimpleVariableCache;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import java.util.List;
import com.smartfoxserver.v2.api.ISFSBuddyApi;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.Map;
import com.smartfoxserver.v2.core.ISFSEventListener;
import com.smartfoxserver.v2.buddylist.cache.BuddyVariablesCache;
import com.smartfoxserver.v2.buddylist.storage.BuddyStorage;
import com.smartfoxserver.v2.entities.Zone;
import org.slf4j.Logger;

public class SFSBuddyListManager implements BuddyListManager
{
    private static final int DEFAULT_VAR_CACHE_SIZE = 500;
    protected final Logger log;
    protected final Zone zone;
    protected final String serviceName;
    protected boolean active;
    protected boolean offlineBuddyVariables;
    protected boolean useTempBuddies;
    protected boolean useBadWordsFilter;
    protected int maxListSize;
    protected int maxVariables;
    protected int bvCacheSize;
    protected BuddyStorage buddyStorage;
    protected BuddyVariablesCache offlineVarsCache;
    protected final ISFSEventListener userExitEventHandler;
    protected final Map<String, BuddyList> buddyLists;
    protected final SmartFoxServer sfs;
    protected final ISFSBuddyApi buddyApi;
    protected List<String> buddyStates;
    
    public SFSBuddyListManager(final Zone parentZone, final boolean isActive) {
        this.maxListSize = 30;
        this.maxVariables = 5;
        this.bvCacheSize = 500;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = SmartFoxServer.getInstance();
        this.buddyApi = this.sfs.getAPIManager().getBuddyApi();
        this.zone = parentZone;
        this.serviceName = "BuddyListManager-" + this.zone.getName();
        this.active = isActive;
        this.userExitEventHandler = new UserExitEventHandler((UserExitEventHandler)null);
        this.buddyLists = new ConcurrentHashMap<String, BuddyList>();
    }
    
    public void init(final Object o) {
        if (this.active) {
            this.offlineVarsCache = new SimpleVariableCache(this.bvCacheSize);
            this.buddyStorage.setBuddyListManager(this);
            this.buddyStorage.init();
            this.sfs.getEventManager().addEventListener(SFSEventType.USER_DISCONNECT, this.userExitEventHandler);
            this.sfs.getEventManager().addEventListener(SFSEventType.USER_LOGOUT, this.userExitEventHandler);
        }
    }
    
    public void destroy(final Object o) {
        if (this.active) {
            this.sfs.getEventManager().removeEventListener(SFSEventType.USER_DISCONNECT, this.userExitEventHandler);
            this.sfs.getEventManager().removeEventListener(SFSEventType.USER_LOGOUT, this.userExitEventHandler);
            this.saveAll();
            this.buddyStorage.destroy();
        }
    }
    
    @Override
    public boolean allowOfflineBuddyVariables() {
        return this.offlineBuddyVariables;
    }
    
    @Override
    public void setAllowOfflineBuddyVariables(final boolean value) {
        this.offlineBuddyVariables = value;
    }
    
    @Override
    public Buddy addBuddy(final String ownerName, final String buddyName, final boolean isTemp) throws SFSBuddyListException {
        final BuddyList buddyList = this.buddyLists.get(ownerName);
        if (buddyList != null) {
            Buddy buddy = new SFSBuddy(buddyName, isTemp);
            buddy.setParentBuddyList(buddyList);
            buddy = buddyList.addBuddy(buddy);
            return buddy;
        }
        throw new SFSBuddyListException("Cannot add Buddy to " + ownerName + " BuddyList. The BuddyList was not loaded first.");
    }
    
    @Override
    public BuddyList getBuddyList(final String ownerName) {
        return this.buddyLists.get(ownerName);
    }
    
    @Override
    public int getBuddyListMaxSize() {
        return this.maxListSize;
    }
    
    @Override
    public int getMaxBuddyVariables() {
        return this.maxVariables;
    }
    
    @Override
    public BuddyStorage getStorageHandler() {
        return this.buddyStorage;
    }
    
    @Override
    public Zone getZone() {
        return this.zone;
    }
    
    @Override
    public boolean isActive() {
        return this.active;
    }
    
    @Override
    public BuddyList loadBuddyList(final String ownerName) throws IOException {
        BuddyList buddyList = null;
        try {
            buddyList = this.buddyStorage.loadList(ownerName);
        }
        catch (SFSBuddyListNotFoundException notFoundErr) {
            buddyList = new SFSBuddyList(ownerName, this);
        }
        this.buddyLists.put(ownerName, buddyList);
        if (this.log.isDebugEnabled()) {
            this.log.debug("BuddyList inited: " + buddyList);
        }
        return buddyList;
    }
    
    @Override
    public Buddy removeBuddy(final String ownerName, final String buddyName) {
        final BuddyList buddyList = this.buddyLists.get(ownerName);
        Buddy buddy = null;
        if (buddyList != null) {
            buddy = buddyList.removeBuddy(buddyName);
        }
        return buddy;
    }
    
    @Override
    public void removeBuddyList(final String ownerName) {
        this.buddyLists.remove(ownerName);
    }
    
    @Override
    public void saveAll() {
        if (!this.isActive()) {
            return;
        }
        final List<String> erroneousList = new ArrayList<String>();
        for (final BuddyList buddyList : this.buddyLists.values()) {
            try {
                this.saveBuddyList(buddyList);
            }
            catch (IOException e) {
                erroneousList.add(buddyList.getOwnerName());
            }
        }
        if (erroneousList.size() > 0) {
            this.log.warn("There were errors during BuddyList saveAll(). The following lists were not saved: " + erroneousList);
        }
    }
    
    @Override
    public void saveBuddyList(final String ownerName) throws IOException {
        final BuddyList buddyList = this.buddyLists.get(ownerName);
        if (buddyList != null) {
            this.saveBuddyList(buddyList);
        }
        else if (this.log.isDebugEnabled()) {
            this.log.debug("Skipping BuddyList save request. No BuddyList available for: " + ownerName);
        }
    }
    
    @Override
    public List<String> getBuddyStates() {
        return this.buddyStates;
    }
    
    @Override
    public void setBuddyStates(final List<String> states) {
        this.buddyStates = states;
    }
    
    @Override
    public boolean getApplyBadWordsFilter() {
        return this.useBadWordsFilter;
    }
    
    @Override
    public void setApplyBadWordsFilter(final boolean value) {
        this.useBadWordsFilter = value;
    }
    
    private void saveBuddyList(final BuddyList buddyList) throws IOException {
        if (!this.isActive()) {
            return;
        }
        final User owner = buddyList.getOwner();
        if (owner != null && owner.getBuddyProperties().isChangedSinceLastSave()) {
            this.buddyStorage.saveList(buddyList);
            this.offlineVarsCache.addVariables(buddyList.getOwnerName(), owner.getBuddyProperties().getPersistentVariables());
            owner.getBuddyProperties().setChangedSinceLastSave(false);
        }
    }
    
    @Override
    public BuddyVariable getOfflineBuddyVariable(final String ownerName, final String varName) {
        BuddyVariable var = null;
        final List<BuddyVariable> varList = this.getOfflineBuddyVariables(ownerName);
        if (varList != null) {
            var = BuddyUtils.findVariable(varList, varName);
        }
        return var;
    }
    
    @Override
    public List<BuddyVariable> getOfflineBuddyVariables(final String ownerName) {
        return this.getOfflineBuddyVariables(ownerName, false);
    }
    
    @Override
    public List<BuddyVariable> getOfflineBuddyVariables(final String ownerName, final boolean bypassCache) {
        List<BuddyVariable> varList = bypassCache ? null : this.offlineVarsCache.getVariables(ownerName);
        if (varList == null) {
            try {
                varList = this.buddyStorage.getOfflineVariables(ownerName);
                if (varList != null) {
                    this.offlineVarsCache.addVariables(ownerName, varList);
                }
            }
            catch (IOException e) {
                this.log.info("Unexpected I/O error while accessing offline variables for buddy: " + ownerName + ", " + this.zone);
            }
        }
        return varList;
    }
    
    @Override
    public void setActive(final boolean value) {
        this.active = value;
    }
    
    @Override
    public void setBuddyListMaxSize(int maxSize) {
        if (maxSize < 1) {
            maxSize = 1;
        }
        this.maxListSize = maxSize;
    }
    
    @Override
    public void setMaxBuddyVariables(int maxVariables) {
        if (maxVariables < 0) {
            maxVariables = 0;
        }
        this.maxVariables = maxVariables;
    }
    
    @Override
    public int getOfflineBuddyVariablesCacheSize() {
        return this.offlineVarsCache.getSize();
    }
    
    @Override
    public void setOfflineBuddyVariablesCacheSize(final int size) {
        this.bvCacheSize = ((size > 0) ? size : 500);
    }
    
    @Override
    public void setStorageHandler(final BuddyStorage buddyStorage) {
        if (this.buddyStorage != null) {
            throw new IllegalStateException("A Storage Buddy already exists: " + this.buddyStorage);
        }
        this.buddyStorage = buddyStorage;
    }
    
    public String getName() {
        return this.serviceName;
    }
    
    public void handleMessage(final Object arg0) throws Exception {
        throw new UnsupportedOperationException("Method not available");
    }
    
    public void setName(final String arg0) {
        throw new UnsupportedOperationException("Method not available");
    }
    
    @Override
    public boolean getUseTempBuddies() {
        return this.useTempBuddies;
    }
    
    @Override
    public void setUseTempBuddies(final boolean value) {
        this.useTempBuddies = value;
    }
    
    @Override
    public List<ISession> getClientsWatchingBuddy(final String buddyName) {
        return this.getClientsWatchingBuddy(buddyName, false);
    }
    
    @Override
    public List<String> getRecipientNamesForUpdate(final String owner) {
        final List<String> targets = new LinkedList<String>();
        final BuddyList recipientBuddies = this.getBuddyList(owner);
        if (recipientBuddies != null) {
            for (final Buddy buddy : recipientBuddies.getBuddies()) {
                if (buddy.isBlocked()) {
                    continue;
                }
                targets.add(buddy.getName());
            }
        }
        return targets;
    }
    
    @Override
    public List<ISession> getClientsWatchingBuddy(final String buddyName, final boolean onlineUsersOnly) {
        final List<ISession> theClients = new ArrayList<ISession>();
        final BuddyList senderBuddyList = this.getBuddyList(buddyName);
        for (final BuddyList bList : this.buddyLists.values()) {
            final Buddy buddy = bList.getBuddy(buddyName);
            if (buddy != null) {
                final User owner = bList.getOwner();
                boolean reciprocalBlockedCheck = true;
                if (senderBuddyList != null) {
                    reciprocalBlockedCheck &= !senderBuddyList.isBuddyBlocked(bList.getOwnerName());
                }
                if (owner == null || buddy.isBlocked() || !reciprocalBlockedCheck) {
                    continue;
                }
                final boolean addUserToList = !onlineUsersOnly || owner.getBuddyProperties().isOnline();
                if (!addUserToList) {
                    continue;
                }
                theClients.add(owner.getSession());
            }
        }
        return theClients;
    }
    
    private final class UserExitEventHandler implements ISFSEventListener
    {
        @Override
        public void handleServerEvent(final ISFSEvent event) throws Exception {
            final User user = (User)event.getParameter(SFSEventParam.USER);
            if (user != null && SFSBuddyListManager.this.isActive()) {
                final String userName = user.getName();
                try {
                    SFSBuddyListManager.this.saveBuddyList(userName);
                    SFSBuddyListManager.this.buddyApi.getResponseAPI().notifyBuddyOnlineStateChange(user, BuddyOnlineState.LEFT_THE_SERVER, true);
                    SFSBuddyListManager.this.buddyLists.remove(userName);
                }
                catch (IOException e) {
                    SFSBuddyListManager.this.log.warn("Failed saving buddy list for User on exit: " + user + ", Error: " + e);
                }
            }
        }
    }
}

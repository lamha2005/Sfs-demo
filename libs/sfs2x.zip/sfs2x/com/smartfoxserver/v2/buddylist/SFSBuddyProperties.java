// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SFSBuddyProperties implements BuddyProperties
{
    protected Map<String, BuddyVariable> variables;
    protected volatile boolean updated;
    protected volatile boolean inited;
    
    public SFSBuddyProperties() {
        this.updated = false;
        this.inited = false;
    }
    
    @Override
    public void init(final Object o) {
    }
    
    @Override
    public boolean isInited() {
        return this.inited;
    }
    
    @Override
    public void setInited() {
        if (this.inited) {
            throw new IllegalStateException("BuddyProperties already inited.");
        }
        this.inited = true;
    }
    
    @Override
    public boolean containsVariable(final String varName) {
        return this.variables != null && this.variables.containsKey(varName);
    }
    
    @Override
    public String getNickName() {
        if (this.variables == null) {
            return null;
        }
        return (String)this.getBuddyVariableValue("$__BV_NICKNAME__");
    }
    
    @Override
    public String getState() {
        if (this.variables == null) {
            return null;
        }
        return (String)this.getBuddyVariableValue("$__BV_STATE__");
    }
    
    @Override
    public boolean isOnline() {
        boolean result = true;
        if (this.variables != null) {
            final Boolean flag = (Boolean)this.getBuddyVariableValue("$__BV_ONLINE__");
            if (flag != null) {
                result = flag;
            }
        }
        return result;
    }
    
    private Object getBuddyVariableValue(final String varName) {
        Object value = null;
        final BuddyVariable var = this.variables.get(varName);
        if (var != null) {
            value = var.getValue();
        }
        return value;
    }
    
    @Override
    public BuddyVariable getVariable(final String varName) {
        if (this.variables == null) {
            return null;
        }
        return this.variables.get(varName);
    }
    
    @Override
    public List<BuddyVariable> getVariables() {
        if (this.variables == null) {
            return null;
        }
        return new ArrayList<BuddyVariable>(this.variables.values());
    }
    
    @Override
    public List<BuddyVariable> getPersistentVariables() {
        if (this.variables == null) {
            return null;
        }
        final List<BuddyVariable> pVars = new ArrayList<BuddyVariable>();
        for (final BuddyVariable bv : this.variables.values()) {
            if (bv.isOffline()) {
                pVars.add(bv);
            }
        }
        return pVars;
    }
    
    @Override
    public int getVariablesCount() {
        if (this.variables == null) {
            return 0;
        }
        return this.variables.size();
    }
    
    @Override
    public void removeVariable(final String varName) {
        if (this.variables != null) {
            this.variables.remove(varName);
        }
    }
    
    @Override
    public void setNickName(final String buddyNickName) {
        this.setVariable(new SFSBuddyVariable("$__BV_NICKNAME__", buddyNickName));
    }
    
    @Override
    public void setOnline(final boolean flag) {
        this.setVariable(new SFSBuddyVariable("$__BV_ONLINE__", flag));
    }
    
    @Override
    public void setState(final String state) {
        this.setVariable(new SFSBuddyVariable("$__BV_STATE__", state));
    }
    
    @Override
    public void setVariable(final BuddyVariable buddyVariable) {
        this.lazyInit();
        this.variables.put(buddyVariable.getName(), buddyVariable);
    }
    
    @Override
    public void setVariables(final List<BuddyVariable> buddyVariables) {
        if (buddyVariables != null) {
            this.lazyInit();
            for (final BuddyVariable bVar : buddyVariables) {
                this.variables.put(bVar.getName(), bVar);
            }
        }
    }
    
    @Override
    public boolean isChangedSinceLastSave() {
        return this.updated;
    }
    
    @Override
    public void setChangedSinceLastSave(final boolean flag) {
        this.updated = flag;
    }
    
    @Override
    public String toString() {
        return this.variables.toString();
    }
    
    private synchronized void lazyInit() {
        if (this.variables == null) {
            this.variables = new ConcurrentHashMap<String, BuddyVariable>();
        }
    }
}

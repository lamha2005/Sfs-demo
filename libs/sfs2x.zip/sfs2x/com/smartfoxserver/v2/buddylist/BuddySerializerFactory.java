// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.buddylist;

import com.smartfoxserver.v2.SmartFoxServer;

public class BuddySerializerFactory
{
    private static IBuddySerializer serializer;
    
    public static void init() {
        if (BuddySerializerFactory.serializer == null) {
            BuddySerializerFactory.serializer = SmartFoxServer.getInstance().getServiceProvider().getBuddySerializer();
        }
    }
    
    public static IBuddySerializer getSerializer() {
        return BuddySerializerFactory.serializer;
    }
}

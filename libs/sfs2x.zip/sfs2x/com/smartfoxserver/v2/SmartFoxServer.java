// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2;

import com.smartfoxserver.v2.util.StringHelper;
import com.smartfoxserver.bitswarm.events.IEvent;
import java.util.Map;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.core.ISFSEventParam;
import java.util.HashMap;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.util.IDisconnectionReason;
import com.smartfoxserver.v2.util.ClientDisconnectionReason;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.List;
import org.joda.time.ReadablePartial;
import org.joda.time.Minutes;
import org.joda.time.LocalTime;
import com.smartfoxserver.v2.util.stats.LogAnalyzerTask;
import java.util.concurrent.TimeUnit;
import com.smartfoxserver.v2.util.stats.CCULoggerTask;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEvent;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.entities.SFS2XVersion;
import com.smartfoxserver.bitswarm.data.BindableSocket;
import java.util.Iterator;
import com.smartfoxserver.v2.config.CoreSettings;
import com.smartfoxserver.bitswarm.io.IPacketFinalizer;
import com.smartfoxserver.v2.protocol.binary.DefaultPacketFinalizer;
import com.smartfoxserver.bitswarm.websocket.WebSocketConfig;
import java.io.IOException;
import com.smartfoxserver.v2.util.FlashMasterSocketPolicyLoader;
import com.smartfoxserver.bitswarm.data.BufferType;
import com.smartfoxserver.bitswarm.config.ControllerConfig;
import com.smartfoxserver.v2.config.DefaultConstants;
import com.smartfoxserver.bitswarm.config.SocketConfig;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.config.EngineConfiguration;
import com.smartfoxserver.v2.config.ServerSettings;
import java.util.concurrent.Executor;
import com.smartfoxserver.v2.util.executor.SmartExecutorConfig;
import com.smartfoxserver.v2.util.executor.SmartThreadPoolExecutor;
import com.smartfoxserver.v2.util.monitor.GhostUserHunter;
import com.smartfoxserver.v2.core.SFSShutdownHook;
import org.apache.log4j.PropertyConfigurator;
import com.smartfoxserver.v2.config.SFSService;
import com.smartfoxserver.v2.util.ServerUptime;
import com.smartfoxserver.bitswarm.sessions.ISessionManager;
import com.smartfoxserver.v2.util.SFSRestart;
import com.smartfoxserver.v2.util.PreShutDownCleanerTask;
import java.net.BindException;
import java.io.FileNotFoundException;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.http.JettyServer;
import com.smartfoxserver.v2.entities.managers.SFSPostOffice;
import com.smartfoxserver.v2.core.AdminToolService;
import com.smartfoxserver.v2.util.monitor.TraceMessageMonitor;
import com.smartfoxserver.v2.scala.LSManagerProvider;
import com.smartfoxserver.v2.entities.managers.ILSManager;
import com.smartfoxserver.v2.entities.managers.SFSStatsManager;
import com.smartfoxserver.v2.entities.managers.SFSExtensionManager;
import com.smartfoxserver.v2.entities.managers.SFSUserManager;
import com.smartfoxserver.v2.core.SFSEventManager;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.core.ServiceProvider;
import com.smartfoxserver.v2.entities.IDGenerator;
import com.smartfoxserver.v2.core.IServiceProvider;
import com.smartfoxserver.v2.grid.IGridManager;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.util.DebugConsole;
import com.smartfoxserver.v2.http.IHttpServer;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;
import com.smartfoxserver.v2.entities.managers.IExtensionManager;
import com.smartfoxserver.v2.entities.managers.IUserManager;
import com.smartfoxserver.v2.util.monitor.IGhostUserHunter;
import com.smartfoxserver.v2.entities.managers.IStatsManager;
import com.smartfoxserver.v2.entities.invitation.InvitationManager;
import com.smartfoxserver.v2.entities.managers.IZoneManager;
import com.smartfoxserver.v2.core.ISFSEventManager;
import java.util.concurrent.ThreadPoolExecutor;
import com.smartfoxserver.v2.util.monitor.ITraceMonitor;
import com.smartfoxserver.v2.entities.managers.IMailerService;
import com.smartfoxserver.bitswarm.service.IService;
import com.smartfoxserver.v2.util.TaskScheduler;
import com.smartfoxserver.bitswarm.events.IEventListener;
import com.smartfoxserver.v2.config.IConfigurator;
import com.smartfoxserver.v2.core.ServerState;
import com.smartfoxserver.v2.api.APIManager;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.v2.config.ServiceBootStrapper;
import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.v2.entities.IVersion;

public final class SmartFoxServer
{
    private IVersion version;
    private static SmartFoxServer _instance;
    private static AtomicInteger restartCounter;
    private final ServiceBootStrapper serviceBootStrapper;
    private final BitSwarmEngine bitSwarmEngine;
    private final Logger log;
    private APIManager apiManager;
    private volatile ServerState state;
    private volatile boolean initialized;
    private volatile boolean started;
    private volatile long serverStartTime;
    private volatile boolean isRebooting;
    private volatile boolean isHalting;
    private IConfigurator sfsConfigurator;
    private IEventListener networkEvtListener;
    private TaskScheduler taskScheduler;
    private IService adminToolService;
    private IMailerService mailService;
    private ITraceMonitor traceMonitor;
    private ThreadPoolExecutor sysmtemWorkerPool;
    private static boolean clustered;
    private final ISFSEventManager eventManager;
    private IZoneManager zoneManager;
    private InvitationManager invitationManager;
    private IStatsManager statsManager;
    private IGhostUserHunter ghostUserHunter;
    private IUserManager userManager;
    private IExtensionManager extensionManager;
    private IBannedUserManager bannedUserManger;
    private IHttpServer httpServer;
    private DebugConsole debugConsole;
    private SFSException zoneInitError;
    private IGridManager gridManager;
    private final IServiceProvider services;
    private StartupMessage startupMessage;
    private IDGenerator userIDGenerator;
    
    static {
        SmartFoxServer._instance = null;
        SmartFoxServer.restartCounter = new AtomicInteger(0);
        SmartFoxServer.clustered = false;
    }
    
    public static SmartFoxServer getInstance() {
        if (SmartFoxServer._instance == null) {
            SmartFoxServer._instance = new SmartFoxServer();
        }
        return SmartFoxServer._instance;
    }
    
    private SmartFoxServer() {
        this.state = ServerState.STARTING;
        this.initialized = false;
        this.started = false;
        this.isRebooting = false;
        this.isHalting = false;
        this.startupMessage = new StartupMessage(null);
        SmartFoxServer.clustered = "true".equalsIgnoreCase(System.getProperty("sfs2x.grid"));
        this.services = new ServiceProvider();
        this.version = this.services.getVersion();
        this.serviceBootStrapper = ServiceBootStrapper.getInstance();
        this.bitSwarmEngine = BitSwarmEngine.getInstance();
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.networkEvtListener = (IEventListener)new NetworkEvtListener((NetworkEvtListener)null);
        this.eventManager = new SFSEventManager();
        this.zoneManager = this.services.getZoneManager();
        if (this.userManager == null) {
            this.userManager = new SFSUserManager();
        }
        this.extensionManager = new SFSExtensionManager();
        this.bannedUserManger = this.services.getBannedUserManager();
        this.statsManager = new SFSStatsManager();
        this.taskScheduler = new TaskScheduler(1);
        this.userIDGenerator = this.services.getUIDGenerator();
    }
    
    public String getVersion() {
        return this.version.get();
    }
    
    public void setGridManager(final IGridManager manager) {
        if (!SmartFoxServer.clustered) {
            return;
        }
        if (this.gridManager != null) {
            throw new IllegalStateException("Cannot re-assign this service.");
        }
        this.gridManager = manager;
    }
    
    public IGridManager getGridManager() {
        return this.gridManager;
    }
    
    public ILSManager getLSManager() {
        return LSManagerProvider.instance();
    }
    
    public IServiceProvider getServiceProvider() {
        return this.services;
    }
    
    public IDGenerator getUIDGenerator() {
        return this.userIDGenerator;
    }
    
    public void start() {
        try {
            if (!this.initialized) {
                this.initialize();
            }
            this.sfsConfigurator.loadConfiguration();
            try {
                LSManagerProvider.initializeServerLicense();
            }
            catch (SFSException e) {
                this.log.warn(e.toString());
            }
            this.initSystemWorkers();
            this.configureServer();
            this.configureBitSwarm();
            this.traceMonitor = new TraceMessageMonitor();
            try {
                this.zoneManager.initializeZones();
            }
            catch (SFSException err) {
                this.zoneInitError = err;
            }
            (this.adminToolService = (IService)new AdminToolService()).init((Object)null);
            if (this.sfsConfigurator.getServerSettings().mailer.isActive) {
                (this.mailService = new SFSPostOffice()).init((Object)this.sfsConfigurator.getServerSettings().mailer);
            }
            this.bitSwarmEngine.start("SmartFoxServer 2X");
            if (this.sfsConfigurator.getServerSettings().webServer.isActive) {
                try {
                    (this.httpServer = new JettyServer()).init((Object)null);
                    this.httpServer.start();
                }
                catch (Exception e2) {
                    this.log.warn(e2.toString());
                }
            }
        }
        catch (FileNotFoundException e3) {
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(e3);
            msg.setDescription("There has been a problem loading the server configuration. The server cannot start.");
            msg.setPossibleCauses("Make sure that core.xml and server.xml files exist in your config/ folder.");
            this.log.error(msg.toString());
        }
        catch (BindException e4) {
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(e4);
            msg.setDescription("The specified TCP port cannot be bound to the configured IP address.");
            msg.setPossibleCauses("Probably you are running another instance of SFS2X. Please double check using the AdminTool.");
            msg.addInfo("Start a new browser page at http://<your-sfs-domain>/admin/");
            msg.addInfo("If the problem persists, email us the content of this error message to support[at]smartfoxserver.com");
            this.log.error(msg.toString());
        }
        catch (SFSException e) {
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(e);
            msg.setDescription("An error occurred during the Server boot, preventing it to start.");
            this.log.error(msg.toString());
        }
        catch (Exception e2) {
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(e2);
            msg.setDescription("Unexpected error during Server boot. The server cannot start.");
            msg.addInfo("Solution: Please email us the content of this error message, including the stack trace to support[at]smartfoxserver.com");
            this.log.error(msg.toString());
        }
    }
    
    public boolean isGrid() {
        return SmartFoxServer.clustered;
    }
    
    public static boolean grid() {
        return SmartFoxServer.clustered;
    }
    
    public int getRestartCount() {
        return SmartFoxServer.restartCounter.get();
    }
    
    public synchronized void restart() {
        if (this.isRebooting) {
            return;
        }
        this.isRebooting = true;
        this.log.warn("*** SERVER RESTARTING ***");
        try {
            if (this.httpServer != null) {
                this.httpServer.destroy((Object)null);
            }
            this.bitSwarmEngine.shutDownSequence();
            this.started = false;
            new PreShutDownCleanerTask(this);
            final Thread restarter = new SFSRestart();
            restarter.start();
        }
        catch (Exception e) {
            this.log.error("Restart Failure: " + e);
        }
    }
    
    public void halt() {
        if (this.isHalting) {
            return;
        }
        this.isHalting = true;
        new PreShutDownCleanerTask(this);
        this.log.warn("*** SERVER HALTING ***");
        try {
            final Thread stopper = new Thread(new Runnable() {
                int countDown = 3;
                
                @Override
                public void run() {
                    while (this.countDown > 0) {
                        SmartFoxServer.this.log.warn("Server Halt in " + this.countDown-- + " seconds...");
                        try {
                            Thread.sleep(1000L);
                        }
                        catch (InterruptedException ex) {}
                    }
                    System.exit(0);
                }
            });
            stopper.start();
        }
        catch (Exception e) {
            this.log.error("Halt Failure: " + e);
        }
    }
    
    public boolean isStarted() {
        return this.started;
    }
    
    public boolean isProcessControlAllowed() {
        final String osName = System.getProperty("os.name");
        return osName.toLowerCase().indexOf("linux") != -1 || osName.toLowerCase().indexOf("mac os x") != -1 || osName.toLowerCase().indexOf("windows") != -1;
    }
    
    public ITraceMonitor getTraceMonitor() {
        return this.traceMonitor;
    }
    
    public IMailerService getMailService() {
        return this.mailService;
    }
    
    public TaskScheduler getTaskScheduler() {
        return this.taskScheduler;
    }
    
    public ISFSEventManager getEventManager() {
        return this.eventManager;
    }
    
    public IZoneManager getZoneManager() {
        return this.zoneManager;
    }
    
    public IExtensionManager getExtensionManager() {
        return this.extensionManager;
    }
    
    public IBannedUserManager getBannedUserManager() {
        return this.bannedUserManger;
    }
    
    public InvitationManager getInvitationManager() {
        return this.invitationManager;
    }
    
    public IUserManager getUserManager() {
        return this.userManager;
    }
    
    public ISessionManager getSessionManager() {
        return this.bitSwarmEngine.getSessionManager();
    }
    
    public ServerState getState() {
        return this.state;
    }
    
    public IConfigurator getConfigurator() {
        return this.sfsConfigurator;
    }
    
    public int getMinClientApiVersion() {
        return 60;
    }
    
    public APIManager getAPIManager() {
        return this.apiManager;
    }
    
    public IStatsManager getStatsManager() {
        return this.statsManager;
    }
    
    public IHttpServer getHttpServer() {
        return this.httpServer;
    }
    
    public ServerUptime getUptime() {
        if (this.serverStartTime == 0L) {
            throw new IllegalStateException("Server not ready yet, cannot provide uptime!");
        }
        return new ServerUptime(System.currentTimeMillis() - this.serverStartTime);
    }
    
    public void startDebugConsole() {
        if (this.debugConsole != null) {
            throw new IllegalStateException("A DebugConsole was already created.");
        }
        this.debugConsole = new DebugConsole();
    }
    
    private void initialize() {
        if (this.initialized) {
            throw new IllegalStateException("SmartFoxServer engine already initialized!");
        }
        this.sfsConfigurator = (IConfigurator)this.serviceBootStrapper.load(SFSService.Configurator);
        if (!grid()) {
            PropertyConfigurator.configure("config/log4j.properties");
        }
        this.log.info("Boot sequence starts...");
        LSManagerProvider.instance().init((Object)this.log);
        Runtime.getRuntime().addShutdownHook(new SFSShutdownHook());
        (this.apiManager = new APIManager()).init(null);
        this.ghostUserHunter = new GhostUserHunter();
        this.bitSwarmEngine.addEventListener("serverStarted", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("sessionAdded", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("sessionLost", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("sessionIdle", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("sessionIdleCheckComplete", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("packetDropped", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("sessionReconnectionTry", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("sessionReconnectionSuccess", this.networkEvtListener);
        this.bitSwarmEngine.addEventListener("sessionReconnectionFailure", this.networkEvtListener);
        this.initialized = true;
    }
    
    private void initSystemWorkers() {
        final SmartExecutorConfig cfg = this.getConfigurator().getServerSettings().systemThreadPoolSettings;
        cfg.name = "Sys";
        this.sysmtemWorkerPool = new SmartThreadPoolExecutor(cfg);
    }
    
    public Executor getSystemThreadPool() {
        return this.sysmtemWorkerPool;
    }
    
    private void configureServer() {
        final ServerSettings settings = this.sfsConfigurator.getServerSettings();
        this.taskScheduler.resizeThreadPool(settings.schedulerThreadPoolSize);
        this.bannedUserManger.setAutoRemoveBan(settings.bannedUserManager.isAutoRemove);
        this.bannedUserManger.setName("BannedUserManager");
        this.bannedUserManger.setPersistent(settings.bannedUserManager.isPersistent);
        this.bannedUserManger.setPersistenceClass(settings.bannedUserManager.customPersistenceClass);
        this.bannedUserManger.init((Object)null);
        this.extensionManager.setExtensionMonitorActive(settings.startExtensionFileMonitor);
        ExceptionMessageComposer.globalPrintStackTrace = settings.useDebugMode;
        ExceptionMessageComposer.useExtendedMessages = settings.useFriendlyExceptions;
        this.invitationManager = this.getServiceProvider().getInvitationManager();
        ((IService)this.invitationManager).init((Object)null);
    }
    
    private void configureBitSwarm() {
        final EngineConfiguration engineConfiguration = new EngineConfiguration();
        final CoreSettings coreSettings = this.sfsConfigurator.getCoreSettings();
        final ServerSettings sfsSettings = this.sfsConfigurator.getServerSettings();
        for (final ServerSettings.SocketAddress addr : sfsSettings.socketAddresses) {
            engineConfiguration.addBindableAddress(new SocketConfig(addr.address, addr.port, TransportType.fromName(addr.type)));
        }
        engineConfiguration.addController(new ControllerConfig(coreSettings.systemControllerClass, (Object)DefaultConstants.CORE_SYSTEM_CONTROLLER_ID, 0, sfsSettings.systemControllerRequestQueueSize));
        engineConfiguration.addController(new ControllerConfig(coreSettings.extensionControllerClass, (Object)DefaultConstants.CORE_EXTENSIONS_CONTROLLER_ID, 0, sfsSettings.extensionControllerRequestQueueSize));
        if (sfsSettings.enableSmasherController) {
            engineConfiguration.addController(new ControllerConfig("com.smartfoxserver.v2.controllers.v290.SmasherReqController", (Object)DefaultConstants.CORE_SMASHER_CONTROLLER_ID, 1, 1000));
        }
        engineConfiguration.setDefaultMaxSessionIdleTime(sfsSettings.sessionMaxIdleTime);
        try {
            engineConfiguration.setDefaultMaxLoggedInSessionIdleTime(sfsSettings.userMaxIdleTime);
        }
        catch (IllegalArgumentException err) {
            engineConfiguration.setDefaultMaxLoggedInSessionIdleTime(sfsSettings.sessionMaxIdleTime + 60);
            final ExceptionMessageComposer msg = new ExceptionMessageComposer(err);
            msg.setDescription("Make sure that userMaxIdleTime > socketIdleTime");
            msg.addInfo("The problem was temporarily fixed by setting userMaxIdleTime as: " + engineConfiguration.getDefaultMaxLoggedInSessionIdleTime());
            msg.addInfo("Please review your server.xml file and fix the problem.");
            this.log.warn(msg.toString());
            engineConfiguration.setDefaultMaxLoggedInSessionIdleTime(sfsSettings.sessionMaxIdleTime + 60);
        }
        String protocolType = "Protocol Type is: ";
        if (sfsSettings.useBinaryProtocol) {
            engineConfiguration.setIoHandlerClass("com.smartfoxserver.v2.protocol.SFSIoHandler");
            protocolType = String.valueOf(protocolType) + "BINARY";
        }
        else {
            engineConfiguration.setIoHandlerClass("com.smartfoxserver.v2.protocol.SFSTxtIoHandler");
            protocolType = String.valueOf(protocolType) + "JSON";
        }
        this.log.info(protocolType);
        engineConfiguration.setReadBufferType(coreSettings.readBufferType.equalsIgnoreCase("direct") ? BufferType.DIRECT : BufferType.HEAP);
        engineConfiguration.setWriteBufferType(coreSettings.writeBufferType.equalsIgnoreCase("direct") ? BufferType.DIRECT : BufferType.HEAP);
        engineConfiguration.setReadMaxBufferSize(coreSettings.maxReadBufferSize);
        engineConfiguration.setWriteMaxBufferSize(coreSettings.maxWriteBufferSize);
        engineConfiguration.setMaxIncomingRequestSize(coreSettings.maxIncomingRequestSize);
        engineConfiguration.setSessionPacketQueueMaxSize(coreSettings.sessionPacketQueueSize);
        engineConfiguration.setNagleAlgorithm(!coreSettings.tcpNoDelay);
        engineConfiguration.setPacketDebug(coreSettings.packetDebug);
        engineConfiguration.setLagDebug(coreSettings.lagDebug);
        engineConfiguration.setAcceptorThreadPoolSize(coreSettings.socketAcceptorThreadPoolSize);
        engineConfiguration.setReaderThreadPoolSize(coreSettings.socketReaderThreadPoolSize);
        engineConfiguration.setWriterThreadPoolSize(coreSettings.socketWriterThreadPoolSize);
        engineConfiguration.setFlashCrossdomainPolicyEnabled(sfsSettings.flashCrossdomainPolicy.useMasterSocketPolicy);
        if (engineConfiguration.isFlashCrossdomainPolicyEnabled()) {
            final String crossdomainFile = "config/" + sfsSettings.flashCrossdomainPolicy.policyXmlFile;
            try {
                final String crossdomainXml = new FlashMasterSocketPolicyLoader().loadPolicy(crossdomainFile);
                engineConfiguration.setFlashCrossdomainPolicyXml(crossdomainXml);
            }
            catch (IOException e) {
                final ExceptionMessageComposer msg2 = new ExceptionMessageComposer(e);
                msg2.setDescription("could not load the specified Flash crossdomain policy file: " + crossdomainFile);
                msg2.setPossibleCauses("make sure to put the specified file in the expected location");
                msg2.addInfo("More infos: more details on Flash crossdomain files are found at http://www.adobe.com/devnet/flashplayer/articles/fplayer9_security_04.html");
                this.log.warn(msg2.toString());
            }
        }
        engineConfiguration.setMaxConnectionsFromSameIp(99999);
        final WebSocketConfig wsc = new WebSocketConfig();
        if (sfsSettings.webSocket != null) {
            wsc.setActive(sfsSettings.webSocket.isActive);
            wsc.setHost(sfsSettings.webSocket.bindAddress);
            wsc.setPort(sfsSettings.webSocket.tcpPort);
            wsc.setSslPort(sfsSettings.webSocket.sslPort);
            wsc.setSSL(sfsSettings.webSocket.isSSL);
            wsc.setKeyStoreFile(sfsSettings.webSocket.keyStoreFile);
            wsc.setKeyStorePassword(sfsSettings.webSocket.keyStorePassword);
        }
        engineConfiguration.setWebSocketEngineConfig(wsc);
        engineConfiguration.setPacketFinalizerImpl((IPacketFinalizer)new DefaultPacketFinalizer());
        this.bitSwarmEngine.setConfiguration(engineConfiguration);
    }
    
    private void onSocketEngineStart() {
        this.statsManager.init((Object)null);
        for (final String blockedIp : this.sfsConfigurator.getServerSettings().ipFilter.addressBlackList) {
            this.bitSwarmEngine.getSocketAcceptor().getConnectionFilter().addBannedAddress(blockedIp);
        }
        for (final String allowedIp : this.sfsConfigurator.getServerSettings().ipFilter.addressWhiteList) {
            this.bitSwarmEngine.getSocketAcceptor().getConnectionFilter().addWhiteListAddress(allowedIp);
        }
        this.bitSwarmEngine.getSocketAcceptor().getConnectionFilter().setMaxConnectionsPerIp(this.sfsConfigurator.getServerSettings().ipFilter.maxConnectionsPerAddress);
        final List<BindableSocket> sockets = (List<BindableSocket>)this.bitSwarmEngine.getSocketAcceptor().getBoundSockets();
        String message = "Listening Sockets: ";
        for (final BindableSocket socket : sockets) {
            message = String.valueOf(message) + socket.toString() + " ";
        }
        if (this.sfsConfigurator.getServerSettings().webSocket != null && this.sfsConfigurator.getServerSettings().webSocket.isActive) {
            message = String.valueOf(message) + "{ " + this.sfsConfigurator.getServerSettings().webSocket.bindAddress + ":" + (this.sfsConfigurator.getServerSettings().webSocket.isSSL ? (String.valueOf(this.sfsConfigurator.getServerSettings().webSocket.sslPort) + " (SSL)") : this.sfsConfigurator.getServerSettings().webSocket.tcpPort) + " (WebSocket) }";
        }
        this.log.info(message);
        final String asciiArt_ServerReadyMessage = this.startupMessage.getReadyMessage();
        if (asciiArt_ServerReadyMessage != null) {
            final String text = String.format("%s[ %s ] %s\n", asciiArt_ServerReadyMessage, this.version.get(), "");
            this.log.info(text);
        }
        this.log.info("SmartFoxServer 2X (" + new SFS2XVersion().get() + ") READY!");
        if (this.zoneInitError != null) {
            final ExceptionMessageComposer composer = new ExceptionMessageComposer(this.zoneInitError);
            composer.setDescription("There were startup errors during the Zone Setup");
            composer.addInfo("Please connect via the AdminTool and correct the problem");
            this.log.warn(composer.toString());
        }
        this.serverStartTime = System.currentTimeMillis();
        this.started = true;
        if (this.debugConsole != null) {
            this.debugConsole.init();
        }
        this.eventManager.dispatchEvent(new SFSEvent(SFSEventType.SERVER_READY));
        if (this.bitSwarmEngine.getConfiguration().isPacketDebug()) {
            this.log.info("<< PACKET DEBUGGER ACTIVE >>");
        }
        if (this.getConfigurator().getServerSettings().statsExtraLoggingEnabled) {
            this.taskScheduler.scheduleAtFixedRate(new CCULoggerTask(), 1, 1, TimeUnit.MINUTES);
        }
        final ServerSettings.AnalyticsSettings anSet = this.getConfigurator().getServerSettings().analytics;
        if (anSet != null && anSet.isActive) {
            final LogAnalyzerTask lat = new LogAnalyzerTask(anSet.runOnStartup);
            final LocalTime now = new LocalTime();
            final LocalTime first = now.plusHours(1).withMinuteOfHour(0);
            final int delay = Minutes.minutesBetween((ReadablePartial)now, (ReadablePartial)first).getMinutes();
            this.taskScheduler.scheduleAtFixedRate(lat, delay, 60, TimeUnit.MINUTES);
            if (anSet.runOnStartup) {
                this.taskScheduler.schedule(lat, 1, TimeUnit.MINUTES);
            }
        }
    }
    
    private void onSessionClosed(final ISession session) {
        this.apiManager.getSFSApi().disconnect(session);
    }
    
    private void onSessionIdle(final ISession idleSession) {
        final User user = this.getUserManager().getUserBySession(idleSession);
        if (user == null) {
            throw new SFSRuntimeException("IdleSession event ignored, cannot find any User for Session: " + idleSession);
        }
        if (this.log.isDebugEnabled()) {
            this.log.debug("Terminating idle connection");
        }
        this.apiManager.getSFSApi().disconnectUser(user, ClientDisconnectionReason.IDLE);
    }
    
    private void onSessionReconnectionTry(final ISession session) {
        final User user = this.getUserManager().getUserBySession(session);
        if (user == null) {
            throw new SFSRuntimeException("-Unexpected- Cannot find any User for Session: " + session);
        }
        final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
        evtParams.put(SFSEventParam.ZONE, user.getZone());
        evtParams.put(SFSEventParam.USER, user);
        this.eventManager.dispatchEvent(new SFSEvent(SFSEventType.USER_RECONNECTION_TRY, evtParams));
    }
    
    private void onSessionReconnectionSuccess(final ISession session) {
        final User user = this.getUserManager().getUserBySession(session);
        if (user == null) {
            throw new SFSRuntimeException("-Unexpected- Cannot find any User for Session: " + session);
        }
        final Map<ISFSEventParam, Object> evtParams = new HashMap<ISFSEventParam, Object>();
        evtParams.put(SFSEventParam.ZONE, user.getZone());
        evtParams.put(SFSEventParam.USER, user);
        this.eventManager.dispatchEvent(new SFSEvent(SFSEventType.USER_RECONNECTION_SUCCESS, evtParams));
    }
    
    private void onSessionReconnectionFailure(final ISession incomingSession) {
        this.apiManager.getSFSApi().getResponseAPI().notifyReconnectionFailure(incomingSession);
    }
    
    private final class NetworkEvtListener implements IEventListener
    {
        public void handleEvent(final IEvent event) {
            SmartFoxServer.this.sysmtemWorkerPool.execute(new EventDelegate(event));
        }
    }
    
    private final class EventDelegate implements Runnable
    {
        private final IEvent event;
        
        public EventDelegate(final IEvent event) {
            this.event = event;
        }
        
        @Override
        public void run() {
            try {
                final String evtName = this.event.getName();
                if (evtName.equals("serverStarted")) {
                    SmartFoxServer.this.onSocketEngineStart();
                }
                else if (evtName.equals("sessionLost")) {
                    final ISession session = (ISession)this.event.getParameter("session");
                    if (session == null) {
                        throw new SFSRuntimeException("UNEXPECTED: Session was lost, but session object is NULL!");
                    }
                    SmartFoxServer.this.onSessionClosed(session);
                }
                else if (evtName.equals("sessionIdleCheckComplete") && SmartFoxServer.this.getConfigurator().getServerSettings().ghostHunterEnabled) {
                    SmartFoxServer.this.ghostUserHunter.hunt();
                }
                else if (evtName.equals("sessionIdle")) {
                    SmartFoxServer.this.onSessionIdle((ISession)this.event.getParameter("session"));
                }
                else if (evtName.equals("sessionReconnectionTry")) {
                    SmartFoxServer.this.onSessionReconnectionTry((ISession)this.event.getParameter("session"));
                }
                else if (evtName.equals("sessionReconnectionSuccess")) {
                    SmartFoxServer.this.onSessionReconnectionSuccess((ISession)this.event.getParameter("session"));
                }
                else if (evtName.equals("sessionReconnectionFailure")) {
                    SmartFoxServer.this.onSessionReconnectionFailure((ISession)this.event.getParameter("session"));
                }
            }
            catch (Throwable t) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(t);
                SmartFoxServer.this.log.warn(emc.toString());
            }
        }
    }
    
    private static final class StartupMessage
    {
        String getBootMessage() {
            final String msgKey = SmartFoxServer.grid() ? "grid-boot" : "boot";
            return StringHelper.getAsciiMessage(msgKey);
        }
        
        String getReadyMessage() {
            final String msgKey = SmartFoxServer.grid() ? "grid-ready" : "ready";
            return StringHelper.getAsciiMessage(msgKey);
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

public interface ISFSEventDispatcher
{
    void addEventListener(final SFSEventType p0, final ISFSEventListener p1);
    
    boolean hasEventListener(final SFSEventType p0);
    
    void removeEventListener(final SFSEventType p0, final ISFSEventListener p1);
    
    void dispatchEvent(final ISFSEvent p0);
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.v2.extensions.ExtensionType;
import com.smartfoxserver.v2.extensions.ExtensionReloadMode;
import com.smartfoxserver.v2.extensions.ExtensionLevel;
import com.smartfoxserver.v2.extensions.SFSExtension;
import java.util.List;
import java.util.ArrayList;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.buddylist.SFSBuddyListManager;
import com.smartfoxserver.v2.entities.SFSZone;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.entities.managers.IZoneManager;
import com.smartfoxserver.v2.entities.managers.IExtensionManager;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.service.IService;

public final class AdminToolService implements IService
{
    public static final String ZONE_NAME = "--=={{{ AdminZone }}}==--";
    private static final String EXT_NAME = "Admin";
    private static final String EXT_CLASS = "com.smartfoxserver.v2.admin.AdminExtension";
    private final String name = "AdminToolService";
    private final Logger log;
    private SmartFoxServer sfs;
    private IExtensionManager extensionManager;
    private IZoneManager zoneManager;
    private ISFSExtension adminExtension;
    private Zone adminZone;
    private volatile boolean inited;
    
    public AdminToolService() {
        this.inited = false;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    public void init(final Object param) {
        if (this.inited) {
            throw new IllegalStateException("AdminToolService was already initialized!");
        }
        this.sfs = SmartFoxServer.getInstance();
        this.extensionManager = this.sfs.getExtensionManager();
        this.zoneManager = this.sfs.getZoneManager();
        this.initializeAdminZone();
        this.log.info("AdminTool Service started");
    }
    
    public void destroy(final Object arg0) {
        this.adminExtension.setActive(false);
        this.adminZone.setActive(false);
        this.adminExtension = null;
        this.adminZone = null;
    }
    
    public void handleMessage(final Object message) {
        throw new UnsupportedOperationException("This operation is not supported.");
    }
    
    public String getName() {
        return "AdminToolService";
    }
    
    public void setName(final String arg0) {
    }
    
    private void initializeAdminZone() {
        (this.adminZone = new SFSZone("--=={{{ AdminZone }}}==--")).setId(-1);
        this.adminZone.setActive(true);
        this.adminZone.setCustomLogin(true);
        this.adminZone.setForceLogout(true);
        this.adminZone.setFilterUserNames(false);
        this.adminZone.setFilterRoomNames(false);
        this.adminZone.setGuestUserAllowed(false);
        this.adminZone.setMaxAllowedRooms(1);
        this.adminZone.setMaxAllowedUsers(1000);
        this.adminZone.setMaxUserVariablesAllowed(2);
        this.adminZone.setMaxRoomVariablesAllowed(0);
        this.adminZone.setMinRoomNameChars(0);
        this.adminZone.setMaxRoomNameChars(10);
        this.adminZone.setUserReconnectionSeconds(0);
        this.adminZone.setBuddyListManager(new SFSBuddyListManager(this.adminZone, false));
        this.adminZone.setFilterUserNames(false);
        this.adminZone.setFilterRoomNames(false);
        this.adminZone.setFilterPrivateMessages(false);
        this.adminZone.setUploadEnabled(true);
        this.adminZone.setMaxUserIdleTime(999999999);
        this.adminZone.setDefaultGroups(new ArrayList<String>());
        try {
            final Class<?> extClass = Class.forName("com.smartfoxserver.v2.admin.AdminExtension");
            (this.adminExtension = (SFSExtension)extClass.newInstance()).setActive(true);
            this.adminExtension.setLevel(ExtensionLevel.ZONE);
            this.adminExtension.setName("Admin");
            this.adminExtension.setParentZone(this.adminZone);
            this.adminExtension.setReloadMode(ExtensionReloadMode.NONE);
            this.adminExtension.setType(ExtensionType.JAVA);
        }
        catch (Exception e) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
            emc.setDescription("**FATAL ERROR**, Cannot initialize AdminToolService");
            emc.addInfo("Holy fagioli, Batman! This should really never happen. Something is wrong with this installation");
            emc.addInfo("Please contact our support for help");
            this.log.error(emc.toString());
        }
        this.adminZone.setExtension(this.adminExtension);
        this.extensionManager.addExtension(this.adminExtension);
        this.zoneManager.addZone(this.adminZone);
        this.adminExtension.init();
    }
}

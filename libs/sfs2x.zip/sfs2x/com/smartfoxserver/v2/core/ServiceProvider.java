// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import com.smartfoxserver.v2.util.IWordFilterLoader;
import com.smartfoxserver.v2.entities.IRoomFactory;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;
import com.smartfoxserver.v2.api.ISFSGameApi;
import com.smartfoxserver.v2.entities.invitation.InvitationManager;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;
import com.smartfoxserver.v2.buddylist.IBuddySerializer;
import com.smartfoxserver.v2.api.response.IBuddyInitResponseSerializer;
import com.smartfoxserver.v2.grid.IGridBuddyEventDispatcher;
import com.smartfoxserver.v2.entities.IDGenerator;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.buddylist.BuddyProperties;
import com.smartfoxserver.v2.entities.IVersion;
import com.smartfoxserver.v2.entities.ILoginFinalizer;
import java.lang.reflect.Constructor;
import com.smartfoxserver.grid.SFSGrid;
import com.smartfoxserver.v2.entities.Loggable;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.managers.IZoneManager;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class ServiceProvider extends ObjectFactory implements IServiceProvider
{
    private static final String DEFAULT_ZONE_MANAGER = "com.smartfoxserver.v2.entities.managers.SFSZoneManager";
    private static final String GRID_ZONE_MANAGER = "com.smartfoxserver.grid.service.GridZoneManager";
    public static final String DEFAULT_ZONE_LOGIN = "com.smartfoxserver.v2.scala.DefLI";
    private static final String GRID_ZONE_LOGIN_LOBBY = "com.smartfoxserver.grid.service.GridLobbyLI";
    private static final String GRID_ZONE_LOGIN_FINALIZER = "com.smartfoxserver.grid.service.GridLoginFinalizer";
    private static final String DEFAULT_BUDDY_PROPERTIES = "com.smartfoxserver.v2.buddylist.SFSBuddyProperties";
    private static final String GRID_BUDDY_PROPERTIES = "com.smartfoxserver.grid.entities.BuddyPropertiesWrapper";
    private static final String DEFAULT_BUDDY_LIST_MANAGER = "com.smartfoxserver.v2.buddylist.SFSBuddyListManager";
    private static final String GRID_BUDDY_LIST_MANAGER = "com.smartfoxserver.grid.service.GridBuddyListManager";
    private static final String DEFAULT_VERSION = "com.smartfoxserver.v2.entities.SFS2XVersion";
    private static final String GRID_VERSION = "com.smartfoxserver.grid.entities.GridVersion";
    private static final String DEFAULT_UID_GENERATOR = "com.smartfoxserver.v2.entities.SFSIDGenerator";
    private static final String GRID_UID_GENERATOR = "com.smartfoxserver.grid.entities.GridUIDGenerator";
    private static final String GRID_BUDDY_EVENT_DISPATCHER = "com.smartfoxserver.grid.service.GridBuddyEventDispatcher";
    private static final String DEFAULT_BUDDY_INIT = "com.smartfoxserver.v2.api.response.DefaultBuddyInitSerializer";
    private static final String GRID_BUDDY_INIT = "com.smartfoxserver.grid.service.GridBuddyInitResponseSerializer";
    private static final String DEFAULT_BUDDY_SERIALIZER = "com.smartfoxserver.v2.buddylist.DefaultBuddySerializer";
    private static final String GRID_BUDDY_SERIALIZER = "com.smartfoxserver.grid.service.GridBuddySerializer";
    private static final String DEFAULT_BANNED_USER_MANAGER = "com.smartfoxserver.v2.entities.managers.SFSBannedUserManager";
    private static final String GRID_BANNED_USER_MANAGER = "com.smartfoxserver.grid.service.GridBannedUserManager";
    private static final String DEFAULT_INVITATION_MANAGER = "com.smartfoxserver.v2.entities.invitation.SFSInvitationManager";
    private static final String GRID_INVITATION_MANAGER = "com.smartfoxserver.grid.service.GridInvitationManager";
    private static final String DEFAULT_GAME_API = "com.smartfoxserver.v2.api.SFSGameApi";
    private static final String GRID_GAME_API = "com.smartfoxserver.grid.api.SFSGridGameApi";
    private static final String DEFAULT_INVITATION_CALLBACK = "com.smartfoxserver.v2.game.GenericInvitationCallback";
    private static final String GRID_INVITATION_CALLBACK = "com.smartfoxserver.grid.api.GridInvitationCallback";
    private static final String DEFAULT_WORD_FILTER_LOADER = "com.smartfoxserver.v2.util.DefaultWordFilterLoader";
    private static final String GRID_WORD_FILTER_LOADER = "com.smartfoxserver.grid.service.util.GridWordFilterLoader";
    private static final String DEFAULT_LOGIN_GATEWAY = "com.smartfoxserver.v2.controllers.util.DefaultLoginGateway";
    private static final String GRID_LOGIN_GATEWAY = "com.smartfoxserver.grid.service.GridLoginGateway";
    private static final String DEFAULT_ROOM_FACTORY = "com.smartfoxserver.v2.entities.DefaultRoomFactory";
    private static final String GRID_ROOM_FACTORY = "com.smartfoxserver.grid.entities.GridRoomFactory";
    private static final String GRID_LOGIN_IMPL_PROVIDER = "com.smartfoxserver.grid.service.GridLoginImplProvider";
    private static final String GRID_SHUT_DOWN_HELPER = "com.smartfoxserver.grid.service.util.GracefulShutDownHelper";
    private static final String DEFAULT_INVITATION_ID_GENERATOR = "com.smartfoxserver.v2.entities.SFSIDGenerator";
    private static final String GRID_INVITATION_ID_GENERATOR = "com.smartfoxserver.grid.entities.GridInvitationIDGenerator";
    private final Logger log;
    private final boolean isGrid;
    
    public ServiceProvider() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.isGrid = SmartFoxServer.grid();
    }
    
    @Override
    public IZoneManager getZoneManager() {
        return (IZoneManager)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.service.GridZoneManager" : "com.smartfoxserver.v2.entities.managers.SFSZoneManager");
    }
    
    @Override
    public Loggable getLoginImpl(final Zone zone) {
        String loginClass = "com.smartfoxserver.v2.scala.DefLI";
        if (this.isGrid) {
            final boolean isAdminZone = zone.getName().equals("--=={{{ AdminZone }}}==--");
            if (!isAdminZone && SFSGrid.manager().isLobby()) {
                loginClass = "com.smartfoxserver.grid.service.GridLobbyLI";
            }
        }
        Object serviceImpl = null;
        try {
            final Class<?> serviceClass = Class.forName(loginClass);
            final Constructor<?> constr = serviceClass.getConstructors()[0];
            serviceImpl = constr.newInstance(zone);
        }
        catch (Exception exc) {
            this.logServiceFail(loginClass, exc);
        }
        return (Loggable)serviceImpl;
    }
    
    @Override
    public ILoginFinalizer getLoginFinalizer() {
        return (ILoginFinalizer)this.makeInstance("com.smartfoxserver.grid.service.GridLoginFinalizer");
    }
    
    @Override
    public IVersion getVersion() {
        return (IVersion)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.entities.GridVersion" : "com.smartfoxserver.v2.entities.SFS2XVersion");
    }
    
    @Override
    public BuddyProperties getBuddyPropertiesImpl() {
        return (BuddyProperties)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.entities.BuddyPropertiesWrapper" : "com.smartfoxserver.v2.buddylist.SFSBuddyProperties");
    }
    
    @Override
    public BuddyListManager getBuddyListManagerImpl(final Zone zone, final boolean isActive) {
        final String managerClass = this.isGrid ? "com.smartfoxserver.grid.service.GridBuddyListManager" : "com.smartfoxserver.v2.buddylist.SFSBuddyListManager";
        Object serviceImpl = null;
        try {
            final Class<?> serviceClass = Class.forName(managerClass);
            final Constructor<?> constr = serviceClass.getConstructors()[0];
            serviceImpl = constr.newInstance(zone, isActive);
        }
        catch (Exception exc) {
            this.logServiceFail(managerClass, exc);
        }
        return (BuddyListManager)serviceImpl;
    }
    
    @Override
    public IDGenerator getUIDGenerator() {
        return (IDGenerator)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.entities.GridUIDGenerator" : "com.smartfoxserver.v2.entities.SFSIDGenerator");
    }
    
    @Override
    public IGridBuddyEventDispatcher getGridBuddyEventDisptacher() {
        if (this.isGrid) {
            return (IGridBuddyEventDispatcher)this.makeInstance("com.smartfoxserver.grid.service.GridBuddyEventDispatcher");
        }
        return null;
    }
    
    @Override
    public IBuddyInitResponseSerializer getBuddyInitResponseSerializer() {
        return (IBuddyInitResponseSerializer)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.service.GridBuddyInitResponseSerializer" : "com.smartfoxserver.v2.api.response.DefaultBuddyInitSerializer");
    }
    
    @Override
    public IBuddySerializer getBuddySerializer() {
        return (IBuddySerializer)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.service.GridBuddySerializer" : "com.smartfoxserver.v2.buddylist.DefaultBuddySerializer");
    }
    
    @Override
    public IBannedUserManager getBannedUserManager() {
        return (IBannedUserManager)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.service.GridBannedUserManager" : "com.smartfoxserver.v2.entities.managers.SFSBannedUserManager");
    }
    
    @Override
    public InvitationManager getInvitationManager() {
        return (InvitationManager)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.service.GridInvitationManager" : "com.smartfoxserver.v2.entities.invitation.SFSInvitationManager");
    }
    
    @Override
    public ISFSGameApi getGameApi() {
        return (ISFSGameApi)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.api.SFSGridGameApi" : "com.smartfoxserver.v2.api.SFSGameApi");
    }
    
    @Override
    public InvitationCallback getGenericInvitationCallback() {
        return (InvitationCallback)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.api.GridInvitationCallback" : "com.smartfoxserver.v2.game.GenericInvitationCallback");
    }
    
    @Override
    public IRoomFactory getRoomFactory() {
        return (IRoomFactory)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.entities.GridRoomFactory" : "com.smartfoxserver.v2.entities.DefaultRoomFactory");
    }
    
    @Override
    public IWordFilterLoader getWordFilterLoader() {
        return (IWordFilterLoader)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.service.util.GridWordFilterLoader" : "com.smartfoxserver.v2.util.DefaultWordFilterLoader");
    }
    
    @Override
    public IDGenerator getInvitationIDGenerator() {
        return (IDGenerator)this.makeInstance(this.isGrid ? "com.smartfoxserver.grid.entities.GridInvitationIDGenerator" : "com.smartfoxserver.v2.entities.SFSIDGenerator");
    }
    
    @Override
    public Runnable getShutDownHelper() {
        return this.isGrid ? ((Runnable)this.makeInstance("com.smartfoxserver.grid.service.util.GracefulShutDownHelper")) : null;
    }
    
    private Object makeInstance(final String serviceClass) {
        Object serviceImpl = null;
        try {
            serviceImpl = this.loadClass(serviceClass);
        }
        catch (Exception exc) {
            this.logServiceFail(serviceClass, exc);
        }
        return serviceImpl;
    }
    
    private void logServiceFail(final String serviceName, final Exception exc) {
        final String msg = "Failed loading service: " + serviceName;
        exc.printStackTrace();
        if (this.log.isDebugEnabled()) {
            this.log.debug(msg, (Throwable)exc);
        }
        else {
            this.log.error(msg);
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import com.smartfoxserver.v2.util.IWordFilterLoader;
import com.smartfoxserver.v2.entities.IRoomFactory;
import com.smartfoxserver.v2.entities.invitation.InvitationCallback;
import com.smartfoxserver.v2.api.ISFSGameApi;
import com.smartfoxserver.v2.entities.invitation.InvitationManager;
import com.smartfoxserver.v2.entities.managers.IBannedUserManager;
import com.smartfoxserver.v2.buddylist.IBuddySerializer;
import com.smartfoxserver.v2.api.response.IBuddyInitResponseSerializer;
import com.smartfoxserver.v2.grid.IGridBuddyEventDispatcher;
import com.smartfoxserver.v2.entities.IDGenerator;
import com.smartfoxserver.v2.buddylist.BuddyListManager;
import com.smartfoxserver.v2.buddylist.BuddyProperties;
import com.smartfoxserver.v2.entities.IVersion;
import com.smartfoxserver.v2.entities.ILoginFinalizer;
import com.smartfoxserver.v2.entities.Loggable;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.managers.IZoneManager;

public interface IServiceProvider
{
    IZoneManager getZoneManager();
    
    Loggable getLoginImpl(final Zone p0);
    
    ILoginFinalizer getLoginFinalizer();
    
    IVersion getVersion();
    
    BuddyProperties getBuddyPropertiesImpl();
    
    BuddyListManager getBuddyListManagerImpl(final Zone p0, final boolean p1);
    
    IDGenerator getUIDGenerator();
    
    IGridBuddyEventDispatcher getGridBuddyEventDisptacher();
    
    IBuddyInitResponseSerializer getBuddyInitResponseSerializer();
    
    IBuddySerializer getBuddySerializer();
    
    IBannedUserManager getBannedUserManager();
    
    InvitationManager getInvitationManager();
    
    ISFSGameApi getGameApi();
    
    InvitationCallback getGenericInvitationCallback();
    
    IDGenerator getInvitationIDGenerator();
    
    IRoomFactory getRoomFactory();
    
    IWordFilterLoader getWordFilterLoader();
    
    Runnable getShutDownHelper();
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.Executor;
import com.smartfoxserver.v2.util.executor.SmartExecutorConfig;
import com.smartfoxserver.v2.util.executor.SmartThreadPoolExecutor;
import com.smartfoxserver.v2.SmartFoxServer;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.util.Set;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

public final class SFSEventManager extends BaseCoreService implements ISFSEventManager
{
    private ThreadPoolExecutor threadPool;
    private final Map<SFSEventType, Set<ISFSEventListener>> listenersByEvent;
    private final Logger logger;
    private boolean inited;
    
    public SFSEventManager() {
        this.inited = false;
        this.setName("SFSEventManager");
        this.logger = LoggerFactory.getLogger((Class)SFSEventManager.class);
        this.listenersByEvent = new ConcurrentHashMap<SFSEventType, Set<ISFSEventListener>>();
    }
    
    @Override
    public synchronized void init(final Object o) {
        if (!this.inited) {
            super.init(o);
            final SmartExecutorConfig cfg = SmartFoxServer.getInstance().getConfigurator().getServerSettings().extensionThreadPoolSettings;
            cfg.name = "Ext";
            this.threadPool = new SmartThreadPoolExecutor(cfg);
            this.logger.info(String.valueOf(this.name) + " initialized");
            this.inited = true;
        }
    }
    
    @Override
    public void destroy(final Object o) {
        super.destroy(o);
        this.listenersByEvent.clear();
        this.logger.info(String.valueOf(this.name) + " shut down.");
    }
    
    @Override
    public Executor getThreadPool() {
        return this.threadPool;
    }
    
    @Override
    public void setThreadPoolSize(final int poolSize) {
        this.threadPool.setCorePoolSize(poolSize);
    }
    
    @Override
    public synchronized void addEventListener(final SFSEventType type, final ISFSEventListener listener) {
        Set<ISFSEventListener> listeners = this.listenersByEvent.get(type);
        if (listeners == null) {
            listeners = new CopyOnWriteArraySet<ISFSEventListener>();
            this.listenersByEvent.put(type, listeners);
        }
        listeners.add(listener);
    }
    
    @Override
    public boolean hasEventListener(final SFSEventType type) {
        boolean found = false;
        final Set<ISFSEventListener> listeners = this.listenersByEvent.get(type);
        if (listeners != null && listeners.size() > 0) {
            found = true;
        }
        return found;
    }
    
    @Override
    public synchronized void removeEventListener(final SFSEventType type, final ISFSEventListener listener) {
        final Set<ISFSEventListener> listeners = this.listenersByEvent.get(type);
        if (listeners != null) {
            listeners.remove(listener);
        }
    }
    
    @Override
    public void dispatchEvent(final ISFSEvent event) {
        final Set<ISFSEventListener> listeners = this.listenersByEvent.get(event.getType());
        if (listeners != null && listeners.size() > 0) {
            for (final ISFSEventListener listener : listeners) {
                this.threadPool.execute(new SFSEventRunner(listener, event));
            }
        }
    }
    
    private static final class SFSEventRunner implements Runnable
    {
        private final ISFSEventListener listener;
        private final ISFSEvent event;
        private final Logger log;
        
        public SFSEventRunner(final ISFSEventListener listener, final ISFSEvent event) {
            this.log = LoggerFactory.getLogger((Class)SFSEventManager.class);
            this.listener = listener;
            this.event = event;
        }
        
        @Override
        public void run() {
            try {
                this.listener.handleServerEvent(this.event);
            }
            catch (Throwable t) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(t);
                emc.setDescription("Error handling event: " + this.event + " Listener: " + this.listener);
                this.log.warn(emc.toString());
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

public class SFSConstants
{
    public static final String REQUEST_LOGIN_DATA_OUT = "$FS_REQUEST_LOGIN_DATA_OUT";
    public static final String NEW_LOGIN_NAME = "$FS_NEW_LOGIN_NAME";
    public static final String SESSION_CLIENT_TYPE = "ClientType";
    public static final String DEFAULT_PLAYER_ID_GENERATOR = "com.smartfoxserver.v2.util.DefaultPlayerIdGenerator";
    public static final String CLIENT_UNKNOWN_TYPE = "Unknown";
    public static final String REQUEST_UDP_PACKET_ID = "$FS_REQUEST_UDP_TIMESTAMP";
    public static final String STORAGE_DATA_FOLDER = "data/";
    public static final String BLUEBOX_CONNECTION_MANAGER_INSTANCE = "connectionManagerInstance";
    public static final int CCU_LOGGER_RUN_INTERVAL = 1;
    public static final int LOG_ANALYSIS_RUN_CHECK_INTERVAL = 60;
    public static final String ATTR_ENCRYPTED = "Encrypted";
    public static final String SESSION_PERMISSION = "$permission";
    public static final String SESSION_FAILED_LOGINS_COUNT = "FailedLoginCounts";
    public static final String SESSION_GEOLOCATION = "GeoLocation";
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

public enum SFSEventParam implements ISFSEventParam
{
    ZONE("ZONE", 0), 
    ROOM("ROOM", 1), 
    USER("USER", 2), 
    LOGIN_NAME("LOGIN_NAME", 3), 
    LOGIN_PASSWORD("LOGIN_PASSWORD", 4), 
    LOGIN_IN_DATA("LOGIN_IN_DATA", 5), 
    LOGIN_OUT_DATA("LOGIN_OUT_DATA", 6), 
    JOINED_ROOMS("JOINED_ROOMS", 7), 
    PLAYER_ID("PLAYER_ID", 8), 
    PLAYER_IDS_BY_ROOM("PLAYER_IDS_BY_ROOM", 9), 
    SESSION("SESSION", 10), 
    DISCONNECTION_REASON("DISCONNECTION_REASON", 11), 
    VARIABLES("VARIABLES", 12), 
    VARIABLES_MAP("VARIABLES_MAP", 13), 
    RECIPIENT("RECIPIENT", 14), 
    MESSAGE("MESSAGE", 15), 
    OBJECT("OBJECT", 16), 
    UPLOAD_FILE_LIST("UPLOAD_FILE_LIST", 17), 
    UPLOAD_HTTP_PARAMS("UPLOAD_HTTP_PARAMS", 18);
    
    private SFSEventParam(final String s, final int n) {
    }
}

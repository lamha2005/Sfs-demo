// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import java.util.concurrent.atomic.AtomicInteger;

public abstract class BaseCoreService implements ICoreService
{
    private static final AtomicInteger serviceId;
    private static final String DEFAULT_NAME = "AnonymousService-";
    protected String name;
    protected volatile boolean active;
    
    static {
        serviceId = new AtomicInteger(0);
    }
    
    public BaseCoreService() {
        this.active = false;
    }
    
    public void init(final Object o) {
        this.name = getId();
        this.active = true;
    }
    
    public void destroy(final Object o) {
        this.active = false;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void handleMessage(final Object param) {
        throw new UnsupportedOperationException("This method should be overridden by the child class!");
    }
    
    @Override
    public boolean isActive() {
        return this.active;
    }
    
    @Override
    public String toString() {
        return "[Core Service]: " + this.name + ", State: " + (this.isActive() ? "active" : "not active");
    }
    
    protected static String getId() {
        return "AnonymousService-" + BaseCoreService.serviceId.getAndIncrement();
    }
}

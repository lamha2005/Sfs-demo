// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import com.smartfoxserver.bitswarm.service.IService;

public interface ICoreService extends IService
{
    boolean isActive();
}

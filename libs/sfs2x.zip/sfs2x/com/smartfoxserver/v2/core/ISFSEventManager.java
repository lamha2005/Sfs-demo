// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import java.util.concurrent.Executor;
import com.smartfoxserver.bitswarm.service.IService;

public interface ISFSEventManager extends ISFSEventDispatcher, IService
{
    void setThreadPoolSize(final int p0);
    
    Executor getThreadPool();
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.util.PreShutDownCleanerTask;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class SFSShutdownHook extends Thread
{
    private final Logger log;
    
    public SFSShutdownHook() {
        super("SFS2X ShutdownHook");
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void run() {
        new PreShutDownCleanerTask(SmartFoxServer.getInstance());
        this.log.warn("SFS2X is shutting down. The process may take a few seconds...");
    }
}

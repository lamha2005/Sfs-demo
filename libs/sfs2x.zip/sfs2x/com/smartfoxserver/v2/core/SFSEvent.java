// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import java.util.Map;

public class SFSEvent implements ISFSEvent
{
    private final SFSEventType type;
    private final Map<ISFSEventParam, Object> params;
    
    public SFSEvent(final SFSEventType type) {
        this(type, null);
    }
    
    public SFSEvent(final SFSEventType type, final Map<ISFSEventParam, Object> params) {
        this.type = type;
        this.params = params;
    }
    
    @Override
    public SFSEventType getType() {
        return this.type;
    }
    
    @Override
    public Object getParameter(final ISFSEventParam id) {
        Object param = null;
        if (this.params != null) {
            param = this.params.get(id);
        }
        return param;
    }
    
    @Override
    public String toString() {
        return String.format("{ %s, Params: %s }", this.type, (this.params != null) ? this.params.keySet() : "none");
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

public enum SFSEventSysParam implements ISFSEventParam
{
    REQUEST_OBJ("REQUEST_OBJ", 0), 
    NEXT_COMMAND("NEXT_COMMAND", 1), 
    TRACE_MESSAGE_LIST("TRACE_MESSAGE_LIST", 2);
    
    private SFSEventSysParam(final String s, final int n) {
    }
}

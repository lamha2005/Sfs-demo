// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

public class BaseSFSEventListener
{
    private Object parentObject;
    
    public BaseSFSEventListener() {
        this.parentObject = null;
    }
    
    public BaseSFSEventListener(final Object parentObject) {
        this.parentObject = parentObject;
    }
    
    public Object getParentObject() {
        return this.parentObject;
    }
    
    public void handleServerEvent(final ISFSEvent event) {
    }
    
    @Override
    public String toString() {
        return (this.parentObject == null) ? "{ Anonymous listener }" : this.parentObject.toString();
    }
}

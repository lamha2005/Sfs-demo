// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

import java.util.Map;

public class SFSSystemEvent extends SFSEvent
{
    private final Map<ISFSEventParam, Object> sysParams;
    
    public SFSSystemEvent(final SFSEventType type, final Map<ISFSEventParam, Object> params, final Map<ISFSEventParam, Object> sysParams) {
        super(type, params);
        this.sysParams = sysParams;
    }
    
    public Object getSysParameter(final ISFSEventParam key) {
        return this.sysParams.get(key);
    }
    
    public void setSysParameter(final ISFSEventParam key, final Object value) {
        if (this.sysParams != null) {
            this.sysParams.put(key, value);
        }
    }
}

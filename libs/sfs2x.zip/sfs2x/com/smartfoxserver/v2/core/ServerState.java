// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

public enum ServerState
{
    STARTING("STARTING", 0), 
    STARTED("STARTED", 1), 
    REBOOTING("REBOOTING", 2);
    
    private ServerState(final String s, final int n) {
    }
}

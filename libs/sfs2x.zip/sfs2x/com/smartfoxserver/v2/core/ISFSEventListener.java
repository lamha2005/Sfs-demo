// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.core;

public interface ISFSEventListener
{
    void handleServerEvent(final ISFSEvent p0) throws Exception;
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol;

public enum SFSProtocolType
{
    BINARY("BINARY", 0), 
    TEXT("TEXT", 1), 
    AUTO("AUTO", 2);
    
    private SFSProtocolType(final String s, final int n) {
    }
}

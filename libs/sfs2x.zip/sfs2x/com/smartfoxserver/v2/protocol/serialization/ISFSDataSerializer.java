// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.serialization;

import com.smartfoxserver.v2.entities.data.SFSArray;
import java.sql.SQLException;
import com.smartfoxserver.v2.entities.data.SFSObject;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public interface ISFSDataSerializer
{
    byte[] object2binary(final ISFSObject p0);
    
    byte[] array2binary(final ISFSArray p0);
    
    ISFSObject binary2object(final byte[] p0);
    
    ISFSArray binary2array(final byte[] p0);
    
    String object2json(final Map<String, Object> p0);
    
    String array2json(final List<Object> p0);
    
    ISFSObject json2object(final String p0);
    
    ISFSArray json2array(final String p0);
    
    ISFSObject pojo2sfs(final Object p0);
    
    Object sfs2pojo(final ISFSObject p0);
    
    SFSObject resultSet2object(final ResultSet p0) throws SQLException;
    
    SFSArray resultSet2array(final ResultSet p0) throws SQLException;
}

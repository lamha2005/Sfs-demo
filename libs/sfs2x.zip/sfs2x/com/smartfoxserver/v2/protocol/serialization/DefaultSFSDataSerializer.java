// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.serialization;

import java.util.concurrent.LinkedBlockingDeque;
import java.util.ArrayDeque;
import java.util.concurrent.Delayed;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.PriorityQueue;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.TreeSet;
import java.util.LinkedHashSet;
import java.util.HashSet;
import java.util.Vector;
import java.util.LinkedList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import org.apache.commons.lang.StringUtils;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.apache.commons.io.IOUtils;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.sql.SQLException;
import java.sql.Blob;
import java.sql.ResultSetMetaData;
import java.sql.ResultSet;
import com.smartfoxserver.v2.entities.data.SFSObjectLite;
import net.sf.json.JSONObject;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.data.SFSArrayLite;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSDataWrapper;
import com.smartfoxserver.v2.exceptions.SFSCodecException;
import com.smartfoxserver.v2.entities.data.SFSDataType;
import com.smartfoxserver.v2.entities.data.SFSArray;
import java.nio.ByteBuffer;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import net.sf.json.JSONArray;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class DefaultSFSDataSerializer implements ISFSDataSerializer
{
    private static final String CLASS_MARKER_KEY = "$C";
    private static final String CLASS_FIELDS_KEY = "$F";
    private static final String FIELD_NAME_KEY = "N";
    private static final String FIELD_VALUE_KEY = "V";
    private static DefaultSFSDataSerializer instance;
    private static int BUFFER_CHUNK_SIZE;
    private final Logger logger;
    
    static {
        DefaultSFSDataSerializer.instance = new DefaultSFSDataSerializer();
        DefaultSFSDataSerializer.BUFFER_CHUNK_SIZE = 512;
    }
    
    public static DefaultSFSDataSerializer getInstance() {
        return DefaultSFSDataSerializer.instance;
    }
    
    private DefaultSFSDataSerializer() {
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    public int getUnsignedByte(final byte b) {
        return 0xFF & b;
    }
    
    @Override
    public String array2json(final List<Object> array) {
        return JSONArray.fromObject((Object)array).toString();
    }
    
    @Override
    public ISFSArray binary2array(final byte[] data) {
        if (data.length < 3) {
            throw new IllegalStateException("Can't decode an SFSArray. Byte data is insufficient. Size: " + data.length + " bytes");
        }
        final ByteBuffer buffer = ByteBuffer.allocate(data.length);
        buffer.put(data);
        buffer.flip();
        return this.decodeSFSArray(buffer);
    }
    
    private ISFSArray decodeSFSArray(final ByteBuffer buffer) {
        final ISFSArray sfsArray = SFSArray.newInstance();
        final byte headerBuffer = buffer.get();
        if (headerBuffer != SFSDataType.SFS_ARRAY.getTypeID()) {
            throw new IllegalStateException("Invalid SFSDataType. Expected: " + SFSDataType.SFS_ARRAY.getTypeID() + ", found: " + headerBuffer);
        }
        final short size = buffer.getShort();
        if (size < 0) {
            throw new IllegalStateException("Can't decode SFSArray. Size is negative = " + size);
        }
        try {
            for (int i = 0; i < size; ++i) {
                final SFSDataWrapper decodedObject = this.decodeObject(buffer);
                if (decodedObject == null) {
                    throw new IllegalStateException("Could not decode SFSArray item at index: " + i);
                }
                sfsArray.add(decodedObject);
            }
        }
        catch (SFSCodecException codecError) {
            throw new IllegalArgumentException(codecError.getMessage());
        }
        return sfsArray;
    }
    
    @Override
    public ISFSObject binary2object(final byte[] data) {
        if (data.length < 3) {
            throw new IllegalStateException("Can't decode an SFSObject. Byte data is insufficient. Size: " + data.length + " bytes");
        }
        final ByteBuffer buffer = ByteBuffer.allocate(data.length);
        buffer.put(data);
        buffer.flip();
        return this.decodeSFSObject(buffer);
    }
    
    private ISFSObject decodeSFSObject(final ByteBuffer buffer) {
        final ISFSObject sfsObject = SFSObject.newInstance();
        final byte headerBuffer = buffer.get();
        if (headerBuffer != SFSDataType.SFS_OBJECT.getTypeID()) {
            throw new IllegalStateException("Invalid SFSDataType. Expected: " + SFSDataType.SFS_OBJECT.getTypeID() + ", found: " + headerBuffer);
        }
        final short size = buffer.getShort();
        if (size < 0) {
            throw new IllegalStateException("Can't decode SFSObject. Size is negative = " + size);
        }
        try {
            for (int i = 0; i < size; ++i) {
                final short keySize = buffer.getShort();
                if (keySize < 0 || keySize > 255) {
                    throw new IllegalStateException("Invalid SFSObject key length. Found = " + keySize);
                }
                final byte[] keyData = new byte[keySize];
                buffer.get(keyData, 0, keyData.length);
                final String key = new String(keyData);
                final SFSDataWrapper decodedObject = this.decodeObject(buffer);
                if (decodedObject == null) {
                    throw new IllegalStateException("Could not decode value for key: " + keyData);
                }
                sfsObject.put(key, decodedObject);
            }
        }
        catch (SFSCodecException codecError) {
            throw new IllegalArgumentException(codecError.getMessage());
        }
        return sfsObject;
    }
    
    @Override
    public ISFSArray json2array(final String jsonStr) {
        if (jsonStr.length() < 2) {
            throw new IllegalStateException("Can't decode SFSObject. JSON String is too short. Len: " + jsonStr.length());
        }
        final JSONArray jsa = JSONArray.fromObject((Object)jsonStr);
        return this.decodeSFSArray(jsa);
    }
    
    private ISFSArray decodeSFSArray(final JSONArray jsa) {
        final ISFSArray sfsArray = SFSArrayLite.newInstance();
        for (final Object value : jsa) {
            final SFSDataWrapper decodedObject = this.decodeJsonObject(value);
            if (decodedObject == null) {
                throw new IllegalStateException("(json2sfarray) Could not decode value for object: " + value);
            }
            sfsArray.add(decodedObject);
        }
        return sfsArray;
    }
    
    @Override
    public ISFSObject json2object(final String jsonStr) {
        if (jsonStr.length() < 2) {
            throw new IllegalStateException("Can't decode SFSObject. JSON String is too short. Len: " + jsonStr.length());
        }
        final JSONObject jso = JSONObject.fromObject((Object)jsonStr);
        return this.decodeSFSObject(jso);
    }
    
    private ISFSObject decodeSFSObject(final JSONObject jso) {
        final ISFSObject sfsObject = SFSObjectLite.newInstance();
        for (final Object key : jso.keySet()) {
            final Object value = jso.get(key);
            final SFSDataWrapper decodedObject = this.decodeJsonObject(value);
            if (decodedObject == null) {
                throw new IllegalStateException("(json2sfsobj) Could not decode value for key: " + key);
            }
            sfsObject.put((String)key, decodedObject);
        }
        return sfsObject;
    }
    
    private SFSDataWrapper decodeJsonObject(final Object o) {
        if (o instanceof Integer) {
            return new SFSDataWrapper(SFSDataType.INT, o);
        }
        if (o instanceof Long) {
            return new SFSDataWrapper(SFSDataType.LONG, o);
        }
        if (o instanceof Double) {
            return new SFSDataWrapper(SFSDataType.DOUBLE, o);
        }
        if (o instanceof Boolean) {
            return new SFSDataWrapper(SFSDataType.BOOL, o);
        }
        if (o instanceof String) {
            final String value = (String)o;
            SFSDataType type = SFSDataType.UTF_STRING;
            if (value.length() > 32767) {
                type = SFSDataType.TEXT;
            }
            return new SFSDataWrapper(type, o);
        }
        if (o instanceof JSONObject) {
            final JSONObject jso = (JSONObject)o;
            if (jso.isNullObject()) {
                return new SFSDataWrapper(SFSDataType.NULL, null);
            }
            return new SFSDataWrapper(SFSDataType.SFS_OBJECT, this.decodeSFSObject(jso));
        }
        else {
            if (o instanceof JSONArray) {
                return new SFSDataWrapper(SFSDataType.SFS_ARRAY, this.decodeSFSArray((JSONArray)o));
            }
            throw new IllegalArgumentException(String.format("Unrecognized DataType while converting JSONObject 2 SFSObject. Object: %s, Type: %s", o, (o == null) ? "null" : o.getClass()));
        }
    }
    
    @Override
    public SFSObject resultSet2object(final ResultSet rset) throws SQLException {
        final ResultSetMetaData metaData = rset.getMetaData();
        final SFSObject sfso = new SFSObject();
        if (rset.isBeforeFirst()) {
            rset.next();
        }
        for (int col = 1; col <= metaData.getColumnCount(); ++col) {
            final String colName = metaData.getColumnLabel(col);
            final int type = metaData.getColumnType(col);
            final Object rawDataObj = rset.getObject(col);
            if (rawDataObj != null) {
                if (type == 0) {
                    sfso.putNull(colName);
                }
                else if (type == 16) {
                    sfso.putBool(colName, rset.getBoolean(col));
                }
                else if (type == 91) {
                    sfso.putLong(colName, rset.getDate(col).getTime());
                }
                else if (type == 6 || type == 3 || type == 8 || type == 7) {
                    sfso.putDouble(colName, rset.getDouble(col));
                }
                else if (type == 4 || type == -6 || type == 5) {
                    sfso.putInt(colName, rset.getInt(col));
                }
                else if (type == -1 || type == 12 || type == 1) {
                    sfso.putUtfString(colName, rset.getString(col));
                }
                else if (type == -9 || type == -16 || type == -15) {
                    sfso.putUtfString(colName, rset.getNString(col));
                }
                else if (type == 93) {
                    sfso.putLong(colName, rset.getTimestamp(col).getTime());
                }
                else if (type == -5) {
                    sfso.putLong(colName, rset.getLong(col));
                }
                else if (type == -4) {
                    final byte[] binData = this.getBlobData(colName, rset.getBinaryStream(col));
                    if (binData != null) {
                        sfso.putByteArray(colName, binData);
                    }
                }
                else if (type == 2004) {
                    final Blob blob = rset.getBlob(col);
                    sfso.putByteArray(colName, blob.getBytes(0L, (int)blob.length()));
                }
                else {
                    this.logger.info("Skipping Unsupported SQL TYPE: " + type + ", Column:" + colName);
                }
            }
        }
        return sfso;
    }
    
    private byte[] getBlobData(final String colName, final InputStream stream) {
        final BufferedInputStream bis = new BufferedInputStream(stream);
        byte[] bytes = null;
        try {
            bytes = new byte[bis.available()];
            bis.read(bytes);
        }
        catch (IOException ex) {
            this.logger.warn("SFSObject serialize error. Failed reading BLOB data for column: " + colName);
            return bytes;
        }
        finally {
            IOUtils.closeQuietly((InputStream)bis);
        }
        IOUtils.closeQuietly((InputStream)bis);
        return bytes;
    }
    
    @Override
    public SFSArray resultSet2array(final ResultSet rset) throws SQLException {
        final SFSArray sfsa = new SFSArray();
        while (rset.next()) {
            sfsa.addSFSObject(this.resultSet2object(rset));
        }
        return sfsa;
    }
    
    @Override
    public byte[] object2binary(final ISFSObject object) {
        final ByteBuffer buffer = ByteBuffer.allocate(DefaultSFSDataSerializer.BUFFER_CHUNK_SIZE);
        buffer.put((byte)SFSDataType.SFS_OBJECT.getTypeID());
        buffer.putShort((short)object.size());
        return this.obj2bin(object, buffer);
    }
    
    private byte[] obj2bin(final ISFSObject object, ByteBuffer buffer) {
        final Set<String> keys = object.getKeys();
        for (final String key : keys) {
            final SFSDataWrapper wrapper = object.get(key);
            final Object dataObj = wrapper.getObject();
            buffer = this.encodeSFSObjectKey(buffer, key);
            buffer = this.encodeObject(buffer, wrapper.getTypeId(), dataObj);
        }
        final int pos = buffer.position();
        final byte[] result = new byte[pos];
        buffer.flip();
        buffer.get(result, 0, pos);
        return result;
    }
    
    @Override
    public byte[] array2binary(final ISFSArray array) {
        final ByteBuffer buffer = ByteBuffer.allocate(DefaultSFSDataSerializer.BUFFER_CHUNK_SIZE);
        buffer.put((byte)SFSDataType.SFS_ARRAY.getTypeID());
        buffer.putShort((short)array.size());
        return this.arr2bin(array, buffer);
    }
    
    private byte[] arr2bin(final ISFSArray array, ByteBuffer buffer) {
        for (final SFSDataWrapper wrapper : array) {
            final Object dataObj = wrapper.getObject();
            buffer = this.encodeObject(buffer, wrapper.getTypeId(), dataObj);
        }
        final int pos = buffer.position();
        final byte[] result = new byte[pos];
        buffer.flip();
        buffer.get(result, 0, pos);
        return result;
    }
    
    @Override
    public String object2json(final Map<String, Object> map) {
        return JSONObject.fromObject((Object)map).toString();
    }
    
    public void flattenObject(final Map<String, Object> map, final SFSObject sfsObj) {
        for (final Map.Entry<String, SFSDataWrapper> entry : sfsObj) {
            final String key = entry.getKey();
            final SFSDataWrapper value = entry.getValue();
            if (value.getTypeId() == SFSDataType.SFS_OBJECT) {
                final Map<String, Object> newMap = new HashMap<String, Object>();
                map.put(key, newMap);
                this.flattenObject(newMap, (SFSObject)value.getObject());
            }
            else if (value.getTypeId() == SFSDataType.SFS_ARRAY) {
                final List<Object> newList = new ArrayList<Object>();
                map.put(key, newList);
                this.flattenArray(newList, (SFSArray)value.getObject());
            }
            else {
                map.put(key, value.getObject());
            }
        }
    }
    
    public void flattenArray(final List<Object> array, final SFSArray sfsArray) {
        for (final SFSDataWrapper value : sfsArray) {
            if (value.getTypeId() == SFSDataType.SFS_OBJECT) {
                final Map<String, Object> newMap = new HashMap<String, Object>();
                array.add(newMap);
                this.flattenObject(newMap, (SFSObject)value.getObject());
            }
            else if (value.getTypeId() == SFSDataType.SFS_ARRAY) {
                final List<Object> newList = new ArrayList<Object>();
                array.add(newList);
                this.flattenArray(newList, (SFSArray)value.getObject());
            }
            else {
                array.add(value.getObject());
            }
        }
    }
    
    private SFSDataWrapper decodeObject(final ByteBuffer buffer) throws SFSCodecException {
        SFSDataWrapper decodedObject = null;
        final byte headerByte = buffer.get();
        if (headerByte == SFSDataType.NULL.getTypeID()) {
            decodedObject = this.binDecode_NULL(buffer);
        }
        else if (headerByte == SFSDataType.BOOL.getTypeID()) {
            decodedObject = this.binDecode_BOOL(buffer);
        }
        else if (headerByte == SFSDataType.BOOL_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_BOOL_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.BYTE.getTypeID()) {
            decodedObject = this.binDecode_BYTE(buffer);
        }
        else if (headerByte == SFSDataType.BYTE_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_BYTE_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.SHORT.getTypeID()) {
            decodedObject = this.binDecode_SHORT(buffer);
        }
        else if (headerByte == SFSDataType.SHORT_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_SHORT_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.INT.getTypeID()) {
            decodedObject = this.binDecode_INT(buffer);
        }
        else if (headerByte == SFSDataType.INT_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_INT_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.LONG.getTypeID()) {
            decodedObject = this.binDecode_LONG(buffer);
        }
        else if (headerByte == SFSDataType.LONG_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_LONG_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.FLOAT.getTypeID()) {
            decodedObject = this.binDecode_FLOAT(buffer);
        }
        else if (headerByte == SFSDataType.FLOAT_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_FLOAT_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.DOUBLE.getTypeID()) {
            decodedObject = this.binDecode_DOUBLE(buffer);
        }
        else if (headerByte == SFSDataType.DOUBLE_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_DOUBLE_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.UTF_STRING.getTypeID()) {
            decodedObject = this.binDecode_UTF_STRING(buffer);
        }
        else if (headerByte == SFSDataType.TEXT.getTypeID()) {
            decodedObject = this.binDecode_TEXT(buffer);
        }
        else if (headerByte == SFSDataType.UTF_STRING_ARRAY.getTypeID()) {
            decodedObject = this.binDecode_UTF_STRING_ARRAY(buffer);
        }
        else if (headerByte == SFSDataType.SFS_ARRAY.getTypeID()) {
            buffer.position(buffer.position() - 1);
            decodedObject = new SFSDataWrapper(SFSDataType.SFS_ARRAY, this.decodeSFSArray(buffer));
        }
        else {
            if (headerByte != SFSDataType.SFS_OBJECT.getTypeID()) {
                throw new SFSCodecException("Unknow SFSDataType ID: " + headerByte);
            }
            buffer.position(buffer.position() - 1);
            final ISFSObject sfsObj = this.decodeSFSObject(buffer);
            SFSDataType type = SFSDataType.SFS_OBJECT;
            Object finalSfsObj = sfsObj;
            if (sfsObj.containsKey("$C") && sfsObj.containsKey("$F")) {
                type = SFSDataType.CLASS;
                finalSfsObj = this.sfs2pojo(sfsObj);
            }
            decodedObject = new SFSDataWrapper(type, finalSfsObj);
        }
        return decodedObject;
    }
    
    private ByteBuffer encodeObject(ByteBuffer buffer, final SFSDataType typeId, final Object object) {
        switch (typeId) {
            case NULL: {
                buffer = this.binEncode_NULL(buffer);
                break;
            }
            case BOOL: {
                buffer = this.binEncode_BOOL(buffer, (Boolean)object);
                break;
            }
            case BYTE: {
                buffer = this.binEncode_BYTE(buffer, (Byte)object);
                break;
            }
            case SHORT: {
                buffer = this.binEncode_SHORT(buffer, (Short)object);
                break;
            }
            case INT: {
                buffer = this.binEncode_INT(buffer, (Integer)object);
                break;
            }
            case LONG: {
                buffer = this.binEncode_LONG(buffer, (Long)object);
                break;
            }
            case FLOAT: {
                buffer = this.binEncode_FLOAT(buffer, (Float)object);
                break;
            }
            case DOUBLE: {
                buffer = this.binEncode_DOUBLE(buffer, (Double)object);
                break;
            }
            case UTF_STRING: {
                buffer = this.binEncode_UTF_STRING(buffer, (String)object);
                break;
            }
            case TEXT: {
                buffer = this.binEncode_TEXT(buffer, (String)object);
                break;
            }
            case BOOL_ARRAY: {
                buffer = this.binEncode_BOOL_ARRAY(buffer, (Collection<Boolean>)object);
                break;
            }
            case BYTE_ARRAY: {
                buffer = this.binEncode_BYTE_ARRAY(buffer, (byte[])object);
                break;
            }
            case SHORT_ARRAY: {
                buffer = this.binEncode_SHORT_ARRAY(buffer, (Collection<Short>)object);
                break;
            }
            case INT_ARRAY: {
                buffer = this.binEncode_INT_ARRAY(buffer, (Collection<Integer>)object);
                break;
            }
            case LONG_ARRAY: {
                buffer = this.binEncode_LONG_ARRAY(buffer, (Collection<Long>)object);
                break;
            }
            case FLOAT_ARRAY: {
                buffer = this.binEncode_FLOAT_ARRAY(buffer, (Collection<Float>)object);
                break;
            }
            case DOUBLE_ARRAY: {
                buffer = this.binEncode_DOUBLE_ARRAY(buffer, (Collection<Double>)object);
                break;
            }
            case UTF_STRING_ARRAY: {
                buffer = this.binEncode_UTF_STRING_ARRAY(buffer, (Collection<String>)object);
                break;
            }
            case SFS_ARRAY: {
                buffer = this.addData(buffer, this.array2binary((ISFSArray)object));
                break;
            }
            case SFS_OBJECT: {
                buffer = this.addData(buffer, this.object2binary((ISFSObject)object));
                break;
            }
            case CLASS: {
                buffer = this.addData(buffer, this.object2binary(this.pojo2sfs(object)));
                break;
            }
            default: {
                throw new IllegalArgumentException("Unrecognized type in SFSObject serialization: " + typeId);
            }
        }
        return buffer;
    }
    
    private SFSDataWrapper binDecode_NULL(final ByteBuffer buffer) {
        return new SFSDataWrapper(SFSDataType.NULL, null);
    }
    
    private SFSDataWrapper binDecode_BOOL(final ByteBuffer buffer) throws SFSCodecException {
        final byte boolByte = buffer.get();
        Boolean bool = null;
        if (boolByte == 0) {
            bool = new Boolean(false);
        }
        else {
            if (boolByte != 1) {
                throw new SFSCodecException("Error decoding Bool type. Illegal value: " + bool);
            }
            bool = new Boolean(true);
        }
        return new SFSDataWrapper(SFSDataType.BOOL, bool);
    }
    
    private SFSDataWrapper binDecode_BYTE(final ByteBuffer buffer) {
        final byte boolByte = buffer.get();
        return new SFSDataWrapper(SFSDataType.BYTE, boolByte);
    }
    
    private SFSDataWrapper binDecode_SHORT(final ByteBuffer buffer) {
        final short shortValue = buffer.getShort();
        return new SFSDataWrapper(SFSDataType.SHORT, shortValue);
    }
    
    private SFSDataWrapper binDecode_INT(final ByteBuffer buffer) {
        final int intValue = buffer.getInt();
        return new SFSDataWrapper(SFSDataType.INT, intValue);
    }
    
    private SFSDataWrapper binDecode_LONG(final ByteBuffer buffer) {
        final long longValue = buffer.getLong();
        return new SFSDataWrapper(SFSDataType.LONG, longValue);
    }
    
    private SFSDataWrapper binDecode_FLOAT(final ByteBuffer buffer) {
        final float floatValue = buffer.getFloat();
        return new SFSDataWrapper(SFSDataType.FLOAT, floatValue);
    }
    
    private SFSDataWrapper binDecode_DOUBLE(final ByteBuffer buffer) {
        final double doubleValue = buffer.getDouble();
        return new SFSDataWrapper(SFSDataType.DOUBLE, doubleValue);
    }
    
    private SFSDataWrapper binDecode_UTF_STRING(final ByteBuffer buffer) throws SFSCodecException {
        final short strLen = buffer.getShort();
        if (strLen < 0) {
            throw new SFSCodecException("Error decoding UtfString. Negative size: " + strLen);
        }
        final byte[] strData = new byte[strLen];
        buffer.get(strData, 0, strLen);
        final String decodedString = new String(strData);
        return new SFSDataWrapper(SFSDataType.UTF_STRING, decodedString);
    }
    
    private SFSDataWrapper binDecode_TEXT(final ByteBuffer buffer) throws SFSCodecException {
        final int strLen = buffer.getInt();
        if (strLen < 0) {
            throw new SFSCodecException("Error decoding Text. Negative size: " + strLen);
        }
        final byte[] strData = new byte[strLen];
        buffer.get(strData, 0, strLen);
        final String decodedString = new String(strData);
        return new SFSDataWrapper(SFSDataType.TEXT, decodedString);
    }
    
    private SFSDataWrapper binDecode_BOOL_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = this.getTypeArraySize(buffer);
        final List<Boolean> array = new ArrayList<Boolean>();
        for (int j = 0; j < arraySize; ++j) {
            final byte boolData = buffer.get();
            if (boolData == 0) {
                array.add(false);
            }
            else {
                if (boolData != 1) {
                    throw new SFSCodecException("Error decoding BoolArray. Invalid bool value: " + boolData);
                }
                array.add(true);
            }
        }
        return new SFSDataWrapper(SFSDataType.BOOL_ARRAY, array);
    }
    
    private SFSDataWrapper binDecode_BYTE_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final int arraySize = buffer.getInt();
        if (arraySize < 0) {
            throw new SFSCodecException("Error decoding typed array size. Negative size: " + arraySize);
        }
        final byte[] byteData = new byte[arraySize];
        buffer.get(byteData, 0, arraySize);
        return new SFSDataWrapper(SFSDataType.BYTE_ARRAY, byteData);
    }
    
    private SFSDataWrapper binDecode_SHORT_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = this.getTypeArraySize(buffer);
        final List<Short> array = new ArrayList<Short>();
        for (int j = 0; j < arraySize; ++j) {
            final short shortValue = buffer.getShort();
            array.add(shortValue);
        }
        return new SFSDataWrapper(SFSDataType.SHORT_ARRAY, array);
    }
    
    private SFSDataWrapper binDecode_INT_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = this.getTypeArraySize(buffer);
        final List<Integer> array = new ArrayList<Integer>();
        for (int j = 0; j < arraySize; ++j) {
            final int intValue = buffer.getInt();
            array.add(intValue);
        }
        return new SFSDataWrapper(SFSDataType.INT_ARRAY, array);
    }
    
    private SFSDataWrapper binDecode_LONG_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = this.getTypeArraySize(buffer);
        final List<Long> array = new ArrayList<Long>();
        for (int j = 0; j < arraySize; ++j) {
            final long longValue = buffer.getLong();
            array.add(longValue);
        }
        return new SFSDataWrapper(SFSDataType.LONG_ARRAY, array);
    }
    
    private SFSDataWrapper binDecode_FLOAT_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = this.getTypeArraySize(buffer);
        final List<Float> array = new ArrayList<Float>();
        for (int j = 0; j < arraySize; ++j) {
            final float floatValue = buffer.getFloat();
            array.add(floatValue);
        }
        return new SFSDataWrapper(SFSDataType.FLOAT_ARRAY, array);
    }
    
    private SFSDataWrapper binDecode_DOUBLE_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = this.getTypeArraySize(buffer);
        final List<Double> array = new ArrayList<Double>();
        for (int j = 0; j < arraySize; ++j) {
            final double doubleValue = buffer.getDouble();
            array.add(doubleValue);
        }
        return new SFSDataWrapper(SFSDataType.DOUBLE_ARRAY, array);
    }
    
    private SFSDataWrapper binDecode_UTF_STRING_ARRAY(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = this.getTypeArraySize(buffer);
        final List<String> array = new ArrayList<String>();
        for (int j = 0; j < arraySize; ++j) {
            final short strLen = buffer.getShort();
            if (strLen < 0) {
                throw new SFSCodecException("Error decoding UtfStringArray element. Element has negative size: " + strLen);
            }
            final byte[] strData = new byte[strLen];
            buffer.get(strData, 0, strLen);
            array.add(new String(strData));
        }
        return new SFSDataWrapper(SFSDataType.UTF_STRING_ARRAY, array);
    }
    
    private short getTypeArraySize(final ByteBuffer buffer) throws SFSCodecException {
        final short arraySize = buffer.getShort();
        if (arraySize < 0) {
            throw new SFSCodecException("Error decoding typed array size. Negative size: " + arraySize);
        }
        return arraySize;
    }
    
    private ByteBuffer binEncode_NULL(final ByteBuffer buffer) {
        return this.addData(buffer, new byte[1]);
    }
    
    private ByteBuffer binEncode_BOOL(final ByteBuffer buffer, final Boolean value) {
        final byte[] data = { (byte)SFSDataType.BOOL.getTypeID(), value };
        return this.addData(buffer, data);
    }
    
    private ByteBuffer binEncode_BYTE(final ByteBuffer buffer, final Byte value) {
        final byte[] data = { (byte)SFSDataType.BYTE.getTypeID(), value };
        return this.addData(buffer, data);
    }
    
    private ByteBuffer binEncode_SHORT(final ByteBuffer buffer, final Short value) {
        final ByteBuffer buf = ByteBuffer.allocate(3);
        buf.put((byte)SFSDataType.SHORT.getTypeID());
        buf.putShort(value);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_INT(final ByteBuffer buffer, final Integer value) {
        final ByteBuffer buf = ByteBuffer.allocate(5);
        buf.put((byte)SFSDataType.INT.getTypeID());
        buf.putInt(value);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_LONG(final ByteBuffer buffer, final Long value) {
        final ByteBuffer buf = ByteBuffer.allocate(9);
        buf.put((byte)SFSDataType.LONG.getTypeID());
        buf.putLong(value);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_FLOAT(final ByteBuffer buffer, final Float value) {
        final ByteBuffer buf = ByteBuffer.allocate(5);
        buf.put((byte)SFSDataType.FLOAT.getTypeID());
        buf.putFloat(value);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_DOUBLE(final ByteBuffer buffer, final Double value) {
        final ByteBuffer buf = ByteBuffer.allocate(9);
        buf.put((byte)SFSDataType.DOUBLE.getTypeID());
        buf.putDouble(value);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_UTF_STRING(final ByteBuffer buffer, final String value) {
        final byte[] stringBytes = value.getBytes();
        final ByteBuffer buf = ByteBuffer.allocate(3 + stringBytes.length);
        buf.put((byte)SFSDataType.UTF_STRING.getTypeID());
        buf.putShort((short)stringBytes.length);
        buf.put(stringBytes);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_TEXT(final ByteBuffer buffer, final String value) {
        final byte[] stringBytes = value.getBytes();
        final ByteBuffer buf = ByteBuffer.allocate(5 + stringBytes.length);
        buf.put((byte)SFSDataType.TEXT.getTypeID());
        buf.putInt(stringBytes.length);
        buf.put(stringBytes);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_BOOL_ARRAY(final ByteBuffer buffer, final Collection<Boolean> value) {
        final ByteBuffer buf = ByteBuffer.allocate(3 + value.size());
        buf.put((byte)SFSDataType.BOOL_ARRAY.getTypeID());
        buf.putShort((short)value.size());
        for (final boolean b : value) {
            buf.put((byte)(b ? 1 : 0));
        }
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_BYTE_ARRAY(final ByteBuffer buffer, final byte[] value) {
        final ByteBuffer buf = ByteBuffer.allocate(5 + value.length);
        buf.put((byte)SFSDataType.BYTE_ARRAY.getTypeID());
        buf.putInt(value.length);
        buf.put(value);
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_SHORT_ARRAY(final ByteBuffer buffer, final Collection<Short> value) {
        final ByteBuffer buf = ByteBuffer.allocate(3 + 2 * value.size());
        buf.put((byte)SFSDataType.SHORT_ARRAY.getTypeID());
        buf.putShort((short)value.size());
        for (final short item : value) {
            buf.putShort(item);
        }
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_INT_ARRAY(final ByteBuffer buffer, final Collection<Integer> value) {
        final ByteBuffer buf = ByteBuffer.allocate(3 + 4 * value.size());
        buf.put((byte)SFSDataType.INT_ARRAY.getTypeID());
        buf.putShort((short)value.size());
        for (final int item : value) {
            buf.putInt(item);
        }
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_LONG_ARRAY(final ByteBuffer buffer, final Collection<Long> value) {
        final ByteBuffer buf = ByteBuffer.allocate(3 + 8 * value.size());
        buf.put((byte)SFSDataType.LONG_ARRAY.getTypeID());
        buf.putShort((short)value.size());
        for (final long item : value) {
            buf.putLong(item);
        }
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_FLOAT_ARRAY(final ByteBuffer buffer, final Collection<Float> value) {
        final ByteBuffer buf = ByteBuffer.allocate(3 + 4 * value.size());
        buf.put((byte)SFSDataType.FLOAT_ARRAY.getTypeID());
        buf.putShort((short)value.size());
        for (final float item : value) {
            buf.putFloat(item);
        }
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_DOUBLE_ARRAY(final ByteBuffer buffer, final Collection<Double> value) {
        final ByteBuffer buf = ByteBuffer.allocate(3 + 8 * value.size());
        buf.put((byte)SFSDataType.DOUBLE_ARRAY.getTypeID());
        buf.putShort((short)value.size());
        for (final double item : value) {
            buf.putDouble(item);
        }
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer binEncode_UTF_STRING_ARRAY(final ByteBuffer buffer, final Collection<String> value) {
        int stringDataLen = 0;
        final byte[][] binStrings = new byte[value.size()][];
        int count = 0;
        for (final String item : value) {
            final byte[] binStr = item.getBytes();
            binStrings[count++] = binStr;
            stringDataLen += 2 + binStr.length;
        }
        final ByteBuffer buf = ByteBuffer.allocate(3 + stringDataLen);
        buf.put((byte)SFSDataType.UTF_STRING_ARRAY.getTypeID());
        buf.putShort((short)value.size());
        byte[][] array;
        for (int length = (array = binStrings).length, i = 0; i < length; ++i) {
            final byte[] binItem = array[i];
            buf.putShort((short)binItem.length);
            buf.put(binItem);
        }
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer encodeSFSObjectKey(final ByteBuffer buffer, final String value) {
        final ByteBuffer buf = ByteBuffer.allocate(2 + value.length());
        buf.putShort((short)value.length());
        buf.put(value.getBytes());
        return this.addData(buffer, buf.array());
    }
    
    private ByteBuffer addData(ByteBuffer buffer, final byte[] newData) {
        if (buffer.remaining() < newData.length) {
            int newSize = DefaultSFSDataSerializer.BUFFER_CHUNK_SIZE;
            if (newSize < newData.length) {
                newSize = newData.length;
            }
            final ByteBuffer newBuffer = ByteBuffer.allocate(buffer.capacity() + newSize);
            buffer.flip();
            newBuffer.put(buffer);
            buffer = newBuffer;
        }
        buffer.put(newData);
        return buffer;
    }
    
    @Override
    public ISFSObject pojo2sfs(final Object pojo) {
        final ISFSObject sfsObj = SFSObject.newInstance();
        try {
            this.convertPojo(pojo, sfsObj);
        }
        catch (Exception e) {
            throw new SFSRuntimeException(e);
        }
        return sfsObj;
    }
    
    private void convertPojo(final Object pojo, final ISFSObject sfsObj) throws Exception {
        final Class<?> pojoClazz = pojo.getClass();
        final String classFullName = pojoClazz.getCanonicalName();
        if (classFullName == null) {
            throw new IllegalArgumentException("Anonymous classes cannot be serialized!");
        }
        if (!(pojo instanceof SerializableSFSType)) {
            throw new IllegalStateException("Cannot serialize object: " + pojo + ", type: " + classFullName + " -- It doesn't implement the SerializableSFSType interface");
        }
        final ISFSArray fieldList = SFSArray.newInstance();
        sfsObj.putUtfString("$C", classFullName);
        sfsObj.putSFSArray("$F", fieldList);
        Field[] declaredFields;
        for (int length = (declaredFields = pojoClazz.getDeclaredFields()).length, i = 0; i < length; ++i) {
            final Field field = declaredFields[i];
            try {
                final int modifiers = field.getModifiers();
                if (!Modifier.isTransient(modifiers)) {
                    if (!Modifier.isStatic(modifiers)) {
                        final String fieldName = field.getName();
                        Object fieldValue = null;
                        if (Modifier.isPublic(modifiers)) {
                            fieldValue = field.get(pojo);
                        }
                        else {
                            fieldValue = this.readValueFromGetter(fieldName, field.getType().getSimpleName(), pojo);
                        }
                        final ISFSObject fieldDescriptor = SFSObject.newInstance();
                        fieldDescriptor.putUtfString("N", fieldName);
                        fieldDescriptor.put("V", this.wrapPojoField(fieldValue));
                        fieldList.addSFSObject(fieldDescriptor);
                    }
                }
            }
            catch (NoSuchMethodException err) {
                this.logger.info("-- No public getter -- Serializer skipping private field: " + field.getName() + ", from class: " + pojoClazz);
                err.printStackTrace();
            }
        }
    }
    
    private Object readValueFromGetter(final String fieldName, final String type, final Object pojo) throws Exception {
        Object value = null;
        final boolean isBool = type.equalsIgnoreCase("boolean");
        final String getterName = isBool ? ("is" + StringUtils.capitalize(fieldName)) : ("get" + StringUtils.capitalize(fieldName));
        final Method getterMethod = pojo.getClass().getMethod(getterName, (Class<?>[])new Class[0]);
        value = getterMethod.invoke(pojo, new Object[0]);
        return value;
    }
    
    private SFSDataWrapper wrapPojoField(final Object value) {
        if (value == null) {
            return new SFSDataWrapper(SFSDataType.NULL, null);
        }
        SFSDataWrapper wrapper = null;
        if (value instanceof Boolean) {
            wrapper = new SFSDataWrapper(SFSDataType.BOOL, value);
        }
        else if (value instanceof Byte) {
            wrapper = new SFSDataWrapper(SFSDataType.BYTE, value);
        }
        else if (value instanceof Short) {
            wrapper = new SFSDataWrapper(SFSDataType.SHORT, value);
        }
        else if (value instanceof Integer) {
            wrapper = new SFSDataWrapper(SFSDataType.INT, value);
        }
        else if (value instanceof Long) {
            wrapper = new SFSDataWrapper(SFSDataType.LONG, value);
        }
        else if (value instanceof Float) {
            wrapper = new SFSDataWrapper(SFSDataType.FLOAT, value);
        }
        else if (value instanceof Double) {
            wrapper = new SFSDataWrapper(SFSDataType.DOUBLE, value);
        }
        else if (value instanceof String) {
            wrapper = new SFSDataWrapper(SFSDataType.UTF_STRING, value);
        }
        else if (value.getClass().isArray()) {
            wrapper = new SFSDataWrapper(SFSDataType.SFS_ARRAY, this.unrollArray((Object[])value));
        }
        else if (value instanceof Collection) {
            wrapper = new SFSDataWrapper(SFSDataType.SFS_ARRAY, this.unrollCollection((Collection)value));
        }
        else if (value instanceof Map) {
            wrapper = new SFSDataWrapper(SFSDataType.SFS_OBJECT, this.unrollMap((Map)value));
        }
        else if (value instanceof SerializableSFSType) {
            wrapper = new SFSDataWrapper(SFSDataType.SFS_OBJECT, this.pojo2sfs(value));
        }
        return wrapper;
    }
    
    private ISFSArray unrollArray(final Object[] arr) {
        final ISFSArray array = SFSArray.newInstance();
        for (final Object item : arr) {
            array.add(this.wrapPojoField(item));
        }
        return array;
    }
    
    private ISFSArray unrollCollection(final Collection collection) {
        final ISFSArray array = SFSArray.newInstance();
        for (final Object item : collection) {
            array.add(this.wrapPojoField(item));
        }
        return array;
    }
    
    private ISFSObject unrollMap(final Map map) {
        final ISFSObject sfsObj = SFSObject.newInstance();
        final Set entries = map.entrySet();
        for (final Map.Entry item : entries) {
            final Object key = item.getKey();
            if (key instanceof String) {
                sfsObj.put((String)key, this.wrapPojoField(item.getValue()));
            }
        }
        return sfsObj;
    }
    
    @Override
    public Object sfs2pojo(final ISFSObject sfsObj) {
        Object pojo = null;
        if (!sfsObj.containsKey("$C") && !sfsObj.containsKey("$F")) {
            throw new SFSRuntimeException("The SFSObject passed does not represent any serialized class.");
        }
        try {
            final String className = sfsObj.getUtfString("$C");
            final Class<?> theClass = Class.forName(className);
            pojo = theClass.newInstance();
            if (!(pojo instanceof SerializableSFSType)) {
                throw new IllegalStateException("Cannot deserialize object: " + pojo + ", type: " + className + " -- It doesn't implement the SerializableSFSType interface");
            }
            this.convertSFSObject(sfsObj.getSFSArray("$F"), pojo);
        }
        catch (Exception e) {
            throw new SFSRuntimeException(e);
        }
        return pojo;
    }
    
    private void convertSFSObject(final ISFSArray fieldList, final Object pojo) throws Exception {
        for (int j = 0; j < fieldList.size(); ++j) {
            final ISFSObject fieldDescriptor = fieldList.getSFSObject(j);
            final String fieldName = fieldDescriptor.getUtfString("N");
            final Object fieldValue = this.unwrapPojoField(fieldDescriptor.get("V"));
            this.setObjectField(pojo, fieldName, fieldValue);
        }
    }
    
    private void setObjectField(final Object pojo, final String fieldName, Object fieldValue) throws Exception {
        final Class pojoClass = pojo.getClass();
        final Field field = pojoClass.getDeclaredField(fieldName);
        final int fieldModifier = field.getModifiers();
        if (Modifier.isTransient(fieldModifier)) {
            return;
        }
        final boolean isArray = field.getType().isArray();
        if (isArray) {
            if (!(fieldValue instanceof Collection)) {
                throw new SFSRuntimeException("Problem during SFSObject => POJO conversion. Found array field in POJO: " + fieldName + ", but data is not a Collection!");
            }
            final Collection collection = (Collection)fieldValue;
            fieldValue = collection.toArray();
            final int arraySize = collection.size();
            final Object typedArray = Array.newInstance(field.getType().getComponentType(), arraySize);
            System.arraycopy(fieldValue, 0, typedArray, 0, arraySize);
            fieldValue = typedArray;
        }
        else if (fieldValue instanceof Collection) {
            final Collection collection = (Collection)fieldValue;
            final String fieldClass = field.getType().getSimpleName();
            if (fieldClass.equals("ArrayList") || fieldClass.equals("List")) {
                fieldValue = new ArrayList(collection);
            }
            if (fieldClass.equals("CopyOnWriteArrayList")) {
                fieldValue = new CopyOnWriteArrayList(collection);
            }
            else if (fieldClass.equals("LinkedList")) {
                fieldValue = new LinkedList(collection);
            }
            else if (fieldClass.equals("Vector")) {
                fieldValue = new Vector(collection);
            }
            else if (fieldClass.equals("Set") || fieldClass.equals("HashSet")) {
                fieldValue = new HashSet(collection);
            }
            else if (fieldClass.equals("LinkedHashSet")) {
                fieldValue = new LinkedHashSet(collection);
            }
            else if (fieldClass.equals("TreeSet")) {
                fieldValue = new TreeSet(collection);
            }
            else if (fieldClass.equals("CopyOnWriteArraySet")) {
                fieldValue = new CopyOnWriteArraySet(collection);
            }
            else if (fieldClass.equals("Queue") || fieldClass.equals("PriorityQueue")) {
                fieldValue = new PriorityQueue(collection);
            }
            else if (fieldClass.equals("BlockingQueue") || fieldClass.equals("LinkedBlockingQueue")) {
                fieldValue = new LinkedBlockingQueue(collection);
            }
            else if (fieldClass.equals("PriorityBlockingQueue")) {
                fieldValue = new PriorityBlockingQueue(collection);
            }
            else if (fieldClass.equals("ConcurrentLinkedQueue")) {
                fieldValue = new ConcurrentLinkedQueue(collection);
            }
            else if (fieldClass.equals("DelayQueue")) {
                fieldValue = new DelayQueue(collection);
            }
            else if (fieldClass.equals("Deque") || fieldClass.equals("ArrayDeque")) {
                fieldValue = new ArrayDeque(collection);
            }
            else if (fieldClass.equals("LinkedBlockingDeque")) {
                fieldValue = new LinkedBlockingDeque(collection);
            }
        }
        if (Modifier.isPublic(fieldModifier)) {
            field.set(pojo, fieldValue);
        }
        else {
            this.writeValueFromSetter(field, pojo, fieldValue);
        }
    }
    
    private void writeValueFromSetter(final Field field, final Object pojo, final Object fieldValue) throws Exception {
        final String setterName = "set" + StringUtils.capitalize(field.getName());
        try {
            final Method setterMethod = pojo.getClass().getMethod(setterName, field.getType());
            setterMethod.invoke(pojo, fieldValue);
        }
        catch (NoSuchMethodException e) {
            this.logger.info("-- No public setter -- Serializer skipping private field: " + field.getName() + ", from class: " + pojo.getClass().getName());
        }
    }
    
    private Object unwrapPojoField(final SFSDataWrapper wrapper) {
        Object obj = null;
        final SFSDataType type = wrapper.getTypeId();
        if (type.getTypeID() <= SFSDataType.UTF_STRING.getTypeID()) {
            obj = wrapper.getObject();
        }
        else if (type == SFSDataType.SFS_ARRAY) {
            obj = this.rebuildArray((ISFSArray)wrapper.getObject());
        }
        else if (type == SFSDataType.SFS_OBJECT) {
            obj = this.rebuildMap((ISFSObject)wrapper.getObject());
        }
        else if (type == SFSDataType.CLASS) {
            obj = wrapper.getObject();
        }
        return obj;
    }
    
    private Object rebuildArray(final ISFSArray sfsArray) {
        final Collection<Object> collection = new ArrayList<Object>();
        final Iterator<SFSDataWrapper> iter = sfsArray.iterator();
        while (iter.hasNext()) {
            final Object item = this.unwrapPojoField(iter.next());
            collection.add(item);
        }
        return collection;
    }
    
    private Object rebuildMap(final ISFSObject sfsObj) {
        final Map<String, Object> map = new HashMap<String, Object>();
        for (final String key : sfsObj.getKeys()) {
            final SFSDataWrapper wrapper = sfsObj.get(key);
            map.put(key, this.unwrapPojoField(wrapper));
        }
        return map;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol;

import java.util.Arrays;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.data.Packet;
import com.smartfoxserver.v2.protocol.binary.PacketHeader;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.util.ArrayList;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.util.ByteUtils;
import java.net.SocketAddress;
import java.nio.channels.DatagramChannel;
import com.smartfoxserver.v2.protocol.binary.PacketReadState;
import com.smartfoxserver.bitswarm.io.protocols.ProtocolType;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import com.smartfoxserver.bitswarm.io.IOHandler;
import org.slf4j.LoggerFactory;
import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.v2.protocol.text.TextIoHandler;
import com.smartfoxserver.v2.protocol.binary.BinaryIoHandler;
import com.smartfoxserver.bitswarm.io.AbstractIOHandler;

public class DefaultIoHandler extends AbstractIOHandler
{
    private static final String FLASH_CROSSDOMAIN_POLICY_REQ = "<policy-file-request/>";
    private static final char TAG_TOKEN = '<';
    private static final int CROSSDOMAIN_REQ_LEN;
    private final BinaryIoHandler binHandler;
    private final TextIoHandler textHandler;
    private final Logger logger;
    private final SmartFoxServer sfs;
    private final BitSwarmEngine engine;
    private boolean useBinaryProtocol;
    private ByteBuffer bufferedXmlSocketPolicy;
    
    static {
        CROSSDOMAIN_REQ_LEN = "<policy-file-request/>".length() + 1;
    }
    
    public DefaultIoHandler() {
        this.useBinaryProtocol = false;
        this.logger = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = SmartFoxServer.getInstance();
        this.engine = BitSwarmEngine.getInstance();
        this.binHandler = null;
        this.textHandler = null;
        this.bufferedXmlSocketPolicy = null;
        this.setCodec((IProtocolCodec)new DefaultProtocolCodec((IOHandler)this));
    }
    
    public long getIncomingDroppedPackets() {
        return 0L;
    }
    
    public void onDataRead(final ISession session, final byte[] data) {
        if (data == null || data.length < 1) {
            throw new IllegalArgumentException("Unexpected null or empty byte array!");
        }
        ProtocolType sessionProtocol = (ProtocolType)session.getSystemProperty("session_protocol");
        if (sessionProtocol == null) {
            if (data[0] == 60) {
                this.handlSocketPolicyRequest(data, session);
            }
            else {
                sessionProtocol = this.decodeProtocol(data[0]);
                session.setSystemProperty("session_protocol", (Object)sessionProtocol);
                session.setSystemProperty("read_state", (Object)PacketReadState.WAIT_NEW_PACKET);
            }
        }
        if (sessionProtocol != null) {
            if (sessionProtocol == ProtocolType.BINARY) {
                this.binHandler.handleRead(session, data);
            }
            else if (sessionProtocol == ProtocolType.TEXT) {
                this.textHandler.handleRead(session, data);
            }
        }
    }
    
    public void setCodec(final IProtocolCodec codec) {
        super.setCodec(codec);
        this.binHandler.setProtocolCodec(codec);
        this.textHandler.setProtocolCodec(codec);
    }
    
    public void onDataRead(final DatagramChannel channel, final SocketAddress address, final byte[] data) {
        System.out.println("UDP DATA:\n " + ByteUtils.fullHexDump(data));
    }
    
    public void onDataWrite(final IPacket packet) {
        List<ISession> textProtocolRecipients = null;
        if (!this.useBinaryProtocol) {
            final Iterator<ISession> iter = packet.getRecipients().iterator();
            while (iter.hasNext()) {
                final ISession session = iter.next();
                final ProtocolType proto = (ProtocolType)session.getSystemProperty("session_protocol");
                if (proto != null && proto == ProtocolType.TEXT) {
                    if (textProtocolRecipients == null) {
                        textProtocolRecipients = new ArrayList<ISession>();
                    }
                    iter.remove();
                    textProtocolRecipients.add(session);
                }
            }
        }
        if (packet.getRecipients().size() > 0) {
            try {
                this.binHandler.handleWrite(packet);
            }
            catch (Exception e) {
                final ExceptionMessageComposer composer = new ExceptionMessageComposer(e);
                this.logger.warn(composer.toString());
            }
        }
        if (textProtocolRecipients != null && textProtocolRecipients.size() > 0) {
            final IPacket textPacket = packet.clone();
            textPacket.setRecipients((Collection)textProtocolRecipients);
            this.textHandler.handleWrite(packet);
        }
    }
    
    public PacketHeader decodeFirstHeaderByte(final byte headerByte) {
        return new PacketHeader((headerByte & 0x80) > 0, (headerByte & 0x40) > 0, (headerByte & 0x20) > 0, (headerByte & 0x10) > 0, (headerByte & 0x8) > 0);
    }
    
    public byte encodeFirstHeaderByte(final PacketHeader packetHeader) {
        byte headerByte = 0;
        if (packetHeader.isBinary()) {
            headerByte += 128;
        }
        if (packetHeader.isEncrypted()) {
            headerByte += 64;
        }
        if (packetHeader.isCompressed()) {
            headerByte += 32;
        }
        if (packetHeader.isBlueBoxed()) {
            headerByte += 16;
        }
        if (packetHeader.isBigSized()) {
            headerByte += 8;
        }
        return headerByte;
    }
    
    private byte[] handlSocketPolicyRequest(final byte[] data, final ISession session) {
        final String stringMsg = new String(data);
        byte[] newData = data;
        if (stringMsg.startsWith("<policy-file-request/>")) {
            this.logger.debug("Handling Flash Policy request");
            if (data.length > DefaultIoHandler.CROSSDOMAIN_REQ_LEN) {
                newData = new byte[data.length - DefaultIoHandler.CROSSDOMAIN_REQ_LEN];
            }
            System.arraycopy(data, DefaultIoHandler.CROSSDOMAIN_REQ_LEN, newData, 0, newData.length - DefaultIoHandler.CROSSDOMAIN_REQ_LEN);
        }
        if (this.bufferedXmlSocketPolicy == null) {
            final String policyText = this.engine.getConfiguration().getFlashCrossdomainPolicyXml();
            (this.bufferedXmlSocketPolicy = ByteBuffer.allocate(policyText.length() + 1)).put(policyText.getBytes());
            this.bufferedXmlSocketPolicy.put((byte)0);
            this.bufferedXmlSocketPolicy.flip();
        }
        final IPacket policyPacket = (IPacket)new Packet();
        policyPacket.setData((Object)this.bufferedXmlSocketPolicy.array());
        policyPacket.setTransportType(TransportType.TCP);
        policyPacket.setRecipients((Collection)Arrays.asList(session));
        this.engine.getSocketWriter().enqueuePacket(policyPacket);
        return newData;
    }
    
    private ProtocolType decodeProtocol(final byte headerFirstByte) {
        return ((headerFirstByte & 0x80) > 0) ? ProtocolType.BINARY : ProtocolType.TEXT;
    }
}

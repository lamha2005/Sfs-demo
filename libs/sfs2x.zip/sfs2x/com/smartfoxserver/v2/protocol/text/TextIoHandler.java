// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.text;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.bitswarm.io.protocols.ProtocolType;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.data.Packet;
import com.smartfoxserver.v2.protocol.binary.PacketHeader;
import com.smartfoxserver.v2.protocol.binary.PendingPacket;
import com.smartfoxserver.bitswarm.util.ByteUtils;
import java.nio.ByteBuffer;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.v2.protocol.binary.ProcessedPacket;
import com.smartfoxserver.v2.protocol.binary.PacketReadState;
import com.smartfoxserver.bitswarm.sessions.ISession;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.config.ServerSettings;
import org.slf4j.Logger;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import com.smartfoxserver.v2.protocol.SFSTxtIoHandler;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.v2.SmartFoxServer;

public class TextIoHandler
{
    private final SmartFoxServer sfs;
    private final BitSwarmEngine engine;
    private final SFSTxtIoHandler parentHandler;
    private IProtocolCodec protocolCodec;
    private final String EOM;
    private final Logger log;
    private ServerSettings serverSettings;
    private final int maxIncomingPacketSize;
    private volatile long packetsRead;
    private volatile long droppedIncomingPackets;
    
    public TextIoHandler(final SFSTxtIoHandler parentHandler) {
        this.EOM = new String(new char[] { '\u00ff' });
        this.packetsRead = 0L;
        this.droppedIncomingPackets = 0L;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.engine = BitSwarmEngine.getInstance();
        this.sfs = SmartFoxServer.getInstance();
        this.parentHandler = parentHandler;
        this.maxIncomingPacketSize = BitSwarmEngine.getInstance().getConfiguration().getMaxIncomingRequestSize();
        this.serverSettings = this.sfs.getConfigurator().getServerSettings();
    }
    
    public void setProtocolCodec(final IProtocolCodec protocolCodec) {
        this.protocolCodec = protocolCodec;
    }
    
    public void handleRead(final ISession session, byte[] data) {
        PacketReadState readState = (PacketReadState)session.getSystemProperty("read_state");
        if (readState == PacketReadState.WAIT_NEW_PACKET) {
            final ProcessedPacket process = this.handleNewPacket(session, data);
            readState = process.getState();
            data = process.getData();
        }
        if (readState == PacketReadState.WAIT_DATA) {
            final ProcessedPacket process = this.handlePacketData(session, data);
            readState = process.getState();
            data = process.getData();
        }
        session.setSystemProperty("read_state", (Object)readState);
    }
    
    public void handleWrite(final IPacket packet) {
        final byte[] binData = ((SFSObject)packet.getData()).toJson().getBytes();
        final ByteBuffer packetBuffer = ByteBuffer.allocate(1 + binData.length);
        packetBuffer.put(binData);
        packetBuffer.put((byte)0);
        packet.setData((Object)packetBuffer.array());
        if (this.log.isDebugEnabled()) {
            this.log.info("TEXT DATA written:");
            this.log.info(ByteUtils.fullHexDump(packetBuffer.array()));
        }
        this.engine.getSocketWriter().enqueuePacket(packet);
    }
    
    private ProcessedPacket handleNewPacket(final ISession session, final byte[] data) {
        final PendingPacket pending = new PendingPacket(null);
        pending.setBuffer(new StringBuilder());
        session.setSystemProperty("session_data_buffer", (Object)pending);
        this.log.info("data post-header: " + data.length);
        return new ProcessedPacket(PacketReadState.WAIT_DATA, data);
    }
    
    private ProcessedPacket handlePacketData(final ISession session, byte[] data) {
        final PacketReadState state = PacketReadState.WAIT_DATA;
        final PendingPacket pending = (PendingPacket)session.getSystemProperty("session_data_buffer");
        final String rawStr = new String(data);
        final StringBuilder buffer = (StringBuilder)pending.getBuffer();
        buffer.append(rawStr);
        for (int posEOM = buffer.indexOf(this.EOM); posEOM != -1; posEOM = buffer.indexOf(this.EOM)) {
            final String fullMsg = buffer.substring(0, posEOM).trim();
            final int msgSize = fullMsg.length();
            if (this.log.isDebugEnabled()) {
                this.log.info("<<< PACKET COMPLETE >>>");
                this.log.info("=> " + fullMsg);
            }
            final IPacket newPacket = (IPacket)new Packet();
            newPacket.setData((Object)fullMsg);
            newPacket.setSender(session);
            newPacket.setOriginalSize(fullMsg.length());
            newPacket.setTransportType(TransportType.TCP);
            newPacket.setAttribute("type", (Object)ProtocolType.TEXT);
            ++this.packetsRead;
            this.protocolCodec.onPacketRead(newPacket);
            buffer.delete(0, posEOM + 1);
        }
        data = new byte[0];
        return new ProcessedPacket(state, data);
    }
    
    public long getReadPackets() {
        return this.packetsRead;
    }
    
    public long getIncomingDroppedPackets() {
        return this.droppedIncomingPackets;
    }
    
    private void validateIncomingDataSize(final ISession session, final int dataSize) {
        final User user = this.sfs.getUserManager().getUserBySession(session);
        final String who = (user != null) ? user.toString() : session.toString();
        if (dataSize < 1) {
            ++this.droppedIncomingPackets;
            throw new IllegalArgumentException("Illegal request size: " + dataSize + " bytes, from: " + who);
        }
        if (dataSize > this.maxIncomingPacketSize) {
            this.sfs.getAPIManager().getSFSApi().disconnect(session);
            ++this.droppedIncomingPackets;
            throw new IllegalArgumentException(String.format("Incoming request size too large: %s, Current limit: %s, From: %s", dataSize, this.maxIncomingPacketSize, who));
        }
    }
}

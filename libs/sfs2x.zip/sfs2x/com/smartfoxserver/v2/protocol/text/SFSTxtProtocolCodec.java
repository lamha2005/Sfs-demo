// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.text;

import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.data.Packet;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.bitswarm.io.Request;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.io.IOHandler;
import java.util.concurrent.atomic.AtomicLong;
import com.smartfoxserver.bitswarm.io.protocols.AbstractProtocolCodec;

public class SFSTxtProtocolCodec extends AbstractProtocolCodec
{
    private static final String CONTROLLER_ID = "c";
    private static final String ACTION_ID = "a";
    private static final String PARAM_ID = "p";
    private final AtomicLong udpPacketCounter;
    
    public SFSTxtProtocolCodec(final IOHandler ioHandler) {
        this.setIOHandler(ioHandler);
        this.udpPacketCounter = new AtomicLong();
    }
    
    public void onPacketRead(final IPacket packet) {
        if (packet == null) {
            throw new IllegalStateException("Protocol Codec didn't expect a null packet!");
        }
        ISFSObject requestObject = null;
        if (packet.isTcp()) {
            final String buff = (String)packet.getData();
            try {
                requestObject = SFSObject.newFromJsonData(buff);
            }
            catch (Exception e) {
                this.logger.warn("Error deserializing request: " + e);
            }
        }
        else if (packet.isUdp()) {
            requestObject = (ISFSObject)packet.getData();
            requestObject.putShort("a", (short)0);
        }
        if (requestObject != null) {
            if (this.logger.isDebugEnabled()) {
                this.logger.debug(requestObject.getDump());
            }
            this.dispatchRequest(requestObject, packet);
        }
    }
    
    private void dispatchRequest(final ISFSObject requestObject, final IPacket packet) {
        if (requestObject.isNull("c")) {
            throw new IllegalStateException("Request rejected: No Controller ID in request!");
        }
        if (requestObject.isNull("a")) {
            throw new IllegalStateException("Request rejected: No Action ID in request!");
        }
        if (requestObject.isNull("p")) {
            throw new IllegalStateException("Request rejected: Missing parameters field!");
        }
        final IRequest request = (IRequest)new Request();
        Object controllerKey = null;
        request.setId((Object)Short.parseShort(requestObject.getInt("a").toString()));
        controllerKey = Byte.parseByte(requestObject.getInt("c").toString());
        request.setContent((Object)requestObject.getSFSObject("p"));
        request.setSender(packet.getSender());
        request.setTransportType(packet.getTransportType());
        if (packet.isUdp()) {
            request.setAttribute("$FS_REQUEST_UDP_TIMESTAMP", (Object)requestObject.getLong("i"));
        }
        this.dispatchRequestToController(request, controllerKey);
    }
    
    public void onPacketWrite(final IResponse response) {
        final ISFSObject params = SFSObject.newInstance();
        params.putByte("c", (byte)response.getTargetController());
        params.putShort("a", (short)response.getId());
        if (response.isUDP()) {
            params.putLong("i", this.udpPacketCounter.getAndIncrement());
        }
        params.putSFSObject("p", (ISFSObject)response.getContent());
        final IPacket packet = (IPacket)new Packet();
        packet.setTransportType(response.getTransportType());
        packet.setData((Object)params);
        packet.setRecipients(response.getRecipients());
        if (response.getRecipients().size() > 0 && this.logger.isDebugEnabled()) {
            this.logger.debug("{OUT}: " + SystemRequest.fromId(response.getId()));
        }
        this.ioHandler.onDataWrite(packet);
    }
}

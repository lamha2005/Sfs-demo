// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.text;

import com.smartfoxserver.v2.exceptions.WebSocketHandshakeException;
import org.apache.commons.lang.StringUtils;

public class WSHandshake
{
    private static final String GET_TOKEN = "GET";
    private static final String WS_ORIGIN = "Origin:";
    private static final String WS_HOST = "Host:";
    private static final String WS_KEY = "Sec-WebSocket-Key:";
    private static final String CRLF;
    private String wsHandshake;
    private String wsOrigin;
    private String wsHost;
    private String wsKey;
    private boolean valid;
    private String[] handshakeLines;
    
    static {
        CRLF = new String(new byte[] { 13, 10 });
    }
    
    public WSHandshake(final byte[] rawData) {
        this.wsHandshake = new String(rawData);
        this.handshakeLines = StringUtils.split(this.wsHandshake, WSHandshake.CRLF);
        this.wsOrigin = this.extractHandshakeValue(this.wsHandshake, "Origin:");
        this.wsHost = this.extractHandshakeValue(this.wsHandshake, "Host:");
        this.wsKey = this.extractHandshakeValue(this.wsHandshake, "Sec-WebSocket-Key:");
    }
    
    public void validate() throws WebSocketHandshakeException {
    }
    
    public String getHost() {
        return this.wsHost;
    }
    
    public String getOrigin() {
        return this.wsOrigin;
    }
    
    public String getKey() {
        return this.wsKey;
    }
    
    public String getDump() {
        return this.wsHandshake;
    }
    
    private String extractHandshakeValue(final String wsHandshake, final String key) {
        String wsOrigin = null;
        String[] handshakeLines;
        for (int length = (handshakeLines = this.handshakeLines).length, i = 0; i < length; ++i) {
            final String line = handshakeLines[i];
            final int pos = line.indexOf(key);
            if (pos > -1) {
                wsOrigin = line.substring(pos + key.length(), line.length()).trim();
                break;
            }
        }
        return wsOrigin;
    }
    
    @Override
    public String toString() {
        return this.getDump();
    }
}

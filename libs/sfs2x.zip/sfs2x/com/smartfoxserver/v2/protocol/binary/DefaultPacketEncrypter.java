// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.io.IPacketEncrypter;

public final class DefaultPacketEncrypter implements IPacketEncrypter
{
    private final String ALGORITHM = "AES";
    private final String ALGORITHM_MODE = "AES/CBC/PKCS5PADDING";
    
    public byte[] encrypt(final ISession session, final byte[] data) throws Exception {
        return this.execute(1, session, data);
    }
    
    public byte[] decrypt(final ISession session, final byte[] data) throws Exception {
        return this.execute(2, session, data);
    }
    
    private byte[] execute(final int mode, final ISession session, final byte[] data) throws Exception {
        final CryptoKey ck = (CryptoKey)session.getCryptoKey();
        if (ck != null) {
            final IvParameterSpec iv = new IvParameterSpec(ck.getInitVector());
            final SecretKeySpec skeySpec = new SecretKeySpec(ck.getSecretKey(), "AES");
            final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(mode, skeySpec, iv);
            return cipher.doFinal(data);
        }
        throw new IllegalStateException("Session does not support encryption: " + session);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

import java.nio.ByteBuffer;

public class CryptoKey
{
    private byte[] secretKey;
    private byte[] initVector;
    
    public CryptoKey(final byte[] secretKey, final byte[] initVector) {
        this.secretKey = secretKey;
        this.initVector = initVector;
    }
    
    public byte[] combinedBytes() {
        final ByteBuffer buf = ByteBuffer.allocate(this.secretKey.length + this.initVector.length);
        buf.put(this.secretKey);
        buf.put(this.initVector);
        return buf.array();
    }
    
    public byte[] getSecretKey() {
        return this.secretKey;
    }
    
    public byte[] getInitVector() {
        return this.initVector;
    }
}

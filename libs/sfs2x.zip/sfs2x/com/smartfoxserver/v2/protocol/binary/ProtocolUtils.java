// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

public class ProtocolUtils
{
    public static final int SHORT_SIZE = 2;
    public static final int INT_SIZE = 4;
    private static final IUDPSessionTracker sessionTracker;
    
    static {
        sessionTracker = new UDPSessionTracker();
    }
    
    public static IUDPSessionTracker getUDPSessionTracker() {
        return ProtocolUtils.sessionTracker;
    }
    
    public static byte encodeFirstHeaderByte(final PacketHeader packetHeader) {
        byte headerByte = 0;
        if (packetHeader.isBinary()) {
            headerByte += 128;
        }
        if (packetHeader.isEncrypted()) {
            headerByte += 64;
        }
        if (packetHeader.isCompressed()) {
            headerByte += 32;
        }
        if (packetHeader.isBlueBoxed()) {
            headerByte += 16;
        }
        if (packetHeader.isBigSized()) {
            headerByte += 8;
        }
        return headerByte;
    }
    
    public static PacketHeader decodeFirstHeaderByte(final byte headerByte) {
        return new PacketHeader((headerByte & 0x80) > 0, (headerByte & 0x40) > 0, (headerByte & 0x20) > 0, (headerByte & 0x10) > 0, (headerByte & 0x8) > 0);
    }
}

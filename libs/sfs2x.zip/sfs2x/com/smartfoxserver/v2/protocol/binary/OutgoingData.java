// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

public class OutgoingData
{
    private PacketHeader header;
    private byte[] body;
    
    public OutgoingData(final PacketHeader header, final byte[] body) {
        this.header = header;
        this.body = body;
    }
    
    public PacketHeader getHeader() {
        return this.header;
    }
    
    public byte[] getBody() {
        return this.body;
    }
}

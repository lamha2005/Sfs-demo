// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

import java.io.IOException;
import java.util.zip.Inflater;
import java.io.ByteArrayOutputStream;
import java.util.zip.Deflater;

public final class DefaultPacketCompressor implements IPacketCompressor
{
    public final int MAX_SIZE_FOR_COMPRESSION = 1000000;
    private final int compressionBufferSize = 512;
    private final int maxPacketSize;
    
    public DefaultPacketCompressor() {
        this.maxPacketSize = Integer.MAX_VALUE;
    }
    
    public DefaultPacketCompressor(final int maxPacketSize) {
        this.maxPacketSize = maxPacketSize;
    }
    
    @Override
    public byte[] compress(final byte[] data) throws Exception {
        if (data.length > 1000000) {
            return data;
        }
        final Deflater compressor = new Deflater();
        compressor.setInput(data);
        compressor.finish();
        final ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length);
        final byte[] buf = new byte[512];
        while (!compressor.finished()) {
            final int count = compressor.deflate(buf);
            bos.write(buf, 0, count);
        }
        bos.close();
        return bos.toByteArray();
    }
    
    @Override
    public byte[] uncompress(final byte[] zipData) throws Exception {
        final Inflater unzipper = new Inflater();
        unzipper.setInput(zipData);
        final ByteArrayOutputStream bos = new ByteArrayOutputStream(zipData.length);
        final byte[] buf = new byte[512];
        int uncompressedByteSize = 0;
        try {
            while (!unzipper.finished()) {
                final int count = unzipper.inflate(buf);
                if (count < 1 && unzipper.needsInput()) {
                    throw new IOException("Bad Packet compression format! Packet dropped.");
                }
                uncompressedByteSize += count;
                if (uncompressedByteSize > this.maxPacketSize) {
                    throw new IOException("Uncompressed size exceeds current packet size limit. Packet dropped.");
                }
                bos.write(buf, 0, count);
            }
            return bos.toByteArray();
        }
        finally {
            bos.close();
        }
    }
}

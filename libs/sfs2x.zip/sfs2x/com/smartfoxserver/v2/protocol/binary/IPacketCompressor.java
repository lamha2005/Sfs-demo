// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

public interface IPacketCompressor
{
    byte[] compress(final byte[] p0) throws Exception;
    
    byte[] uncompress(final byte[] p0) throws Exception;
}

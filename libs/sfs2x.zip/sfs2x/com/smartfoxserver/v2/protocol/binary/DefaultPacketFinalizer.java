// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.io.IPacketEncrypter;
import com.smartfoxserver.bitswarm.io.IPacketFinalizer;

public class DefaultPacketFinalizer implements IPacketFinalizer
{
    private final IPacketEncrypter packetEncrypter;
    
    public DefaultPacketFinalizer() {
        this.packetEncrypter = (IPacketEncrypter)new DefaultPacketEncrypter();
    }
    
    public byte[] process(final ISession session, final IPacket packet) throws Exception {
        final Object data = packet.getData();
        if (data instanceof byte[]) {
            return (byte[])data;
        }
        final OutgoingData od = (OutgoingData)data;
        final PacketHeader header = od.getHeader();
        byte[] outBytes = od.getBody();
        if (session.isEncrypted()) {
            outBytes = this.packetEncrypter.encrypt(session, outBytes);
            header.setEncrypted(true);
        }
        final byte headerByte = ProtocolUtils.encodeFirstHeaderByte(header);
        final int payloadSize = header.isBigSized() ? 4 : 2;
        final ByteBuffer packetBuffer = ByteBuffer.allocate(1 + payloadSize + outBytes.length);
        packetBuffer.put(headerByte);
        if (payloadSize == 4) {
            packetBuffer.putInt(outBytes.length);
        }
        else {
            packetBuffer.putShort((short)outBytes.length);
        }
        packetBuffer.put(outBytes);
        return packetBuffer.array();
    }
}

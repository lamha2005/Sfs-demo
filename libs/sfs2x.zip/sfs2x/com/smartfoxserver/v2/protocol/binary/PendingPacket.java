// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

public class PendingPacket
{
    private PacketHeader header;
    private Object buffer;
    
    public PendingPacket(final PacketHeader header) {
        this.header = header;
    }
    
    public PacketHeader getHeader() {
        return this.header;
    }
    
    public Object getBuffer() {
        return this.buffer;
    }
    
    public void setBuffer(final Object buffer) {
        this.buffer = buffer;
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.header.toString()) + this.buffer.toString();
    }
}

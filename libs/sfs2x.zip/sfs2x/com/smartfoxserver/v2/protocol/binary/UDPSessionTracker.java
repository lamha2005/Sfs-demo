// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.concurrent.ConcurrentMap;

class UDPSessionTracker implements IUDPSessionTracker
{
    private ConcurrentMap<String, ISession> sessionsByOrigin;
    
    UDPSessionTracker() {
        this.sessionsByOrigin = new ConcurrentHashMap<String, ISession>();
    }
    
    @Override
    public ISession getSession(final String key) {
        return this.sessionsByOrigin.get(key);
    }
    
    @Override
    public void storeSession(final String key, final ISession session) {
        this.sessionsByOrigin.put(key, session);
    }
    
    @Override
    public void remove(final String key) {
        this.sessionsByOrigin.remove(key);
    }
    
    public Set<String> getKeys() {
        return this.sessionsByOrigin.keySet();
    }
}

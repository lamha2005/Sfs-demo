// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

import com.smartfoxserver.bitswarm.sessions.ISession;

public interface IUDPSessionTracker
{
    ISession getSession(final String p0);
    
    void storeSession(final String p0, final ISession p1);
    
    void remove(final String p0);
}

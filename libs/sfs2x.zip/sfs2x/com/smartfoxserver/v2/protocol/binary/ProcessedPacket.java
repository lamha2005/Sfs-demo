// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

public class ProcessedPacket
{
    private byte[] data;
    private PacketReadState state;
    
    public ProcessedPacket(final PacketReadState state, final byte[] data) {
        this.state = state;
        this.data = data;
    }
    
    public byte[] getData() {
        return this.data;
    }
    
    public PacketReadState getState() {
        return this.state;
    }
}

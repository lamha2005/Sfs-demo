// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

public enum PacketReadState
{
    WAIT_NEW_PACKET("WAIT_NEW_PACKET", 0), 
    WAIT_DATA_SIZE("WAIT_DATA_SIZE", 1), 
    WAIT_DATA_SIZE_FRAGMENT("WAIT_DATA_SIZE_FRAGMENT", 2), 
    WAIT_DATA("WAIT_DATA", 3);
    
    private PacketReadState(final String s, final int n) {
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol.binary;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.data.Packet;
import java.nio.ByteBuffer;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.util.ByteUtils;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.bitswarm.data.IPacket;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.protocol.SFSIoHandler;
import java.util.concurrent.Executor;
import com.smartfoxserver.v2.config.ServerSettings;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import com.smartfoxserver.bitswarm.io.IPacketEncrypter;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import org.slf4j.Logger;

public class BinaryIoHandler
{
    private static final int MAX_PACKET_DEBUG_LEN = 2048;
    private final Logger log;
    private final BitSwarmEngine engine;
    private final SmartFoxServer sfs;
    private final IPacketCompressor packetCompressor;
    private final IPacketEncrypter packetEncrypter;
    private IProtocolCodec protocolCodec;
    private ServerSettings serverSettings;
    private final int maxIncomingPacketSize;
    private volatile long packetsRead;
    private volatile long droppedIncomingPackets;
    private final Executor systemThreadPool;
    
    public BinaryIoHandler(final SFSIoHandler parentHandler) {
        this.packetsRead = 0L;
        this.droppedIncomingPackets = 0L;
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.engine = BitSwarmEngine.getInstance();
        this.sfs = SmartFoxServer.getInstance();
        this.serverSettings = this.sfs.getConfigurator().getServerSettings();
        this.packetEncrypter = (IPacketEncrypter)new DefaultPacketEncrypter();
        this.maxIncomingPacketSize = BitSwarmEngine.getInstance().getConfiguration().getMaxIncomingRequestSize();
        this.packetCompressor = new DefaultPacketCompressor(this.maxIncomingPacketSize);
        this.systemThreadPool = this.sfs.getSystemThreadPool();
    }
    
    public void setProtocolCodec(final IProtocolCodec protocolCodec) {
        this.protocolCodec = protocolCodec;
    }
    
    public IPacketCompressor getPacketCompressor() {
        return this.packetCompressor;
    }
    
    public IPacketEncrypter getPacketEncrypter() {
        return this.packetEncrypter;
    }
    
    public long getReadPackets() {
        return this.packetsRead;
    }
    
    public long getIncomingDroppedPackets() {
        return this.droppedIncomingPackets;
    }
    
    public void handleWrite(final IPacket packet) throws Exception {
        byte[] binData = ((ISFSObject)packet.getData()).toBinary();
        packet.setData((Object)binData);
        boolean isCompressed = false;
        final int originalSize = binData.length;
        if (binData.length > this.serverSettings.protocolCompressionThreshold) {
            final byte[] beforeCompression = binData;
            binData = this.packetCompressor.compress(binData);
            if (binData != beforeCompression) {
                isCompressed = true;
            }
        }
        int sizeBytes = 2;
        if (binData.length > 65535) {
            sizeBytes = 4;
        }
        final PacketHeader packetHeader = new PacketHeader(true, false, isCompressed, false, sizeBytes == 4);
        final OutgoingData od = new OutgoingData(packetHeader, binData);
        packet.setData((Object)od);
        if (this.log.isDebugEnabled()) {
            if (isCompressed) {
                this.log.debug(String.format(" (cmp: %sb / %sb)", originalSize, binData.length));
            }
            if (binData.length < 2048) {
                this.log.debug(ByteUtils.fullHexDump(od.getBody()));
            }
        }
        this.engine.getSocketWriter().enqueuePacket(packet);
    }
    
    public void handleRead(final ISession session, byte[] data) {
        if (data.length < 1024 && this.log.isDebugEnabled()) {
            this.log.debug(ByteUtils.fullHexDump(data));
        }
        PacketReadState readState = (PacketReadState)session.getSystemProperty("read_state");
        try {
            while (data.length > 0) {
                if (this.log.isDebugEnabled()) {
                    this.log.debug("STATE: " + readState);
                }
                if (readState == PacketReadState.WAIT_NEW_PACKET) {
                    final ProcessedPacket process = this.handleNewPacket(session, data);
                    readState = process.getState();
                    data = process.getData();
                }
                if (readState == PacketReadState.WAIT_DATA_SIZE) {
                    final ProcessedPacket process = this.handleDataSize(session, data);
                    readState = process.getState();
                    data = process.getData();
                }
                if (readState == PacketReadState.WAIT_DATA_SIZE_FRAGMENT) {
                    final ProcessedPacket process = this.handleDataSizeFragment(session, data);
                    readState = process.getState();
                    data = process.getData();
                }
                if (readState == PacketReadState.WAIT_DATA) {
                    final ProcessedPacket process = this.handlePacketData(session, data);
                    readState = process.getState();
                    data = process.getData();
                }
            }
        }
        catch (Exception err) {
            final ExceptionMessageComposer emc = new ExceptionMessageComposer(err);
            emc.addInfo("Sender: " + session.toString());
            this.log.warn(emc.toString());
            readState = PacketReadState.WAIT_NEW_PACKET;
        }
        session.setSystemProperty("read_state", (Object)readState);
    }
    
    private ProcessedPacket handleNewPacket(final ISession session, byte[] data) {
        final PacketHeader header = ProtocolUtils.decodeFirstHeaderByte(data[0]);
        session.setSystemProperty("session_data_buffer", (Object)new PendingPacket(header));
        data = ByteUtils.resizeByteArray(data, 1, data.length - 1);
        return new ProcessedPacket(PacketReadState.WAIT_DATA_SIZE, data);
    }
    
    private ProcessedPacket handleDataSize(final ISession session, byte[] data) {
        PacketReadState state = PacketReadState.WAIT_DATA;
        final PendingPacket pending = (PendingPacket)session.getSystemProperty("session_data_buffer");
        int dataSize = -1;
        int sizeBytes = 2;
        if (pending.getHeader().isBigSized()) {
            if (data.length >= 4) {
                dataSize = 0;
                for (int i = 0; i < 4; ++i) {
                    final int pow256 = (int)Math.pow(256.0, 3 - i);
                    final int intByte = data[i] & 0xFF;
                    dataSize += pow256 * intByte;
                }
            }
            sizeBytes = 4;
            if (this.log.isDebugEnabled()) {
                this.log.debug("BIG SIZED PACKET: " + ((dataSize == -1) ? "Unknown" : dataSize));
            }
        }
        else {
            if (data.length >= 2) {
                final int msb = data[0] & 0xFF;
                final int lsb = data[1] & 0xFF;
                dataSize = msb * 256 + lsb;
            }
            if (this.log.isDebugEnabled()) {
                this.log.debug("NORMAL SIZED PACKET: " + ((dataSize == -1) ? "Unknown" : dataSize));
            }
        }
        if (dataSize != -1) {
            this.validateIncomingDataSize(session, dataSize);
            pending.getHeader().setExpectedLen(dataSize);
            pending.setBuffer(ByteBuffer.allocate(dataSize));
            data = ByteUtils.resizeByteArray(data, sizeBytes, data.length - sizeBytes);
        }
        else {
            state = PacketReadState.WAIT_DATA_SIZE_FRAGMENT;
            final ByteBuffer sizeBuffer = ByteBuffer.allocate(4);
            sizeBuffer.put(data);
            pending.setBuffer(sizeBuffer);
            data = new byte[0];
        }
        return new ProcessedPacket(state, data);
    }
    
    private ProcessedPacket handleDataSizeFragment(final ISession session, byte[] data) {
        if (this.log.isDebugEnabled()) {
            this.log.debug("Handling DataSize fragment...");
        }
        PacketReadState state = PacketReadState.WAIT_DATA_SIZE_FRAGMENT;
        final PendingPacket pending = (PendingPacket)session.getSystemProperty("session_data_buffer");
        final ByteBuffer sizeBuffer = (ByteBuffer)pending.getBuffer();
        final int remaining = pending.getHeader().isBigSized() ? (4 - sizeBuffer.position()) : (2 - sizeBuffer.position());
        if (data.length >= remaining) {
            sizeBuffer.put(data, 0, remaining);
            sizeBuffer.flip();
            final int dataSize = pending.getHeader().isBigSized() ? sizeBuffer.getInt() : sizeBuffer.getShort();
            if (this.log.isDebugEnabled()) {
                this.log.debug("DataSize is ready: " + dataSize);
            }
            this.validateIncomingDataSize(session, dataSize);
            pending.getHeader().setExpectedLen(dataSize);
            pending.setBuffer(ByteBuffer.allocate(dataSize));
            state = PacketReadState.WAIT_DATA;
            if (data.length > remaining) {
                data = ByteUtils.resizeByteArray(data, remaining, data.length - remaining);
            }
            else {
                data = new byte[0];
            }
        }
        else {
            sizeBuffer.put(data);
            data = new byte[0];
        }
        return new ProcessedPacket(state, data);
    }
    
    private ProcessedPacket handlePacketData(final ISession session, byte[] data) throws Exception {
        PacketReadState state = PacketReadState.WAIT_DATA;
        final PendingPacket pending = (PendingPacket)session.getSystemProperty("session_data_buffer");
        ByteBuffer dataBuffer = (ByteBuffer)pending.getBuffer();
        final int readLen = dataBuffer.remaining();
        final boolean isThereMore = data.length > readLen;
        if (data.length >= readLen) {
            dataBuffer.put(data, 0, readLen);
            if (pending.getHeader().getExpectedLen() != dataBuffer.capacity()) {
                throw new IllegalStateException("Expected data size differs from the buffer capacity! Expected: " + pending.getHeader().getExpectedLen() + ", Buffer size: " + dataBuffer.capacity());
            }
            if (this.log.isDebugEnabled()) {
                this.log.debug("<<< PACKET COMPLETE >>>");
            }
            if (pending.getHeader().isEncrypted()) {
                final byte[] decryptedData = this.packetEncrypter.decrypt(session, dataBuffer.array());
                dataBuffer = ByteBuffer.wrap(decryptedData);
            }
            if (pending.getHeader().isCompressed()) {
                final byte[] compressedData = dataBuffer.array();
                final long t1 = System.nanoTime();
                final byte[] deflatedData = this.packetCompressor.uncompress(compressedData);
                final long t2 = System.nanoTime();
                if (this.log.isDebugEnabled()) {
                    this.log.debug(String.format("Original: %s, Deflated: %s, Comp. Ratio: %s%%, Time: %sms.", dataBuffer.capacity(), deflatedData.length, 100 - dataBuffer.capacity() * 100 / deflatedData.length, (t2 - t1) / 1000000.0f));
                }
                dataBuffer = ByteBuffer.wrap(deflatedData);
            }
            final IPacket newPacket = (IPacket)new Packet();
            newPacket.setData((Object)dataBuffer);
            newPacket.setSender(session);
            newPacket.setOriginalSize(dataBuffer.capacity());
            newPacket.setTransportType(TransportType.TCP);
            if (pending.getHeader().isEncrypted()) {
                newPacket.setAttribute("Encrypted", (Object)true);
            }
            ++this.packetsRead;
            state = PacketReadState.WAIT_NEW_PACKET;
            this.systemThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    BinaryIoHandler.this.protocolCodec.onPacketRead(newPacket);
                }
            });
        }
        else {
            dataBuffer.put(data);
            if (this.log.isDebugEnabled()) {
                this.log.debug("NOT ENOUGH DATA, GO AHEAD");
            }
        }
        if (isThereMore) {
            data = ByteUtils.resizeByteArray(data, readLen, data.length - readLen);
        }
        else {
            data = new byte[0];
        }
        return new ProcessedPacket(state, data);
    }
    
    private void validateIncomingDataSize(final ISession session, final int dataSize) {
        final User user = this.sfs.getUserManager().getUserBySession(session);
        final String who = (user != null) ? user.toString() : session.toString();
        if (dataSize < 1) {
            ++this.droppedIncomingPackets;
            throw new IllegalArgumentException("Illegal request size: " + dataSize + " bytes, from: " + who);
        }
        if (dataSize > this.maxIncomingPacketSize) {
            this.sfs.getAPIManager().getSFSApi().disconnect(session);
            ++this.droppedIncomingPackets;
            throw new IllegalArgumentException(String.format("Incoming request size too large: %s, Current limit: %s, From: %s", dataSize, this.maxIncomingPacketSize, who));
        }
    }
}

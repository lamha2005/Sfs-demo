// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol;

import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.bitswarm.io.Response;
import java.util.ArrayList;
import com.smartfoxserver.bitswarm.sessions.ISession;
import java.util.List;
import java.util.Collection;
import java.util.Arrays;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.bitswarm.controllers.AbstractController;

public class DefaultRequestController extends AbstractController
{
    public void processRequest(final IRequest request) throws Exception {
        final ISFSObject reqObj = (SFSObject)request.getContent();
        final int reqId = (short)request.getId();
        System.out.println("Got a request! ID: " + reqId);
        switch (reqId) {
            case 1: {
                this.handleReqOne(request);
                break;
            }
        }
    }
    
    private void handleReqOne(final IRequest request) {
        final ISFSObject responseObj = SFSObject.newInstance();
        responseObj.putIntArray("123", Arrays.asList(1, 2, 3));
        responseObj.putUtfString("res", "Hello to you!");
        this.sendResponse((short)1, request.getSender(), responseObj);
    }
    
    private void sendResponse(final short actionId, final Object recipients, final ISFSObject responseObject) {
        List<ISession> recipientList = null;
        if (recipients instanceof List) {
            recipientList = (List<ISession>)recipients;
        }
        else {
            if (!(recipients instanceof ISession)) {
                throw new IllegalArgumentException("Wrong recipients argument in sendResponse!");
            }
            recipientList = new ArrayList<ISession>();
            recipientList.add((ISession)recipients);
        }
        final IResponse response = (IResponse)new Response();
        response.setId(this.id);
        response.setRecipients((Collection)recipientList);
        final ISFSObject fullObj = SFSObject.newInstance();
        fullObj.putByte("id", (byte)1);
        fullObj.putShort("a", actionId);
        fullObj.putSFSObject("p", responseObject);
        response.setContent((Object)fullObj);
        response.write();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol;

import com.smartfoxserver.v2.protocol.binary.PacketHeader;
import com.smartfoxserver.v2.protocol.binary.ProtocolUtils;
import com.smartfoxserver.v2.entities.data.SFSObject;
import java.util.Collection;
import java.util.Arrays;
import com.smartfoxserver.bitswarm.data.TransportType;
import com.smartfoxserver.bitswarm.data.Packet;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSCodecException;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.net.SocketAddress;
import java.nio.channels.DatagramChannel;
import com.smartfoxserver.v2.protocol.binary.PacketReadState;
import com.smartfoxserver.bitswarm.io.protocols.ProtocolType;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.bitswarm.io.IProtocolCodec;
import com.smartfoxserver.bitswarm.io.IOHandler;
import org.slf4j.LoggerFactory;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import com.smartfoxserver.bitswarm.core.BitSwarmEngine;
import com.smartfoxserver.v2.SmartFoxServer;
import org.slf4j.Logger;
import com.smartfoxserver.v2.protocol.binary.BinaryIoHandler;
import com.smartfoxserver.bitswarm.io.AbstractIOHandler;

public class SFSIoHandler extends AbstractIOHandler
{
    private static final String FLASH_CROSSDOMAIN_POLICY_REQ = "<policy-file-request/>";
    private static final char TAG_TOKEN = '<';
    private static final int CROSSDOMAIN_REQ_LEN;
    private static final int UDP_PACKET_MIN_SIZE = 13;
    private static final String KEY_UDP_HANDSHAKE = "h";
    private final BinaryIoHandler binHandler;
    private final Logger log;
    private final SmartFoxServer sfs;
    private final BitSwarmEngine engine;
    private final Executor systemThreadPool;
    private ByteBuffer bufferedXmlSocketPolicy;
    
    static {
        CROSSDOMAIN_REQ_LEN = "<policy-file-request/>".length() + 1;
    }
    
    public SFSIoHandler() {
        this.log = LoggerFactory.getLogger((Class)this.getClass());
        this.sfs = SmartFoxServer.getInstance();
        this.engine = BitSwarmEngine.getInstance();
        this.binHandler = new BinaryIoHandler(this);
        this.bufferedXmlSocketPolicy = null;
        this.systemThreadPool = this.sfs.getSystemThreadPool();
        this.setCodec((IProtocolCodec)new SFSProtocolCodec((IOHandler)this));
    }
    
    public void onDataRead(final ISession session, final byte[] data) {
        if (data == null || data.length < 1) {
            throw new IllegalArgumentException("Unexpected null or empty byte array!");
        }
        final ProtocolType sessionProtocol = (ProtocolType)session.getSystemProperty("session_protocol");
        if (sessionProtocol == null) {
            if (data[0] == 60) {
                this.handlSocketPolicyRequest(data, session);
                return;
            }
            session.setSystemProperty("session_protocol", (Object)ProtocolType.BINARY);
            session.setSystemProperty("read_state", (Object)PacketReadState.WAIT_NEW_PACKET);
        }
        this.binHandler.handleRead(session, data);
    }
    
    public void setCodec(final IProtocolCodec codec) {
        super.setCodec(codec);
        this.binHandler.setProtocolCodec(codec);
    }
    
    public long getReadPackets() {
        return this.binHandler.getReadPackets();
    }
    
    public long getIncomingDroppedPackets() {
        return this.binHandler.getIncomingDroppedPackets();
    }
    
    public void onDataRead(final DatagramChannel channel, final SocketAddress address, final byte[] data) {
        this.systemThreadPool.execute(new UdpIOExecutor(channel, address, data));
    }
    
    private ISession validateUDPRequest(final String senderIP, final int senderPort, final ISFSObject packet) throws SFSCodecException {
        if (!packet.containsKey("c")) {
            throw new SFSCodecException("Missing controllerId");
        }
        if (!packet.containsKey("u")) {
            throw new SFSCodecException("Missing userId");
        }
        if (!packet.containsKey("i")) {
            throw new SFSCodecException("Missing packet id");
        }
        final int userId = packet.getInt("u");
        final User sender = this.sfs.getUserManager().getUserById(userId);
        if (sender == null) {
            throw new SFSCodecException("User does not exist, id: " + userId);
        }
        final ISession session = sender.getSession();
        if (!session.getAddress().equals(senderIP)) {
            throw new SFSCodecException(String.format("Sender IP doesn't match TCP session address: %s != %s", senderIP, session.getAddress()));
        }
        final Integer sessionUdpPort = (Integer)session.getSystemProperty("UDPPort");
        if (sessionUdpPort == null) {
            session.setSystemProperty("UDPPort", (Object)senderPort);
        }
        else if (senderPort != sessionUdpPort) {
            throw new SFSCodecException(String.format("Sender UDP Port doesn't match current session port: %s != %s", senderPort, sessionUdpPort));
        }
        return sender.getSession();
    }
    
    public void onDataWrite(final IPacket packet) {
        if (packet.getRecipients().size() > 0) {
            try {
                this.binHandler.handleWrite(packet);
            }
            catch (Exception e) {
                final ExceptionMessageComposer composer = new ExceptionMessageComposer(e);
                this.log.warn(composer.toString());
            }
        }
    }
    
    private byte[] handlSocketPolicyRequest(final byte[] data, final ISession session) {
        final String stringMsg = new String(data);
        byte[] newData = data;
        if (stringMsg.startsWith("<policy-file-request/>")) {
            if (this.log.isDebugEnabled()) {
                this.log.debug("Handling Flash Policy request");
            }
            if (data.length > SFSIoHandler.CROSSDOMAIN_REQ_LEN) {
                newData = new byte[data.length - SFSIoHandler.CROSSDOMAIN_REQ_LEN];
            }
            System.arraycopy(data, SFSIoHandler.CROSSDOMAIN_REQ_LEN, newData, 0, newData.length - SFSIoHandler.CROSSDOMAIN_REQ_LEN);
        }
        if (this.bufferedXmlSocketPolicy == null) {
            final String policyText = this.engine.getConfiguration().getFlashCrossdomainPolicyXml();
            (this.bufferedXmlSocketPolicy = ByteBuffer.allocate(policyText.length() + 1)).put(policyText.getBytes());
            this.bufferedXmlSocketPolicy.put((byte)0);
            this.bufferedXmlSocketPolicy.flip();
        }
        final IPacket policyPacket = (IPacket)new Packet();
        policyPacket.setData((Object)this.bufferedXmlSocketPolicy.array());
        policyPacket.setTransportType(TransportType.TCP);
        policyPacket.setRecipients((Collection)Arrays.asList(session));
        this.engine.getSocketWriter().enqueuePacket(policyPacket);
        return newData;
    }
    
    private void sendUDPHandshakeResponse(final ISession recipient) {
        final ISFSObject responseObj = new SFSObject();
        responseObj.putByte("c", (byte)1);
        responseObj.putByte("h", (byte)1);
        responseObj.putShort("a", (short)0);
        final IPacket udpResponsePacket = (IPacket)new Packet();
        udpResponsePacket.setTransportType(TransportType.UDP);
        udpResponsePacket.setRecipients((Collection)Arrays.asList(recipient));
        udpResponsePacket.setData((Object)responseObj);
        this.onDataWrite(udpResponsePacket);
    }
    
    private final class UdpIOExecutor implements Runnable
    {
        DatagramChannel channel;
        SocketAddress address;
        byte[] data;
        
        public UdpIOExecutor(final DatagramChannel channel, final SocketAddress address, final byte[] data) {
            this.channel = channel;
            this.address = address;
            this.data = data;
        }
        
        @Override
        public void run() {
            String senderIP = null;
            int senderPort = 0;
            try {
                if (this.data.length < 4) {
                    throw new SFSCodecException("Packet too small: " + this.data.length + " bytes");
                }
                final PacketHeader packetHeader = ProtocolUtils.decodeFirstHeaderByte(this.data[0]);
                final int msb = this.data[1] & 0xFF;
                final int lsb = this.data[2] & 0xFF;
                final int dataSize = msb * 256 + lsb;
                if (dataSize < 13) {
                    throw new SFSCodecException("Packet data too small: " + this.data.length + " bytes");
                }
                final String[] adrData = this.address.toString().split("\\:");
                senderIP = adrData[0].substring(1);
                senderPort = Integer.parseInt(adrData[1]);
                byte[] sfsObjData = new byte[this.data.length - 3];
                System.arraycopy(this.data, 3, sfsObjData, 0, sfsObjData.length);
                if (sfsObjData.length != dataSize) {
                    throw new SFSCodecException("Packet truncated. Expected: " + dataSize + ", only got: " + sfsObjData.length);
                }
                Label_0361: {
                    if (packetHeader.isEncrypted()) {
                        final ISession session = ProtocolUtils.getUDPSessionTracker().getSession(String.valueOf(senderIP) + ":" + senderPort);
                        if (session != null) {
                            try {
                                sfsObjData = SFSIoHandler.this.binHandler.getPacketEncrypter().decrypt(session, sfsObjData);
                                break Label_0361;
                            }
                            catch (Exception e) {
                                throw new SFSCodecException(e.getMessage());
                            }
                        }
                        if (SFSIoHandler.this.log.isDebugEnabled()) {
                            SFSIoHandler.this.log.debug("No session found for UDP packet sent from: " + this.address);
                        }
                    }
                }
                if (packetHeader.isCompressed()) {
                    try {
                        sfsObjData = SFSIoHandler.this.binHandler.getPacketCompressor().uncompress(sfsObjData);
                    }
                    catch (Exception e2) {
                        throw new RuntimeException(e2);
                    }
                }
                final ISFSObject reqObj = SFSObject.newFromBinaryData(sfsObjData);
                final ISession session2 = SFSIoHandler.this.validateUDPRequest(senderIP, senderPort, reqObj);
                if (session2 != null) {
                    session2.addReadBytes((long)this.data.length);
                }
                if (reqObj.containsKey("h")) {
                    if (SFSIoHandler.this.log.isDebugEnabled()) {
                        SFSIoHandler.this.log.debug("UDP Handshake OK: " + session2);
                    }
                    if (session2.getDatagramChannel() == null) {
                        if (session2.getCryptoKey() != null) {
                            ProtocolUtils.getUDPSessionTracker().storeSession(String.valueOf(senderIP) + ":" + senderPort, session2);
                        }
                        session2.setDatagramChannel(this.channel);
                        SFSIoHandler.this.sendUDPHandshakeResponse(session2);
                    }
                    else {
                        SFSIoHandler.this.log.warn("Client already UDP inited: " + session2.toString());
                    }
                    return;
                }
                final IPacket newPacket = (IPacket)new Packet();
                newPacket.setData((Object)reqObj);
                newPacket.setSender(session2);
                newPacket.setOriginalSize(dataSize);
                newPacket.setTransportType(TransportType.UDP);
                newPacket.setAttribute("type", (Object)ProtocolType.BINARY);
                SFSIoHandler.this.codec.onPacketRead(newPacket);
            }
            catch (RuntimeException err) {
                SFSIoHandler.this.log.warn("Problems decoding UDP packet from: " + senderIP + ":" + senderPort + ", " + err);
                err.printStackTrace();
            }
            catch (SFSCodecException codecErr) {
                SFSIoHandler.this.log.warn(String.format("Discard UDP packet from %s:%s, reason: %s ", senderIP, senderPort, codecErr.getMessage()));
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.protocol;

import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.bitswarm.data.Packet;
import com.smartfoxserver.bitswarm.io.IResponse;
import com.smartfoxserver.bitswarm.io.IRequest;
import com.smartfoxserver.bitswarm.io.Request;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import java.nio.ByteBuffer;
import com.smartfoxserver.bitswarm.io.protocols.ProtocolType;
import com.smartfoxserver.bitswarm.data.IPacket;
import com.smartfoxserver.bitswarm.io.IOHandler;
import com.smartfoxserver.bitswarm.io.protocols.AbstractProtocolCodec;

public class DefaultProtocolCodec extends AbstractProtocolCodec
{
    private static final String CONTROLLER_ID = "c";
    private static final String ACTION_ID = "a";
    private static final String PARAM_ID = "p";
    
    public DefaultProtocolCodec(final IOHandler ioHandler) {
        this.setIOHandler(ioHandler);
    }
    
    public void onPacketRead(final IPacket packet) {
        if (packet == null) {
            throw new IllegalStateException("Protocol Codec didn't expect a null packet!");
        }
        final ProtocolType type = (ProtocolType)packet.getAttribute("type");
        if (type == ProtocolType.BINARY) {
            this.onBinaryData(packet);
        }
        else {
            if (type != ProtocolType.TEXT) {
                throw new IllegalArgumentException("Protocol Codec is not able to decode protocol type: " + type);
            }
            this.onTextData(packet);
        }
    }
    
    private void onBinaryData(final IPacket packet) {
        final ByteBuffer buff = (ByteBuffer)packet.getData();
        final ISFSObject requestObject = SFSObject.newFromBinaryData(buff.array());
        if (this.logger.isDebugEnabled()) {
            this.logger.debug(requestObject.getDump());
        }
        this.dispatchRequest(requestObject, packet, true);
    }
    
    private void onTextData(final IPacket packet) {
        final String jsonData = (String)packet.getData();
        final ISFSObject requestObject = SFSObject.newFromJsonData(jsonData);
        this.dispatchRequest(requestObject, packet, false);
    }
    
    private void dispatchRequest(final ISFSObject requestObject, final IPacket packet, final boolean isBinary) {
        if (requestObject.isNull("c")) {
            throw new IllegalStateException("Request rejected: No Controller ID in request!");
        }
        if (requestObject.isNull("a")) {
            throw new IllegalStateException("Request rejected: No Action ID in request!");
        }
        if (requestObject.isNull("p")) {
            throw new IllegalStateException("Request rejected: Missing parameters field!");
        }
        final IRequest request = (IRequest)new Request();
        Object controllerKey = null;
        if (isBinary) {
            request.setId((Object)requestObject.getShort("a"));
            controllerKey = requestObject.getByte("c");
        }
        else {
            request.setId((Object)(short)(Object)requestObject.getInt("a"));
            controllerKey = (Object)requestObject.getInt("c");
        }
        request.setContent((Object)requestObject.getSFSObject("p"));
        request.setSender(packet.getSender());
        request.setTransportType(packet.getTransportType());
        this.dispatchRequestToController(request, controllerKey);
    }
    
    public void onPacketWrite(final IResponse response) {
        final ISFSObject params = SFSObject.newInstance();
        params.putByte("c", (byte)response.getTargetController());
        params.putShort("a", (short)response.getId());
        params.putSFSObject("p", (ISFSObject)response.getContent());
        final IPacket packet = (IPacket)new Packet();
        packet.setTransportType(response.getTransportType());
        packet.setData((Object)params);
        packet.setRecipients(response.getRecipients());
        if (response.getRecipients().size() > 0) {
            this.logger.info("{OUT}: " + SystemRequest.fromId(response.getId()));
        }
        this.ioHandler.onDataWrite(packet);
    }
}

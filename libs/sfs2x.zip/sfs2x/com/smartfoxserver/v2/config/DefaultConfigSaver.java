// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import org.joda.time.format.DateTimeFormatter;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.apache.commons.io.FileUtils;
import java.io.File;
import org.apache.commons.io.FilenameUtils;
import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class DefaultConfigSaver implements IConfigSaver
{
    private static final String BACKUP_FOLDER = "_backups";
    private final XMLConfigHelper xmlHelper;
    private final Logger log;
    
    public DefaultConfigSaver() {
        this.xmlHelper = new XMLConfigHelper();
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public void saveServerSettings(final ServerSettings serverSettings, final boolean makeBackup) throws IOException {
        if (makeBackup) {
            this.makeBackup(this.xmlHelper.getServerConfigFileName());
        }
        final OutputStream outStream = new FileOutputStream(this.xmlHelper.getServerConfigFileName());
        this.xmlHelper.getServerXStreamDefinitions().toXML((Object)serverSettings, outStream);
    }
    
    @Override
    public void saveZoneSettings(final ZoneSettings settings, final boolean makeBackup) throws IOException {
        final String filePath = FilenameUtils.concat("zones/", String.valueOf(settings.name) + ".zone.xml");
        if (makeBackup) {
            this.makeBackup(filePath);
        }
        final OutputStream outStream = new FileOutputStream(filePath);
        this.xmlHelper.getZonesXStreamDefinitions().toXML((Object)settings, outStream);
    }
    
    @Override
    public void saveZoneSettings(final ZoneSettings zoneSettings, final boolean makeBackup, final String oldZoneName) throws IOException {
        final String newFilePath = FilenameUtils.concat("zones/", String.valueOf(zoneSettings.name) + ".zone.xml");
        final String oldFilePath = FilenameUtils.concat("zones/", String.valueOf(oldZoneName) + ".zone.xml");
        if (makeBackup) {
            this.makeBackup(oldFilePath);
        }
        final OutputStream outStream = new FileOutputStream(newFilePath);
        this.xmlHelper.getZonesXStreamDefinitions().toXML((Object)zoneSettings, outStream);
        FileUtils.forceDelete(new File(oldFilePath));
    }
    
    @Override
    public synchronized boolean removeZoneSetting(final ZoneSettings settings) throws IOException {
        if (settings != null) {
            final String path = FilenameUtils.concat("zones/", String.valueOf(settings.name) + ".zone.xml");
            this.makeBackup(path);
            FileUtils.forceDelete(new File(path));
            return true;
        }
        return false;
    }
    
    private void makeBackup(final String filePath) throws IOException {
        final String basePath = FilenameUtils.getPath(filePath);
        final String backupBasePath = FilenameUtils.concat(basePath, "_backups");
        final DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd-HH-mm-ss");
        final String backupId = new DateTime().toString(fmt);
        final String backupFileName = FilenameUtils.concat(backupBasePath, String.valueOf(backupId) + "__" + FilenameUtils.getName(filePath));
        final File sourceFile = new File(filePath);
        final File backupFile = new File(backupFileName);
        final File backupDir = new File(backupBasePath);
        if (!backupDir.isDirectory()) {
            FileUtils.forceMkdir(backupDir);
        }
        FileUtils.copyFile(sourceFile, backupFile);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.Iterator;
import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.io.FileNotFoundException;
import java.io.InputStream;
import com.thoughtworks.xstream.XStream;
import java.io.FileInputStream;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class DefaultConfigLoader implements IConfigLoader
{
    private final XMLConfigHelper xmlHelper;
    private final Logger log;
    
    public DefaultConfigLoader() {
        this.xmlHelper = new XMLConfigHelper();
        this.log = LoggerFactory.getLogger((Class)this.getClass());
    }
    
    @Override
    public CoreSettings loadCoreSettings() throws FileNotFoundException {
        final FileInputStream inStream = new FileInputStream("config/core.xml");
        final XStream xstream = new XStream();
        xstream.alias("coreSettings", (Class)CoreSettings.class);
        return (CoreSettings)xstream.fromXML((InputStream)inStream);
    }
    
    @Override
    public ServerSettings loadServerSettings() throws FileNotFoundException {
        final FileInputStream inStream = new FileInputStream(this.xmlHelper.getServerConfigFileName());
        return (ServerSettings)this.xmlHelper.getServerXStreamDefinitions().fromXML((InputStream)inStream);
    }
    
    @Override
    public synchronized List<ZoneSettings> loadZonesConfiguration() throws SFSException {
        final List<ZoneSettings> zonesSettings = new ArrayList<ZoneSettings>();
        final List<File> zoneDefinitionFiles = this.getZoneDefinitionFiles("zones/");
        for (final File file : zoneDefinitionFiles) {
            try {
                final FileInputStream inStream = new FileInputStream(file);
                this.log.info("Loading: " + file.toString());
                zonesSettings.add((ZoneSettings)this.xmlHelper.getZonesXStreamDefinitions().fromXML((InputStream)inStream));
            }
            catch (FileNotFoundException e) {
                throw new SFSRuntimeException("Could not locate Zone definition file: " + file.getAbsolutePath());
            }
        }
        return zonesSettings;
    }
    
    private List<File> getZoneDefinitionFiles(final String path) throws SFSException {
        final List<File> files = new ArrayList<File>();
        final File currDir = new File(path);
        if (currDir.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = currDir.listFiles()).length, i = 0; i < length; ++i) {
                final File f = listFiles[i];
                if (f.getName().endsWith(".zone.xml")) {
                    files.add(f);
                }
            }
            return files;
        }
        throw new SFSException("Invalid zones definition folder: " + currDir);
    }
}

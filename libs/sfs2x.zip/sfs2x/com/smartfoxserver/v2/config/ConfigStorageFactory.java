// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import com.smartfoxserver.v2.exceptions.SFSRuntimeException;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.core.ObjectFactory;

public class ConfigStorageFactory extends ObjectFactory
{
    private static final String DEFAULT_LOADER = "com.smartfoxserver.v2.config.DefaultConfigLoader";
    private static final String DEFAULT_SAVER = "com.smartfoxserver.v2.config.DefaultConfigSaver";
    private static final String GRID_LOADER = "com.smartfoxserver.grid.config.DistributedConfigLoader";
    private static final String GRID_SAVER = "com.smartfoxserver.grid.config.DistributedConfigSaver";
    private static final String GRID_CONFIG_POST_PROCESSOR = "com.smartfoxserver.grid.config.GridConfigPostProcessor";
    private static final ConfigStorageFactory instance;
    
    static {
        instance = new ConfigStorageFactory();
    }
    
    public static IConfigLoader getLoader() {
        return getLoader(SmartFoxServer.grid() ? "com.smartfoxserver.grid.config.DistributedConfigLoader" : "com.smartfoxserver.v2.config.DefaultConfigLoader");
    }
    
    private static IConfigLoader getLoader(final String cName) {
        IConfigLoader loader = null;
        try {
            loader = (IConfigLoader)ConfigStorageFactory.instance.loadClass(cName);
        }
        catch (Exception e) {
            throw new SFSRuntimeException(e);
        }
        return loader;
    }
    
    public static IConfigSaver getSaver() {
        return getSaver(SmartFoxServer.grid() ? "com.smartfoxserver.grid.config.DistributedConfigSaver" : "com.smartfoxserver.v2.config.DefaultConfigSaver");
    }
    
    private static IConfigSaver getSaver(final String cName) {
        IConfigSaver saver = null;
        try {
            saver = (IConfigSaver)ConfigStorageFactory.instance.loadClass(cName);
        }
        catch (Exception e) {
            throw new SFSRuntimeException(e);
        }
        return saver;
    }
    
    public static Runnable getConfigPostProcessor() {
        if (!SmartFoxServer.grid()) {
            return null;
        }
        try {
            return (Runnable)ConfigStorageFactory.instance.loadClass("com.smartfoxserver.grid.config.GridConfigPostProcessor");
        }
        catch (Exception e) {
            throw new SFSRuntimeException(e);
        }
    }
}

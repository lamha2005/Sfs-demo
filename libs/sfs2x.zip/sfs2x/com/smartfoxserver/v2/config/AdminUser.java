// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import java.util.Arrays;
import java.util.Collection;
import org.apache.commons.lang.StringUtils;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class AdminUser implements Serializable
{
    public volatile String login;
    public volatile String password;
    public volatile boolean allowHalt;
    public List<String> disabledModules;
    
    public AdminUser() {
        this.allowHalt = true;
        this.disabledModules = new ArrayList<String>();
    }
    
    public String getDisabledModulesString() {
        return StringUtils.join((Collection)this.disabledModules, ",");
    }
    
    public void setDisabledModulesString(final Object stringList) {
        final String list = stringList.toString();
        if (list.length() > 0) {
            this.disabledModules = Arrays.asList(list.toString().split("\\,"));
        }
        else {
            this.disabledModules.clear();
        }
    }
}

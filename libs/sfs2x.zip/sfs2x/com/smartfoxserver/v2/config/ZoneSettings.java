// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import java.util.Collection;
import org.apache.commons.lang.StringUtils;
import java.util.Collections;
import com.smartfoxserver.v2.controllers.SystemRequest;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.Iterator;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import com.smartfoxserver.v2.db.DBConfig;
import java.util.List;
import java.io.Serializable;

public class ZoneSettings implements Serializable
{
    private static final long serialVersionUID = 1670527616055373677L;
    public String name;
    public boolean isCustomLogin;
    public boolean isForceLogout;
    public boolean isFilterUserNames;
    public boolean isFilterRoomNames;
    public boolean isFilterPrivateMessages;
    public boolean isFilterBuddyMessages;
    public boolean isEncrypted;
    public int maxUsers;
    public int maxUserVariablesAllowed;
    public int maxRoomVariablesAllowed;
    public int minRoomNameChars;
    public int maxRoomNameChars;
    public int maxRooms;
    public int maxRoomsCreatedPerUser;
    public int userCountChangeUpdateInterval;
    public int userReconnectionSeconds;
    public int overrideMaxUserIdleTime;
    public int maxFailedLogins;
    public boolean allowGuestUsers;
    public String guestUserNamePrefix;
    public String publicRoomGroups;
    public String defaultRoomGroups;
    public String defaultPlayerIdGeneratorClass;
    public boolean allowInvitationsOnlyForBuddies;
    public int maxUsersPerJoinInvitationRequest;
    public boolean geoLocationEnabled;
    public WordFilterSettings wordsFilter;
    public FloodFilterSettings floodFilter;
    public List<RoomSettings> rooms;
    public List<String> disabledSystemEvents;
    public PrivilegeManagerSettings privilegeManager;
    public ExtensionSettings extension;
    public BuddyListSettings buddyList;
    public DBConfig databaseManager;
    public boolean allowUploads;
    public static final String DENIABLE_REQUESTS = "JoinRoom,CreateRoom,ChangeRoomName,ChangeRoomPassword,ObjectMessage,SetRoomVariables,SetUserVariables,LeaveRoom,SubscribeRoomGroup,UnsubscribeRoomGroup,SpectatorToPlayer,PlayerToSpectator,ChangeRoomCapacity,PublicMessage,PrivateMessage,FindRooms,FindUsers,InitBuddyList,AddBuddy,BlockBuddy,RemoveBuddy,SetBuddyVariables,GoOnline,BuddyMessage,InviteUser,InvitationReply,CreateSFSGame,QuickJoinGame";
    public static final String DB_EXHAUSTED_POOL_MODES;
    private static final transient AtomicInteger idGenerator;
    private transient Integer id;
    
    static {
        DB_EXHAUSTED_POOL_MODES = String.format("%s,%s,%s", "BLOCK", "FAIL", "GROW");
        idGenerator = new AtomicInteger(0);
    }
    
    public ZoneSettings() {
        this.name = "";
        this.isCustomLogin = false;
        this.isForceLogout = true;
        this.isFilterUserNames = true;
        this.isFilterRoomNames = true;
        this.isFilterPrivateMessages = true;
        this.isFilterBuddyMessages = true;
        this.isEncrypted = false;
        this.maxUsers = 1000;
        this.maxUserVariablesAllowed = 5;
        this.maxRoomVariablesAllowed = 5;
        this.minRoomNameChars = 3;
        this.maxRoomNameChars = 10;
        this.maxRooms = 500;
        this.maxRoomsCreatedPerUser = 3;
        this.userCountChangeUpdateInterval = 1000;
        this.userReconnectionSeconds = 0;
        this.overrideMaxUserIdleTime = 120;
        this.maxFailedLogins = 4;
        this.allowGuestUsers = true;
        this.guestUserNamePrefix = "Guest#";
        this.publicRoomGroups = "default";
        this.defaultRoomGroups = "default";
        this.defaultPlayerIdGeneratorClass = "";
        this.allowInvitationsOnlyForBuddies = false;
        this.maxUsersPerJoinInvitationRequest = 5;
        this.geoLocationEnabled = false;
        this.allowUploads = false;
        this.initId();
    }
    
    public int getId() {
        return this.id;
    }
    
    protected synchronized void initId() {
        this.id = ZoneSettings.idGenerator.getAndIncrement();
    }
    
    public ZoneSettings(final String name) {
        this();
        this.name = name;
        this.wordsFilter = new WordFilterSettings();
        this.floodFilter = new FloodFilterSettings();
        this.rooms = new ArrayList<RoomSettings>();
        this.disabledSystemEvents = new ArrayList<String>();
        this.buddyList = new BuddyListSettings();
        this.privilegeManager = new PrivilegeManagerSettings();
        this.privilegeManager.profiles = new ArrayList<PermissionProfile>();
        this.setupDefaultPrivileges();
        this.extension = new ExtensionSettings();
        this.databaseManager = new DBConfig();
    }
    
    private void setupDefaultPrivileges() {
        final PermissionProfile guestProfile = new PermissionProfile();
        guestProfile.id = 0;
        guestProfile.name = "Guest";
        guestProfile.permissionFlags = new ArrayList<String>();
        guestProfile.deniedRequests = Arrays.asList("CreateRoom", "PrivateMessage", "SetRoomVariables", "SetUserVariables", "ChangeRoomName", "ChangeRoomPassword", "ChangeRoomCapacity", "InitBuddyList", "AddBuddy", "BlockBuddy", "RemoveBuddy", "SetBuddyVariables", "GoOnline", "BuddyMessage", "ModeratorMessage", "AdminMessage", "KickUser", "BanUser");
        final PermissionProfile regularProfile = new PermissionProfile();
        regularProfile.id = 1;
        regularProfile.name = "Standard";
        regularProfile.permissionFlags = new ArrayList<String>();
        regularProfile.deniedRequests = Arrays.asList("ModeratorMessage", "AdminMessage", "KickUser", "BanUser");
        regularProfile.permissionFlags = Arrays.asList("ExtensionCalls");
        final PermissionProfile modProfile = new PermissionProfile();
        modProfile.id = 2;
        modProfile.name = "Moderator";
        modProfile.deniedRequests = Arrays.asList("AdminMessage");
        modProfile.permissionFlags = Arrays.asList("ExtensionCalls", "SuperUser");
        final PermissionProfile adminProfile = new PermissionProfile();
        adminProfile.id = 3;
        adminProfile.name = "Administrator";
        adminProfile.deniedRequests = new ArrayList<String>();
        adminProfile.permissionFlags = Arrays.asList("ExtensionCalls", "SuperUser");
        this.privilegeManager.profiles = Arrays.asList(guestProfile, regularProfile, modProfile, adminProfile);
    }
    
    public String getDeniableRequests() {
        return "JoinRoom,CreateRoom,ChangeRoomName,ChangeRoomPassword,ObjectMessage,SetRoomVariables,SetUserVariables,LeaveRoom,SubscribeRoomGroup,UnsubscribeRoomGroup,SpectatorToPlayer,PlayerToSpectator,ChangeRoomCapacity,PublicMessage,PrivateMessage,FindRooms,FindUsers,InitBuddyList,AddBuddy,BlockBuddy,RemoveBuddy,SetBuddyVariables,GoOnline,BuddyMessage,InviteUser,InvitationReply,CreateSFSGame,QuickJoinGame";
    }
    
    public synchronized RoomSettings getRoomSettings(final int id) {
        if (this.rooms == null) {
            throw new IllegalStateException("No Room configuration has been loaded yet!");
        }
        RoomSettings settings = null;
        for (final RoomSettings item : this.rooms) {
            if (item.getId() == id) {
                settings = item;
                break;
            }
        }
        return settings;
    }
    
    public synchronized RoomSettings getRoomSettings(final String name) {
        if (this.rooms == null) {
            throw new IllegalStateException("No Room configuration has been loaded yet!");
        }
        RoomSettings settings = null;
        for (final RoomSettings item : this.rooms) {
            if (item.name.equals(name)) {
                settings = item;
                break;
            }
        }
        return settings;
    }
    
    public synchronized void addRoomSettings(final RoomSettings settings) {
        if (this.getRoomSettings(settings.name) != null) {
            throw new IllegalArgumentException("A room with the same name already exists: " + settings.name);
        }
        this.rooms.add(settings);
    }
    
    public synchronized void removeRoomSetting(final RoomSettings settings) {
        this.rooms.remove(settings);
    }
    
    public ISFSObject toSFSObject() {
        final ISFSObject sfsObj = SFSObject.newInstance();
        return sfsObj;
    }
    
    public static ZoneSettings fromSFSObject(final ISFSObject sfsObj) {
        final ZoneSettings settings = new ZoneSettings();
        return settings;
    }
    
    public static final class WordFilterSettings implements Serializable
    {
        public boolean isActive;
        public boolean useWarnings;
        public int warningsBeforeKick;
        public int kicksBeforeBan;
        public int banDuration;
        public int maxBadWordsPerMessage;
        public int kicksBeforeBanMinutes;
        public int secondsBeforeBanOrKick;
        public String warningMessage;
        public String kickMessage;
        public String banMessage;
        public String wordsFile;
        public String filterMode;
        public String banMode;
        public String hideBadWordWithCharacter;
        public String customWordFilterClass;
        public String wordsListText;
        
        public WordFilterSettings() {
            this.isActive = false;
            this.useWarnings = false;
            this.warningsBeforeKick = 3;
            this.kicksBeforeBan = 2;
            this.banDuration = 1440;
            this.maxBadWordsPerMessage = 0;
            this.kicksBeforeBanMinutes = 3;
            this.secondsBeforeBanOrKick = 5;
            this.warningMessage = "Stop swearing or you will be banned";
            this.kickMessage = "Swearing not allowed: you are being kicked";
            this.banMessage = "Too much swearing: you are banned";
            this.wordsFile = "config/wordsFile.txt";
            this.filterMode = "BLACKLIST";
            this.banMode = "NAME";
            this.hideBadWordWithCharacter = "*";
            this.customWordFilterClass = null;
        }
    }
    
    public static final class FloodFilterSettings implements Serializable
    {
        private static String REQUEST_LIST;
        public boolean isActive;
        public int banDurationMinutes;
        public int maxFloodingAttempts;
        public int secondsBeforeBan;
        public String banMode;
        public boolean logFloodingAttempts;
        public String banMessage;
        public List<RequestFilterSettings> requestFilters;
        
        static {
            FloodFilterSettings.REQUEST_LIST = null;
        }
        
        public FloodFilterSettings() {
            this.isActive = false;
            this.banDurationMinutes = 1440;
            this.maxFloodingAttempts = 5;
            this.secondsBeforeBan = 5;
            this.banMode = "NAME";
            this.logFloodingAttempts = true;
            this.banMessage = "Too much flooding, you are banned";
        }
        
        public String getRequestsList() {
            if (FloodFilterSettings.REQUEST_LIST == null) {
                this.createRequestList();
            }
            return FloodFilterSettings.REQUEST_LIST;
        }
        
        private void createRequestList() {
            final List<String> names = new ArrayList<String>();
            SystemRequest[] values;
            for (int length = (values = SystemRequest.values()).length, i = 0; i < length; ++i) {
                final SystemRequest item = values[i];
                final Short reqId = (Short)item.getId();
                if (reqId >= 3 && reqId < 1000 && reqId != 13) {
                    names.add(item.toString());
                }
            }
            Collections.sort(names);
            FloodFilterSettings.REQUEST_LIST = "";
            for (final String name : names) {
                FloodFilterSettings.REQUEST_LIST = String.valueOf(FloodFilterSettings.REQUEST_LIST) + name + ",";
            }
            FloodFilterSettings.REQUEST_LIST = FloodFilterSettings.REQUEST_LIST.substring(0, FloodFilterSettings.REQUEST_LIST.length() - 1);
        }
    }
    
    public static final class RequestFilterSettings implements Serializable
    {
        public String reqName;
        public int maxRequestsPerSecond;
    }
    
    public static final class RoomEventsSettings implements Serializable
    {
        public boolean isClientOverrideAllowed;
        public String registeredEvents;
        
        public RoomEventsSettings() {
            this.isClientOverrideAllowed = true;
            this.registeredEvents = "ROOM_NAME_CHANGE,PASSWORD_STATE_CHANGE,USER_COUNT_CHANGE,ROOM_VARIABLES_UPDATE";
        }
    }
    
    public static final class RegisteredRoomEvents implements Serializable
    {
        public String groupId;
        public boolean roomNameChange;
        public boolean roomCapacityChange;
        public boolean userCountChange;
        public boolean roomVariablesUpdate;
        public boolean passwordStatusChange;
        
        public RegisteredRoomEvents() {
            this.groupId = "";
            this.roomNameChange = false;
            this.roomCapacityChange = false;
            this.userCountChange = true;
            this.roomVariablesUpdate = true;
            this.passwordStatusChange = false;
        }
    }
    
    public static final class RoomSettings implements Serializable
    {
        public static final String EVENTS = "USER_ENTER_EVENT,USER_EXIT_EVENT,USER_COUNT_CHANGE_EVENT,USER_VARIABLES_UPDATE_EVENT";
        private static final AtomicInteger idGenerator;
        private transient Integer id;
        public String name;
        public String groupId;
        public String password;
        public int maxUsers;
        public int maxSpectators;
        public boolean isDynamic;
        public boolean isGame;
        public boolean isHidden;
        public String autoRemoveMode;
        public RoomPermissions permissions;
        public String events;
        public BadWordsFilterSettings badWordsFilter;
        public List<RoomVariableDefinition> roomVariables;
        public ExtensionSettings extension;
        public MMOSettings mmoSettings;
        public boolean allowOwnerInvitation;
        
        static {
            idGenerator = new AtomicInteger();
        }
        
        public RoomSettings() {
            this.name = null;
            this.groupId = "default";
            this.password = null;
            this.maxUsers = 20;
            this.maxSpectators = 0;
            this.isDynamic = false;
            this.isGame = false;
            this.isHidden = false;
            this.autoRemoveMode = "DEFAULT";
            this.permissions = new RoomPermissions();
            this.events = "USER_ENTER_EVENT,USER_EXIT_EVENT,USER_COUNT_CHANGE_EVENT,USER_VARIABLES_UPDATE_EVENT";
            this.badWordsFilter = new BadWordsFilterSettings();
            this.mmoSettings = new MMOSettings();
            this.allowOwnerInvitation = true;
            this.getId();
        }
        
        public RoomSettings(final String name) {
            this();
            this.name = name;
            this.password = "";
            this.roomVariables = new ArrayList<RoomVariableDefinition>();
            this.extension = new ExtensionSettings();
        }
        
        public int getId() {
            if (this.id == null) {
                this.id = getUniqueId();
            }
            return this.id;
        }
        
        private static int getUniqueId() {
            return RoomSettings.idGenerator.getAndIncrement();
        }
        
        public String getAvailableEvents() {
            return "USER_ENTER_EVENT,USER_EXIT_EVENT,USER_COUNT_CHANGE_EVENT,USER_VARIABLES_UPDATE_EVENT";
        }
    }
    
    public static final class MMOSettings implements Serializable
    {
        public boolean isActive;
        public String defaultAOI;
        public String lowerMapLimit;
        public String higherMapLimit;
        public boolean forceFloats;
        public int userMaxLimboSeconds;
        public int proximityListUpdateMillis;
        public boolean sendAOIEntryPoint;
        
        public MMOSettings() {
            this.isActive = false;
            this.defaultAOI = "100,100,0";
            this.lowerMapLimit = "";
            this.higherMapLimit = "";
            this.forceFloats = false;
            this.userMaxLimboSeconds = 50;
            this.proximityListUpdateMillis = 500;
            this.sendAOIEntryPoint = true;
        }
    }
    
    public static final class RoomPermissions implements Serializable
    {
        public static final String FLAGS = "ROOM_NAME_CHANGE,PASSWORD_STATE_CHANGE,PUBLIC_MESSAGES,CAPACITY_CHANGE";
        public String flags;
        public int maxRoomVariablesAllowed;
        
        public RoomPermissions() {
            this.flags = "PASSWORD_STATE_CHANGE,PUBLIC_MESSAGES";
            this.maxRoomVariablesAllowed = 10;
        }
        
        public String getAvailableFlags() {
            return "ROOM_NAME_CHANGE,PASSWORD_STATE_CHANGE,PUBLIC_MESSAGES,CAPACITY_CHANGE";
        }
    }
    
    public static final class BadWordsFilterSettings implements Serializable
    {
        public boolean isActive;
        
        public BadWordsFilterSettings() {
            this.isActive = false;
        }
    }
    
    public static final class RoomVariableDefinition implements Serializable
    {
        public String name;
        public String value;
        public String type;
        public boolean isPrivate;
        public boolean isPersistent;
        public boolean isGlobal;
        public boolean isHidden;
        
        public RoomVariableDefinition() {
            this.name = "";
            this.value = "";
            this.type = "";
            this.isPrivate = false;
            this.isPersistent = false;
            this.isGlobal = false;
            this.isHidden = false;
        }
    }
    
    public static final class PrivilegeManagerSettings implements Serializable
    {
        public boolean active;
        public List<PermissionProfile> profiles;
        
        public PrivilegeManagerSettings() {
            this.active = false;
        }
    }
    
    public static final class PermissionProfile implements Serializable
    {
        public short id;
        public String name;
        public List<String> deniedRequests;
        public List<String> permissionFlags;
        
        public PermissionProfile() {
            this.id = -1;
            this.name = "";
        }
        
        public String getDeniedRequestsString() {
            return StringUtils.join((Collection)this.deniedRequests, ",");
        }
        
        public void setDeniedRequestsString(final Object stringList) {
            final String list = stringList.toString();
            if (list.length() > 0) {
                this.deniedRequests = Arrays.asList(list.toString().split("\\,"));
            }
            else {
                this.deniedRequests = new ArrayList<String>();
            }
        }
        
        public String getPermissionFlagsString() {
            return StringUtils.join((Collection)this.permissionFlags, ",");
        }
        
        public void setPermissionFlagsString(final Object stringList) {
            final String list = stringList.toString();
            if (list.length() > 0) {
                this.permissionFlags = Arrays.asList(list.split("\\,"));
            }
            else {
                this.permissionFlags = new ArrayList<String>();
            }
        }
        
        public int getIntId() {
            return this.id;
        }
        
        public void setIntId(final Object id) {
            this.id = (short)id;
        }
    }
    
    public static final class ExtensionSettings implements Serializable
    {
        public String name;
        public String type;
        public String file;
        public String propertiesFile;
        public String reloadMode;
        
        public ExtensionSettings() {
            this.name = "";
            this.type = "JAVA";
            this.file = "";
            this.propertiesFile = "";
            this.reloadMode = "AUTO";
        }
    }
    
    public static final class BuddyListSettings implements Serializable
    {
        public boolean active;
        public boolean allowOfflineBuddyVariables;
        public int maxItemsPerList;
        public int maxBuddyVariables;
        public int offlineBuddyVariablesCacheSize;
        public String customStorageClass;
        public boolean useTempBuddies;
        public List<String> buddyStates;
        public BadWordsFilterSettings badWordsFilter;
        
        public BuddyListSettings() {
            this.active = false;
            this.allowOfflineBuddyVariables = true;
            this.maxItemsPerList = 100;
            this.maxBuddyVariables = 15;
            this.offlineBuddyVariablesCacheSize = 500;
            this.customStorageClass = "";
            this.useTempBuddies = true;
            this.buddyStates = Arrays.asList("Available", "Away", "Occupied");
            this.badWordsFilter = new BadWordsFilterSettings();
        }
    }
}

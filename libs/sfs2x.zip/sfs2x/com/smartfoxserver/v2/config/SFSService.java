// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

public enum SFSService
{
    Configurator("Configurator", 0), 
    ZoneManager("ZoneManager", 1), 
    RoomManager("RoomManager", 2), 
    BannedUserManager("BannedUserManager", 3), 
    BuddyManager("BuddyManager", 4);
    
    private SFSService(final String s, final int n) {
    }
}

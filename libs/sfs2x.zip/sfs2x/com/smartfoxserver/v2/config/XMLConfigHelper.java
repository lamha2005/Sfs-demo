// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import com.smartfoxserver.v2.db.DBConfig;
import com.thoughtworks.xstream.io.HierarchicalStreamDriver;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.XStream;

public final class XMLConfigHelper
{
    public XStream getServerXStreamDefinitions() {
        final XStream xstream = new XStream();
        xstream.alias("serverSettings", (Class)ServerSettings.class);
        xstream.alias("socket", (Class)ServerSettings.SocketAddress.class);
        xstream.useAttributeFor((Class)ServerSettings.SocketAddress.class, "address");
        xstream.useAttributeFor((Class)ServerSettings.SocketAddress.class, "port");
        xstream.useAttributeFor((Class)ServerSettings.SocketAddress.class, "type");
        xstream.alias("ipFilter", (Class)ServerSettings.IpFilterSettings.class);
        xstream.alias("flashCrossdomainPolicy", (Class)ServerSettings.FlashCrossDomainPolicySettings.class);
        xstream.alias("remoteAdmin", (Class)RemoteAdminSettings.class);
        xstream.alias("adminUser", (Class)AdminUser.class);
        xstream.alias("mailer", (Class)MailerSettings.class);
        xstream.alias("webServer", (Class)ServerSettings.WebServerSettings.class);
        xstream.alias("bannedUserManager", (Class)ServerSettings.BannedUserManagerSettings.class);
        xstream.alias("websocketEngine", (Class)ServerSettings.WebSocketEngineSettings.class);
        return xstream;
    }
    
    public XStream getZonesXStreamDefinitions() {
        final XStream xstream = new XStream((HierarchicalStreamDriver)new DomDriver());
        xstream.alias("zone", (Class)ZoneSettings.class);
        xstream.aliasField("applyWordsFilterToUserName", (Class)ZoneSettings.class, "isFilterUserNames");
        xstream.aliasField("applyWordsFilterToRoomName", (Class)ZoneSettings.class, "isFilterRoomNames");
        xstream.aliasField("applyWordsFilterToPrivateMessages", (Class)ZoneSettings.class, "isFilterPrivateMessages");
        xstream.alias("wordsFilter", (Class)ZoneSettings.WordFilterSettings.class);
        xstream.useAttributeFor((Class)ZoneSettings.WordFilterSettings.class, "isActive");
        xstream.aliasAttribute((Class)ZoneSettings.WordFilterSettings.class, "isActive", "active");
        xstream.alias("floodFilter", (Class)ZoneSettings.FloodFilterSettings.class);
        xstream.useAttributeFor((Class)ZoneSettings.FloodFilterSettings.class, "isActive");
        xstream.aliasAttribute((Class)ZoneSettings.FloodFilterSettings.class, "isActive", "active");
        xstream.alias("requestFilter", (Class)ZoneSettings.RequestFilterSettings.class);
        xstream.alias("roomEvents", (Class)ZoneSettings.RoomEventsSettings.class);
        xstream.alias("registerEvent", (Class)ZoneSettings.RegisteredRoomEvents.class);
        xstream.useAttributeFor((Class)ZoneSettings.RegisteredRoomEvents.class, "groupId");
        xstream.alias("extension", (Class)ZoneSettings.ExtensionSettings.class);
        xstream.alias("room", (Class)ZoneSettings.RoomSettings.class);
        xstream.alias("permissions", (Class)ZoneSettings.RoomPermissions.class);
        xstream.alias("MMOSettings", (Class)ZoneSettings.MMOSettings.class);
        xstream.alias("badWordsFilter", (Class)ZoneSettings.BadWordsFilterSettings.class);
        xstream.useAttributeFor((Class)ZoneSettings.BadWordsFilterSettings.class, "isActive");
        xstream.alias("variable", (Class)ZoneSettings.RoomVariableDefinition.class);
        xstream.alias("privilegeManager", (Class)ZoneSettings.PrivilegeManagerSettings.class);
        xstream.useAttributeFor((Class)ZoneSettings.PrivilegeManagerSettings.class, "active");
        xstream.alias("profile", (Class)ZoneSettings.PermissionProfile.class);
        xstream.useAttributeFor((Class)ZoneSettings.PermissionProfile.class, "id");
        xstream.alias("buddyList", (Class)ZoneSettings.BuddyListSettings.class);
        xstream.useAttributeFor((Class)ZoneSettings.BuddyListSettings.class, "active");
        xstream.alias("databaseManager", (Class)DBConfig.class);
        xstream.useAttributeFor((Class)DBConfig.class, "active");
        return xstream;
    }
    
    public String getServerConfigFileName() {
        return "config/server.xml";
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import java.io.Serializable;

public class MailerSettings implements Serializable
{
    public volatile boolean isActive;
    public volatile String mailHost;
    public volatile String mailUser;
    public volatile String mailPass;
    public volatile int smtpPort;
    public volatile int workerThreads;
    
    public MailerSettings() {
        this.isActive = true;
        this.mailHost = "";
        this.mailUser = "";
        this.mailPass = "";
        this.smtpPort = 25;
        this.workerThreads = 1;
    }
}

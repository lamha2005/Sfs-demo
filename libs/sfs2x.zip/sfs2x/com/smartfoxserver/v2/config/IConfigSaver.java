// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import java.io.IOException;

public interface IConfigSaver
{
    void saveServerSettings(final ServerSettings p0, final boolean p1) throws IOException;
    
    void saveZoneSettings(final ZoneSettings p0, final boolean p1) throws IOException;
    
    void saveZoneSettings(final ZoneSettings p0, final boolean p1, final String p2) throws IOException;
    
    boolean removeZoneSetting(final ZoneSettings p0) throws IOException;
}

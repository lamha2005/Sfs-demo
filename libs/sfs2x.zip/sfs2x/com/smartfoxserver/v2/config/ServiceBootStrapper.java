// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import com.smartfoxserver.v2.exceptions.SFSBootException;
import java.util.HashMap;
import java.util.Map;
import com.smartfoxserver.v2.core.ObjectFactory;

public final class ServiceBootStrapper extends ObjectFactory
{
    private static final ServiceBootStrapper _instance;
    private final Map<SFSService, String> servicesByKey;
    
    static {
        _instance = new ServiceBootStrapper();
    }
    
    public static ServiceBootStrapper getInstance() {
        return ServiceBootStrapper._instance;
    }
    
    private ServiceBootStrapper() {
        this.servicesByKey = new HashMap<SFSService, String>();
        this.populateDefaults();
    }
    
    public void addService(final SFSService serviceKey, final String className) {
        this.servicesByKey.put(serviceKey, className);
    }
    
    public Object load(final SFSService serviceKey) throws SFSBootException {
        final String className = this.servicesByKey.get(serviceKey);
        Object service = null;
        if (className == null) {
            throw new SFSBootException("No service definition found for: " + serviceKey + ". Service not found");
        }
        try {
            service = this.loadClass(className);
        }
        catch (Exception e) {
            throw new SFSBootException(String.format("Error while bootstrapping service: %s, %s. Cause: %s", serviceKey, className, e.toString()));
        }
        return service;
    }
    
    private void populateDefaults() {
        this.servicesByKey.put(SFSService.BannedUserManager, "com.smartfoxserver.v2.entities.managers.SFSBannedUserManager");
        this.servicesByKey.put(SFSService.ZoneManager, "com.smartfoxserver.v2.entities.managers.SFSZoneManager");
        this.servicesByKey.put(SFSService.RoomManager, "com.smartfoxserver.v2.entities.managers.SFSRoomManager");
        this.servicesByKey.put(SFSService.BuddyManager, "com.smartfoxserver.v2.buddylist.SFSBuddyListManager");
        this.servicesByKey.put(SFSService.Configurator, "com.smartfoxserver.v2.config.SFSConfigurator");
    }
}

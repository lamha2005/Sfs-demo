// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.List;
import java.io.IOException;

public interface IConfigLoader
{
    CoreSettings loadCoreSettings() throws IOException;
    
    ServerSettings loadServerSettings() throws IOException;
    
    List<ZoneSettings> loadZonesConfiguration() throws SFSException;
}

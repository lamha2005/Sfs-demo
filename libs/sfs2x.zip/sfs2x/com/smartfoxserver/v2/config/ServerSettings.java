// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import java.util.Collection;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.io.File;
import com.smartfoxserver.v2.exceptions.ExceptionMessageComposer;
import java.util.Iterator;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.ArrayList;
import org.slf4j.LoggerFactory;
import com.smartfoxserver.v2.util.executor.SmartExecutorConfig;
import java.util.List;
import com.smartfoxserver.v2.util.IAdminHelper;
import org.slf4j.Logger;
import java.io.Serializable;

public class ServerSettings implements Serializable
{
    private static final long serialVersionUID = 2784901283989933331L;
    private static final Logger log;
    public transient IAdminHelper adminHelper;
    public volatile List<SocketAddress> socketAddresses;
    public volatile IpFilterSettings ipFilter;
    public volatile FlashCrossDomainPolicySettings flashCrossdomainPolicy;
    public volatile int systemControllerRequestQueueSize;
    public volatile int extensionControllerRequestQueueSize;
    public volatile int schedulerThreadPoolSize;
    public volatile int protocolCompressionThreshold;
    public String protocolMode;
    public boolean useBinaryProtocol;
    public RemoteAdminSettings remoteAdmin;
    public BannedUserManagerSettings bannedUserManager;
    public MailerSettings mailer;
    public WebServerSettings webServer;
    public WebSocketEngineSettings webSocket;
    public volatile boolean startExtensionFileMonitor;
    public volatile boolean useDebugMode;
    public volatile boolean extensionRemoteDebug;
    public volatile boolean useFriendlyExceptions;
    public int sessionMaxIdleTime;
    public int userMaxIdleTime;
    public String licenseCode;
    public String licenseEmails;
    public volatile boolean maxCcuAlert;
    public volatile boolean ghostHunterEnabled;
    public volatile boolean statsExtraLoggingEnabled;
    public volatile boolean enableSmasherController;
    public AnalyticsSettings analytics;
    public SmartExecutorConfig systemThreadPoolSettings;
    public SmartExecutorConfig extensionThreadPoolSettings;
    public String serverName;
    public ClientBlueBoxSettings clientBlueBoxSettings;
    
    static {
        log = LoggerFactory.getLogger((Class)ServerSettings.class);
    }
    
    public ServerSettings() {
        this.socketAddresses = new ArrayList<SocketAddress>();
        this.ipFilter = new IpFilterSettings();
        this.flashCrossdomainPolicy = new FlashCrossDomainPolicySettings();
        this.systemControllerRequestQueueSize = 10000;
        this.extensionControllerRequestQueueSize = 10000;
        this.schedulerThreadPoolSize = 1;
        this.protocolCompressionThreshold = 300;
        this.useBinaryProtocol = true;
        this.remoteAdmin = new RemoteAdminSettings();
        this.bannedUserManager = new BannedUserManagerSettings();
        this.mailer = new MailerSettings();
        this.webServer = new WebServerSettings();
        this.webSocket = new WebSocketEngineSettings();
        this.startExtensionFileMonitor = false;
        this.useDebugMode = false;
        this.extensionRemoteDebug = true;
        this.useFriendlyExceptions = true;
        this.licenseCode = "";
        this.licenseEmails = "";
        this.maxCcuAlert = false;
        this.ghostHunterEnabled = true;
        this.statsExtraLoggingEnabled = true;
        this.enableSmasherController = true;
        this.analytics = new AnalyticsSettings();
        this.systemThreadPoolSettings = new SmartExecutorConfig();
        this.extensionThreadPoolSettings = new SmartExecutorConfig();
        this.serverName = "";
        this.clientBlueBoxSettings = new ClientBlueBoxSettings();
    }
    
    public ISFSObject toSFSObject() {
        final ISFSObject sfsObj = SFSObject.newInstance();
        return sfsObj;
    }
    
    public static ServerSettings fromSFSObject(final ISFSObject sfsObj) {
        final ServerSettings settings = new ServerSettings();
        return settings;
    }
    
    public static final class SocketAddress implements Serializable
    {
        public static final String TYPE_UDP = "UDP";
        public static final String TYPE_TCP = "TCP";
        public volatile String address;
        public volatile int port;
        public volatile String type;
        
        public SocketAddress() {
            this.address = "127.0.0.1";
            this.port = 9339;
            this.type = "TCP";
        }
    }
    
    public static final class IpFilterSettings implements Serializable
    {
        public List<String> addressBlackList;
        public List<String> addressWhiteList;
        public volatile int maxConnectionsPerAddress;
        
        public IpFilterSettings() {
            this.addressBlackList = new ArrayList<String>();
            this.addressWhiteList = new ArrayList<String>();
            this.maxConnectionsPerAddress = 5;
        }
    }
    
    public static final class FlashCrossDomainPolicySettings implements Serializable
    {
        public volatile boolean useMasterSocketPolicy;
        public volatile String policyXmlFile;
        
        public FlashCrossDomainPolicySettings() {
            this.useMasterSocketPolicy = false;
            this.policyXmlFile = "crossdomain.xml";
        }
    }
    
    public static final class WebServerSettings implements Serializable
    {
        private static final String JETTY_HTTP_CONFIG = "lib/jetty/start.d/http.ini";
        private static final String JETTY_HTTPS_CONFIG = "lib/jetty/start.d/ssl.ini";
        private static final String JETTY_HTTP_MODULE = "--module=http";
        private static final String JETTY_HTTPS_MODULE = "--module=ssl";
        private static final String JETTY_HTTP_PORT_SETTING = "jetty.http.port";
        private static final String JETTY_HTTPS_PORT_SETTING = "jetty.ssl.port";
        public volatile boolean isActive;
        public volatile int blueBoxPollingTimeout;
        public volatile int blueBoxMsgQueueSize;
        public volatile int gHttpPort;
        public volatile int gHttpsPort;
        
        public WebServerSettings() {
            this.isActive = true;
            this.blueBoxPollingTimeout = 26;
            this.blueBoxMsgQueueSize = 40;
            this.gHttpPort = 8080;
            this.gHttpsPort = 8443;
        }
        
        public boolean getEnableHttp() {
            return this.getModuleEnabled("lib/jetty/start.d/http.ini", "--module=http");
        }
        
        public void setEnableHttp(final boolean value) {
            this.setModuleEnabled("lib/jetty/start.d/http.ini", "--module=http", value);
        }
        
        public int getHttpPort() {
            return this.getPortValue("lib/jetty/start.d/http.ini", "jetty.http.port");
        }
        
        public void setHttpPort(final int value) {
            this.setPortValue("lib/jetty/start.d/http.ini", "jetty.http.port", value);
        }
        
        public boolean getEnableHttps() {
            return this.getModuleEnabled("lib/jetty/start.d/ssl.ini", "--module=ssl");
        }
        
        public void setEnableHttps(final boolean value) {
            this.setModuleEnabled("lib/jetty/start.d/ssl.ini", "--module=ssl", value);
        }
        
        public int getHttpsPort() {
            return this.getPortValue("lib/jetty/start.d/ssl.ini", "jetty.ssl.port");
        }
        
        public void setHttpsPort(final int value) {
            this.setPortValue("lib/jetty/start.d/ssl.ini", "jetty.ssl.port", value);
        }
        
        private boolean getModuleEnabled(final String filename, final String module) {
            final List<String> lines = this.readFileLines(filename);
            for (final String line : lines) {
                if (line.replaceAll("\\p{Z}", "").equalsIgnoreCase(module)) {
                    return true;
                }
            }
            return false;
        }
        
        private void setModuleEnabled(final String filename, final String module, final boolean enable) {
            final List<String> lines = this.readFileLines(filename);
            for (int i = 0; i < lines.size(); ++i) {
                final String line = lines.get(i);
                if (line.replaceAll("\\p{Z}", "").toLowerCase().contains(module)) {
                    lines.set(i, String.valueOf(enable ? "" : "#") + module);
                }
            }
            this.writeFileLines(filename, lines);
        }
        
        private int getPortValue(final String filename, final String setting) {
            final List<String> lines = this.readFileLines(filename);
            try {
                for (final String line : lines) {
                    final String compact = line.replaceAll("\\p{Z}", "").toLowerCase();
                    if (compact.startsWith(setting)) {
                        final String valueStr = compact.substring(compact.indexOf("=") + 1);
                        return Integer.parseInt(valueStr);
                    }
                }
                throw new IllegalArgumentException("'" + setting + "' setting can't be located in '" + filename + "' Jetty configuration file");
            }
            catch (Exception e) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
                emc.setDescription("Unable to parse the '" + setting + "' setting in Jetty configuration");
                emc.setPossibleCauses("The setting is missing or its value contains invalid characters (an integer is required)");
                ServerSettings.log.error(emc.toString());
                throw new IllegalStateException(e);
            }
        }
        
        private void setPortValue(final String filename, final String setting, final int value) {
            final List<String> lines = this.readFileLines(filename);
            int index = -1;
            for (int i = 0; i < lines.size(); ++i) {
                final String line = lines.get(i);
                if (line.replaceAll("\\p{Z}", "").toLowerCase().startsWith(setting)) {
                    index = i;
                    break;
                }
            }
            final String newLine = String.valueOf(setting) + "=" + value;
            if (index > -1) {
                lines.set(index, newLine);
            }
            else {
                lines.add(newLine);
            }
            this.writeFileLines(filename, lines);
        }
        
        private synchronized List<String> readFileLines(final String filename) {
            try {
                final File file = new File(filename);
                return (List<String>)FileUtils.readLines(file);
            }
            catch (IOException e) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
                emc.setDescription("Unable to read the Jetty configuration");
                emc.setPossibleCauses("The file was deleted or it is locked by another application/process");
                ServerSettings.log.error(emc.toString());
                throw new IllegalStateException(e);
            }
        }
        
        private synchronized void writeFileLines(final String filename, final List<String> lines) {
            try {
                final File file = new File(filename);
                FileUtils.writeLines(file, (Collection)lines);
            }
            catch (IOException e) {
                final ExceptionMessageComposer emc = new ExceptionMessageComposer(e);
                emc.setDescription("Unable to write the Jetty configuration");
                emc.setPossibleCauses("The file is locked by another application/process");
                ServerSettings.log.error(emc.toString());
                throw new IllegalStateException(e);
            }
        }
    }
    
    public static final class BannedUserManagerSettings implements Serializable
    {
        public boolean isAutoRemove;
        public boolean isPersistent;
        public String customPersistenceClass;
        
        public BannedUserManagerSettings() {
            this.isAutoRemove = true;
            this.isPersistent = true;
            this.customPersistenceClass = null;
        }
    }
    
    public static final class WebSocketEngineSettings implements Serializable
    {
        public boolean isActive;
        public String bindAddress;
        public int tcpPort;
        public int sslPort;
        public List<String> validDomains;
        public boolean isSSL;
        public String keyStoreFile;
        public String keyStorePassword;
        
        public WebSocketEngineSettings() {
            this.isActive = false;
            this.bindAddress = "127.0.0.1";
            this.tcpPort = 8888;
            this.sslPort = 8843;
            this.validDomains = new ArrayList<String>();
            this.isSSL = false;
            this.keyStoreFile = "config/keystore.jks";
            this.keyStorePassword = "password";
        }
    }
    
    public static final class AnalyticsSettings implements Serializable
    {
        public static final String RUN_EVERYDAY = "[everyday]";
        public boolean isActive;
        public String runOnDay;
        public int runAtHour;
        public boolean runOnStartup;
        public boolean rebuildDB;
        public boolean skipGeolocation;
        public String sourceFolder;
        public String locale;
        
        public AnalyticsSettings() {
            this.isActive = false;
            this.runOnDay = "[everyday]";
            this.runAtHour = 2;
            this.runOnStartup = false;
            this.rebuildDB = false;
            this.skipGeolocation = false;
            this.sourceFolder = "";
            this.locale = "";
        }
    }
    
    public static final class ClientBlueBoxSettings implements Serializable
    {
        public boolean useBlueBox;
        public int blueBoxPollingRate;
        
        public ClientBlueBoxSettings() {
            this.useBlueBox = true;
            this.blueBoxPollingRate = 700;
        }
    }
}

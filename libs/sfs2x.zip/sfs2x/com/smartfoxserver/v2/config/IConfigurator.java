// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import java.io.IOException;
import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.List;

public interface IConfigurator
{
    void loadConfiguration() throws Exception;
    
    List<ZoneSettings> loadZonesConfiguration() throws SFSException;
    
    void saveServerSettings(final boolean p0) throws IOException;
    
    void saveZoneSettings(final ZoneSettings p0, final boolean p1) throws IOException;
    
    void saveZoneSettings(final ZoneSettings p0, final boolean p1, final String p2) throws IOException;
    
    CoreSettings getCoreSettings();
    
    ServerSettings getServerSettings();
    
    List<ZoneSettings> getZoneSettings();
    
    ZoneSettings getZoneSetting(final String p0);
    
    ZoneSettings getZoneSetting(final int p0);
    
    void saveNewZoneSettings(final ZoneSettings p0) throws IOException;
    
    void removeZoneSetting(final String p0) throws IOException;
}

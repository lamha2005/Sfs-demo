// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.Iterator;
import java.io.IOException;
import java.util.List;

public final class SFSConfigurator implements IConfigurator
{
    private volatile CoreSettings coreSettings;
    private volatile ServerSettings serverSettings;
    private volatile List<ZoneSettings> zonesSettings;
    private IConfigLoader cLoader;
    private IConfigSaver cSaver;
    private Runnable cPostProcessor;
    
    public SFSConfigurator() {
        this.initalizeConfigurator();
    }
    
    private void initalizeConfigurator() {
        this.cLoader = ConfigStorageFactory.getLoader();
        this.cSaver = ConfigStorageFactory.getSaver();
        this.cPostProcessor = ConfigStorageFactory.getConfigPostProcessor();
    }
    
    @Override
    public void loadConfiguration() throws IOException {
        this.coreSettings = this.cLoader.loadCoreSettings();
        this.serverSettings = this.cLoader.loadServerSettings();
        if (this.serverSettings.webSocket == null) {
            this.serverSettings.webSocket = new ServerSettings.WebSocketEngineSettings();
        }
        if (this.cPostProcessor != null) {
            this.cPostProcessor.run();
        }
    }
    
    @Override
    public CoreSettings getCoreSettings() {
        return this.coreSettings;
    }
    
    @Override
    public synchronized ServerSettings getServerSettings() {
        return this.serverSettings;
    }
    
    @Override
    public synchronized List<ZoneSettings> getZoneSettings() {
        return this.zonesSettings;
    }
    
    @Override
    public synchronized ZoneSettings getZoneSetting(final String zoneName) {
        if (this.zonesSettings == null) {
            throw new IllegalStateException("No Zone configuration has been loaded yet!");
        }
        ZoneSettings settings = null;
        for (final ZoneSettings item : this.zonesSettings) {
            if (item.name.equals(zoneName)) {
                settings = item;
                break;
            }
        }
        return settings;
    }
    
    @Override
    public synchronized ZoneSettings getZoneSetting(final int id) {
        if (this.zonesSettings == null) {
            throw new IllegalStateException("No Zone configuration has been loaded yet!");
        }
        ZoneSettings settings = null;
        for (final ZoneSettings item : this.zonesSettings) {
            if (item.getId() == id) {
                settings = item;
                break;
            }
        }
        return settings;
    }
    
    @Override
    public synchronized void removeZoneSetting(final String name) throws IOException {
        final ZoneSettings settings = this.getZoneSetting(name);
        final boolean ok = this.cSaver.removeZoneSetting(settings);
        if (ok) {
            this.zonesSettings.remove(settings);
        }
    }
    
    @Override
    public synchronized List<ZoneSettings> loadZonesConfiguration() throws SFSException {
        return this.zonesSettings = this.cLoader.loadZonesConfiguration();
    }
    
    @Override
    public synchronized void saveServerSettings(final boolean makeBackup) throws IOException {
        this.cSaver.saveServerSettings(this.serverSettings, makeBackup);
    }
    
    @Override
    public synchronized void saveZoneSettings(final ZoneSettings settings, final boolean makeBackup) throws IOException {
        this.cSaver.saveZoneSettings(settings, makeBackup);
    }
    
    @Override
    public synchronized void saveZoneSettings(final ZoneSettings zoneSettings, final boolean makeBackup, final String oldZoneName) throws IOException {
        this.cSaver.saveZoneSettings(zoneSettings, makeBackup, oldZoneName);
    }
    
    @Override
    public synchronized void saveNewZoneSettings(final ZoneSettings settings) throws IOException {
        if (this.getZoneSetting(settings.name) != null) {
            throw new IllegalArgumentException("Save request failed. The new Zone name is already in use: " + settings.name);
        }
        this.saveZoneSettings(settings, false);
        this.zonesSettings.add(settings);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

public final class CoreSettings
{
    public String systemControllerClass;
    public String extensionControllerClass;
    public String ioHandlerClass;
    public String sessionManagerClass;
    public String packetQueuePolicyClass;
    public String readBufferType;
    public String writeBufferType;
    public int maxIncomingRequestSize;
    public int maxReadBufferSize;
    public int maxWriteBufferSize;
    public int socketAcceptorThreadPoolSize;
    public int socketReaderThreadPoolSize;
    public int socketWriterThreadPoolSize;
    public int sessionPacketQueueSize;
    public boolean tcpNoDelay;
    public boolean packetDebug;
    public boolean lagDebug;
    public int bbMaxLogFiles;
    public int bbMaxLogFileSize;
    public boolean bbDebugMode;
    
    public CoreSettings() {
        this.systemControllerClass = "com.smartfoxserver.v2.controllers.v290.SystemReqController";
        this.extensionControllerClass = "com.smartfoxserver.v2.controllers.v290.ExtensionReqController";
        this.ioHandlerClass = "com.smartfoxserver.v2.protocol.SFSIoHandler";
        this.sessionManagerClass = "com.smartfoxserver.bitswarm.sessions.DefaultSessionManager";
        this.packetQueuePolicyClass = "com.smartfoxserver.bitswarm.sessions.DefaultPacketQueuePolicy";
        this.readBufferType = "HEAP";
        this.writeBufferType = "HEAP";
        this.maxIncomingRequestSize = 4096;
        this.maxReadBufferSize = 1024;
        this.maxWriteBufferSize = 32768;
        this.socketAcceptorThreadPoolSize = 1;
        this.socketReaderThreadPoolSize = 1;
        this.socketWriterThreadPoolSize = 1;
        this.sessionPacketQueueSize = 120;
        this.tcpNoDelay = false;
        this.packetDebug = false;
        this.lagDebug = false;
        this.bbMaxLogFiles = 10;
        this.bbMaxLogFileSize = 1000000;
        this.bbDebugMode = false;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class RemoteAdminSettings implements Serializable
{
    private static final long serialVersionUID = 6596460789211260984L;
    public List<AdminUser> administrators;
    public List<String> allowedRemoteAddresses;
    public int adminTcpPort;
    public boolean useEncryption;
    
    public RemoteAdminSettings() {
        this.administrators = new ArrayList<AdminUser>();
        this.allowedRemoteAddresses = new ArrayList<String>();
        this.adminTcpPort = 9933;
        this.useEncryption = false;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.config;

public class GlobalSettings
{
    public static boolean FRIENDLY_LOGGING;
    public static boolean DEBUG_MODE;
    
    static {
        GlobalSettings.FRIENDLY_LOGGING = true;
        GlobalSettings.DEBUG_MODE = true;
    }
}

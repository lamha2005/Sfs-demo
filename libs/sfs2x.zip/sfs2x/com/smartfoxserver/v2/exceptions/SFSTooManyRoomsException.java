// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSTooManyRoomsException extends SFSException
{
    public SFSTooManyRoomsException(final String message) {
        super(message);
    }
    
    public SFSTooManyRoomsException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

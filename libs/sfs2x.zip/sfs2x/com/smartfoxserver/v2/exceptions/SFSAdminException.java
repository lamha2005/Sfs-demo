// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSAdminException extends SFSException
{
    public SFSAdminException() {
    }
    
    public SFSAdminException(final String message) {
        super(message);
    }
    
    public SFSAdminException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

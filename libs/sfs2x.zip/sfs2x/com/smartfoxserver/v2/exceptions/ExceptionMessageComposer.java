// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

import java.util.Iterator;
import java.util.ArrayList;
import com.smartfoxserver.bitswarm.util.Logging;
import org.python.core.PyException;
import java.util.List;

public class ExceptionMessageComposer
{
    private static final String NEW_LINE;
    public static volatile boolean globalPrintStackTrace;
    public static volatile boolean useExtendedMessages;
    private String mainErrorMessage;
    private String exceptionType;
    private String description;
    private String possibleCauses;
    private String stackTrace;
    private List<String> additionalInfos;
    private StringBuilder buf;
    
    static {
        NEW_LINE = System.getProperty("line.separator");
        ExceptionMessageComposer.globalPrintStackTrace = true;
        ExceptionMessageComposer.useExtendedMessages = true;
    }
    
    public ExceptionMessageComposer(final Throwable t) {
        this(t, ExceptionMessageComposer.globalPrintStackTrace);
    }
    
    public ExceptionMessageComposer(final Throwable t, final boolean printStackTrace) {
        this.mainErrorMessage = t.getMessage();
        if (this.mainErrorMessage == null) {
            this.mainErrorMessage = "*** Null ***";
        }
        this.exceptionType = t.getClass().getName();
        this.buf = new StringBuilder();
        if (printStackTrace) {
            this.setStackTrace(t);
        }
        if (t instanceof PyException) {
            final PyException pyErr = (PyException)t;
            this.addInfo("Python type: " + pyErr.type);
            this.addInfo("Python value: " + pyErr.value);
            this.addInfo("Python stack: " + pyErr.traceback.dumpStack());
        }
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public void setPossibleCauses(final String possibleCauses) {
        this.possibleCauses = possibleCauses;
    }
    
    private void setStackTrace(final Throwable t) {
        this.stackTrace = Logging.formatStackTrace(t.getStackTrace());
    }
    
    public void addInfo(final String infoMessage) {
        if (this.additionalInfos == null) {
            this.additionalInfos = new ArrayList<String>();
        }
        this.additionalInfos.add(infoMessage);
    }
    
    @Override
    public String toString() {
        if (!ExceptionMessageComposer.useExtendedMessages) {
            this.buf.append(this.exceptionType).append(": ").append(this.mainErrorMessage);
            return this.buf.toString();
        }
        this.buf.append(this.exceptionType).append(":").append(ExceptionMessageComposer.NEW_LINE);
        this.buf.append("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::").append(ExceptionMessageComposer.NEW_LINE);
        this.buf.append("Exception: ").append(this.exceptionType).append(ExceptionMessageComposer.NEW_LINE);
        this.buf.append("Message: ").append(this.mainErrorMessage).append(ExceptionMessageComposer.NEW_LINE);
        if (this.description != null) {
            this.buf.append("Description: ").append(this.description).append(ExceptionMessageComposer.NEW_LINE);
        }
        if (this.possibleCauses != null) {
            this.buf.append("Possible Causes: ").append(this.possibleCauses).append(ExceptionMessageComposer.NEW_LINE);
        }
        if (this.additionalInfos != null) {
            for (final String info : this.additionalInfos) {
                this.buf.append(info).append(ExceptionMessageComposer.NEW_LINE);
            }
        }
        if (this.stackTrace != null) {
            this.buf.append("+--- --- ---+").append(ExceptionMessageComposer.NEW_LINE);
            this.buf.append("Stack Trace:").append(ExceptionMessageComposer.NEW_LINE);
            this.buf.append("+--- --- ---+").append(ExceptionMessageComposer.NEW_LINE);
            this.buf.append(this.stackTrace);
            this.buf.append("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::").append(ExceptionMessageComposer.NEW_LINE);
        }
        else {
            this.buf.append("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::").append(ExceptionMessageComposer.NEW_LINE);
        }
        return this.buf.toString();
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSFloodingException extends SFSException
{
    public SFSFloodingException() {
    }
    
    public SFSFloodingException(final String message) {
        super(message);
    }
    
    public SFSFloodingException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

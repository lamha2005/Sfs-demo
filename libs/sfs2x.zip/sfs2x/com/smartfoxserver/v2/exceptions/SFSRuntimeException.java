// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSRuntimeException extends RuntimeException
{
    public SFSRuntimeException() {
    }
    
    public SFSRuntimeException(final String message) {
        super(message);
    }
    
    public SFSRuntimeException(final Throwable t) {
        super(t);
    }
}

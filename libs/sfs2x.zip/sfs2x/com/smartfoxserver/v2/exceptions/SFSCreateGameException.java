// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSCreateGameException extends SFSCreateRoomException
{
    private static final long serialVersionUID = -5896198785404576552L;
    
    public SFSCreateGameException() {
    }
    
    public SFSCreateGameException(final String message) {
        super(message);
    }
    
    public SFSCreateGameException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

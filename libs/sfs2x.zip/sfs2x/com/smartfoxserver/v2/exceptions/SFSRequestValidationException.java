// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSRequestValidationException extends Exception
{
    public SFSRequestValidationException() {
    }
    
    public SFSRequestValidationException(final String message) {
        super(message);
    }
    
    public SFSRequestValidationException(final Throwable t) {
        super(t);
    }
}

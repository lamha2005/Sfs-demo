// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSBuddyListException extends SFSException
{
    public SFSBuddyListException() {
    }
    
    public SFSBuddyListException(final String message) {
        super(message);
    }
    
    public SFSBuddyListException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

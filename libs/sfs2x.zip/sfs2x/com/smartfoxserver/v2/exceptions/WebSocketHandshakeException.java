// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class WebSocketHandshakeException extends Exception
{
    public WebSocketHandshakeException() {
    }
    
    public WebSocketHandshakeException(final String message) {
        super(message);
    }
}

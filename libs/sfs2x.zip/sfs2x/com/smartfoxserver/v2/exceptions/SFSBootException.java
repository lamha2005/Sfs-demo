// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSBootException extends SFSRuntimeException
{
    private static final long serialVersionUID = -2794913926097473673L;
    
    public SFSBootException() {
    }
    
    public SFSBootException(final String message) {
        super(message);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSBuddyListNotFoundException extends SFSBuddyListException
{
    public SFSBuddyListNotFoundException() {
    }
    
    public SFSBuddyListNotFoundException(final String message) {
        super(message);
    }
    
    public SFSBuddyListNotFoundException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSLoginInterruptedException extends SFSRuntimeException
{
    private boolean stop;
    
    public SFSLoginInterruptedException() {
        this.stop = false;
    }
    
    public SFSLoginInterruptedException(final boolean stop) {
        this.stop = false;
        this.stop = stop;
    }
    
    public boolean isStop() {
        return this.stop;
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

import java.util.ArrayList;
import java.util.List;

public class SFSErrorData
{
    IErrorCode code;
    List<String> params;
    
    public SFSErrorData(final IErrorCode code) {
        this.code = code;
        this.params = new ArrayList<String>();
    }
    
    public IErrorCode getCode() {
        return this.code;
    }
    
    public void setCode(final IErrorCode code) {
        this.code = code;
    }
    
    public List<String> getParams() {
        return this.params;
    }
    
    public void setParams(final List<String> params) {
        this.params = params;
    }
    
    public void addParameter(final String parameter) {
        this.params.add(parameter);
    }
}

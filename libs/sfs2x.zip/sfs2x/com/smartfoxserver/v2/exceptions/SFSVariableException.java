// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSVariableException extends SFSException
{
    public SFSVariableException() {
    }
    
    public SFSVariableException(final String message) {
        super(message);
    }
    
    public SFSVariableException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

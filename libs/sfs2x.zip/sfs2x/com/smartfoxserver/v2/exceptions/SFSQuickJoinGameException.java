// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSQuickJoinGameException extends SFSJoinRoomException
{
    private static final long serialVersionUID = -4059208183771012804L;
    
    public SFSQuickJoinGameException() {
    }
    
    public SFSQuickJoinGameException(final String message) {
        super(message);
    }
    
    public SFSQuickJoinGameException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

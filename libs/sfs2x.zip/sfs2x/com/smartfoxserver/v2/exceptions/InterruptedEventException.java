// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public final class InterruptedEventException extends SFSRuntimeException
{
    private static final long serialVersionUID = 1729674312557697005L;
    
    public InterruptedEventException() {
        super("Event Interrupted");
    }
}

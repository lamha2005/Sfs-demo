// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSJoinRoomException extends SFSException
{
    private static final long serialVersionUID = 6384101728401558209L;
    
    public SFSJoinRoomException() {
    }
    
    public SFSJoinRoomException(final String message) {
        super(message);
    }
    
    public SFSJoinRoomException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

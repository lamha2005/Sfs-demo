// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSInvitationException extends SFSException
{
    public SFSInvitationException() {
    }
    
    public SFSInvitationException(final String message) {
        super(message);
    }
    
    public SFSInvitationException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

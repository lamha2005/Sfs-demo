// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSCodecException extends SFSException
{
    public SFSCodecException() {
    }
    
    public SFSCodecException(final String message) {
        super(message);
    }
    
    public SFSCodecException(final Throwable t) {
        super(t);
    }
}

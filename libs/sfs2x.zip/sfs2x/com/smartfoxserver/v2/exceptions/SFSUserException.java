// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSUserException extends SFSException
{
    public SFSUserException() {
    }
    
    public SFSUserException(final String message) {
        super(message);
    }
    
    public SFSUserException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

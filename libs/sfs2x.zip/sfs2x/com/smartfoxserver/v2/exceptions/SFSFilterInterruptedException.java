// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSFilterInterruptedException extends SFSRuntimeException
{
    public SFSFilterInterruptedException() {
    }
    
    public SFSFilterInterruptedException(final String errorMsg) {
        super(errorMsg);
    }
}

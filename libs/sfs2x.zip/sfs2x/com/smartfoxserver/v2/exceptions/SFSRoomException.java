// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSRoomException extends SFSException
{
    public SFSRoomException() {
    }
    
    public SFSRoomException(final String message) {
        super(message);
    }
    
    public SFSRoomException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

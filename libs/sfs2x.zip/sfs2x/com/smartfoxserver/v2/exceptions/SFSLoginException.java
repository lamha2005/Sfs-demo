// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSLoginException extends SFSException
{
    public SFSLoginException() {
    }
    
    public SFSLoginException(final String message) {
        super(message);
    }
    
    public SFSLoginException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

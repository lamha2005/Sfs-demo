// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSException extends Exception
{
    private static final long serialVersionUID = 6052949605652105170L;
    SFSErrorData errorData;
    
    public SFSException() {
        this.errorData = null;
    }
    
    public SFSException(final String message) {
        super(message);
        this.errorData = null;
    }
    
    public SFSException(final String message, final SFSErrorData data) {
        super(message);
        this.errorData = data;
    }
    
    public SFSException(final Throwable t) {
        super(t);
        this.errorData = null;
    }
    
    public SFSErrorData getErrorData() {
        return this.errorData;
    }
}

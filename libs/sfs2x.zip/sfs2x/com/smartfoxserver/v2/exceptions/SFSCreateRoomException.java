// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSCreateRoomException extends SFSException
{
    private static final long serialVersionUID = 4751733417642191809L;
    
    public SFSCreateRoomException() {
    }
    
    public SFSCreateRoomException(final String message) {
        super(message);
    }
    
    public SFSCreateRoomException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}

// 
// Decompiled by Procyon v0.5.30
// 

package com.smartfoxserver.v2.exceptions;

public class SFSExtensionException extends SFSException
{
    public SFSExtensionException() {
    }
    
    public SFSExtensionException(final String message) {
        super(message);
    }
    
    public SFSExtensionException(final String message, final SFSErrorData data) {
        super(message, data);
    }
}
